module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/router-context":
/*!**************************************************************!*\
  !*** external "next/dist/next-server/lib/router-context.js" ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/router-context.js");

/***/ }),

/***/ "./actions/devicesActions.js":
/*!***********************************!*\
  !*** ./actions/devicesActions.js ***!
  \***********************************/
/*! exports provided: fetchAvailableDevices, fetchAvailableDevicesSuccess, fetchAvailableDevicesError, transferPlaybackToDevice, transferPlaybackToDeviceSuccess, transferPlaybackToDeviceError */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchAvailableDevices", function() { return fetchAvailableDevices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchAvailableDevicesSuccess", function() { return fetchAvailableDevicesSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchAvailableDevicesError", function() { return fetchAvailableDevicesError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transferPlaybackToDevice", function() { return transferPlaybackToDevice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transferPlaybackToDeviceSuccess", function() { return transferPlaybackToDeviceSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transferPlaybackToDeviceError", function() { return transferPlaybackToDeviceError; });
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");

const fetchAvailableDevices = () => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["FETCH_AVAILABLE_DEVICES"]
});
const fetchAvailableDevicesSuccess = list => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["FETCH_AVAILABLE_DEVICES_SUCCESS"],
  list
});
const fetchAvailableDevicesError = error => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["FETCH_AVAILABLE_DEVICES_ERROR"],
  error
});
const transferPlaybackToDevice = deviceId => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["TRANSFER_PLAYBACK_TO_DEVICE"],
  deviceId
});
const transferPlaybackToDeviceSuccess = list => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["TRANSFER_PLAYBACK_TO_DEVICE_SUCCESS"]
});
const transferPlaybackToDeviceError = list => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["TRANSFER_PLAYBACK_TO_DEVICE_ERROR"],
  error
});

/***/ }),

/***/ "./actions/playbackActions.js":
/*!************************************!*\
  !*** ./actions/playbackActions.js ***!
  \************************************/
/*! exports provided: playTrack, updateNowPlaying, playTrackSuccess, mutePlayback, unmutePlayback, fetchPlayingContextSuccess, fetchPlayingContext */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "playTrack", function() { return playTrack; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateNowPlaying", function() { return updateNowPlaying; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "playTrackSuccess", function() { return playTrackSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mutePlayback", function() { return mutePlayback; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unmutePlayback", function() { return unmutePlayback; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchPlayingContextSuccess", function() { return fetchPlayingContextSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchPlayingContext", function() { return fetchPlayingContext; });
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! isomorphic-unfetch */ "isomorphic-unfetch");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_app__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../config/app */ "./config/app.js");
/* harmony import */ var _config_app__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_config_app__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");


 // playback

const playTrack = (track, user, position) => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["PLAY_TRACK"],
  track,
  user,
  position
});
const updateNowPlaying = (track, user, position) => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["UPDATE_NOW_PLAYING"],
  track,
  user,
  position
});
const playTrackSuccess = (track, user, position) => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["PLAY_TRACK_SUCCESS"],
  track,
  user,
  position
});
const mutePlayback = () => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["MUTE_PLAYBACK"]
});
const unmutePlayback = () => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["UNMUTE_PLAYBACK"]
});
const fetchPlayingContextSuccess = playingContext => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["FETCH_PLAYING_CONTEXT_SUCCESS"],
  playingContext
});
const fetchPlayingContext = () => dispatch => isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default()(`${_config_app__WEBPACK_IMPORTED_MODULE_1___default.a.HOST}/api/now-playing`).then(res => res.json()).then(res => dispatch(fetchPlayingContextSuccess(res)));

/***/ }),

/***/ "./actions/queueActions.js":
/*!*********************************!*\
  !*** ./actions/queueActions.js ***!
  \*********************************/
/*! exports provided: queueTrack, updateQueue, queueEnded, queueRemoveTrack, fetchQueue */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queueTrack", function() { return queueTrack; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateQueue", function() { return updateQueue; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queueEnded", function() { return queueEnded; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "queueRemoveTrack", function() { return queueRemoveTrack; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchQueue", function() { return fetchQueue; });
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! isomorphic-unfetch */ "isomorphic-unfetch");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_app__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../config/app */ "./config/app.js");
/* harmony import */ var _config_app__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_config_app__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");



const queueTrack = id => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["QUEUE_TRACK"],
  id
});
const updateQueue = queue => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["UPDATE_QUEUE"],
  data: queue
});
const queueEnded = () => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["QUEUE_ENDED"]
});
const queueRemoveTrack = id => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["QUEUE_REMOVE_TRACK"],
  id
});
const fetchQueue = () => dispatch => isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default()(`${_config_app__WEBPACK_IMPORTED_MODULE_1___default.a.HOST}/api/queue`).then(res => res.json()).then(res => dispatch(updateQueue(res)));

/***/ }),

/***/ "./actions/searchActions.js":
/*!**********************************!*\
  !*** ./actions/searchActions.js ***!
  \**********************************/
/*! exports provided: searchTracks, searchTracksSuccess, searchTracksReset, fetchTrack, fetchTrackSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchTracks", function() { return searchTracks; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchTracksSuccess", function() { return searchTracksSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "searchTracksReset", function() { return searchTracksReset; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchTrack", function() { return fetchTrack; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchTrackSuccess", function() { return fetchTrackSuccess; });
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");

const searchTracks = query => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["SEARCH_TRACKS"],
  query
});
const searchTracksSuccess = (query, results) => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["SEARCH_TRACKS_SUCCESS"],
  query,
  results
});
const searchTracksReset = () => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["SEARCH_TRACKS_RESET"]
});
const fetchTrack = id => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["FETCH_TRACK"],
  id
});
const fetchTrackSuccess = (id, track) => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["FETCH_TRACK_SUCCESS"],
  id
});

/***/ }),

/***/ "./actions/sessionActions.js":
/*!***********************************!*\
  !*** ./actions/sessionActions.js ***!
  \***********************************/
/*! exports provided: load, login, loginSuccess, loginFailure, updateToken, updateTokenSuccess, updateCurrentUser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "load", function() { return load; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "login", function() { return login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loginSuccess", function() { return loginSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loginFailure", function() { return loginFailure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateToken", function() { return updateToken; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateTokenSuccess", function() { return updateTokenSuccess; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateCurrentUser", function() { return updateCurrentUser; });
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");

const load = () => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["LOAD"]
});
const login = () => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["LOGIN"]
});
const loginSuccess = () => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["LOGIN_SUCCESS"]
});
const loginFailure = refresh_token => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["LOGIN_FAILURE"],
  refresh_token
});
const updateToken = refreshToken => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["UPDATE_TOKEN"],
  refreshToken
});
const updateTokenSuccess = access_token => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["UPDATE_TOKEN_SUCCESS"],
  access_token
});
const updateCurrentUser = user => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["UPDATE_CURRENT_USER"],
  user
});

/***/ }),

/***/ "./actions/usersActions.js":
/*!*********************************!*\
  !*** ./actions/usersActions.js ***!
  \*********************************/
/*! exports provided: updateUsers, fetchUsers */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateUsers", function() { return updateUsers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchUsers", function() { return fetchUsers; });
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! isomorphic-unfetch */ "isomorphic-unfetch");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_app__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../config/app */ "./config/app.js");
/* harmony import */ var _config_app__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_config_app__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");



const updateUsers = users => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_2__["UPDATE_USERS"],
  data: users
});
const fetchUsers = () => dispatch => isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default()(`${_config_app__WEBPACK_IMPORTED_MODULE_1___default.a.HOST}/api/users`).then(res => res.json()).then(res => dispatch(updateUsers(res)));

/***/ }),

/***/ "./actions/voteActions.js":
/*!********************************!*\
  !*** ./actions/voteActions.js ***!
  \********************************/
/*! exports provided: voteUp, voteUpSuccess */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "voteUp", function() { return voteUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "voteUpSuccess", function() { return voteUpSuccess; });
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");

const voteUp = id => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["VOTE_UP"],
  id
});
const voteUpSuccess = () => ({
  type: _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["VOTE_UP_SUCCESS"]
});

/***/ }),

/***/ "./components/AddToQueue.js":
/*!**********************************!*\
  !*** ./components/AddToQueue.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _actions_searchActions__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../actions/searchActions */ "./actions/searchActions.js");
/* harmony import */ var _actions_queueActions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../actions/queueActions */ "./actions/queueActions.js");

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







class ResultsList extends react__WEBPACK_IMPORTED_MODULE_1__["Component"] {
  render() {
    const {
      results,
      focus
    } = this.props;
    return __jsx("ul", {
      className: "jsx-344683958" + " " + "add-to-queue__search-results"
    }, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
      id: "344683958"
    }, ".add-to-queue__search-results.jsx-344683958{border:1px solid #999;list-style:none;margin:0;padding:0;}.add-to-queue__search-results-item.jsx-344683958{padding:5px 0 5px 5px;}.add-to-queue__search-results-item--focused.jsx-344683958{background-color:#fff;}.container.jsx-344683958{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}.album-img.jsx-344683958{width:64;padding-right:1em;}.flex-item.jsx-344683958{-webkit-box-flex:1;-webkit-flex-grow:1;-ms-flex-positive:1;flex-grow:1;}.song-name.jsx-344683958{font-size:1.3em;margin-bottom:0.3em;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxBZGRUb1F1ZXVlLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQVlvQixBQUdtQyxBQU1BLEFBR0EsQUFHVCxBQUdKLEFBSUcsQUFJSSxTQVBFLE9BUUUsTUF2QkosQUFNbEIsQUFHQSxLQU9BLFNBUUEsRUF2QlcsU0FDQyxVQUNaLGNBZ0JBLEdBUEEiLCJmaWxlIjoiQzpcXFVzZXJzXFxHZWJydWlrZXJcXFdlYnN0b3JtUHJvamVjdHNcXFNwb3RpZnlcXGNvbXBvbmVudHNcXEFkZFRvUXVldWUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gJ3JlYWN0LXJlZHV4JztcbmltcG9ydCB7IGluamVjdEludGwgfSBmcm9tICdyZWFjdC1pbnRsJztcblxuaW1wb3J0IHsgc2VhcmNoVHJhY2tzLCBzZWFyY2hUcmFja3NSZXNldCB9IGZyb20gJy4uL2FjdGlvbnMvc2VhcmNoQWN0aW9ucyc7XG5pbXBvcnQgeyBxdWV1ZVRyYWNrIH0gZnJvbSAnLi4vYWN0aW9ucy9xdWV1ZUFjdGlvbnMnO1xuXG5jbGFzcyBSZXN1bHRzTGlzdCBleHRlbmRzIENvbXBvbmVudCB7XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IHJlc3VsdHMsIGZvY3VzIH0gPSB0aGlzLnByb3BzO1xuICAgIHJldHVybiAoXG4gICAgICA8dWwgY2xhc3NOYW1lPVwiYWRkLXRvLXF1ZXVlX19zZWFyY2gtcmVzdWx0c1wiPlxuICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgLmFkZC10by1xdWV1ZV9fc2VhcmNoLXJlc3VsdHMge1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzk5OTtcbiAgICAgICAgICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICAgIH1cbiAgICAgICAgICAuYWRkLXRvLXF1ZXVlX19zZWFyY2gtcmVzdWx0cy1pdGVtIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDVweCAwIDVweCA1cHg7XG4gICAgICAgICAgfVxuICAgICAgICAgIC5hZGQtdG8tcXVldWVfX3NlYXJjaC1yZXN1bHRzLWl0ZW0tLWZvY3VzZWQge1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICAgICAgICB9XG4gICAgICAgICAgLmNvbnRhaW5lciB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgIH1cbiAgICAgICAgICAuYWxidW0taW1nIHtcbiAgICAgICAgICAgIHdpZHRoOiA2NDtcbiAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDFlbTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLmZsZXgtaXRlbSB7XG4gICAgICAgICAgICBmbGV4LWdyb3c6IDE7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLnNvbmctbmFtZSB7XG4gICAgICAgICAgICBmb250LXNpemU6IDEuM2VtO1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMC4zZW07XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICAgIHtyZXN1bHRzLm1hcCgociwgaW5kZXgpID0+IHtcbiAgICAgICAgICBjb25zdCBpc0ZvY3VzZWQgPSBmb2N1cyA9PT0gaW5kZXg7XG4gICAgICAgICAgY29uc3QgY2xhc3NOYW1lID1cbiAgICAgICAgICAgICdhZGQtdG8tcXVldWVfX3NlYXJjaC1yZXN1bHRzLWl0ZW0nICsgKGlzRm9jdXNlZCA/ICcgYWRkLXRvLXF1ZXVlX19zZWFyY2gtcmVzdWx0cy1pdGVtLS1mb2N1c2VkJyA6ICcnKTtcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGxpIGtleT17ci5pZH0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IG9uQ2xpY2s9eygpID0+IHRoaXMucHJvcHMub25TZWxlY3Qoci5pZCl9PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxidW0taW1nXCI+XG4gICAgICAgICAgICAgICAgICA8aW1nIHNyYz17ci5hbGJ1bS5pbWFnZXNbMl0udXJsfSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvbmctbmFtZVwiPntyLm5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PntyLmFydGlzdHNbMF0ubmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICk7XG4gICAgICAgIH0pfVxuICAgICAgPC91bD5cbiAgICApO1xuICB9XG59XG5cbmNsYXNzIEFkZFRvUXVldWUgZXh0ZW5kcyBDb21wb25lbnQge1xuICBzdGF0ZSA9IHtcbiAgICB0ZXh0OiB0aGlzLnByb3BzLnRleHQgfHwgJycsXG4gICAgZm9jdXM6IC0xXG4gIH07XG5cbiAgaGFuZGxlQ2hhbmdlID0gZSA9PiB7XG4gICAgY29uc3QgdGV4dCA9IGUudGFyZ2V0LnZhbHVlO1xuICAgIHRoaXMuc2V0U3RhdGUoeyB0ZXh0OiB0ZXh0IH0pO1xuICAgIGlmICh0ZXh0ICE9PSAnJykge1xuICAgICAgdGhpcy5wcm9wcy5zZWFyY2hUcmFja3ModGV4dCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuc2V0U3RhdGUoeyBmb2N1czogLTEgfSk7XG4gICAgICB0aGlzLnByb3BzLnNlYXJjaFRyYWNrc1Jlc2V0KCk7XG4gICAgfVxuICB9O1xuXG4gIGhhbmRsZVNlbGVjdEVsZW1lbnQgPSBpZCA9PiB7XG4gICAgdGhpcy5zZXRTdGF0ZSh7IHRleHQ6ICcnIH0pO1xuICAgIHRoaXMucHJvcHMucXVldWVUcmFjayhpZCk7XG4gICAgdGhpcy5wcm9wcy5zZWFyY2hUcmFja3NSZXNldCgpO1xuICB9O1xuXG4gIGhhbmRsZUJsdXIgPSBlID0+IHtcbiAgICAvLyB0b2RvOiB0aGlzIGhhcHBlbnMgYmVmb3JlIHRoZSBpdGVtIGZyb20gdGhlIGxpc3QgaXMgc2VsZWN0ZWQsIGhpZGluZyB0aGVcbiAgICAvLyBsaXN0IG9mIHJlc3VsdHMuIFdlIG5lZWQgdG8gZG8gdGhpcyBpbiBhIGRpZmZlcmVudCB3YXkuXG4gICAgLyogICAgdGhpcy5zZXRTdGF0ZSh7IGZvY3VzOiAtMSB9KTtcbiAgICB0aGlzLnByb3BzLnNlYXJjaFRyYWNrc1Jlc2V0KCk7ICovXG4gIH07XG5cbiAgaGFuZGxlRm9jdXMgPSBlID0+IHtcbiAgICBpZiAoZS50YXJnZXQudmFsdWUgIT09ICcnKSB7XG4gICAgICB0aGlzLnByb3BzLnNlYXJjaFRyYWNrcyhlLnRhcmdldC52YWx1ZSk7XG4gICAgfVxuICB9O1xuXG4gIGhhbmRsZUtleURvd24gPSBlID0+IHtcbiAgICBzd2l0Y2ggKGUua2V5Q29kZSkge1xuICAgICAgY2FzZSAzODogLy8gdXBcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGZvY3VzOiB0aGlzLnN0YXRlLmZvY3VzIC0gMSB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDQwOiAvLyBkb3duXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyBmb2N1czogdGhpcy5zdGF0ZS5mb2N1cyArIDEgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAxMzoge1xuICAgICAgICBsZXQgY29ycmVjdCA9IGZhbHNlO1xuICAgICAgICBpZiAodGhpcy5zdGF0ZS5mb2N1cyAhPT0gLTEpIHtcbiAgICAgICAgICB0aGlzLnByb3BzLnF1ZXVlVHJhY2sodGhpcy5wcm9wcy5zZWFyY2gucmVzdWx0c1t0aGlzLnN0YXRlLmZvY3VzXS5pZCk7XG4gICAgICAgICAgY29ycmVjdCA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgdGV4dCA9IGUudGFyZ2V0LnZhbHVlLnRyaW0oKTtcbiAgICAgICAgICBpZiAodGV4dC5sZW5ndGggIT09IDApIHtcbiAgICAgICAgICAgIHRoaXMucHJvcHMucXVldWVUcmFjayh0ZXh0KTtcbiAgICAgICAgICAgIGNvcnJlY3QgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoY29ycmVjdCkge1xuICAgICAgICAgIHRoaXMuc2V0U3RhdGUoeyB0ZXh0OiAnJyB9KTtcbiAgICAgICAgICB0aGlzLnByb3BzLnNlYXJjaFRyYWNrc1Jlc2V0KCk7XG4gICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGZvY3VzOiAtMSB9KTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgcmVuZGVyKCkge1xuICAgIGNvbnN0IHBsYWNlaG9sZGVyID0gdGhpcy5wcm9wcy5pbnRsLmZvcm1hdE1lc3NhZ2UoeyBpZDogJ3F1ZXVlLmFkZCcgfSk7XG4gICAgY29uc3QgcmVzdWx0cyA9IHRoaXMucHJvcHMuc2VhcmNoLnJlc3VsdHM7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWRkLXRvLXF1ZXVlXCIgb25CbHVyPXt0aGlzLmhhbmRsZUJsdXJ9PlxuICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgLmFkZC10by1xdWV1ZV9faW5wdXQge1xuICAgICAgICAgICAgIHdpZHRoOiAzMDBweDtcbiAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgaGVpZ2h0OiAzN3B4O1xuICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDlweDtcbiAgICAgICAgICAgICAgYm9yZGVyOiBub25lO1xuICAgICAgICAgICAgICBmb250LXNpemU6IDExcHg7XG4gICAgICAgICAgICAgIGNvbG9yOiAjQjJCMkIyO1xuICAgICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMTVweDtcbiAgICAgICAgICB9XG4gICAgICAgIGB9PC9zdHlsZT5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWRkLXRvLXF1ZXVlX19pbnB1dFwiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9e3BsYWNlaG9sZGVyfVxuICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLnRleHR9XG4gICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfVxuICAgICAgICAgIG9uS2V5RG93bj17dGhpcy5oYW5kbGVLZXlEb3dufVxuICAgICAgICAgIG9uRm9jdXM9e3RoaXMuaGFuZGxlRm9jdXN9XG4gICAgICAgIC8+XG4gICAgICAgIHtyZXN1bHRzICYmIDxSZXN1bHRzTGlzdCByZXN1bHRzPXtyZXN1bHRzfSBvblNlbGVjdD17dGhpcy5oYW5kbGVTZWxlY3RFbGVtZW50fSBmb2N1cz17dGhpcy5zdGF0ZS5mb2N1c30gLz59XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG59XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IGRpc3BhdGNoID0+ICh7XG4gIHF1ZXVlVHJhY2s6IHRleHQgPT4gZGlzcGF0Y2gocXVldWVUcmFjayh0ZXh0KSksXG4gIHNlYXJjaFRyYWNrczogcXVlcnkgPT4gZGlzcGF0Y2goc2VhcmNoVHJhY2tzKHF1ZXJ5KSksXG4gIHNlYXJjaFRyYWNrc1Jlc2V0OiAoKSA9PiBkaXNwYXRjaChzZWFyY2hUcmFja3NSZXNldCgpKVxufSk7XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IHN0YXRlID0+ICh7XG4gIHNlYXJjaDogc3RhdGUuc2VhcmNoXG59KTtcblxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykoaW5qZWN0SW50bChBZGRUb1F1ZXVlKSk7XG4iXX0= */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\components\\\\AddToQueue.js */"), results.map((r, index) => {
      const isFocused = focus === index;
      const className = 'add-to-queue__search-results-item' + (isFocused ? ' add-to-queue__search-results-item--focused' : '');
      return __jsx("li", {
        key: r.id,
        onClick: () => this.props.onSelect(r.id),
        className: "jsx-344683958" + " " + (className || "")
      }, __jsx("div", {
        className: "jsx-344683958" + " " + "container"
      }, __jsx("div", {
        className: "jsx-344683958" + " " + "album-img"
      }, __jsx("img", {
        src: r.album.images[2].url,
        className: "jsx-344683958"
      })), __jsx("div", {
        className: "jsx-344683958" + " " + "flex-item"
      }, __jsx("div", {
        className: "jsx-344683958" + " " + "song-name"
      }, r.name), __jsx("div", {
        className: "jsx-344683958"
      }, r.artists[0].name))));
    }));
  }

}

class AddToQueue extends react__WEBPACK_IMPORTED_MODULE_1__["Component"] {
  constructor(...args) {
    super(...args);

    _defineProperty(this, "state", {
      text: this.props.text || '',
      focus: -1
    });

    _defineProperty(this, "handleChange", e => {
      const text = e.target.value;
      this.setState({
        text: text
      });

      if (text !== '') {
        this.props.searchTracks(text);
      } else {
        this.setState({
          focus: -1
        });
        this.props.searchTracksReset();
      }
    });

    _defineProperty(this, "handleSelectElement", id => {
      this.setState({
        text: ''
      });
      this.props.queueTrack(id);
      this.props.searchTracksReset();
    });

    _defineProperty(this, "handleBlur", e => {// todo: this happens before the item from the list is selected, hiding the
      // list of results. We need to do this in a different way.

      /*    this.setState({ focus: -1 });
      this.props.searchTracksReset(); */
    });

    _defineProperty(this, "handleFocus", e => {
      if (e.target.value !== '') {
        this.props.searchTracks(e.target.value);
      }
    });

    _defineProperty(this, "handleKeyDown", e => {
      switch (e.keyCode) {
        case 38:
          // up
          this.setState({
            focus: this.state.focus - 1
          });
          break;

        case 40:
          // down
          this.setState({
            focus: this.state.focus + 1
          });
          break;

        case 13:
          {
            let correct = false;

            if (this.state.focus !== -1) {
              this.props.queueTrack(this.props.search.results[this.state.focus].id);
              correct = true;
            } else {
              const text = e.target.value.trim();

              if (text.length !== 0) {
                this.props.queueTrack(text);
                correct = true;
              }
            }

            if (correct) {
              this.setState({
                text: ''
              });
              this.props.searchTracksReset();
              this.setState({
                focus: -1
              });
            }

            break;
          }
      }
    });
  }

  render() {
    const placeholder = this.props.intl.formatMessage({
      id: 'queue.add'
    });
    const results = this.props.search.results;
    return __jsx("div", {
      onBlur: this.handleBlur,
      className: "jsx-4262985479" + " " + "add-to-queue"
    }, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
      id: "4262985479"
    }, ".add-to-queue__input.jsx-4262985479{width:300px;width:100%;height:37px;padding-left:10px;border-radius:9px;border:none;font-size:11px;color:#B2B2B2;font-weight:bold;text-transform:uppercase;margin-top:15px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxBZGRUb1F1ZXVlLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXVJb0IsQUFHMEIsWUFDRCxXQUNFLFlBQ00sa0JBQ0Esa0JBQ04sWUFDRyxlQUNELGNBQ0csaUJBQ1EseUJBQ1QsZ0JBQ3BCIiwiZmlsZSI6IkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxBZGRUb1F1ZXVlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tICdyZWFjdC1yZWR1eCc7XG5pbXBvcnQgeyBpbmplY3RJbnRsIH0gZnJvbSAncmVhY3QtaW50bCc7XG5cbmltcG9ydCB7IHNlYXJjaFRyYWNrcywgc2VhcmNoVHJhY2tzUmVzZXQgfSBmcm9tICcuLi9hY3Rpb25zL3NlYXJjaEFjdGlvbnMnO1xuaW1wb3J0IHsgcXVldWVUcmFjayB9IGZyb20gJy4uL2FjdGlvbnMvcXVldWVBY3Rpb25zJztcblxuY2xhc3MgUmVzdWx0c0xpc3QgZXh0ZW5kcyBDb21wb25lbnQge1xuICByZW5kZXIoKSB7XG4gICAgY29uc3QgeyByZXN1bHRzLCBmb2N1cyB9ID0gdGhpcy5wcm9wcztcbiAgICByZXR1cm4gKFxuICAgICAgPHVsIGNsYXNzTmFtZT1cImFkZC10by1xdWV1ZV9fc2VhcmNoLXJlc3VsdHNcIj5cbiAgICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAgIC5hZGQtdG8tcXVldWVfX3NlYXJjaC1yZXN1bHRzIHtcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICM5OTk7XG4gICAgICAgICAgICBsaXN0LXN0eWxlOiBub25lO1xuICAgICAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICB9XG4gICAgICAgICAgLmFkZC10by1xdWV1ZV9fc2VhcmNoLXJlc3VsdHMtaXRlbSB7XG4gICAgICAgICAgICBwYWRkaW5nOiA1cHggMCA1cHggNXB4O1xuICAgICAgICAgIH1cbiAgICAgICAgICAuYWRkLXRvLXF1ZXVlX19zZWFyY2gtcmVzdWx0cy1pdGVtLS1mb2N1c2VkIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgICAgICAgfVxuICAgICAgICAgIC5jb250YWluZXIge1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICB9XG4gICAgICAgICAgLmFsYnVtLWltZyB7XG4gICAgICAgICAgICB3aWR0aDogNjQ7XG4gICAgICAgICAgICBwYWRkaW5nLXJpZ2h0OiAxZW07XG4gICAgICAgICAgfVxuICAgICAgICAgIC5mbGV4LWl0ZW0ge1xuICAgICAgICAgICAgZmxleC1ncm93OiAxO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC5zb25nLW5hbWUge1xuICAgICAgICAgICAgZm9udC1zaXplOiAxLjNlbTtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDAuM2VtO1xuICAgICAgICAgIH1cbiAgICAgICAgYH08L3N0eWxlPlxuICAgICAgICB7cmVzdWx0cy5tYXAoKHIsIGluZGV4KSA9PiB7XG4gICAgICAgICAgY29uc3QgaXNGb2N1c2VkID0gZm9jdXMgPT09IGluZGV4O1xuICAgICAgICAgIGNvbnN0IGNsYXNzTmFtZSA9XG4gICAgICAgICAgICAnYWRkLXRvLXF1ZXVlX19zZWFyY2gtcmVzdWx0cy1pdGVtJyArIChpc0ZvY3VzZWQgPyAnIGFkZC10by1xdWV1ZV9fc2VhcmNoLXJlc3VsdHMtaXRlbS0tZm9jdXNlZCcgOiAnJyk7XG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxsaSBrZXk9e3IuaWR9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSBvbkNsaWNrPXsoKSA9PiB0aGlzLnByb3BzLm9uU2VsZWN0KHIuaWQpfT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFsYnVtLWltZ1wiPlxuICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e3IuYWxidW0uaW1hZ2VzWzJdLnVybH0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtaXRlbVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzb25nLW5hbWVcIj57ci5uYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj57ci5hcnRpc3RzWzBdLm5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICApO1xuICAgICAgICB9KX1cbiAgICAgIDwvdWw+XG4gICAgKTtcbiAgfVxufVxuXG5jbGFzcyBBZGRUb1F1ZXVlIGV4dGVuZHMgQ29tcG9uZW50IHtcbiAgc3RhdGUgPSB7XG4gICAgdGV4dDogdGhpcy5wcm9wcy50ZXh0IHx8ICcnLFxuICAgIGZvY3VzOiAtMVxuICB9O1xuXG4gIGhhbmRsZUNoYW5nZSA9IGUgPT4ge1xuICAgIGNvbnN0IHRleHQgPSBlLnRhcmdldC52YWx1ZTtcbiAgICB0aGlzLnNldFN0YXRlKHsgdGV4dDogdGV4dCB9KTtcbiAgICBpZiAodGV4dCAhPT0gJycpIHtcbiAgICAgIHRoaXMucHJvcHMuc2VhcmNoVHJhY2tzKHRleHQpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNldFN0YXRlKHsgZm9jdXM6IC0xIH0pO1xuICAgICAgdGhpcy5wcm9wcy5zZWFyY2hUcmFja3NSZXNldCgpO1xuICAgIH1cbiAgfTtcblxuICBoYW5kbGVTZWxlY3RFbGVtZW50ID0gaWQgPT4ge1xuICAgIHRoaXMuc2V0U3RhdGUoeyB0ZXh0OiAnJyB9KTtcbiAgICB0aGlzLnByb3BzLnF1ZXVlVHJhY2soaWQpO1xuICAgIHRoaXMucHJvcHMuc2VhcmNoVHJhY2tzUmVzZXQoKTtcbiAgfTtcblxuICBoYW5kbGVCbHVyID0gZSA9PiB7XG4gICAgLy8gdG9kbzogdGhpcyBoYXBwZW5zIGJlZm9yZSB0aGUgaXRlbSBmcm9tIHRoZSBsaXN0IGlzIHNlbGVjdGVkLCBoaWRpbmcgdGhlXG4gICAgLy8gbGlzdCBvZiByZXN1bHRzLiBXZSBuZWVkIHRvIGRvIHRoaXMgaW4gYSBkaWZmZXJlbnQgd2F5LlxuICAgIC8qICAgIHRoaXMuc2V0U3RhdGUoeyBmb2N1czogLTEgfSk7XG4gICAgdGhpcy5wcm9wcy5zZWFyY2hUcmFja3NSZXNldCgpOyAqL1xuICB9O1xuXG4gIGhhbmRsZUZvY3VzID0gZSA9PiB7XG4gICAgaWYgKGUudGFyZ2V0LnZhbHVlICE9PSAnJykge1xuICAgICAgdGhpcy5wcm9wcy5zZWFyY2hUcmFja3MoZS50YXJnZXQudmFsdWUpO1xuICAgIH1cbiAgfTtcblxuICBoYW5kbGVLZXlEb3duID0gZSA9PiB7XG4gICAgc3dpdGNoIChlLmtleUNvZGUpIHtcbiAgICAgIGNhc2UgMzg6IC8vIHVwXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyBmb2N1czogdGhpcy5zdGF0ZS5mb2N1cyAtIDEgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSA0MDogLy8gZG93blxuICAgICAgICB0aGlzLnNldFN0YXRlKHsgZm9jdXM6IHRoaXMuc3RhdGUuZm9jdXMgKyAxIH0pO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgMTM6IHtcbiAgICAgICAgbGV0IGNvcnJlY3QgPSBmYWxzZTtcbiAgICAgICAgaWYgKHRoaXMuc3RhdGUuZm9jdXMgIT09IC0xKSB7XG4gICAgICAgICAgdGhpcy5wcm9wcy5xdWV1ZVRyYWNrKHRoaXMucHJvcHMuc2VhcmNoLnJlc3VsdHNbdGhpcy5zdGF0ZS5mb2N1c10uaWQpO1xuICAgICAgICAgIGNvcnJlY3QgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IHRleHQgPSBlLnRhcmdldC52YWx1ZS50cmltKCk7XG4gICAgICAgICAgaWYgKHRleHQubGVuZ3RoICE9PSAwKSB7XG4gICAgICAgICAgICB0aGlzLnByb3BzLnF1ZXVlVHJhY2sodGV4dCk7XG4gICAgICAgICAgICBjb3JyZWN0ID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvcnJlY3QpIHtcbiAgICAgICAgICB0aGlzLnNldFN0YXRlKHsgdGV4dDogJycgfSk7XG4gICAgICAgICAgdGhpcy5wcm9wcy5zZWFyY2hUcmFja3NSZXNldCgpO1xuICAgICAgICAgIHRoaXMuc2V0U3RhdGUoeyBmb2N1czogLTEgfSk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCBwbGFjZWhvbGRlciA9IHRoaXMucHJvcHMuaW50bC5mb3JtYXRNZXNzYWdlKHsgaWQ6ICdxdWV1ZS5hZGQnIH0pO1xuICAgIGNvbnN0IHJlc3VsdHMgPSB0aGlzLnByb3BzLnNlYXJjaC5yZXN1bHRzO1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFkZC10by1xdWV1ZVwiIG9uQmx1cj17dGhpcy5oYW5kbGVCbHVyfT5cbiAgICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAgIC5hZGQtdG8tcXVldWVfX2lucHV0IHtcbiAgICAgICAgICAgICB3aWR0aDogMzAwcHg7XG4gICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICAgIGhlaWdodDogMzdweDtcbiAgICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiA5cHg7XG4gICAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xuICAgICAgICAgICAgICBjb2xvcjogI0IyQjJCMjtcbiAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICAgICAgICAgIG1hcmdpbi10b3A6IDE1cHg7XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIGNsYXNzTmFtZT1cImFkZC10by1xdWV1ZV9faW5wdXRcIlxuICAgICAgICAgIHBsYWNlaG9sZGVyPXtwbGFjZWhvbGRlcn1cbiAgICAgICAgICB2YWx1ZT17dGhpcy5zdGF0ZS50ZXh0fVxuICAgICAgICAgIG9uQ2hhbmdlPXt0aGlzLmhhbmRsZUNoYW5nZX1cbiAgICAgICAgICBvbktleURvd249e3RoaXMuaGFuZGxlS2V5RG93bn1cbiAgICAgICAgICBvbkZvY3VzPXt0aGlzLmhhbmRsZUZvY3VzfVxuICAgICAgICAvPlxuICAgICAgICB7cmVzdWx0cyAmJiA8UmVzdWx0c0xpc3QgcmVzdWx0cz17cmVzdWx0c30gb25TZWxlY3Q9e3RoaXMuaGFuZGxlU2VsZWN0RWxlbWVudH0gZm9jdXM9e3RoaXMuc3RhdGUuZm9jdXN9IC8+fVxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxufVxuXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSBkaXNwYXRjaCA9PiAoe1xuICBxdWV1ZVRyYWNrOiB0ZXh0ID0+IGRpc3BhdGNoKHF1ZXVlVHJhY2sodGV4dCkpLFxuICBzZWFyY2hUcmFja3M6IHF1ZXJ5ID0+IGRpc3BhdGNoKHNlYXJjaFRyYWNrcyhxdWVyeSkpLFxuICBzZWFyY2hUcmFja3NSZXNldDogKCkgPT4gZGlzcGF0Y2goc2VhcmNoVHJhY2tzUmVzZXQoKSlcbn0pO1xuXG5jb25zdCBtYXBTdGF0ZVRvUHJvcHMgPSBzdGF0ZSA9PiAoe1xuICBzZWFyY2g6IHN0YXRlLnNlYXJjaFxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKGluamVjdEludGwoQWRkVG9RdWV1ZSkpO1xuIl19 */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\components\\\\AddToQueue.js */"), __jsx("input", {
      placeholder: placeholder,
      value: this.state.text,
      onChange: this.handleChange,
      onKeyDown: this.handleKeyDown,
      onFocus: this.handleFocus,
      className: "jsx-4262985479" + " " + "add-to-queue__input"
    }), results && __jsx(ResultsList, {
      results: results,
      onSelect: this.handleSelectElement,
      focus: this.state.focus
    }));
  }

}

const mapDispatchToProps = dispatch => ({
  queueTrack: text => dispatch(Object(_actions_queueActions__WEBPACK_IMPORTED_MODULE_5__["queueTrack"])(text)),
  searchTracks: query => dispatch(Object(_actions_searchActions__WEBPACK_IMPORTED_MODULE_4__["searchTracks"])(query)),
  searchTracksReset: () => dispatch(Object(_actions_searchActions__WEBPACK_IMPORTED_MODULE_4__["searchTracksReset"])())
});

const mapStateToProps = state => ({
  search: state.search
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps, mapDispatchToProps)(Object(react_intl__WEBPACK_IMPORTED_MODULE_3__["injectIntl"])(AddToQueue)));

/***/ }),

/***/ "./components/ButtonDarkStyle.js":
/*!***************************************!*\
  !*** ./components/ButtonDarkStyle.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const _defaultExport = new String(".btn--dark.jsx-3295863756{background-color:#fff;border:0px solid #bbc8d5;color:#0D0C0C;font-weight:bold;text-transform:uppercase;font-family:'Sofia Pro';font-size:14px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxCdXR0b25EYXJrU3R5bGUuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRWtCLEFBRXlCLHNCQUNHLHlCQUNYLGNBQ0csaUJBQ1EseUJBQ0Qsd0JBQ1QsZUFDakIiLCJmaWxlIjoiQzpcXFVzZXJzXFxHZWJydWlrZXJcXFdlYnN0b3JtUHJvamVjdHNcXFNwb3RpZnlcXGNvbXBvbmVudHNcXEJ1dHRvbkRhcmtTdHlsZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBjc3MgZnJvbSAnc3R5bGVkLWpzeC9jc3MnO1xuXG5leHBvcnQgZGVmYXVsdCBjc3NgLmJ0bi0tZGFyayB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gIGJvcmRlcjogMHB4IHNvbGlkICNiYmM4ZDU7XG4gIGNvbG9yOiAjMEQwQzBDO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgZm9udC1mYW1pbHk6ICdTb2ZpYSBQcm8nO1xuICBmb250LXNpemU6IDE0cHg7XG59YDtcbiJdfQ== */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\components\\\\ButtonDarkStyle.js */");

_defaultExport.__hash = "3295863756";
/* harmony default export */ __webpack_exports__["default"] = (_defaultExport);

/***/ }),

/***/ "./components/ButtonStyle.js":
/*!***********************************!*\
  !*** ./components/ButtonStyle.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const _defaultExport = new String(".btn.jsx-194504614{background-color:transparent;border:1px solid #666;border-radius:50px;color:#666;cursor:pointer;line-height:28px;padding:0 15px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxCdXR0b25TdHlsZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFa0IsQUFFZ0MsNkJBQ1Asc0JBQ0gsbUJBQ1IsV0FDSSxlQUNFLGlCQUNGLGVBQ2pCIiwiZmlsZSI6IkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxCdXR0b25TdHlsZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBjc3MgZnJvbSAnc3R5bGVkLWpzeC9jc3MnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY3NzYC5idG4ge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICM2NjY7XHJcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICBjb2xvcjogIzY2NjtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgbGluZS1oZWlnaHQ6IDI4cHg7XHJcbiAgcGFkZGluZzogMCAxNXB4O1xyXG59YDtcclxuIl19 */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\components\\\\ButtonStyle.js */");

_defaultExport.__hash = "194504614";
/* harmony default export */ __webpack_exports__["default"] = (_defaultExport);

/***/ }),

/***/ "./components/Devices.js":
/*!*******************************!*\
  !*** ./components/Devices.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ButtonStyle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ButtonStyle */ "./components/ButtonStyle.js");
/* harmony import */ var _ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ButtonDarkStyle */ "./components/ButtonDarkStyle.js");
/* harmony import */ var _actions_devicesActions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../actions/devicesActions */ "./actions/devicesActions.js");
/* harmony import */ var _reducers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../reducers */ "./reducers/index.js");

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;









class Devices extends react__WEBPACK_IMPORTED_MODULE_1___default.a.PureComponent {
  render() {
    const {
      devices,
      isFetching,
      fetchAvailableDevices,
      transferPlaybackToDevice
    } = this.props;
    return __jsx("div", {
      style: {
        paddingBottom: '10px'
      },
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, __jsx("h2", {
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, __jsx(react_intl__WEBPACK_IMPORTED_MODULE_3__["FormattedMessage"], {
      id: "devices.title"
    })), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
      id: _ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash
    }, _ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"]), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
      id: _ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash
    }, _ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"]), __jsx("button", {
      disabled: isFetching,
      onClick: () => {
        fetchAvailableDevices();
      },
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}` + " " + "btn btn--dark"
    }, __jsx(react_intl__WEBPACK_IMPORTED_MODULE_3__["FormattedMessage"], {
      id: "devices.fetch"
    })), devices.length === 0 ? __jsx("p", {
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, __jsx(react_intl__WEBPACK_IMPORTED_MODULE_3__["FormattedMessage"], {
      id: "devices.empty"
    })) : __jsx("table", {
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, __jsx("tbody", {
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, devices.map(device => __jsx("tr", {
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, __jsx("td", {
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, device.is_active ? __jsx("strong", {
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, "Active ->") : __jsx("button", {
      onClick: () => {
        transferPlaybackToDevice(device.id);
      },
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, __jsx(react_intl__WEBPACK_IMPORTED_MODULE_3__["FormattedMessage"], {
      id: "devices.transfer"
    }))), __jsx("td", {
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, device.name), __jsx("td", {
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, device.type), __jsx("td", {
      className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_4__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_5__["default"].__hash}`
    }, device.volume))))));
  }

}

const mapDispatchToProps = dispatch => ({
  fetchAvailableDevices: index => dispatch(Object(_actions_devicesActions__WEBPACK_IMPORTED_MODULE_6__["fetchAvailableDevices"])(index)),
  transferPlaybackToDevice: deviceId => dispatch(Object(_actions_devicesActions__WEBPACK_IMPORTED_MODULE_6__["transferPlaybackToDevice"])(deviceId))
});

const mapStateToProps = state => ({
  isFetching: Object(_reducers__WEBPACK_IMPORTED_MODULE_7__["getIsFetchingDevices"])(state),
  devices: Object(_reducers__WEBPACK_IMPORTED_MODULE_7__["getDevices"])(state)
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps, mapDispatchToProps)(Devices));

/***/ }),

/***/ "./components/Header.js":
/*!******************************!*\
  !*** ./components/Header.js ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _actions_sessionActions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../actions/sessionActions */ "./actions/sessionActions.js");
/* harmony import */ var _actions_playbackActions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../actions/playbackActions */ "./actions/playbackActions.js");
/* harmony import */ var _ButtonStyle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ButtonStyle */ "./components/ButtonStyle.js");
/* harmony import */ var _ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ButtonDarkStyle */ "./components/ButtonDarkStyle.js");


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;







const linkStyle = {
  lineHeight: '30px',
  marginRight: 15
};
const mainLinkStyle = {
  float: 'left',
  marginRight: '10px'
};
const headerStyle = {
  backgroundColor: '#0D0C0C',
  padding: '30px 40px',
  height: '30px',
  color: '#333'
};

const getNameFromUser = user => {
  return user.display_name || user.id;
};

const Header = ({
  session,
  muted,
  mutePlayback,
  unmutePlayback,
  login
}) => __jsx("div", {
  style: headerStyle
}, session.user ? __jsx("div", {
  className: "jsx-61743697" + " " + "media user-header"
}, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "61743697"
}, ".user-header.jsx-61743697{float:right;width:150px;}.user-image.jsx-61743697{border-radius:50%;}.user-name.jsx-61743697{line-height:30px;color:#fff;}.media.jsx-61743697,.media__bd.jsx-61743697{overflow:hidden;_overflow:visible;zoom:1;}.media.jsx-61743697 .media__img.jsx-61743697{float:left;margin-right:10px;}.btn-scafe.jsx-61743697{background-color:#0D0C0C;color:#fff;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxIZWFkZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBaUNvQixBQUd5QixBQUlNLEFBR0QsQUFLRCxBQUtMLEFBSWEsV0FITixDQWpCTixJQVlNLENBTFAsQ0FIYixNQUhBLENBb0JZLEdBYlosQ0FVQSxLQUxTLEVBU1QsS0FSQSIsImZpbGUiOiJDOlxcVXNlcnNcXEdlYnJ1aWtlclxcV2Vic3Rvcm1Qcm9qZWN0c1xcU3BvdGlmeVxcY29tcG9uZW50c1xcSGVhZGVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tICdyZWFjdC1yZWR1eCc7XG5pbXBvcnQgeyBGb3JtYXR0ZWRNZXNzYWdlIH0gZnJvbSAncmVhY3QtaW50bCc7XG5pbXBvcnQgeyBsb2dpbiB9IGZyb20gJy4uL2FjdGlvbnMvc2Vzc2lvbkFjdGlvbnMnO1xuaW1wb3J0IHsgbXV0ZVBsYXliYWNrLCB1bm11dGVQbGF5YmFjayB9IGZyb20gJy4uL2FjdGlvbnMvcGxheWJhY2tBY3Rpb25zJztcbmltcG9ydCBCdXR0b25TdHlsZSBmcm9tICcuL0J1dHRvblN0eWxlJztcbmltcG9ydCBCdXR0b25EYXJrU3R5bGUgZnJvbSAnLi9CdXR0b25EYXJrU3R5bGUnO1xuXG5jb25zdCBsaW5rU3R5bGUgPSB7XG4gIGxpbmVIZWlnaHQ6ICczMHB4JyxcbiAgbWFyZ2luUmlnaHQ6IDE1XG59O1xuXG5jb25zdCBtYWluTGlua1N0eWxlID0ge1xuICBmbG9hdDogJ2xlZnQnLFxuICBtYXJnaW5SaWdodDogJzEwcHgnXG59O1xuXG5jb25zdCBoZWFkZXJTdHlsZSA9IHtcbiAgYmFja2dyb3VuZENvbG9yOiAnIzBEMEMwQycsXG4gIHBhZGRpbmc6ICczMHB4IDQwcHgnLFxuICBoZWlnaHQ6ICczMHB4JyxcbiAgY29sb3I6ICcjMzMzJ1xufTtcblxuY29uc3QgZ2V0TmFtZUZyb21Vc2VyID0gdXNlciA9PiB7XG4gIHJldHVybiB1c2VyLmRpc3BsYXlfbmFtZSB8fCB1c2VyLmlkO1xufTtcblxuY29uc3QgSGVhZGVyID0gKHsgc2Vzc2lvbiwgbXV0ZWQsIG11dGVQbGF5YmFjaywgdW5tdXRlUGxheWJhY2ssIGxvZ2luIH0pID0+IChcbiAgPGRpdiBzdHlsZT17aGVhZGVyU3R5bGV9PlxuICAgIHtzZXNzaW9uLnVzZXIgPyAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhIHVzZXItaGVhZGVyXCI+XG4gICAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgICAudXNlci1oZWFkZXIge1xuICAgICAgICAgICAgZmxvYXQ6IHJpZ2h0O1xuICAgICAgICAgICAgd2lkdGg6IDE1MHB4O1xuICAgICAgICAgIH1cbiAgICAgICAgICAudXNlci1pbWFnZSB7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgfVxuICAgICAgICAgIC51c2VyLW5hbWUge1xuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDMwcHg7XG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICB9XG4gICAgICAgICAgLm1lZGlhLFxuICAgICAgICAgIC5tZWRpYV9fYmQge1xuICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgICAgIF9vdmVyZmxvdzogdmlzaWJsZTtcbiAgICAgICAgICAgIHpvb206IDE7XG4gICAgICAgICAgfVxuICAgICAgICAgIC5tZWRpYSAubWVkaWFfX2ltZyB7XG4gICAgICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICB9XG4gICAgICAgICAgLmJ0bi1zY2FmZSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiMwRDBDMEM7XG4gICAgICAgICAgICBjb2xvcjojZmZmO1xuICAgICAgICAgIH1cbiAgICAgICAgYH08L3N0eWxlPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhX19pbWdcIj5cbiAgICAgICAgICA8aW1nXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1c2VyLWltYWdlXCJcbiAgICAgICAgICAgIHNyYz17XG4gICAgICAgICAgICAgIChzZXNzaW9uLnVzZXIuaW1hZ2VzICYmIHNlc3Npb24udXNlci5pbWFnZXMubGVuZ3RoICYmIHNlc3Npb24udXNlci5pbWFnZXNbMF0udXJsKSB8fFxuICAgICAgICAgICAgICAnL3N0YXRpYy91c2VyLWljb24ucG5nJ1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgd2lkdGg9XCIzMFwiXG4gICAgICAgICAgICBoZWlnaHQ9XCIzMFwiXG4gICAgICAgICAgICBhbHQ9e2dldE5hbWVGcm9tVXNlcihzZXNzaW9uLnVzZXIpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVzZXItbmFtZSBtZWRpYV9fYmRcIj57Z2V0TmFtZUZyb21Vc2VyKHNlc3Npb24udXNlcil9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApIDogKFxuICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLS1kYXJrIGJ0bi1zY2FmZVwiIHN0eWxlPXt7IGZsb2F0OiAncmlnaHQnIH19IG9uQ2xpY2s9e2xvZ2lufT5cbiAgICAgICAgPHN0eWxlIGpzeD57QnV0dG9uU3R5bGV9PC9zdHlsZT5cbiAgICAgICAgPHN0eWxlIGpzeD57QnV0dG9uRGFya1N0eWxlfTwvc3R5bGU+XG4gICAgICAgIDxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwibG9naW5cIiAvPlxuICAgICAgPC9idXR0b24+XG4gICAgKX1cbiAgICB7c2Vzc2lvbi51c2VyID8gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGF5YmFjay1jb250cm9sXCI+XG4gICAgICAgIDxzdHlsZSBqc3g+e0J1dHRvblN0eWxlfTwvc3R5bGU+XG4gICAgICAgIDxzdHlsZSBqc3g+e0J1dHRvbkRhcmtTdHlsZX08L3N0eWxlPlxuICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgLnBsYXliYWNrLWNvbnRyb2wge1xuICAgICAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLS1kYXJrIGJ0bi1zY2FmZVwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgbXV0ZWQgPyB1bm11dGVQbGF5YmFjaygpIDogbXV0ZVBsYXliYWNrKCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIHttdXRlZCA/ICdVbm11dGUnIDogJ011dGUnfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICkgOiBudWxsfVxuICA8L2Rpdj5cbik7XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IGRpc3BhdGNoID0+ICh7XG4gIGxvZ2luOiAoKSA9PiBkaXNwYXRjaChsb2dpbigpKSxcbiAgbXV0ZVBsYXliYWNrOiAoKSA9PiBkaXNwYXRjaChtdXRlUGxheWJhY2soKSksXG4gIHVubXV0ZVBsYXliYWNrOiAoKSA9PiBkaXNwYXRjaCh1bm11dGVQbGF5YmFjaygpKVxufSk7XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IHN0YXRlID0+ICh7XG4gIHNlc3Npb246IHN0YXRlLnNlc3Npb24sXG4gIG11dGVkOiBzdGF0ZS5wbGF5YmFjay5tdXRlZFxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKEhlYWRlcik7XG4iXX0= */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\components\\\\Header.js */"), __jsx("div", {
  className: "jsx-61743697" + " " + "media__img"
}, __jsx("img", {
  src: session.user.images && session.user.images.length && session.user.images[0].url || '/static/user-icon.png',
  width: "30",
  height: "30",
  alt: getNameFromUser(session.user),
  className: "jsx-61743697" + " " + "user-image"
})), __jsx("div", {
  className: "jsx-61743697" + " " + "user-name media__bd"
}, getNameFromUser(session.user))) : __jsx("button", {
  style: {
    float: 'right'
  },
  onClick: login,
  className: `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_7__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_8__["default"].__hash}` + " " + "btn btn--dark btn-scafe"
}, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: _ButtonStyle__WEBPACK_IMPORTED_MODULE_7__["default"].__hash
}, _ButtonStyle__WEBPACK_IMPORTED_MODULE_7__["default"]), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: _ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_8__["default"].__hash
}, _ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_8__["default"]), __jsx(react_intl__WEBPACK_IMPORTED_MODULE_4__["FormattedMessage"], {
  id: "login"
})), session.user ? __jsx("div", {
  className: "jsx-2562770224 " + `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_7__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_8__["default"].__hash}` + " " + "playback-control"
}, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: _ButtonStyle__WEBPACK_IMPORTED_MODULE_7__["default"].__hash
}, _ButtonStyle__WEBPACK_IMPORTED_MODULE_7__["default"]), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: _ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_8__["default"].__hash
}, _ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_8__["default"]), __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "2562770224"
}, ".playback-control.jsx-2562770224{float:left;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxIZWFkZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBcUZvQixBQUd3QixXQUNiIiwiZmlsZSI6IkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxIZWFkZXIuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gJ3JlYWN0LXJlZHV4JztcbmltcG9ydCB7IEZvcm1hdHRlZE1lc3NhZ2UgfSBmcm9tICdyZWFjdC1pbnRsJztcbmltcG9ydCB7IGxvZ2luIH0gZnJvbSAnLi4vYWN0aW9ucy9zZXNzaW9uQWN0aW9ucyc7XG5pbXBvcnQgeyBtdXRlUGxheWJhY2ssIHVubXV0ZVBsYXliYWNrIH0gZnJvbSAnLi4vYWN0aW9ucy9wbGF5YmFja0FjdGlvbnMnO1xuaW1wb3J0IEJ1dHRvblN0eWxlIGZyb20gJy4vQnV0dG9uU3R5bGUnO1xuaW1wb3J0IEJ1dHRvbkRhcmtTdHlsZSBmcm9tICcuL0J1dHRvbkRhcmtTdHlsZSc7XG5cbmNvbnN0IGxpbmtTdHlsZSA9IHtcbiAgbGluZUhlaWdodDogJzMwcHgnLFxuICBtYXJnaW5SaWdodDogMTVcbn07XG5cbmNvbnN0IG1haW5MaW5rU3R5bGUgPSB7XG4gIGZsb2F0OiAnbGVmdCcsXG4gIG1hcmdpblJpZ2h0OiAnMTBweCdcbn07XG5cbmNvbnN0IGhlYWRlclN0eWxlID0ge1xuICBiYWNrZ3JvdW5kQ29sb3I6ICcjMEQwQzBDJyxcbiAgcGFkZGluZzogJzMwcHggNDBweCcsXG4gIGhlaWdodDogJzMwcHgnLFxuICBjb2xvcjogJyMzMzMnXG59O1xuXG5jb25zdCBnZXROYW1lRnJvbVVzZXIgPSB1c2VyID0+IHtcbiAgcmV0dXJuIHVzZXIuZGlzcGxheV9uYW1lIHx8IHVzZXIuaWQ7XG59O1xuXG5jb25zdCBIZWFkZXIgPSAoeyBzZXNzaW9uLCBtdXRlZCwgbXV0ZVBsYXliYWNrLCB1bm11dGVQbGF5YmFjaywgbG9naW4gfSkgPT4gKFxuICA8ZGl2IHN0eWxlPXtoZWFkZXJTdHlsZX0+XG4gICAge3Nlc3Npb24udXNlciA/IChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWEgdXNlci1oZWFkZXJcIj5cbiAgICAgICAgPHN0eWxlIGpzeD57YFxuICAgICAgICAgIC51c2VyLWhlYWRlciB7XG4gICAgICAgICAgICBmbG9hdDogcmlnaHQ7XG4gICAgICAgICAgICB3aWR0aDogMTUwcHg7XG4gICAgICAgICAgfVxuICAgICAgICAgIC51c2VyLWltYWdlIHtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLnVzZXItbmFtZSB7XG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMzBweDtcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgIH1cbiAgICAgICAgICAubWVkaWEsXG4gICAgICAgICAgLm1lZGlhX19iZCB7XG4gICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICAgICAgX292ZXJmbG93OiB2aXNpYmxlO1xuICAgICAgICAgICAgem9vbTogMTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLm1lZGlhIC5tZWRpYV9faW1nIHtcbiAgICAgICAgICAgIGZsb2F0OiBsZWZ0O1xuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgICAgICAgIH1cbiAgICAgICAgICAuYnRuLXNjYWZlIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IzBEMEMwQztcbiAgICAgICAgICAgIGNvbG9yOiNmZmY7XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWFfX2ltZ1wiPlxuICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInVzZXItaW1hZ2VcIlxuICAgICAgICAgICAgc3JjPXtcbiAgICAgICAgICAgICAgKHNlc3Npb24udXNlci5pbWFnZXMgJiYgc2Vzc2lvbi51c2VyLmltYWdlcy5sZW5ndGggJiYgc2Vzc2lvbi51c2VyLmltYWdlc1swXS51cmwpIHx8XG4gICAgICAgICAgICAgICcvc3RhdGljL3VzZXItaWNvbi5wbmcnXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB3aWR0aD1cIjMwXCJcbiAgICAgICAgICAgIGhlaWdodD1cIjMwXCJcbiAgICAgICAgICAgIGFsdD17Z2V0TmFtZUZyb21Vc2VyKHNlc3Npb24udXNlcil9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidXNlci1uYW1lIG1lZGlhX19iZFwiPntnZXROYW1lRnJvbVVzZXIoc2Vzc2lvbi51c2VyKX08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICkgOiAoXG4gICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJ0biBidG4tLWRhcmsgYnRuLXNjYWZlXCIgc3R5bGU9e3sgZmxvYXQ6ICdyaWdodCcgfX0gb25DbGljaz17bG9naW59PlxuICAgICAgICA8c3R5bGUganN4PntCdXR0b25TdHlsZX08L3N0eWxlPlxuICAgICAgICA8c3R5bGUganN4PntCdXR0b25EYXJrU3R5bGV9PC9zdHlsZT5cbiAgICAgICAgPEZvcm1hdHRlZE1lc3NhZ2UgaWQ9XCJsb2dpblwiIC8+XG4gICAgICA8L2J1dHRvbj5cbiAgICApfVxuICAgIHtzZXNzaW9uLnVzZXIgPyAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInBsYXliYWNrLWNvbnRyb2xcIj5cbiAgICAgICAgPHN0eWxlIGpzeD57QnV0dG9uU3R5bGV9PC9zdHlsZT5cbiAgICAgICAgPHN0eWxlIGpzeD57QnV0dG9uRGFya1N0eWxlfTwvc3R5bGU+XG4gICAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgICAucGxheWJhY2stY29udHJvbCB7XG4gICAgICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgICB9XG4gICAgICAgIGB9PC9zdHlsZT5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIGNsYXNzTmFtZT1cImJ0biBidG4tLWRhcmsgYnRuLXNjYWZlXCJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICBtdXRlZCA/IHVubXV0ZVBsYXliYWNrKCkgOiBtdXRlUGxheWJhY2soKTtcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAge211dGVkID8gJ1VubXV0ZScgOiAnTXV0ZSd9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgKSA6IG51bGx9XG4gIDwvZGl2PlxuKTtcblxuY29uc3QgbWFwRGlzcGF0Y2hUb1Byb3BzID0gZGlzcGF0Y2ggPT4gKHtcbiAgbG9naW46ICgpID0+IGRpc3BhdGNoKGxvZ2luKCkpLFxuICBtdXRlUGxheWJhY2s6ICgpID0+IGRpc3BhdGNoKG11dGVQbGF5YmFjaygpKSxcbiAgdW5tdXRlUGxheWJhY2s6ICgpID0+IGRpc3BhdGNoKHVubXV0ZVBsYXliYWNrKCkpXG59KTtcblxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gc3RhdGUgPT4gKHtcbiAgc2Vzc2lvbjogc3RhdGUuc2Vzc2lvbixcbiAgbXV0ZWQ6IHN0YXRlLnBsYXliYWNrLm11dGVkXG59KTtcblxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykoSGVhZGVyKTtcbiJdfQ== */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\components\\\\Header.js */"), __jsx("button", {
  onClick: () => {
    muted ? unmutePlayback() : mutePlayback();
  },
  className: "jsx-2562770224 " + `jsx-${_ButtonStyle__WEBPACK_IMPORTED_MODULE_7__["default"].__hash} jsx-${_ButtonDarkStyle__WEBPACK_IMPORTED_MODULE_8__["default"].__hash}` + " " + "btn btn--dark btn-scafe"
}, muted ? 'Unmute' : 'Mute')) : null);

const mapDispatchToProps = dispatch => ({
  login: () => dispatch(Object(_actions_sessionActions__WEBPACK_IMPORTED_MODULE_5__["login"])()),
  mutePlayback: () => dispatch(Object(_actions_playbackActions__WEBPACK_IMPORTED_MODULE_6__["mutePlayback"])()),
  unmutePlayback: () => dispatch(Object(_actions_playbackActions__WEBPACK_IMPORTED_MODULE_6__["unmutePlayback"])())
});

const mapStateToProps = state => ({
  session: state.session,
  muted: state.playback.muted
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_3__["connect"])(mapStateToProps, mapDispatchToProps)(Header));

/***/ }),

/***/ "./components/MyLayout.js":
/*!********************************!*\
  !*** ./components/MyLayout.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Header */ "./components/Header.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;



const Layout = props => __jsx("div", {
  className: "jsx-1801399454"
}, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
  id: "1801399454"
}, "div.jsx-1801399454{color:#fff;font-family:'Sofia Pro',Helvetica,Arial,sans-serif;font-size:15px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxNeUxheW91dC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFLZ0IsQUFHb0IsV0FDMkMsbURBQ3ZDLGVBQ2pCIiwiZmlsZSI6IkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxNeUxheW91dC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBIZWFkZXIgZnJvbSAnLi9IZWFkZXInO1xuaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJztcblxuY29uc3QgTGF5b3V0ID0gcHJvcHMgPT4gKFxuICA8ZGl2PlxuICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgIGRpdiB7XG4gICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICBmb250LWZhbWlseTogJ1NvZmlhIFBybycsIEhlbHZldGljYSwgQXJpYWwsIHNhbnMtc2VyaWY7XG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICAgIH1cbiAgICBgfTwvc3R5bGU+XG4gICAgPEhlYWRlciAvPlxuICAgIDxkaXY+e3Byb3BzLmNoaWxkcmVufTwvZGl2PlxuICA8L2Rpdj5cbik7XG5cbmV4cG9ydCBkZWZhdWx0IExheW91dDtcbiJdfQ== */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\components\\\\MyLayout.js */"), __jsx(_Header__WEBPACK_IMPORTED_MODULE_2__["default"], null), __jsx("div", {
  className: "jsx-1801399454"
}, props.children));

/* harmony default export */ __webpack_exports__["default"] = (Layout);

/***/ }),

/***/ "./components/NowPlaying.js":
/*!**********************************!*\
  !*** ./components/NowPlaying.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;


class NowPlaying extends react__WEBPACK_IMPORTED_MODULE_1___default.a.PureComponent {
  constructor() {
    super();
    this.state = {
      start: Date.now(),
      currentPosition: 0
    };
    this.timer = null;

    this.tick = () => {
      this.setState({
        currentPosition: Date.now() - this.state.start + (this.props.position || 0)
      });
    };
  }

  componentWillReceiveProps(props) {
    if (this.props.position !== props.position || this.props.track !== props.track) {
      this.setState({
        start: Date.now(),
        currentPosition: 0
      });
    }
  }

  componentDidMount() {
    this.timer = setInterval(this.tick, 300);
  }

  componentWillUnmount() {
    clearInterval(this.timer);
  }

  render() {
    const percentage = +(this.state.currentPosition * 100 / this.props.track.duration_ms).toFixed(2) + '%';
    const userName = this.props.user.display_name || this.props.user.id;
    return __jsx("div", {
      className: "jsx-1063658271" + " " + "now-playing"
    }, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
      id: "1063658271"
    }, ".now-playing.jsx-1063658271{background-color:#0D0C0C;color:#fff;height:250px;position:relative;width:100%;}.now-playing__text.jsx-1063658271{padding:0px 40px;}.now-playing__bd.jsx-1063658271{padding-left:30px;}.now-playing__track-name.jsx-1063658271{font-size:1em;padding-top:1.2em;font-weight:bold;}.now-playing__artist-name.jsx-1063658271{font-size:0.8em;padding-bottom:2em;padding-top:0.5em;}.now-playing__user.jsx-1063658271{padding-top:0.5em;}.now-playing__progress.jsx-1063658271{float:left;width:75%;background-color:#333232;border-radius:23px;height:8px;padding:4px;margin:0px 40px;}.now-playing__progress_bar.jsx-1063658271{background-color:#fff;height:8px;border-radius:20px;}.media.jsx-1063658271,.media__bd.jsx-1063658271{overflow:hidden;_overflow:visible;zoom:1;float:left;font-size:16px;text-transform:uppercase;margin-bottom:6px;text-align:center;width:75%;}.media.jsx-1063658271 .media__img.jsx-1063658271{float:left;margin-right:10px;border-radius:50%;}.media.jsx-1063658271 .media__img.jsx-1063658271 img.jsx-1063658271{border-radius:50%;}.user-image.jsx-1063658271{border-radius:50%;}.user-name.jsx-1063658271{line-height:18px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxOb3dQbGF5aW5nLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQW1Db0IsQUFHc0MsQUFPUixBQUdDLEFBR0osQUFLRSxBQUtFLEFBR1YsQUFVYyxBQVFOLEFBV0wsQUFLTSxBQUdDLEFBR0QsV0F2Q1QsQUE2QlUsR0ExQ0EsRUFLQyxBQTBCRCxDQXJDcEIsQUEyREEsQ0F4REEsQUFhQSxBQXFDQyxBQUdELEdBcEN5QixDQVNaLEdBcENBLElBd0RPLEdBMUNELENBdUJFLENBUVosQ0ExQlcsQ0FsQkwsS0E2Q0gsS0FsQk8sQ0E2Qm5CLEVBdkRvQixBQWFwQixHQXlCQSxBQU9pQixDQTNCakIsWUFTVyxFQTFCRSxBQTZDYyxTQWxCZixFQTFCWixVQTJCZ0IsSUFrQkksWUFqQnBCLE1Ba0JvQixrQkFDUixVQUNaIiwiZmlsZSI6IkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxOb3dQbGF5aW5nLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxuY2xhc3MgTm93UGxheWluZyBleHRlbmRzIFJlYWN0LlB1cmVDb21wb25lbnQge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuc3RhdGUgPSB7XG4gICAgICBzdGFydDogRGF0ZS5ub3coKSxcbiAgICAgIGN1cnJlbnRQb3NpdGlvbjogMFxuICAgIH07XG4gICAgdGhpcy50aW1lciA9IG51bGw7XG4gICAgdGhpcy50aWNrID0gKCkgPT4ge1xuICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgIGN1cnJlbnRQb3NpdGlvbjogRGF0ZS5ub3coKSAtIHRoaXMuc3RhdGUuc3RhcnQgKyAodGhpcy5wcm9wcy5wb3NpdGlvbiB8fCAwKVxuICAgICAgfSk7XG4gICAgfTtcbiAgfVxuICBjb21wb25lbnRXaWxsUmVjZWl2ZVByb3BzKHByb3BzKSB7XG4gICAgaWYgKHRoaXMucHJvcHMucG9zaXRpb24gIT09IHByb3BzLnBvc2l0aW9uIHx8IHRoaXMucHJvcHMudHJhY2sgIT09IHByb3BzLnRyYWNrKSB7XG4gICAgICB0aGlzLnNldFN0YXRlKHtcbiAgICAgICAgc3RhcnQ6IERhdGUubm93KCksXG4gICAgICAgIGN1cnJlbnRQb3NpdGlvbjogMFxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGNvbXBvbmVudERpZE1vdW50KCkge1xuICAgIHRoaXMudGltZXIgPSBzZXRJbnRlcnZhbCh0aGlzLnRpY2ssIDMwMCk7XG4gIH1cbiAgY29tcG9uZW50V2lsbFVubW91bnQoKSB7XG4gICAgY2xlYXJJbnRlcnZhbCh0aGlzLnRpbWVyKTtcbiAgfVxuICByZW5kZXIoKSB7XG4gICAgY29uc3QgcGVyY2VudGFnZSA9ICsoKHRoaXMuc3RhdGUuY3VycmVudFBvc2l0aW9uICogMTAwKSAvIHRoaXMucHJvcHMudHJhY2suZHVyYXRpb25fbXMpLnRvRml4ZWQoMikgKyAnJSc7XG4gICAgY29uc3QgdXNlck5hbWUgPSB0aGlzLnByb3BzLnVzZXIuZGlzcGxheV9uYW1lIHx8IHRoaXMucHJvcHMudXNlci5pZDtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3ctcGxheWluZ1wiPlxuICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgLm5vdy1wbGF5aW5nIHtcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMwRDBDMEM7XG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICAgIGhlaWdodDogMjUwcHg7XG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLm5vdy1wbGF5aW5nX190ZXh0IHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDBweCA0MHB4O1xuICAgICAgICAgIH1cbiAgICAgICAgICAubm93LXBsYXlpbmdfX2JkIHtcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMzBweDtcbiAgICAgICAgICB9XG4gICAgICAgICAgLm5vdy1wbGF5aW5nX190cmFjay1uYW1lIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMWVtO1xuICAgICAgICAgICAgcGFkZGluZy10b3A6IDEuMmVtO1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIC5ub3ctcGxheWluZ19fYXJ0aXN0LW5hbWUge1xuICAgICAgICAgICAgZm9udC1zaXplOiAwLjhlbTtcbiAgICAgICAgICAgIHBhZGRpbmctYm90dG9tOiAyZW07XG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMC41ZW07XG4gICAgICAgICAgfVxuICAgICAgICAgIC5ub3ctcGxheWluZ19fdXNlciB7XG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMC41ZW07XG4gICAgICAgICAgfVxuICAgICAgICAgIC5ub3ctcGxheWluZ19fcHJvZ3Jlc3Mge1xuICAgICAgICAgIGZsb2F0OmxlZnQ7XG4gICAgICAgICAgd2lkdGg6IDc1JTtcbiAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzMzMjMyO1xuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDIzcHg7XG4gICAgICAgICAgaGVpZ2h0OiA4cHg7XG4gICAgICAgICAgcGFkZGluZzogNHB4O1xuICAgICAgICAgIG1hcmdpbjogMHB4IDQwcHg7XG4gICAgICAgICAgfVxuICAgICAgICAgIC5ub3ctcGxheWluZ19fcHJvZ3Jlc3NfYmFyIHtcbiAgICAgICAgICAgIC8vYm90dG9tOiAwO1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICAgICAgICAgIGhlaWdodDogOHB4O1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcbiAgICAgICAgICAgLy8gcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgLy90b3A6MzUycHg7XG4gICAgICAgICAgfVxuICAgICAgICAgIC5tZWRpYSxcbiAgICAgICAgICAubWVkaWFfX2JkIHtcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgICAgICAgICBfb3ZlcmZsb3c6IHZpc2libGU7XG4gICAgICAgICAgICB6b29tOiAxO1xuICAgICAgICAgICAgZmxvYXQ6bGVmdDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gICAgICAgICAgICBtYXJnaW4tYm90dG9tOiA2cHg7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgICB3aWR0aDogNzUlO1xuICAgICAgICAgIH1cbiAgICAgICAgICAubWVkaWEgLm1lZGlhX19pbWcge1xuICAgICAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgfVxuICAgICAgICAgICAubWVkaWEgLm1lZGlhX19pbWcgaW1nIHtcbiAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgICB9XG4gICAgICAgICAgLnVzZXItaW1hZ2Uge1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgICAgIH1cbiAgICAgICAgICAudXNlci1uYW1lIHtcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxOHB4O1xuICAgICAgICAgIH1cbiAgICAgICAgYH08L3N0eWxlPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdy1wbGF5aW5nX190ZXh0IG1lZGlhXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYV9faW1nXCI+XG4gICAgICAgICAgICA8aW1nIHNyYz17dGhpcy5wcm9wcy50cmFjay5hbGJ1bS5pbWFnZXNbMV0udXJsfSB3aWR0aD1cIjI4MFwiIGhlaWdodD1cIjI4MFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3ctcGxheWluZ19fYmQgbWVkaWFfX2JkXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdy1wbGF5aW5nX190cmFjay1uYW1lXCI+e3RoaXMucHJvcHMudHJhY2submFtZX08L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm93LXBsYXlpbmdfX2FydGlzdC1uYW1lXCI+e3RoaXMucHJvcHMudHJhY2suYXJ0aXN0cy5tYXAoYSA9PiBhLm5hbWUpLmpvaW4oJywgJyl9PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhX19pbWdcIj5cbiAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVzZXItaW1hZ2VcIlxuICAgICAgICAgICAgICAgIHNyYz17XG4gICAgICAgICAgICAgICAgICAodGhpcy5wcm9wcy51c2VyLmltYWdlcyAmJiB0aGlzLnByb3BzLnVzZXIuaW1hZ2VzLmxlbmd0aCAmJiB0aGlzLnByb3BzLnVzZXIuaW1hZ2VzWzBdLnVybCkgfHxcbiAgICAgICAgICAgICAgICAgICcvc3RhdGljL3VzZXItaWNvbi5wbmcnXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHdpZHRoPVwiMzBcIlxuICAgICAgICAgICAgICAgIGhlaWdodD1cIjMwXCJcbiAgICAgICAgICAgICAgICBhbHQ9e3VzZXJOYW1lfVxuICAgICAgICAgICAgICAgIHRpdGxlPXt1c2VyTmFtZX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ1c2VyLW5hbWUgbWVkaWFfX2JkXCI+e3VzZXJOYW1lfTwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3ctcGxheWluZ19fcHJvZ3Jlc3NcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdy1wbGF5aW5nX19wcm9ncmVzc19iYXJcIiBzdHlsZT17eyB3aWR0aDogcGVyY2VudGFnZSB9fSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgTm93UGxheWluZztcbiJdfQ== */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\components\\\\NowPlaying.js */"), __jsx("div", {
      className: "jsx-1063658271" + " " + "now-playing__text media"
    }, __jsx("div", {
      className: "jsx-1063658271" + " " + "media__img"
    }, __jsx("img", {
      src: this.props.track.album.images[1].url,
      width: "280",
      height: "280",
      className: "jsx-1063658271"
    })), __jsx("div", {
      className: "jsx-1063658271" + " " + "now-playing__bd media__bd"
    }, __jsx("div", {
      className: "jsx-1063658271" + " " + "now-playing__track-name"
    }, this.props.track.name), __jsx("div", {
      className: "jsx-1063658271" + " " + "now-playing__artist-name"
    }, this.props.track.artists.map(a => a.name).join(', ')), __jsx("div", {
      className: "jsx-1063658271" + " " + "media__img"
    }, __jsx("img", {
      src: this.props.user.images && this.props.user.images.length && this.props.user.images[0].url || '/static/user-icon.png',
      width: "30",
      height: "30",
      alt: userName,
      title: userName,
      className: "jsx-1063658271" + " " + "user-image"
    })), __jsx("div", {
      className: "jsx-1063658271" + " " + "user-name media__bd"
    }, userName))), __jsx("div", {
      className: "jsx-1063658271" + " " + "now-playing__progress"
    }, __jsx("div", {
      style: {
        width: percentage
      },
      className: "jsx-1063658271" + " " + "now-playing__progress_bar"
    })));
  }

}

/* harmony default export */ __webpack_exports__["default"] = (NowPlaying);

/***/ }),

/***/ "./components/PageWithIntl.js":
/*!************************************!*\
  !*** ./components/PageWithIntl.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_1__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


 // Register React Intl's locale data for the user's locale in the browser. This
// locale data was added to the page by `pages/_document.js`. This only happens
// once, on initial page load in the browser.

if (false) {}

/* harmony default export */ __webpack_exports__["default"] = (Page => {
  const IntlPage = Object(react_intl__WEBPACK_IMPORTED_MODULE_1__["injectIntl"])(Page);
  return class PageWithIntl extends react__WEBPACK_IMPORTED_MODULE_0__["Component"] {
    static async getInitialProps(context) {
      let props;

      if (typeof Page.getInitialProps === 'function') {
        props = await Page.getInitialProps(context);
      } // Get the `locale` and `messages` from the request object on the server.
      // In the browser, use the same values that the server serialized.


      const {
        req
      } = context; // todo: for some reason it is not props.initialProps, but props in the example

      const {
        locale,
        messages
      } = req || window.__NEXT_DATA__.props.initialProps; // Always update the current time on page load/transition because the
      // <IntlProvider> will be a new instance even with pushState routing.

      const now = Date.now();
      return _objectSpread(_objectSpread({}, props), {}, {
        locale,
        messages,
        now
      });
    }

    render() {
      const _this$props = this.props,
            {
        locale,
        messages,
        now
      } = _this$props,
            props = _objectWithoutProperties(_this$props, ["locale", "messages", "now"]);

      return __jsx(react_intl__WEBPACK_IMPORTED_MODULE_1__["IntlProvider"], {
        locale: locale,
        messages: messages,
        initialNow: now
      }, __jsx(IntlPage, props));
    }

  };
});

/***/ }),

/***/ "./components/Queue.js":
/*!*****************************!*\
  !*** ./components/Queue.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _QueueItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./QueueItem */ "./components/QueueItem.js");
/* harmony import */ var _actions_queueActions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../actions/queueActions */ "./actions/queueActions.js");
/* harmony import */ var _actions_voteActions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../actions/voteActions */ "./actions/voteActions.js");

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;







class Queue extends react__WEBPACK_IMPORTED_MODULE_1___default.a.PureComponent {
  render() {
    const {
      items,
      session
    } = this.props;
    return __jsx("div", {
      style: {
        paddingBottom: '10px'
      }
    }, __jsx("h2", null, __jsx(react_intl__WEBPACK_IMPORTED_MODULE_3__["FormattedMessage"], {
      id: "queue.title"
    })), items.length === 0 ? __jsx("p", null, __jsx(react_intl__WEBPACK_IMPORTED_MODULE_3__["FormattedMessage"], {
      id: "queue.empty"
    })) : __jsx("table", {
      className: "jsx-1423284646" + " " + "queue"
    }, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
      id: "1423284646"
    }, ".queue.jsx-1423284646{max-width:550px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxRdWV1ZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFpQjBCLEFBR21DLGdCQUNsQiIsImZpbGUiOiJDOlxcVXNlcnNcXEdlYnJ1aWtlclxcV2Vic3Rvcm1Qcm9qZWN0c1xcU3BvdGlmeVxcY29tcG9uZW50c1xcUXVldWUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gJ3JlYWN0LXJlZHV4JztcbmltcG9ydCB7IEZvcm1hdHRlZE1lc3NhZ2UgfSBmcm9tICdyZWFjdC1pbnRsJztcblxuaW1wb3J0IFF1ZXVlSXRlbSBmcm9tICcuL1F1ZXVlSXRlbSc7XG5pbXBvcnQgeyBxdWV1ZVJlbW92ZVRyYWNrIH0gZnJvbSAnLi4vYWN0aW9ucy9xdWV1ZUFjdGlvbnMnO1xuaW1wb3J0IHsgdm90ZVVwIH0gZnJvbSAnLi4vYWN0aW9ucy92b3RlQWN0aW9ucyc7XG5cbmNsYXNzIFF1ZXVlIGV4dGVuZHMgUmVhY3QuUHVyZUNvbXBvbmVudCB7XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IGl0ZW1zLCBzZXNzaW9uIH0gPSB0aGlzLnByb3BzO1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmdCb3R0b206ICcxMHB4JyB9fT5cbiAgICAgICAgPGgyPjxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwicXVldWUudGl0bGVcIiAvPjwvaDI+XG4gICAgICAgIHtpdGVtcy5sZW5ndGggPT09IDBcbiAgICAgICAgICA/IDxwPjxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwicXVldWUuZW1wdHlcIiAvPjwvcD5cbiAgICAgICAgICA6IDx0YWJsZSBjbGFzc05hbWU9XCJxdWV1ZVwiPlxuICAgICAgICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgICAgICAgLnF1ZXVlIHtcbiAgICAgICAgICAgICAgICAgIG1heC13aWR0aDogNTUwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBgfTwvc3R5bGU+XG4gICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICB7aXRlbXMubWFwKChpLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPFF1ZXVlSXRlbVxuICAgICAgICAgICAgICAgICAgICBpdGVtPXtpfVxuICAgICAgICAgICAgICAgICAgICBzZXNzaW9uPXtzZXNzaW9ufVxuICAgICAgICAgICAgICAgICAgICBpbmRleD17aW5kZXh9XG4gICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgICAgICAgICAgICAgIG9uVm90ZVVwPXsoKSA9PiB0aGlzLnByb3BzLnZvdGVVcChpLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgb25SZW1vdmVJdGVtPXsoKSA9PiB0aGlzLnByb3BzLnF1ZXVlUmVtb3ZlVHJhY2soaS5pZCl9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgPC90YWJsZT59XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG59XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IGRpc3BhdGNoID0+ICh7XG4gIHZvdGVVcDogaWQgPT4gZGlzcGF0Y2godm90ZVVwKGlkKSksXG4gIHF1ZXVlUmVtb3ZlVHJhY2s6IGlkID0+IGRpc3BhdGNoKHF1ZXVlUmVtb3ZlVHJhY2soaWQpKVxufSk7XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IHN0YXRlID0+ICh7XG4gIHF1ZXVlOiBzdGF0ZS5xdWV1ZVxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKFF1ZXVlKTtcbiJdfQ== */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\components\\\\Queue.js */"), __jsx("tbody", {
      className: "jsx-1423284646"
    }, items.map((i, index) => __jsx(_QueueItem__WEBPACK_IMPORTED_MODULE_4__["default"], {
      item: i,
      session: session,
      index: index,
      key: index,
      onVoteUp: () => this.props.voteUp(i.id),
      onRemoveItem: () => this.props.queueRemoveTrack(i.id)
    })))));
  }

}

const mapDispatchToProps = dispatch => ({
  voteUp: id => dispatch(Object(_actions_voteActions__WEBPACK_IMPORTED_MODULE_6__["voteUp"])(id)),
  queueRemoveTrack: id => dispatch(Object(_actions_queueActions__WEBPACK_IMPORTED_MODULE_5__["queueRemoveTrack"])(id))
});

const mapStateToProps = state => ({
  queue: state.queue
});

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_2__["connect"])(mapStateToProps, mapDispatchToProps)(Queue));

/***/ }),

/***/ "./components/QueueItem.js":
/*!*********************************!*\
  !*** ./components/QueueItem.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;

/* harmony default export */ __webpack_exports__["default"] = (({
  index,
  item,
  session,
  onRemoveItem,
  onVoteUp
}) => {
  const voteUp = item.voters && session.user && item.voters.filter(v => v.id === session.user.id).length === 0 ? __jsx("button", {
    onClick: onVoteUp
  }, "\u25B2") : null;
  return __jsx("div", {
    style: {
      fontsize: '11px',
      marginBottom: '15px',
      float: "left",
      width: '297px'
    }
  }, __jsx("div", {
    style: {
      paddingRight: '10px',
      float: "left"
    }
  }, __jsx("img", {
    src: item.track.album.images[2].url,
    width: "40",
    height: "40"
  })), __jsx("div", {
    style: {
      paddingRight: '10px',
      float: "left"
    }
  }, index + 1), __jsx("div", {
    style: {
      paddingRight: '10px',
      float: "left"
    }
  }, item.track.name, __jsx("br", null), item.track.artists.map(a => a.name).join(', '), __jsx("br", null)), __jsx("div", {
    style: {
      paddingRight: '10px',
      float: "left",
      display: "none"
    }
  }, item.user && (item.user.display_name || item.user.id)), __jsx("div", {
    style: {
      paddingRight: '10px',
      float: "right"
    }
  }, item.user && session.user && item.user.id === session.user.id ? __jsx("button", {
    onClick: () => {
      onRemoveItem(item.id);
    }
  }, "X") : voteUp), __jsx("div", {
    style: {
      paddingRight: '10px',
      float: "left"
    }
  }, item.voters && item.voters.length > 0 ? __jsx("span", null, item.voters.length === 1 ? '1 vote' : item.voters.length + ' votes') : ''));
});

/***/ }),

/***/ "./components/Users.js":
/*!*****************************!*\
  !*** ./components/Users.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_2__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;


/* harmony default export */ __webpack_exports__["default"] = (({
  items
}) => {
  return __jsx("div", {
    className: "jsx-1123997634"
  }, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
    id: "1123997634"
  }, ".user-list.jsx-1123997634{list-style:none;margin:0;padding:0;}.user-list__item.jsx-1123997634{display:block;margin-bottom:0.5em;}.user-image.jsx-1123997634{border-radius:50%;}.user-name.jsx-1123997634{line-height:30px;}.media.jsx-1123997634,.media__bd.jsx-1123997634{overflow:hidden;_overflow:visible;zoom:1;}.media.jsx-1123997634 .media__img.jsx-1123997634{float:left;margin-right:10px;}.header-2.jsx-1123997634{color:#999;font-size:11px;text-transform:uppercase;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxVc2Vycy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFNa0IsQUFHMkIsQUFLRixBQUlJLEFBR0QsQUFJRCxBQUtMLEFBSUEsV0FITyxBQUlILEdBcEJLLEVBTFgsQUFnQlMsQ0FKcEIsQ0FIQSxPQVJZLENBeUJlLEdBSjNCLEtBaEJBLEFBV1MsQ0FmVCxNQWdCQSxVQVNBIiwiZmlsZSI6IkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxjb21wb25lbnRzXFxVc2Vycy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IEZvcm1hdHRlZE1lc3NhZ2UgfSBmcm9tICdyZWFjdC1pbnRsJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0ICh7IGl0ZW1zIH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPHN0eWxlIGpzeD57YFxyXG4gICAgICAgIC51c2VyLWxpc3Qge1xyXG4gICAgICAgICAgbGlzdC1zdHlsZTogbm9uZTtcclxuICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC51c2VyLWxpc3RfX2l0ZW0ge1xyXG4gICAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICAgICAgICBtYXJnaW4tYm90dG9tOiAwLjVlbTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnVzZXItaW1hZ2Uge1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAudXNlci1uYW1lIHtcclxuICAgICAgICAgIGxpbmUtaGVpZ2h0OiAzMHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAubWVkaWEsXHJcbiAgICAgICAgLm1lZGlhX19iZCB7XHJcbiAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgICAgICAgX292ZXJmbG93OiB2aXNpYmxlO1xyXG4gICAgICAgICAgem9vbTogMTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLm1lZGlhIC5tZWRpYV9faW1nIHtcclxuICAgICAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAuaGVhZGVyLTIge1xyXG4gICAgICAgICAgY29sb3I6ICM5OTk7XHJcbiAgICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgICAgIH1cclxuICAgICAgYH08L3N0eWxlPlxyXG4gICAgICA8aDIgY2xhc3NOYW1lPVwiaGVhZGVyLTJcIj48Rm9ybWF0dGVkTWVzc2FnZSBpZD1cIm9ubGluZVwiIC8+PC9oMj5cclxuICAgICAgPHVsIGNsYXNzTmFtZT1cInVzZXItbGlzdFwiPlxyXG4gICAgICAgIHtpdGVtcy5tYXAoKGksIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCB1c2VyTmFtZSA9IGkuZGlzcGxheV9uYW1lIHx8IGkuaWQ7XHJcbiAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICA8bGkga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwidXNlci1saXN0X19pdGVtIG1lZGlhXCI+XHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWRpYV9faW1nXCI+XHJcbiAgICAgICAgICAgICAgICA8aW1nXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInVzZXItaW1hZ2VcIlxyXG4gICAgICAgICAgICAgICAgICBzcmM9eyhpLmltYWdlcyAmJiBpLmltYWdlcy5sZW5ndGggJiYgaS5pbWFnZXNbMF0udXJsKSB8fCAnL3N0YXRpYy91c2VyLWljb24ucG5nJ31cclxuICAgICAgICAgICAgICAgICAgd2lkdGg9XCIzMFwiXHJcbiAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjMwXCJcclxuICAgICAgICAgICAgICAgICAgYWx0PXt1c2VyTmFtZX1cclxuICAgICAgICAgICAgICAgICAgdGl0bGU9e3VzZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVzZXItbmFtZSBtZWRpYV9fYmRcIj5cclxuICAgICAgICAgICAgICAgIHt1c2VyTmFtZX1cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9saT5cclxuICAgICAgICAgICk7XHJcbiAgICAgICAgfSl9XHJcbiAgICAgIDwvdWw+XHJcbiAgICAgIDxkaXYgc3R5bGU9e3sgY2xlYXI6ICdib3RoJyB9fSAvPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuIl19 */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\components\\\\Users.js */"), __jsx("h2", {
    className: "jsx-1123997634" + " " + "header-2"
  }, __jsx(react_intl__WEBPACK_IMPORTED_MODULE_2__["FormattedMessage"], {
    id: "online"
  })), __jsx("ul", {
    className: "jsx-1123997634" + " " + "user-list"
  }, items.map((i, index) => {
    const userName = i.display_name || i.id;
    return __jsx("li", {
      key: index,
      className: "jsx-1123997634" + " " + "user-list__item media"
    }, __jsx("div", {
      className: "jsx-1123997634" + " " + "media__img"
    }, __jsx("img", {
      src: i.images && i.images.length && i.images[0].url || '/static/user-icon.png',
      width: "30",
      height: "30",
      alt: userName,
      title: userName,
      className: "jsx-1123997634" + " " + "user-image"
    })), __jsx("div", {
      className: "jsx-1123997634" + " " + "user-name media__bd"
    }, userName));
  })), __jsx("div", {
    style: {
      clear: 'both'
    },
    className: "jsx-1123997634"
  }));
});

/***/ }),

/***/ "./config/app.js":
/*!***********************!*\
  !*** ./config/app.js ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  HOST: "http://localhost:3001"
};

/***/ }),

/***/ "./constants/ActionTypes.js":
/*!**********************************!*\
  !*** ./constants/ActionTypes.js ***!
  \**********************************/
/*! exports provided: QUEUE_TRACK, UPDATE_QUEUE, QUEUE_ENDED, QUEUE_REMOVE_TRACK, SEARCH_TRACKS, SEARCH_TRACKS_SUCCESS, SEARCH_TRACKS_RESET, FETCH_TRACK, FETCH_TRACK_SUCCESS, FETCH_PLAYING_CONTEXT_SUCCESS, UPDATE_USERS, LOAD, LOGIN, LOGIN_SUCCESS, LOGIN_FAILURE, UPDATE_TOKEN, UPDATE_TOKEN_SUCCESS, UPDATE_CURRENT_USER, PLAY_TRACK, UPDATE_NOW_PLAYING, PLAY_TRACK_SUCCESS, MUTE_PLAYBACK, UNMUTE_PLAYBACK, FETCH_AVAILABLE_DEVICES, FETCH_AVAILABLE_DEVICES_SUCCESS, FETCH_AVAILABLE_DEVICES_ERROR, TRANSFER_PLAYBACK_TO_DEVICE, TRANSFER_PLAYBACK_TO_DEVICE_SUCCESS, TRANSFER_PLAYBACK_TO_DEVICE_ERROR, VOTE_UP, VOTE_UP_SUCCESS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QUEUE_TRACK", function() { return QUEUE_TRACK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_QUEUE", function() { return UPDATE_QUEUE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QUEUE_ENDED", function() { return QUEUE_ENDED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "QUEUE_REMOVE_TRACK", function() { return QUEUE_REMOVE_TRACK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SEARCH_TRACKS", function() { return SEARCH_TRACKS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SEARCH_TRACKS_SUCCESS", function() { return SEARCH_TRACKS_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SEARCH_TRACKS_RESET", function() { return SEARCH_TRACKS_RESET; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FETCH_TRACK", function() { return FETCH_TRACK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FETCH_TRACK_SUCCESS", function() { return FETCH_TRACK_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FETCH_PLAYING_CONTEXT_SUCCESS", function() { return FETCH_PLAYING_CONTEXT_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_USERS", function() { return UPDATE_USERS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LOAD", function() { return LOAD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LOGIN", function() { return LOGIN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LOGIN_SUCCESS", function() { return LOGIN_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LOGIN_FAILURE", function() { return LOGIN_FAILURE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_TOKEN", function() { return UPDATE_TOKEN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_TOKEN_SUCCESS", function() { return UPDATE_TOKEN_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_CURRENT_USER", function() { return UPDATE_CURRENT_USER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PLAY_TRACK", function() { return PLAY_TRACK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UPDATE_NOW_PLAYING", function() { return UPDATE_NOW_PLAYING; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PLAY_TRACK_SUCCESS", function() { return PLAY_TRACK_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MUTE_PLAYBACK", function() { return MUTE_PLAYBACK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UNMUTE_PLAYBACK", function() { return UNMUTE_PLAYBACK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FETCH_AVAILABLE_DEVICES", function() { return FETCH_AVAILABLE_DEVICES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FETCH_AVAILABLE_DEVICES_SUCCESS", function() { return FETCH_AVAILABLE_DEVICES_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FETCH_AVAILABLE_DEVICES_ERROR", function() { return FETCH_AVAILABLE_DEVICES_ERROR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TRANSFER_PLAYBACK_TO_DEVICE", function() { return TRANSFER_PLAYBACK_TO_DEVICE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TRANSFER_PLAYBACK_TO_DEVICE_SUCCESS", function() { return TRANSFER_PLAYBACK_TO_DEVICE_SUCCESS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TRANSFER_PLAYBACK_TO_DEVICE_ERROR", function() { return TRANSFER_PLAYBACK_TO_DEVICE_ERROR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VOTE_UP", function() { return VOTE_UP; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VOTE_UP_SUCCESS", function() { return VOTE_UP_SUCCESS; });
const QUEUE_TRACK = 'QUEUE_TRACK';
const UPDATE_QUEUE = 'UPDATE_QUEUE';
const QUEUE_ENDED = 'QUEUE_ENDED';
const QUEUE_REMOVE_TRACK = 'QUEUE_REMOVE_TRACK';
const SEARCH_TRACKS = 'SEARCH_TRACKS';
const SEARCH_TRACKS_SUCCESS = 'SEARCH_TRACKS_SUCCESS';
const SEARCH_TRACKS_RESET = 'SEARCH_TRACKS_RESET';
const FETCH_TRACK = 'FETCH_TRACK';
const FETCH_TRACK_SUCCESS = 'FETCH_TRACK_SUCCESS';
const FETCH_PLAYING_CONTEXT_SUCCESS = 'FETCH_PLAYING_CONTEXT_SUCCESS';
const UPDATE_USERS = 'UPDATE_USERS';
const LOAD = 'LOAD';
const LOGIN = 'LOGIN';
const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
const LOGIN_FAILURE = 'LOGIN_FAILURE';
const UPDATE_TOKEN = 'UPDATE_TOKEN';
const UPDATE_TOKEN_SUCCESS = 'UPDATE_TOKEN_SUCCESS';
const UPDATE_CURRENT_USER = 'UPDATE_CURRENT_USER';
const PLAY_TRACK = 'PLAY_TRACK';
const UPDATE_NOW_PLAYING = 'UPDATE_NOW_PLAYING';
const PLAY_TRACK_SUCCESS = 'PLAY_TRACK_SUCCESS';
const MUTE_PLAYBACK = 'MUTE_PLAYBACK';
const UNMUTE_PLAYBACK = 'UNMUTE_PLAYBACK';
const FETCH_AVAILABLE_DEVICES = 'FETCH_AVAILABLE_DEVICES';
const FETCH_AVAILABLE_DEVICES_SUCCESS = 'FETCH_AVAILABLE_DEVICES_SUCCESS';
const FETCH_AVAILABLE_DEVICES_ERROR = 'FETCH_AVAILABLE_DEVICES_ERROR';
const TRANSFER_PLAYBACK_TO_DEVICE = 'TRANSFER_PLAYBACK_TO_DEVICE';
const TRANSFER_PLAYBACK_TO_DEVICE_SUCCESS = 'TRANSFER_PLAYBACK_TO_DEVICE_SUCCESS';
const TRANSFER_PLAYBACK_TO_DEVICE_ERROR = 'TRANSFER_PLAYBACK_TO_DEVICE_ERROR';
const VOTE_UP = 'VOTE_UP';
const VOTE_UP_SUCCESS = 'VOTE_UP_SUCCESS';

/***/ }),

/***/ "./middlewares/devicesMiddleware.js":
/*!******************************************!*\
  !*** ./middlewares/devicesMiddleware.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! isomorphic-unfetch */ "isomorphic-unfetch");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");
/* harmony import */ var _actions_devicesActions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../actions/devicesActions */ "./actions/devicesActions.js");



const SPOTIFY_API_BASE = 'https://api.spotify.com/v1';
/* harmony default export */ __webpack_exports__["default"] = (store => next => action => {
  const result = next(action);

  switch (action.type) {
    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__["FETCH_AVAILABLE_DEVICES"]:
      {
        isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default()(`${SPOTIFY_API_BASE}/me/player/devices`, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${store.getState().session.access_token}`
          }
        }).then(r => r.json()).then(r => {
          if (r.error) {
            store.dispatch(Object(_actions_devicesActions__WEBPACK_IMPORTED_MODULE_2__["fetchAvailableDevicesError"])(r.error));
          } else {
            store.dispatch(Object(_actions_devicesActions__WEBPACK_IMPORTED_MODULE_2__["fetchAvailableDevicesSuccess"])(r.devices));
          }
        });
        break;
      }

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__["TRANSFER_PLAYBACK_TO_DEVICE"]:
      {
        isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default()(`${SPOTIFY_API_BASE}/me/player`, {
          method: 'PUT',
          headers: {
            Authorization: `Bearer ${store.getState().session.access_token}`
          },
          body: JSON.stringify({
            device_ids: [action.deviceId]
          })
        }).then(r => r.json()).then(r => {
          if (r.error) {
            store.dispatch(Object(_actions_devicesActions__WEBPACK_IMPORTED_MODULE_2__["transferPlaybackToDeviceError"])(r.error));
          } else {
            store.dispatch(Object(_actions_devicesActions__WEBPACK_IMPORTED_MODULE_2__["transferPlaybackToDeviceSuccess"])());
            store.dispatch(Object(_actions_devicesActions__WEBPACK_IMPORTED_MODULE_2__["fetchAvailableDevices"])());
          }
        });
        break;
      }

    default:
      break;
  }

  return result;
});

/***/ }),

/***/ "./middlewares/loggerMiddleware.js":
/*!*****************************************!*\
  !*** ./middlewares/loggerMiddleware.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (store => next => action => {
  const result = next(action);
  console.log(action);
});

/***/ }),

/***/ "./middlewares/playbackMiddleware.js":
/*!*******************************************!*\
  !*** ./middlewares/playbackMiddleware.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! isomorphic-unfetch */ "isomorphic-unfetch");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");
/* harmony import */ var _actions_playbackActions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../actions/playbackActions */ "./actions/playbackActions.js");
/* harmony import */ var _actions_devicesActions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../actions/devicesActions */ "./actions/devicesActions.js");




const SPOTIFY_API_BASE = 'https://api.spotify.com/v1';
/* harmony default export */ __webpack_exports__["default"] = (store => next => action => {
  const result = next(action);

  switch (action.type) {
    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__["PLAY_TRACK"]:
      {
        if (false) {}

        break;
      }

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__["UNMUTE_PLAYBACK"]:
      {
        const {
          track,
          user,
          position,
          startTime
        } = store.getState().playback;
        const currentPosition = Date.now() - startTime + position;
        store.dispatch(Object(_actions_playbackActions__WEBPACK_IMPORTED_MODULE_2__["playTrack"])(track, user, currentPosition));
        break;
      }

    default:
      break;
  }

  return result;
});

/***/ }),

/***/ "./middlewares/searchMiddleware.js":
/*!*****************************************!*\
  !*** ./middlewares/searchMiddleware.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! isomorphic-unfetch */ "isomorphic-unfetch");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");
/* harmony import */ var _actions_searchActions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../actions/searchActions */ "./actions/searchActions.js");



const SPOTIFY_API_BASE = 'https://api.spotify.com/v1';

const searchTracks = query => (dispatch, getState) => {
  let shouldAddWildcard = false;

  if (query.length > 1) {
    const words = query.split(' ');
    const lastWord = words[words.length - 1];

    if (/^[a-z0-9\s]+$/i.test(lastWord) && query.lastIndexOf('*') !== query.length - 1) {
      shouldAddWildcard = true;
    }
  }

  const wildcardQuery = `${query}${shouldAddWildcard ? '*' : ''}`; // Trick to improve search results

  return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default()(`${SPOTIFY_API_BASE}/search?q=${encodeURIComponent(wildcardQuery)}&type=track&limit=10`, {
    headers: {
      Authorization: 'Bearer ' + getState().session.access_token
    }
  }).then(res => res.json()).then(res => {
    dispatch(Object(_actions_searchActions__WEBPACK_IMPORTED_MODULE_2__["searchTracksSuccess"])(query, res.tracks.items));
  });
};

/* harmony default export */ __webpack_exports__["default"] = (store => next => action => {
  const result = next(action);

  switch (action.type) {
    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__["SEARCH_TRACKS"]:
      {
        return store.dispatch(searchTracks(action.query));
        break;
      }

    default:
      break;
  }

  return result;
});

/***/ }),

/***/ "./middlewares/sessionMiddleware.js":
/*!******************************************!*\
  !*** ./middlewares/sessionMiddleware.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! isomorphic-unfetch */ "isomorphic-unfetch");
/* harmony import */ var isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");
/* harmony import */ var _actions_sessionActions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../actions/sessionActions */ "./actions/sessionActions.js");
/* harmony import */ var _config_app__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../config/app */ "./config/app.js");
/* harmony import */ var _config_app__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_config_app__WEBPACK_IMPORTED_MODULE_3__);




const SPOTIFY_API_BASE = 'https://api.spotify.com/v1';

const getCurrentUser = () => (dispatch, getState) => isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default()(`${SPOTIFY_API_BASE}/me`, {
  headers: {
    Authorization: 'Bearer ' + getState().session.access_token
  }
}).then(res => res.json()).then(res => {
  dispatch(Object(_actions_sessionActions__WEBPACK_IMPORTED_MODULE_2__["updateCurrentUser"])(res));
});

const updateToken = () => (dispatch, getState) => {
  return isomorphic_unfetch__WEBPACK_IMPORTED_MODULE_0___default()(`${_config_app__WEBPACK_IMPORTED_MODULE_3__["HOST"]}/auth/token`, {
    method: 'POST',
    body: JSON.stringify({
      refresh_token: getState().session.refresh_token
    }),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  }).then(res => res.json()).then(res => {
    console.log(res);
    dispatch(Object(_actions_sessionActions__WEBPACK_IMPORTED_MODULE_2__["updateTokenSuccess"])(res.access_token));
  });
}; // todo: set a timer, both client-side and server-side


/* harmony default export */ __webpack_exports__["default"] = (store => next => action => {
  const result = next(action);

  switch (action.type) {
    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__["LOAD"]:
      {
        const session = store.getState().session;
        const expiresIn = session.expires_in;
        const needsToUpdate = !expiresIn || expiresIn - Date.now() < 10 * 60 * 1000;

        if (needsToUpdate) {
          console.log('sessionMiddleware > needs to update access token');
          const refreshToken = session.refresh_token;

          if (refreshToken) {
            console.log('sessionMiddleware > using refresh token');
            store.dispatch(updateToken()).then(() => {
              return store.dispatch(getCurrentUser());
            }).then(() => {
              store.dispatch(Object(_actions_sessionActions__WEBPACK_IMPORTED_MODULE_2__["loginSuccess"])());
            });
          }
        } else {
          console.log('sessionMiddleware > no need to update access token');
          store.dispatch(getCurrentUser()).then(() => {
            store.dispatch(Object(_actions_sessionActions__WEBPACK_IMPORTED_MODULE_2__["loginSuccess"])());
          });
        }

        break;
      }

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_1__["LOGIN"]:
      {
        const getLoginURL = scopes => {
          return `${_config_app__WEBPACK_IMPORTED_MODULE_3__["HOST"]}/auth/login?scope=${encodeURIComponent(scopes.join(' '))}`;
        };

        const width = 450,
              height = 730,
              left = window.screen.width / 2 - width / 2,
              top = window.screen.height / 2 - height / 2;

        const messageFn = event => {
          try {
            const hash = JSON.parse(event.data);

            if (hash.type === 'access_token') {
              window.removeEventListener('message', messageFn, false);
              const accessToken = hash.access_token;
              const expiresIn = hash.expires_in;

              if (accessToken === '') {// todo: implement login error
              } else {
                const refreshToken = hash.refresh_token;
                localStorage.setItem('refreshToken', refreshToken);
                localStorage.setItem('accessToken', accessToken);
                localStorage.setItem('expiresIn', Date.now() + expiresIn * 1000);
                store.dispatch(Object(_actions_sessionActions__WEBPACK_IMPORTED_MODULE_2__["updateTokenSuccess"])(accessToken));
                store.dispatch(getCurrentUser()).then(() => store.dispatch(Object(_actions_sessionActions__WEBPACK_IMPORTED_MODULE_2__["loginSuccess"])()));
              }
            }
          } catch (e) {
            // do nothing
            console.error(e);
          }
        };

        window.addEventListener('message', messageFn, false);
        const url = getLoginURL(['user-read-playback-state', 'user-modify-playback-state']);
        window.open(url, 'Spotify', 'menubar=no,location=no,resizable=no,scrollbars=no,status=no, width=' + width + ', height=' + height + ', top=' + top + ', left=' + left);
        break;
      }

    default:
      break;
  }

  return result;
});

/***/ }),

/***/ "./middlewares/socketMiddleware.js":
/*!*****************************************!*\
  !*** ./middlewares/socketMiddleware.js ***!
  \*****************************************/
/*! exports provided: socketMiddleware, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "socketMiddleware", function() { return socketMiddleware; });
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");
/* harmony import */ var _actions_usersActions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../actions/usersActions */ "./actions/usersActions.js");
/* harmony import */ var _actions_queueActions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../actions/queueActions */ "./actions/queueActions.js");
/* harmony import */ var _actions_playbackActions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../actions/playbackActions */ "./actions/playbackActions.js");
/* harmony import */ var _config_app__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config/app */ "./config/app.js");
/* harmony import */ var _config_app__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_config_app__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! socket.io-client */ "socket.io-client");
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(socket_io_client__WEBPACK_IMPORTED_MODULE_5__);






var socket = null;

const getIdFromTrackString = (trackString = '') => {
  let matches = trackString.match(/^https:\/\/open\.spotify\.com\/track\/(.*)/);

  if (matches) {
    return matches[1];
  }

  matches = trackString.match(/^https:\/\/play\.spotify\.com\/track\/(.*)/);

  if (matches) {
    return matches[1];
  }

  matches = trackString.match(/^spotify:track:(.*)/);

  if (matches) {
    return matches[1];
  }

  return null;
};

function socketMiddleware(store) {
  return next => action => {
    const result = next(action);

    if (socket) {
      switch (action.type) {
        case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["QUEUE_TRACK"]:
          {
            let trackId = getIdFromTrackString(action.id);

            if (trackId === null) {
              trackId = action.id;
            }

            socket.emit('queue track', trackId);
            break;
          }

        case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["QUEUE_REMOVE_TRACK"]:
          {
            socket.emit('remove track', action.id);
            break;
          }

        case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["LOGIN_SUCCESS"]:
          const user = store.getState().session.user;
          socket.emit('user login', user);
          break;

        case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["VOTE_UP"]:
          socket.emit('vote up', action.id);
          break;

        default:
          break;
      }
    }

    return result;
  };
}
/* harmony default export */ __webpack_exports__["default"] = (function (store) {
  socket = socket_io_client__WEBPACK_IMPORTED_MODULE_5___default.a.connect(_config_app__WEBPACK_IMPORTED_MODULE_4___default.a.HOST);
  socket.on('update queue', data => {
    store.dispatch(Object(_actions_queueActions__WEBPACK_IMPORTED_MODULE_2__["updateQueue"])(data));
  });
  socket.on('queue ended', () => {
    store.dispatch(Object(_actions_queueActions__WEBPACK_IMPORTED_MODULE_2__["queueEnded"])());
  });
  socket.on('play track', (track, user, position) => {
    // we should also set repeat to false!
    store.dispatch(Object(_actions_playbackActions__WEBPACK_IMPORTED_MODULE_3__["playTrack"])(track, user, position));
  });
  socket.on('update users', data => {
    store.dispatch(Object(_actions_usersActions__WEBPACK_IMPORTED_MODULE_1__["updateUsers"])(data));
  });
  socket.on('update now playing', (track, user, position) => {
    store.dispatch(Object(_actions_playbackActions__WEBPACK_IMPORTED_MODULE_3__["updateNowPlaying"])(track, user, position));
  }); // todo: manage end song, end queue
});

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireWildcard.js":
/*!***********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireWildcard.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! ../helpers/typeof */ "./node_modules/@babel/runtime/helpers/typeof.js");

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function _getRequireWildcardCache() {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/typeof.js":
/*!*******************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/typeof.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "./node_modules/next/dist/client/link.js":
/*!***********************************************!*\
  !*** ./node_modules/next/dist/client/link.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "./node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

exports.__esModule = true;
exports.default = void 0;

var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ../next-server/lib/router/router */ "./node_modules/next/dist/next-server/lib/router/router.js");

var _router2 = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

let cachedObserver;
const listeners = new Map();
const IntersectionObserver = false ? undefined : null;
const prefetched = {};

function getObserver() {
  // Return shared instance of IntersectionObserver if already created
  if (cachedObserver) {
    return cachedObserver;
  } // Only create shared IntersectionObserver if supported in browser


  if (!IntersectionObserver) {
    return undefined;
  }

  return cachedObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!listeners.has(entry.target)) {
        return;
      }

      const cb = listeners.get(entry.target);

      if (entry.isIntersecting || entry.intersectionRatio > 0) {
        cachedObserver.unobserve(entry.target);
        listeners.delete(entry.target);
        cb();
      }
    });
  }, {
    rootMargin: '200px'
  });
}

const listenToIntersections = (el, cb) => {
  const observer = getObserver();

  if (!observer) {
    return () => {};
  }

  observer.observe(el);
  listeners.set(el, cb);
  return () => {
    try {
      observer.unobserve(el);
    } catch (err) {
      console.error(err);
    }

    listeners.delete(el);
  };
};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router.isLocalURL)(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (true) {
      // rethrow to show invalid URL errors
      throw err;
    }
  }); // Join on an invalid URI character

  prefetched[href + '%' + as] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
  event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router.isLocalURL)(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null) {
    scroll = as.indexOf('#') < 0;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow
  }).then(success => {
    if (!success) return;

    if (scroll) {
      window.scrollTo(0, 0);
      document.body.focus();
    }
  });
}

function Link(props) {
  if (true) {
    function createPropError(args) {
      return new Error(`Failed prop type: The prop \`${args.key}\` expects a ${args.expected} in \`<Link>\`, but got \`${args.actual}\` instead.` + (false ? undefined : ''));
    } // TypeScript trick for type-guarding:


    const requiredPropsGuard = {
      href: true
    };
    const requiredProps = Object.keys(requiredPropsGuard);
    requiredProps.forEach(key => {
      if (key === 'href') {
        if (props[key] == null || typeof props[key] !== 'string' && typeof props[key] !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: props[key] === null ? 'null' : typeof props[key]
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // TypeScript trick for type-guarding:

    const optionalPropsGuard = {
      as: true,
      replace: true,
      scroll: true,
      shallow: true,
      passHref: true,
      prefetch: true
    };
    const optionalProps = Object.keys(optionalPropsGuard);
    optionalProps.forEach(key => {
      if (key === 'as') {
        if (props[key] && typeof props[key] !== 'string' && typeof props[key] !== 'object') {
          throw createPropError({
            key,
            expected: '`string` or `object`',
            actual: typeof props[key]
          });
        }
      } else if (key === 'replace' || key === 'scroll' || key === 'shallow' || key === 'passHref' || key === 'prefetch') {
        if (props[key] != null && typeof props[key] !== 'boolean') {
          throw createPropError({
            key,
            expected: '`boolean`',
            actual: typeof props[key]
          });
        }
      } else {
        // TypeScript trick for type-guarding:
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const _ = key;
      }
    }); // This hook is in a conditional but that is ok because `process.env.NODE_ENV` never changes
    // eslint-disable-next-line react-hooks/rules-of-hooks

    const hasWarned = _react.default.useRef(false);

    if (props.prefetch && !hasWarned.current) {
      hasWarned.current = true;
      console.warn('Next.js auto-prefetches automatically based on viewport. The prefetch attribute is no longer needed. More: https://err.sh/vercel/next.js/prefetch-true-deprecated');
    }
  }

  const p = props.prefetch !== false;

  const [childElm, setChildElm] = _react.default.useState();

  const router = (0, _router2.useRouter)();
  const pathname = router && router.pathname || '/';

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router.resolveHref)(pathname, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router.resolveHref)(pathname, props.as) : resolvedAs || resolvedHref
    };
  }, [pathname, props.href, props.as]);

  _react.default.useEffect(() => {
    if (p && IntersectionObserver && childElm && childElm.tagName && (0, _router.isLocalURL)(href)) {
      // Join on an invalid URI character
      const isPrefetched = prefetched[href + '%' + as];

      if (!isPrefetched) {
        return listenToIntersections(childElm, () => {
          prefetch(router, href, as);
        });
      }
    }
  }, [p, childElm, href, as, router]);

  let {
    children,
    replace,
    shallow,
    scroll
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  const child = _react.Children.only(children);

  const childProps = {
    ref: el => {
      if (el) setChildElm(el);

      if (child && typeof child === 'object' && child.ref) {
        if (typeof child.ref === 'function') child.ref(el);else if (typeof child.ref === 'object') {
          child.ref.current = el;
        }
      }
    },
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll);
      }
    }
  };

  if (p) {
    childProps.onMouseEnter = e => {
      if (!(0, _router.isLocalURL)(href)) return;

      if (child.props && typeof child.props.onMouseEnter === 'function') {
        child.props.onMouseEnter(e);
      }

      prefetch(router, href, as, {
        priority: true
      });
    };
  } // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    childProps.href = (0, _router.addBasePath)((0, _router.addLocale)(as, router && router.locale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "./node_modules/next/dist/client/normalize-trailing-slash.js":
/*!*******************************************************************!*\
  !*** ./node_modules/next/dist/client/normalize-trailing-slash.js ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;
/**
* Removes the trailing slash of a path if there is one. Preserves the root path `/`.
*/

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}
/**
* Normalizes the trailing slash of a path according to the `trailingSlash` option
* in `next.config.js`.
*/


const normalizePathTrailingSlash =  false ? undefined : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "./node_modules/next/dist/client/router.js":
/*!*************************************************!*\
  !*** ./node_modules/next/dist/client/router.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__(/*! @babel/runtime/helpers/interopRequireWildcard */ "./node_modules/@babel/runtime/helpers/interopRequireWildcard.js");

var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router2 = _interopRequireWildcard(__webpack_require__(/*! ../next-server/lib/router/router */ "./node_modules/next/dist/next-server/lib/router/router.js"));

exports.Router = _router2.default;
exports.NextRouter = _router2.NextRouter;

var _routerContext = __webpack_require__(/*! ../next-server/lib/router-context */ "../next-server/lib/router-context");

var _withRouter = _interopRequireDefault(__webpack_require__(/*! ./with-router */ "./node_modules/next/dist/client/with-router.js"));

exports.withRouter = _withRouter.default;
/* global window */

const singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router2.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because, we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router2.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" inside the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** use inside the server.


const createRouter = (...args) => {
  singletonRouter.router = new _router2.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  const _router = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router[property]) ? [] : {}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/client/with-router.js":
/*!******************************************************!*\
  !*** ./node_modules/next/dist/client/with-router.js ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _router = __webpack_require__(/*! ./router */ "./node_modules/next/dist/client/router.js");

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router.useRouter)()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps // This is needed to allow checking for custom getInitialProps in _app
  ;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (true) {
    const name = ComposedComponent.displayName || ComposedComponent.name || 'Unknown';
    WithRouterWrapper.displayName = `withRouter(${name})`;
  }

  return WithRouterWrapper;
}

/***/ }),

/***/ "./node_modules/next/dist/compiled/path-to-regexp/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/next/dist/compiled/path-to-regexp/index.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Tokenize input string.
 */
function lexer(str) {
    var tokens = [];
    var i = 0;
    while (i < str.length) {
        var char = str[i];
        if (char === "*" || char === "+" || char === "?") {
            tokens.push({ type: "MODIFIER", index: i, value: str[i++] });
            continue;
        }
        if (char === "\\") {
            tokens.push({ type: "ESCAPED_CHAR", index: i++, value: str[i++] });
            continue;
        }
        if (char === "{") {
            tokens.push({ type: "OPEN", index: i, value: str[i++] });
            continue;
        }
        if (char === "}") {
            tokens.push({ type: "CLOSE", index: i, value: str[i++] });
            continue;
        }
        if (char === ":") {
            var name = "";
            var j = i + 1;
            while (j < str.length) {
                var code = str.charCodeAt(j);
                if (
                // `0-9`
                (code >= 48 && code <= 57) ||
                    // `A-Z`
                    (code >= 65 && code <= 90) ||
                    // `a-z`
                    (code >= 97 && code <= 122) ||
                    // `_`
                    code === 95) {
                    name += str[j++];
                    continue;
                }
                break;
            }
            if (!name)
                throw new TypeError("Missing parameter name at " + i);
            tokens.push({ type: "NAME", index: i, value: name });
            i = j;
            continue;
        }
        if (char === "(") {
            var count = 1;
            var pattern = "";
            var j = i + 1;
            if (str[j] === "?") {
                throw new TypeError("Pattern cannot start with \"?\" at " + j);
            }
            while (j < str.length) {
                if (str[j] === "\\") {
                    pattern += str[j++] + str[j++];
                    continue;
                }
                if (str[j] === ")") {
                    count--;
                    if (count === 0) {
                        j++;
                        break;
                    }
                }
                else if (str[j] === "(") {
                    count++;
                    if (str[j + 1] !== "?") {
                        throw new TypeError("Capturing groups are not allowed at " + j);
                    }
                }
                pattern += str[j++];
            }
            if (count)
                throw new TypeError("Unbalanced pattern at " + i);
            if (!pattern)
                throw new TypeError("Missing pattern at " + i);
            tokens.push({ type: "PATTERN", index: i, value: pattern });
            i = j;
            continue;
        }
        tokens.push({ type: "CHAR", index: i, value: str[i++] });
    }
    tokens.push({ type: "END", index: i, value: "" });
    return tokens;
}
/**
 * Parse a string for the raw tokens.
 */
function parse(str, options) {
    if (options === void 0) { options = {}; }
    var tokens = lexer(str);
    var _a = options.prefixes, prefixes = _a === void 0 ? "./" : _a;
    var defaultPattern = "[^" + escapeString(options.delimiter || "/#?") + "]+?";
    var result = [];
    var key = 0;
    var i = 0;
    var path = "";
    var tryConsume = function (type) {
        if (i < tokens.length && tokens[i].type === type)
            return tokens[i++].value;
    };
    var mustConsume = function (type) {
        var value = tryConsume(type);
        if (value !== undefined)
            return value;
        var _a = tokens[i], nextType = _a.type, index = _a.index;
        throw new TypeError("Unexpected " + nextType + " at " + index + ", expected " + type);
    };
    var consumeText = function () {
        var result = "";
        var value;
        // tslint:disable-next-line
        while ((value = tryConsume("CHAR") || tryConsume("ESCAPED_CHAR"))) {
            result += value;
        }
        return result;
    };
    while (i < tokens.length) {
        var char = tryConsume("CHAR");
        var name = tryConsume("NAME");
        var pattern = tryConsume("PATTERN");
        if (name || pattern) {
            var prefix = char || "";
            if (prefixes.indexOf(prefix) === -1) {
                path += prefix;
                prefix = "";
            }
            if (path) {
                result.push(path);
                path = "";
            }
            result.push({
                name: name || key++,
                prefix: prefix,
                suffix: "",
                pattern: pattern || defaultPattern,
                modifier: tryConsume("MODIFIER") || ""
            });
            continue;
        }
        var value = char || tryConsume("ESCAPED_CHAR");
        if (value) {
            path += value;
            continue;
        }
        if (path) {
            result.push(path);
            path = "";
        }
        var open = tryConsume("OPEN");
        if (open) {
            var prefix = consumeText();
            var name_1 = tryConsume("NAME") || "";
            var pattern_1 = tryConsume("PATTERN") || "";
            var suffix = consumeText();
            mustConsume("CLOSE");
            result.push({
                name: name_1 || (pattern_1 ? key++ : ""),
                pattern: name_1 && !pattern_1 ? defaultPattern : pattern_1,
                prefix: prefix,
                suffix: suffix,
                modifier: tryConsume("MODIFIER") || ""
            });
            continue;
        }
        mustConsume("END");
    }
    return result;
}
exports.parse = parse;
/**
 * Compile a string to a template function for the path.
 */
function compile(str, options) {
    return tokensToFunction(parse(str, options), options);
}
exports.compile = compile;
/**
 * Expose a method for transforming tokens into the path function.
 */
function tokensToFunction(tokens, options) {
    if (options === void 0) { options = {}; }
    var reFlags = flags(options);
    var _a = options.encode, encode = _a === void 0 ? function (x) { return x; } : _a, _b = options.validate, validate = _b === void 0 ? true : _b;
    // Compile all the tokens into regexps.
    var matches = tokens.map(function (token) {
        if (typeof token === "object") {
            return new RegExp("^(?:" + token.pattern + ")$", reFlags);
        }
    });
    return function (data) {
        var path = "";
        for (var i = 0; i < tokens.length; i++) {
            var token = tokens[i];
            if (typeof token === "string") {
                path += token;
                continue;
            }
            var value = data ? data[token.name] : undefined;
            var optional = token.modifier === "?" || token.modifier === "*";
            var repeat = token.modifier === "*" || token.modifier === "+";
            if (Array.isArray(value)) {
                if (!repeat) {
                    throw new TypeError("Expected \"" + token.name + "\" to not repeat, but got an array");
                }
                if (value.length === 0) {
                    if (optional)
                        continue;
                    throw new TypeError("Expected \"" + token.name + "\" to not be empty");
                }
                for (var j = 0; j < value.length; j++) {
                    var segment = encode(value[j], token);
                    if (validate && !matches[i].test(segment)) {
                        throw new TypeError("Expected all \"" + token.name + "\" to match \"" + token.pattern + "\", but got \"" + segment + "\"");
                    }
                    path += token.prefix + segment + token.suffix;
                }
                continue;
            }
            if (typeof value === "string" || typeof value === "number") {
                var segment = encode(String(value), token);
                if (validate && !matches[i].test(segment)) {
                    throw new TypeError("Expected \"" + token.name + "\" to match \"" + token.pattern + "\", but got \"" + segment + "\"");
                }
                path += token.prefix + segment + token.suffix;
                continue;
            }
            if (optional)
                continue;
            var typeOfMessage = repeat ? "an array" : "a string";
            throw new TypeError("Expected \"" + token.name + "\" to be " + typeOfMessage);
        }
        return path;
    };
}
exports.tokensToFunction = tokensToFunction;
/**
 * Create path match function from `path-to-regexp` spec.
 */
function match(str, options) {
    var keys = [];
    var re = pathToRegexp(str, keys, options);
    return regexpToFunction(re, keys, options);
}
exports.match = match;
/**
 * Create a path match function from `path-to-regexp` output.
 */
function regexpToFunction(re, keys, options) {
    if (options === void 0) { options = {}; }
    var _a = options.decode, decode = _a === void 0 ? function (x) { return x; } : _a;
    return function (pathname) {
        var m = re.exec(pathname);
        if (!m)
            return false;
        var path = m[0], index = m.index;
        var params = Object.create(null);
        var _loop_1 = function (i) {
            // tslint:disable-next-line
            if (m[i] === undefined)
                return "continue";
            var key = keys[i - 1];
            if (key.modifier === "*" || key.modifier === "+") {
                params[key.name] = m[i].split(key.prefix + key.suffix).map(function (value) {
                    return decode(value, key);
                });
            }
            else {
                params[key.name] = decode(m[i], key);
            }
        };
        for (var i = 1; i < m.length; i++) {
            _loop_1(i);
        }
        return { path: path, index: index, params: params };
    };
}
exports.regexpToFunction = regexpToFunction;
/**
 * Escape a regular expression string.
 */
function escapeString(str) {
    return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
/**
 * Get the flags for a regexp from the options.
 */
function flags(options) {
    return options && options.sensitive ? "" : "i";
}
/**
 * Pull out keys from a regexp.
 */
function regexpToRegexp(path, keys) {
    if (!keys)
        return path;
    // Use a negative lookahead to match only capturing groups.
    var groups = path.source.match(/\((?!\?)/g);
    if (groups) {
        for (var i = 0; i < groups.length; i++) {
            keys.push({
                name: i,
                prefix: "",
                suffix: "",
                modifier: "",
                pattern: ""
            });
        }
    }
    return path;
}
/**
 * Transform an array into a regexp.
 */
function arrayToRegexp(paths, keys, options) {
    var parts = paths.map(function (path) { return pathToRegexp(path, keys, options).source; });
    return new RegExp("(?:" + parts.join("|") + ")", flags(options));
}
/**
 * Create a path regexp from string input.
 */
function stringToRegexp(path, keys, options) {
    return tokensToRegexp(parse(path, options), keys, options);
}
/**
 * Expose a function for taking tokens and returning a RegExp.
 */
function tokensToRegexp(tokens, keys, options) {
    if (options === void 0) { options = {}; }
    var _a = options.strict, strict = _a === void 0 ? false : _a, _b = options.start, start = _b === void 0 ? true : _b, _c = options.end, end = _c === void 0 ? true : _c, _d = options.encode, encode = _d === void 0 ? function (x) { return x; } : _d;
    var endsWith = "[" + escapeString(options.endsWith || "") + "]|$";
    var delimiter = "[" + escapeString(options.delimiter || "/#?") + "]";
    var route = start ? "^" : "";
    // Iterate over the tokens and create our regexp string.
    for (var _i = 0, tokens_1 = tokens; _i < tokens_1.length; _i++) {
        var token = tokens_1[_i];
        if (typeof token === "string") {
            route += escapeString(encode(token));
        }
        else {
            var prefix = escapeString(encode(token.prefix));
            var suffix = escapeString(encode(token.suffix));
            if (token.pattern) {
                if (keys)
                    keys.push(token);
                if (prefix || suffix) {
                    if (token.modifier === "+" || token.modifier === "*") {
                        var mod = token.modifier === "*" ? "?" : "";
                        route += "(?:" + prefix + "((?:" + token.pattern + ")(?:" + suffix + prefix + "(?:" + token.pattern + "))*)" + suffix + ")" + mod;
                    }
                    else {
                        route += "(?:" + prefix + "(" + token.pattern + ")" + suffix + ")" + token.modifier;
                    }
                }
                else {
                    route += "(" + token.pattern + ")" + token.modifier;
                }
            }
            else {
                route += "(?:" + prefix + suffix + ")" + token.modifier;
            }
        }
    }
    if (end) {
        if (!strict)
            route += delimiter + "?";
        route += !options.endsWith ? "$" : "(?=" + endsWith + ")";
    }
    else {
        var endToken = tokens[tokens.length - 1];
        var isEndDelimited = typeof endToken === "string"
            ? delimiter.indexOf(endToken[endToken.length - 1]) > -1
            : // tslint:disable-next-line
                endToken === undefined;
        if (!strict) {
            route += "(?:" + delimiter + "(?=" + endsWith + "))?";
        }
        if (!isEndDelimited) {
            route += "(?=" + delimiter + "|" + endsWith + ")";
        }
    }
    return new RegExp(route, flags(options));
}
exports.tokensToRegexp = tokensToRegexp;
/**
 * Normalize the given path string, returning a regular expression.
 *
 * An empty array can be passed in for the keys, which will hold the
 * placeholder key descriptions. For example, using `/user/:id`, `keys` will
 * contain `[{ name: 'id', delimiter: '/', optional: false, repeat: false }]`.
 */
function pathToRegexp(path, keys, options) {
    if (path instanceof RegExp)
        return regexpToRegexp(path, keys);
    if (Array.isArray(path))
        return arrayToRegexp(path, keys, options);
    return stringToRegexp(path, keys, options);
}
exports.pathToRegexp = pathToRegexp;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/mitt.js":
/*!********************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/mitt.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = mitt;
/*
MIT License
Copyright (c) Jason Miller (https://jasonformat.com/)
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// This file is based on https://github.com/developit/mitt/blob/v1.1.3/src/index.js
// It's been edited for the needs of this script
// See the LICENSE at the top of the file

function mitt() {
  const all = Object.create(null);
  return {
    on(type, handler) {
      ;
      (all[type] || (all[type] = [])).push(handler);
    },

    off(type, handler) {
      if (all[type]) {
        all[type].splice(all[type].indexOf(handler) >>> 0, 1);
      }
    },

    emit(type, ...evts) {
      // eslint-disable-next-line array-callback-return
      ;
      (all[type] || []).slice().map(handler => {
        handler(...evts);
      });
    }

  };
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/router.js":
/*!*****************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/router.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.markLoadingError = markLoadingError;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__(/*! ../../../client/normalize-trailing-slash */ "./node_modules/next/dist/client/normalize-trailing-slash.js");

var _denormalizePagePath = __webpack_require__(/*! ../../server/denormalize-page-path */ "./node_modules/next/dist/next-server/server/denormalize-page-path.js");

var _mitt = _interopRequireDefault(__webpack_require__(/*! ../mitt */ "./node_modules/next/dist/next-server/lib/mitt.js"));

var _utils = __webpack_require__(/*! ../utils */ "./node_modules/next/dist/next-server/lib/utils.js");

var _isDynamic = __webpack_require__(/*! ./utils/is-dynamic */ "./node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js");

var _parseRelativeUrl = __webpack_require__(/*! ./utils/parse-relative-url */ "./node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js");

var _querystring = __webpack_require__(/*! ./utils/querystring */ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js");

var _resolveRewrites = _interopRequireDefault(__webpack_require__(/*! ./utils/resolve-rewrites */ "./node_modules/next/dist/next-server/lib/router/utils/resolve-rewrites.js"));

var _routeMatcher = __webpack_require__(/*! ./utils/route-matcher */ "./node_modules/next/dist/next-server/lib/router/utils/route-matcher.js");

var _routeRegex = __webpack_require__(/*! ./utils/route-regex */ "./node_modules/next/dist/next-server/lib/router/utils/route-regex.js");

var _escapePathDelimiters = _interopRequireDefault(__webpack_require__(/*! ./utils/escape-path-delimiters */ "./node_modules/next/dist/next-server/lib/router/utils/escape-path-delimiters.js"));

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}
/* global __NEXT_DATA__ */
// tslint:disable:no-console


const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(prefix) : `${prefix}${path}` : path;
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function hasBasePath(path) {
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  return path.slice(basePath.length) || '/';
}
/**
* Detects whether a given url is routable by the Next.js router (browser only).
*/


function isLocalURL(url) {
  if (url.startsWith('/')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils.getLocationOrigin)();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex.getRouteRegex)(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher.getRouteMatcher)(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && ( // Interpolate group into data URL if present
    interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map(_escapePathDelimiters.default).join('/') : (0, _escapePathDelimiters.default)(value)) || '/');
  })) {
    interpolatedRoute = ''; // did not satisfy all requirements
    // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}
/**
* Resolves a given hyperlink with a certain router state (basePath not included).
* Preserves absolute urls.
*/


function resolveHref(currentPath, href, resolveAs) {
  // we use a dummy base url for relative urls
  const base = new URL(currentPath, 'http://n');
  const urlAsString = typeof href === 'string' ? href : (0, _utils.formatWithValidation)(href);

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic.isDynamicRoute)(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring.searchParamsToUrlQuery)(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils.formatWithValidation)({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

const PAGE_LOAD_ERROR = Symbol('PAGE_LOAD_ERROR');

function markLoadingError(err) {
  return Object.defineProperty(err, PAGE_LOAD_ERROR, {});
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  return {
    url: addBasePath(resolveHref(router.pathname, url)),
    as: as ? addBasePath(resolveHref(router.pathname, as)) : as
  };
}

const manualScrollRestoration =  false && false;

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      markLoadingError(err);
    }

    throw err;
  });
}

class Router {
  /**
  * Map of all components loaded in `Router`
  */
  // Static Data Cache
  constructor(_pathname, _query, _as, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component,
    initialStyleSheets,
    err,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale
  }) {
    this.route = void 0;
    this.pathname = void 0;
    this.query = void 0;
    this.asPath = void 0;
    this.basePath = void 0;
    this.components = void 0;
    this.sdc = {};
    this.sub = void 0;
    this.clc = void 0;
    this.pageLoader = void 0;
    this._bps = void 0;
    this.events = void 0;
    this._wrapApp = void 0;
    this.isSsr = void 0;
    this.isFallback = void 0;
    this._inFlightRoute = void 0;
    this._shallow = void 0;
    this.locale = void 0;
    this.locales = void 0;
    this.defaultLocale = void 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname,
          query
        } = this;
        this.changeState('replaceState', (0, _utils.formatWithValidation)({
          pathname: addBasePath(pathname),
          query
        }), (0, _utils.getURL)());
        return;
      }

      if (!state.__N) {
        return;
      }

      const {
        url,
        as,
        options
      } = state;
      const {
        pathname
      } = (0, _parseRelativeUrl.parseRelativeUrl)(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as === this.asPath && pathname === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as, Object.assign({}, options, {
        shallow: options.shallow && this._shallow
      }));
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(_pathname); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (_pathname !== '/_error') {
      this.components[this.route] = {
        Component,
        styleSheets: initialStyleSheets,
        props: initialProps,
        err,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: [
        /* /_app does not need its stylesheets managed */
      ]
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = _pathname;
    this.query = _query; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    this.asPath = // @ts-ignore this is temporarily global (attached to window)
    (0, _isDynamic.isDynamicRoute)(_pathname) && __NEXT_DATA__.autoExport ? _pathname : _as;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as = url, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as = url, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options) {
    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute);
    }

    as = addLocale(as, this.locale, this.defaultLocale);
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs)) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route]);
      Router.events.emit('hashChangeComplete', as);
      return true;
    } // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to


    const pages = await this.pageLoader.getPageList();
    const {
      __rewrites: rewrites
    } = await this.pageLoader.promisedBuildManifest;
    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname,
      query
    } = parsed;
    parsed = this._resolveHref(parsed, pages);

    if (parsed.pathname !== pathname) {
      pathname = parsed.pathname;
      url = (0, _utils.formatWithValidation)(parsed);
    } // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1


    pathname = pathname ? (0, _normalizeTrailingSlash.removePathTrailingSlash)(delBasePath(pathname)) : pathname; // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url

    if (!this.urlIsNew(cleanedAs)) {
      method = 'replaceState';
    }

    let route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
    const {
      shallow = false
    } = options; // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly

    let resolvedAs = as;

    if (true) {
      resolvedAs = (0, _resolveRewrites.default)((0, _parseRelativeUrl.parseRelativeUrl)(as).pathname, pages, basePath, rewrites, query, p => this._resolveHref({
        pathname: p
      }, pages).pathname);

      if (resolvedAs !== as) {
        const potentialHref = (0, _normalizeTrailingSlash.removePathTrailingSlash)(this._resolveHref(Object.assign({}, parsed, {
          pathname: resolvedAs
        }), pages, false).pathname); // if this directly matches a page we need to update the href to
        // allow the correct page chunk to be loaded

        if (pages.includes(potentialHref)) {
          route = potentialHref;
          pathname = potentialHref;
          parsed.pathname = pathname;
          url = (0, _utils.formatWithValidation)(parsed);
        }
      }
    }

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic.isDynamicRoute)(route)) {
      const parsedAs = (0, _parseRelativeUrl.parseRelativeUrl)(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex.getRouteRegex)(route);
      const routeMatch = (0, _routeMatcher.getRouteMatcher)(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query[param]);

        if (missingParams.length > 0) {
          if (true) {
            console.warn(`${shouldInterpolate ? `Interpolating href` : `Mismatching \`as\` and \`href\``} failed to manually provide ` + `the params: ${missingParams.join(', ')} in the \`href\`'s \`query\``);
          }

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://err.sh/vercel/next.js/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils.formatWithValidation)(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as);

    try {
      const routeInfo = await this.getRouteInfo(route, pathname, query, as, shallow);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props && props.pageProps && props.pageProps.__N_REDIRECT) {
        const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
        // client-navigation if it is falling back to hard navigation if
        // it's not

        if (destination.startsWith('/')) {
          const parsedHref = (0, _parseRelativeUrl.parseRelativeUrl)(destination);

          this._resolveHref(parsedHref, pages);

          if (pages.includes(parsedHref.pathname)) {
            return this.change('replaceState', destination, destination, options);
          }
        }

        window.location.href = destination;
        return new Promise(() => {});
      }

      Router.events.emit('beforeHistoryChange', as);
      this.changeState(method, url, addLocale(as, this.locale, this.defaultLocale), options);

      if (true) {
        const appComp = this.components['/_app'].Component;
        window.next.isPrerendered = appComp.getInitialProps === appComp.origGetInitialProps && !routeInfo.Component.getInitialProps;
      }

      await this.set(route, pathname, query, cleanedAs, routeInfo).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs);
        throw error;
      }

      if (false) {}

      Router.events.emit('routeChangeComplete', as);
      return true;
    } catch (err) {
      if (err.cancelled) {
        return false;
      }

      throw err;
    }
  }

  changeState(method, url, as, options = {}) {
    if (true) {
      if (typeof window.history === 'undefined') {
        console.error(`Warning: window.history is not available.`);
        return;
      }

      if (typeof window.history[method] === 'undefined') {
        console.error(`Warning: window.history.${method} is not available`);
        return;
      }
    }

    if (method !== 'pushState' || (0, _utils.getURL)() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if (PAGE_LOAD_ERROR in err || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      const {
        page: Component,
        styleSheets
      } = await this.fetchComponent('/_error');
      const routeInfo = {
        Component,
        styleSheets,
        err,
        error: err
      };

      try {
        routeInfo.props = await this.getInitialProps(Component, {
          err,
          pathname,
          query
        });
      } catch (gipErr) {
        console.error('Error in error page `getInitialProps`: ', gipErr);
        routeInfo.props = {};
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, shallow = false) {
    try {
      const cachedRouteInfo = this.components[route];

      if (shallow && cachedRouteInfo && this.route === route) {
        return cachedRouteInfo;
      }

      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (true) {
        const {
          isValidElementType
        } = __webpack_require__(/*! react-is */ "react-is");

        if (!isValidElementType(Component)) {
          throw new Error(`The default export is not a React Component in page: "${pathname}"`);
        }
      }

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils.formatWithValidation)({
          pathname,
          query
        }), delBasePath(as), __N_SSG, this.locale, this.defaultLocale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err) {
      return this.handleRouteInfoError(err, pathname, query, as);
    }
  }

  set(route, pathname, query, as, data) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value

    if (hash === '') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }

  _resolveHref(parsedHref, pages, applyBasePath = true) {
    const {
      pathname
    } = parsedHref;
    const cleanPathname = (0, _normalizeTrailingSlash.removePathTrailingSlash)((0, _denormalizePagePath.denormalizePagePath)(applyBasePath ? delBasePath(pathname) : pathname));

    if (cleanPathname === '/404' || cleanPathname === '/_error') {
      return parsedHref;
    } // handle resolving href for dynamic routes


    if (!pages.includes(cleanPathname)) {
      // eslint-disable-next-line array-callback-return
      pages.some(page => {
        if ((0, _isDynamic.isDynamicRoute)(page) && (0, _routeRegex.getRouteRegex)(page).re.test(cleanPathname)) {
          parsedHref.pathname = applyBasePath ? addBasePath(page) : page;
          return true;
        }
      });
    }

    return parsedHref;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname
    } = parsed;
    const pages = await this.pageLoader.getPageList();
    parsed = this._resolveHref(parsed, pages);

    if (parsed.pathname !== pathname) {
      pathname = parsed.pathname;
      url = (0, _utils.formatWithValidation)(parsed);
    } // Prefetch is not supported in development mode because it would trigger on-demand-entries


    if (true) {
      return;
    }

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
    await Promise.all([this.pageLoader.prefetchData(url, asPath, this.locale, this.defaultLocale), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err = new Error('Loading initial props cancelled');
        err.cancelled = true;
        throw err;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if (false) {}

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    return fetchNextData(dataHref, this.isSsr);
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App);

    ctx.AppTree = AppTree;
    return (0, _utils.loadGetInitialProps)(App, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as);
      this.clc();
      this.clc = null;
    }
  }

  notify(data) {
    return this.sub(data, this.components['/_app'].Component);
  }

}

exports.default = Router;
Router.events = (0, _mitt.default)();

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/escape-path-delimiters.js":
/*!***************************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/escape-path-delimiters.js ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = escapePathDelimiters; // escape delimiters used by path-to-regexp

function escapePathDelimiters(segment) {
  return segment.replace(/[/#?]/g, char => encodeURIComponent(char));
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/format-url.js":
/*!***************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/format-url.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.formatUrl = formatUrl;

var querystring = _interopRequireWildcard(__webpack_require__(/*! ./querystring */ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
} // Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


const slashedProtocols = /https?|ftp|gopher|file/;

function formatUrl(urlObj) {
  let {
    auth,
    hostname
  } = urlObj;
  let protocol = urlObj.protocol || '';
  let pathname = urlObj.pathname || '';
  let hash = urlObj.hash || '';
  let query = urlObj.query || '';
  let host = false;
  auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';

  if (urlObj.host) {
    host = auth + urlObj.host;
  } else if (hostname) {
    host = auth + (~hostname.indexOf(':') ? `[${hostname}]` : hostname);

    if (urlObj.port) {
      host += ':' + urlObj.port;
    }
  }

  if (query && typeof query === 'object') {
    query = String(querystring.urlQueryToSearchParams(query));
  }

  let search = urlObj.search || query && `?${query}` || '';
  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash[0] !== '#') hash = '#' + hash;
  if (search && search[0] !== '?') search = '?' + search;
  pathname = pathname.replace(/[?#]/g, encodeURIComponent);
  search = search.replace('#', '%23');
  return `${protocol}${host}${pathname}${search}${hash}`;
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js":
/*!***************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/is-dynamic.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.isDynamicRoute = isDynamicRoute; // Identify /[param]/ in route string

const TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;

function isDynamicRoute(route) {
  return TEST_ROUTE.test(route);
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js":
/*!***********************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.parseRelativeUrl = parseRelativeUrl;

var _utils = __webpack_require__(/*! ../../utils */ "./node_modules/next/dist/next-server/lib/utils.js");

var _querystring = __webpack_require__(/*! ./querystring */ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js");

const DUMMY_BASE = new URL(true ? 'http://n' : undefined);
/**
* Parses path-relative urls (e.g. `/hello/world?foo=bar`). If url isn't path-relative
* (e.g. `./hello`) then at least base must be.
* Absolute urls are rejected with one exception, in the browser, absolute urls that are on
* the current origin will be parsed as relative
*/

function parseRelativeUrl(url, base) {
  const resolvedBase = base ? new URL(base, DUMMY_BASE) : DUMMY_BASE;
  const {
    pathname,
    searchParams,
    search,
    hash,
    href,
    origin,
    protocol
  } = new URL(url, resolvedBase);

  if (origin !== DUMMY_BASE.origin || protocol !== 'http:' && protocol !== 'https:') {
    throw new Error('invariant: invalid relative URL');
  }

  return {
    pathname,
    query: (0, _querystring.searchParamsToUrlQuery)(searchParams),
    search,
    hash,
    href: href.slice(DUMMY_BASE.origin.length)
  };
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/path-match.js":
/*!***************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/path-match.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.__esModule = true;
exports.pathToRegexp = exports.default = exports.customRouteMatcherOptions = exports.matcherOptions = void 0;

var pathToRegexp = _interopRequireWildcard(__webpack_require__(/*! next/dist/compiled/path-to-regexp */ "./node_modules/next/dist/compiled/path-to-regexp/index.js"));

exports.pathToRegexp = pathToRegexp;

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

const matcherOptions = {
  sensitive: false,
  delimiter: '/'
};
exports.matcherOptions = matcherOptions;

const customRouteMatcherOptions = _objectSpread(_objectSpread({}, matcherOptions), {}, {
  strict: true
});

exports.customRouteMatcherOptions = customRouteMatcherOptions;

var _default = (customRoute = false) => {
  return path => {
    const keys = [];
    const matcherRegex = pathToRegexp.pathToRegexp(path, keys, customRoute ? customRouteMatcherOptions : matcherOptions);
    const matcher = pathToRegexp.regexpToFunction(matcherRegex, keys);
    return (pathname, params) => {
      const res = pathname == null ? false : matcher(pathname);

      if (!res) {
        return false;
      }

      if (customRoute) {
        for (const key of keys) {
          // unnamed params should be removed as they
          // are not allowed to be used in the destination
          if (typeof key.name === 'number') {
            delete res.params[key.name];
          }
        }
      }

      return _objectSpread(_objectSpread({}, params), res.params);
    };
  };
};

exports.default = _default;

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/prepare-destination.js":
/*!************************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/prepare-destination.js ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.__esModule = true;
exports.default = prepareDestination;

var _querystring = __webpack_require__(/*! ./querystring */ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js");

var _parseRelativeUrl = __webpack_require__(/*! ./parse-relative-url */ "./node_modules/next/dist/next-server/lib/router/utils/parse-relative-url.js");

var pathToRegexp = _interopRequireWildcard(__webpack_require__(/*! next/dist/compiled/path-to-regexp */ "./node_modules/next/dist/compiled/path-to-regexp/index.js"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

function prepareDestination(destination, params, query, appendParamsToQuery, basePath) {
  let parsedDestination = {};

  if (destination.startsWith('/')) {
    parsedDestination = (0, _parseRelativeUrl.parseRelativeUrl)(destination);
  } else {
    const {
      pathname,
      searchParams,
      hash,
      hostname,
      port,
      protocol,
      search,
      href
    } = new URL(destination);
    parsedDestination = {
      pathname,
      query: (0, _querystring.searchParamsToUrlQuery)(searchParams),
      hash,
      protocol,
      hostname,
      port,
      search,
      href
    };
  }

  const destQuery = parsedDestination.query;
  const destPath = `${parsedDestination.pathname}${parsedDestination.hash || ''}`;
  const destPathParamKeys = [];
  pathToRegexp.pathToRegexp(destPath, destPathParamKeys);
  const destPathParams = destPathParamKeys.map(key => key.name);
  let destinationCompiler = pathToRegexp.compile(destPath, // we don't validate while compiling the destination since we should
  // have already validated before we got to this point and validating
  // breaks compiling destinations with named pattern params from the source
  // e.g. /something:hello(.*) -> /another/:hello is broken with validation
  // since compile validation is meant for reversing and not for inserting
  // params from a separate path-regex into another
  {
    validate: false
  });
  let newUrl; // update any params in query values

  for (const [key, strOrArray] of Object.entries(destQuery)) {
    let value = Array.isArray(strOrArray) ? strOrArray[0] : strOrArray;

    if (value) {
      // the value needs to start with a forward-slash to be compiled
      // correctly
      value = `/${value}`;
      const queryCompiler = pathToRegexp.compile(value, {
        validate: false
      });
      value = queryCompiler(params).substr(1);
    }

    destQuery[key] = value;
  } // add path params to query if it's not a redirect and not
  // already defined in destination query or path


  const paramKeys = Object.keys(params);

  if (appendParamsToQuery && !paramKeys.some(key => destPathParams.includes(key))) {
    for (const key of paramKeys) {
      if (!(key in destQuery)) {
        destQuery[key] = params[key];
      }
    }
  }

  const shouldAddBasePath = destination.startsWith('/') && basePath;

  try {
    newUrl = `${shouldAddBasePath ? basePath : ''}${destinationCompiler(params)}`;
    const [pathname, hash] = newUrl.split('#');
    parsedDestination.pathname = pathname;
    parsedDestination.hash = `${hash ? '#' : ''}${hash || ''}`;
    delete parsedDestination.search;
  } catch (err) {
    if (err.message.match(/Expected .*? to not repeat, but got an array/)) {
      throw new Error(`To use a multi-match in the destination you must add \`*\` at the end of the param name to signify it should repeat. https://err.sh/vercel/next.js/invalid-multi-match`);
    }

    throw err;
  } // Query merge order lowest priority to highest
  // 1. initial URL query values
  // 2. path segment values
  // 3. destination specified query values


  parsedDestination.query = _objectSpread(_objectSpread({}, query), parsedDestination.query);
  return {
    newUrl,
    parsedDestination
  };
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/querystring.js":
/*!****************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/querystring.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.searchParamsToUrlQuery = searchParamsToUrlQuery;
exports.urlQueryToSearchParams = urlQueryToSearchParams;
exports.assign = assign;

function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === 'undefined') {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [query[key], value];
    }
  });
  return query;
}

function stringifyUrlQueryParam(param) {
  if (typeof param === 'string' || typeof param === 'number' && !isNaN(param) || typeof param === 'boolean') {
    return String(param);
  } else {
    return '';
  }
}

function urlQueryToSearchParams(urlQuery) {
  const result = new URLSearchParams();
  Object.entries(urlQuery).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach(item => result.append(key, stringifyUrlQueryParam(item)));
    } else {
      result.set(key, stringifyUrlQueryParam(value));
    }
  });
  return result;
}

function assign(target, ...searchParamsList) {
  searchParamsList.forEach(searchParams => {
    Array.from(searchParams.keys()).forEach(key => target.delete(key));
    searchParams.forEach((value, key) => target.append(key, value));
  });
  return target;
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/resolve-rewrites.js":
/*!*********************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/resolve-rewrites.js ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = resolveRewrites;

var _pathMatch = _interopRequireDefault(__webpack_require__(/*! ./path-match */ "./node_modules/next/dist/next-server/lib/router/utils/path-match.js"));

var _prepareDestination = _interopRequireDefault(__webpack_require__(/*! ./prepare-destination */ "./node_modules/next/dist/next-server/lib/router/utils/prepare-destination.js"));

var _normalizeTrailingSlash = __webpack_require__(/*! ../../../../client/normalize-trailing-slash */ "./node_modules/next/dist/client/normalize-trailing-slash.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

const customRouteMatcher = (0, _pathMatch.default)(true);

function resolveRewrites(asPath, pages, basePath, rewrites, query, resolveHref) {
  if (!pages.includes(asPath)) {
    for (const rewrite of rewrites) {
      const matcher = customRouteMatcher(rewrite.source);
      const params = matcher(asPath);

      if (params) {
        if (!rewrite.destination) {
          // this is a proxied rewrite which isn't handled on the client
          break;
        }

        const destRes = (0, _prepareDestination.default)(rewrite.destination, params, query, true, rewrite.basePath === false ? '' : basePath);
        asPath = destRes.parsedDestination.pathname;
        Object.assign(query, destRes.parsedDestination.query);

        if (pages.includes((0, _normalizeTrailingSlash.removePathTrailingSlash)(asPath))) {
          // check if we now match a page as this means we are done
          // resolving the rewrites
          break;
        } // check if we match a dynamic-route, if so we break the rewrites chain


        const resolvedHref = resolveHref(asPath);

        if (resolvedHref !== asPath && pages.includes(resolvedHref)) {
          break;
        }
      }
    }
  }

  return asPath;
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/route-matcher.js":
/*!******************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/route-matcher.js ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteMatcher = getRouteMatcher;

function getRouteMatcher(routeRegex) {
  const {
    re,
    groups
  } = routeRegex;
  return pathname => {
    const routeMatch = re.exec(pathname);

    if (!routeMatch) {
      return false;
    }

    const decode = param => {
      try {
        return decodeURIComponent(param);
      } catch (_) {
        const err = new Error('failed to decode param');
        err.code = 'DECODE_FAILED';
        throw err;
      }
    };

    const params = {};
    Object.keys(groups).forEach(slugName => {
      const g = groups[slugName];
      const m = routeMatch[g.pos];

      if (m !== undefined) {
        params[slugName] = ~m.indexOf('/') ? m.split('/').map(entry => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
      }
    });
    return params;
  };
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/router/utils/route-regex.js":
/*!****************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/router/utils/route-regex.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteRegex = getRouteRegex; // this isn't importing the escape-string-regex module
// to reduce bytes

function escapeRegex(str) {
  return str.replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&');
}

function parseParameter(param) {
  const optional = param.startsWith('[') && param.endsWith(']');

  if (optional) {
    param = param.slice(1, -1);
  }

  const repeat = param.startsWith('...');

  if (repeat) {
    param = param.slice(3);
  }

  return {
    key: param,
    repeat,
    optional
  };
}

function getRouteRegex(normalizedRoute) {
  const segments = (normalizedRoute.replace(/\/$/, '') || '/').slice(1).split('/');
  const groups = {};
  let groupIndex = 1;
  const parameterizedRoute = segments.map(segment => {
    if (segment.startsWith('[') && segment.endsWith(']')) {
      const {
        key,
        optional,
        repeat
      } = parseParameter(segment.slice(1, -1));
      groups[key] = {
        pos: groupIndex++,
        repeat,
        optional
      };
      return repeat ? optional ? '(?:/(.+?))?' : '/(.+?)' : '/([^/]+?)';
    } else {
      return `/${escapeRegex(segment)}`;
    }
  }).join(''); // dead code eliminate for browser since it's only needed
  // while generating routes-manifest

  if (true) {
    let routeKeyCharCode = 97;
    let routeKeyCharLength = 1; // builds a minimal routeKey using only a-z and minimal number of characters

    const getSafeRouteKey = () => {
      let routeKey = '';

      for (let i = 0; i < routeKeyCharLength; i++) {
        routeKey += String.fromCharCode(routeKeyCharCode);
        routeKeyCharCode++;

        if (routeKeyCharCode > 122) {
          routeKeyCharLength++;
          routeKeyCharCode = 97;
        }
      }

      return routeKey;
    };

    const routeKeys = {};
    let namedParameterizedRoute = segments.map(segment => {
      if (segment.startsWith('[') && segment.endsWith(']')) {
        const {
          key,
          optional,
          repeat
        } = parseParameter(segment.slice(1, -1)); // replace any non-word characters since they can break
        // the named regex

        let cleanedKey = key.replace(/\W/g, '');
        let invalidKey = false; // check if the key is still invalid and fallback to using a known
        // safe key

        if (cleanedKey.length === 0 || cleanedKey.length > 30) {
          invalidKey = true;
        }

        if (!isNaN(parseInt(cleanedKey.substr(0, 1)))) {
          invalidKey = true;
        }

        if (invalidKey) {
          cleanedKey = getSafeRouteKey();
        }

        routeKeys[cleanedKey] = key;
        return repeat ? optional ? `(?:/(?<${cleanedKey}>.+?))?` : `/(?<${cleanedKey}>.+?)` : `/(?<${cleanedKey}>[^/]+?)`;
      } else {
        return `/${escapeRegex(segment)}`;
      }
    }).join('');
    return {
      re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
      groups,
      routeKeys,
      namedRegex: `^${namedParameterizedRoute}(?:/)?$`
    };
  }

  return {
    re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
    groups
  };
}

/***/ }),

/***/ "./node_modules/next/dist/next-server/lib/utils.js":
/*!*********************************************************!*\
  !*** ./node_modules/next/dist/next-server/lib/utils.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.execOnce = execOnce;
exports.getLocationOrigin = getLocationOrigin;
exports.getURL = getURL;
exports.getDisplayName = getDisplayName;
exports.isResSent = isResSent;
exports.loadGetInitialProps = loadGetInitialProps;
exports.formatWithValidation = formatWithValidation;
exports.ST = exports.SP = exports.urlObjectKeys = void 0;

var _formatUrl = __webpack_require__(/*! ./router/utils/format-url */ "./node_modules/next/dist/next-server/lib/router/utils/format-url.js");
/**
* Utils
*/


function execOnce(fn) {
  let used = false;
  let result;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn(...args);
    }

    return result;
  };
}

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

function isResSent(res) {
  return res.finished || res.headersSent;
}

async function loadGetInitialProps(App, ctx) {
  if (true) {
    var _App$prototype;

    if ((_App$prototype = App.prototype) == null ? void 0 : _App$prototype.getInitialProps) {
      const message = `"${getDisplayName(App)}.getInitialProps()" is defined as an instance method - visit https://err.sh/vercel/next.js/get-initial-props-as-an-instance-method for more information.`;
      throw new Error(message);
    }
  } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (true) {
    if (Object.keys(props).length === 0 && !ctx.ctx) {
      console.warn(`${getDisplayName(App)} returned an empty object from \`getInitialProps\`. This de-optimizes and prevents automatic static optimization. https://err.sh/vercel/next.js/empty-object-getInitialProps`);
    }
  }

  return props;
}

const urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];
exports.urlObjectKeys = urlObjectKeys;

function formatWithValidation(url) {
  if (true) {
    if (url !== null && typeof url === 'object') {
      Object.keys(url).forEach(key => {
        if (urlObjectKeys.indexOf(key) === -1) {
          console.warn(`Unknown key passed via urlObject into url.format: ${key}`);
        }
      });
    }
  }

  return (0, _formatUrl.formatUrl)(url);
}

const SP = typeof performance !== 'undefined';
exports.SP = SP;
const ST = SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';
exports.ST = ST;

/***/ }),

/***/ "./node_modules/next/dist/next-server/server/denormalize-page-path.js":
/*!****************************************************************************!*\
  !*** ./node_modules/next/dist/next-server/server/denormalize-page-path.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
exports.__esModule=true;exports.normalizePathSep=normalizePathSep;exports.denormalizePagePath=denormalizePagePath;function normalizePathSep(path){return path.replace(/\\/g,'/');}function denormalizePagePath(page){page=normalizePathSep(page);if(page.startsWith('/index/')){page=page.slice(6);}else if(page==='/index'){page='/';}return page;}
//# sourceMappingURL=denormalize-page-path.js.map

/***/ }),

/***/ "./node_modules/next/link.js":
/*!***********************************!*\
  !*** ./node_modules/next/link.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/link */ "./node_modules/next/dist/client/link.js")


/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-jsx/style */ "styled-jsx/style");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/link */ "./node_modules/next/link.js");
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next-redux-wrapper */ "next-redux-wrapper");
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_MyLayout_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/MyLayout.js */ "./components/MyLayout.js");
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../store/store */ "./store/store.js");
/* harmony import */ var _actions_queueActions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../actions/queueActions */ "./actions/queueActions.js");
/* harmony import */ var _actions_usersActions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../actions/usersActions */ "./actions/usersActions.js");
/* harmony import */ var _actions_playbackActions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../actions/playbackActions */ "./actions/playbackActions.js");
/* harmony import */ var _components_Users__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../components/Users */ "./components/Users.js");
/* harmony import */ var _components_Queue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../components/Queue */ "./components/Queue.js");
/* harmony import */ var _components_AddToQueue__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../components/AddToQueue */ "./components/AddToQueue.js");
/* harmony import */ var _components_NowPlaying__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../components/NowPlaying */ "./components/NowPlaying.js");
/* harmony import */ var _components_Devices__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../components/Devices */ "./components/Devices.js");
/* harmony import */ var _components_PageWithIntl__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../components/PageWithIntl */ "./components/PageWithIntl.js");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! react-intl */ "react-intl");
/* harmony import */ var react_intl__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_intl__WEBPACK_IMPORTED_MODULE_15__);

var __jsx = react__WEBPACK_IMPORTED_MODULE_2___default.a.createElement;
















class Main extends react__WEBPACK_IMPORTED_MODULE_2___default.a.Component {
  static getInitialProps({
    req,
    store,
    isServer
  }) {
    return Promise.all([store.dispatch(Object(_actions_queueActions__WEBPACK_IMPORTED_MODULE_6__["fetchQueue"])()), store.dispatch(Object(_actions_usersActions__WEBPACK_IMPORTED_MODULE_7__["fetchUsers"])()), store.dispatch(Object(_actions_playbackActions__WEBPACK_IMPORTED_MODULE_8__["fetchPlayingContext"])())]);
  }

  render() {
    return __jsx(_components_MyLayout_js__WEBPACK_IMPORTED_MODULE_4__["default"], null, this.props.playing.track ? __jsx(_components_NowPlaying__WEBPACK_IMPORTED_MODULE_12__["default"], {
      track: this.props.playing.track,
      user: this.props.playing.user,
      position: this.props.playing.position
    }) : null, __jsx("div", {
      className: "jsx-3678439268" + " " + "app"
    }, __jsx(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
      id: "3678439268"
    }, ".app.jsx-3678439268{margin:0 20px;padding:0 20px;}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkM6XFxVc2Vyc1xcR2VicnVpa2VyXFxXZWJzdG9ybVByb2plY3RzXFxTcG90aWZ5XFxwYWdlc1xcaW5kZXguanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBb0NhLEFBRytCLGNBQ0MsZUFDakIiLCJmaWxlIjoiQzpcXFVzZXJzXFxHZWJydWlrZXJcXFdlYnN0b3JtUHJvamVjdHNcXFNwb3RpZnlcXHBhZ2VzXFxpbmRleC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHdpdGhSZWR1eCBmcm9tICduZXh0LXJlZHV4LXdyYXBwZXInO1xuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL015TGF5b3V0LmpzJztcbmltcG9ydCB7IGluaXRTdG9yZSB9IGZyb20gJy4uL3N0b3JlL3N0b3JlJztcbmltcG9ydCB7IGZldGNoUXVldWUgfSBmcm9tICcuLi9hY3Rpb25zL3F1ZXVlQWN0aW9ucyc7XG5pbXBvcnQgeyBmZXRjaFVzZXJzIH0gZnJvbSAnLi4vYWN0aW9ucy91c2Vyc0FjdGlvbnMnO1xuaW1wb3J0IHsgZmV0Y2hQbGF5aW5nQ29udGV4dCB9IGZyb20gJy4uL2FjdGlvbnMvcGxheWJhY2tBY3Rpb25zJztcbmltcG9ydCBVc2VycyBmcm9tICcuLi9jb21wb25lbnRzL1VzZXJzJztcbmltcG9ydCBRdWV1ZSBmcm9tICcuLi9jb21wb25lbnRzL1F1ZXVlJztcbmltcG9ydCBBZGRUb1F1ZXVlIGZyb20gJy4uL2NvbXBvbmVudHMvQWRkVG9RdWV1ZSc7XG5pbXBvcnQgTm93UGxheWluZyBmcm9tICcuLi9jb21wb25lbnRzL05vd1BsYXlpbmcnO1xuaW1wb3J0IERldmljZXMgZnJvbSAnLi4vY29tcG9uZW50cy9EZXZpY2VzJztcbmltcG9ydCBQYWdlV2l0aEludGwgZnJvbSAnLi4vY29tcG9uZW50cy9QYWdlV2l0aEludGwnO1xuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xuXG5jbGFzcyBNYWluIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcbiAgc3RhdGljIGdldEluaXRpYWxQcm9wcyh7IHJlcSwgc3RvcmUsIGlzU2VydmVyIH0pIHtcbiAgICByZXR1cm4gUHJvbWlzZS5hbGwoW1xuICAgICAgc3RvcmUuZGlzcGF0Y2goZmV0Y2hRdWV1ZSgpKSxcbiAgICAgIHN0b3JlLmRpc3BhdGNoKGZldGNoVXNlcnMoKSksXG4gICAgICBzdG9yZS5kaXNwYXRjaChmZXRjaFBsYXlpbmdDb250ZXh0KCkpXG4gICAgXSk7XG4gIH1cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiAoXG4gICAgICA8TGF5b3V0PlxuICAgICAgICB7dGhpcy5wcm9wcy5wbGF5aW5nLnRyYWNrID8gKFxuICAgICAgICAgIDxOb3dQbGF5aW5nXG4gICAgICAgICAgICB0cmFjaz17dGhpcy5wcm9wcy5wbGF5aW5nLnRyYWNrfVxuICAgICAgICAgICAgdXNlcj17dGhpcy5wcm9wcy5wbGF5aW5nLnVzZXJ9XG4gICAgICAgICAgICBwb3NpdGlvbj17dGhpcy5wcm9wcy5wbGF5aW5nLnBvc2l0aW9ufVxuICAgICAgICAgIC8+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcFwiPlxuICAgICAgICAgIDxzdHlsZSBqc3g+XG4gICAgICAgICAgICB7YFxuICAgICAgICAgICAgICAuYXBwIHtcbiAgICAgICAgICAgICAgICBtYXJnaW46IDAgMjBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwIDIwcHg7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGB9XG4gICAgICAgICAgPC9zdHlsZT5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsb2F0OiAnbGVmdCcgfX0+XG4gICAgICAgICAgICA8UXVldWUgaXRlbXM9e3RoaXMucHJvcHMucXVldWV9IHNlc3Npb249e3RoaXMucHJvcHMuc2Vzc2lvbn0gLz5cbiAgICAgICAgICAgIHt0aGlzLnByb3BzLnNlc3Npb24udXNlciAhPT0gbnVsbCA/IDxBZGRUb1F1ZXVlIC8+IDogbnVsbH1cbiAgICAgICAgICAgIHt0aGlzLnByb3BzLnNlc3Npb24udXNlciAhPT0gbnVsbCA/IDxEZXZpY2VzIC8+IDogbnVsbH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsb2F0OiAnbGVmdCcsIHdpZHRoOiAnMTUwcHgnIH19PlxuICAgICAgICAgICAgPFVzZXJzIGl0ZW1zPXt0aGlzLnByb3BzLnVzZXJzfSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvTGF5b3V0PlxuICAgICk7XG4gIH1cbn1cblxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gc3RhdGUgPT4gKHtcbiAgcGxheWluZzogc3RhdGUucGxheWJhY2ssXG4gIHF1ZXVlOiBzdGF0ZS5xdWV1ZSxcbiAgdXNlcnM6IHN0YXRlLnVzZXJzLFxuICBzZXNzaW9uOiBzdGF0ZS5zZXNzaW9uXG59KTtcblxuZXhwb3J0IGRlZmF1bHQgd2l0aFJlZHV4KGluaXRTdG9yZSwgbWFwU3RhdGVUb1Byb3BzLCBudWxsKShQYWdlV2l0aEludGwoTWFpbikpO1xuIl19 */\n/*@ sourceURL=C:\\\\Users\\\\Gebruiker\\\\WebstormProjects\\\\Spotify\\\\pages\\\\index.js */"), __jsx("div", {
      style: {
        float: 'left'
      },
      className: "jsx-3678439268"
    }, __jsx(_components_Queue__WEBPACK_IMPORTED_MODULE_10__["default"], {
      items: this.props.queue,
      session: this.props.session
    }), this.props.session.user !== null ? __jsx(_components_AddToQueue__WEBPACK_IMPORTED_MODULE_11__["default"], null) : null, this.props.session.user !== null ? __jsx(_components_Devices__WEBPACK_IMPORTED_MODULE_13__["default"], null) : null), __jsx("div", {
      style: {
        float: 'left',
        width: '150px'
      },
      className: "jsx-3678439268"
    }, __jsx(_components_Users__WEBPACK_IMPORTED_MODULE_9__["default"], {
      items: this.props.users
    }))));
  }

}

const mapStateToProps = state => ({
  playing: state.playback,
  queue: state.queue,
  users: state.users,
  session: state.session
});

/* harmony default export */ __webpack_exports__["default"] = (next_redux_wrapper__WEBPACK_IMPORTED_MODULE_3___default()(_store_store__WEBPACK_IMPORTED_MODULE_5__["initStore"], mapStateToProps, null)(Object(_components_PageWithIntl__WEBPACK_IMPORTED_MODULE_14__["default"])(Main)));

/***/ }),

/***/ "./reducers/devicesReducer.js":
/*!************************************!*\
  !*** ./reducers/devicesReducer.js ***!
  \************************************/
/*! exports provided: default, getIsFetching, getDevices */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getIsFetching", function() { return getIsFetching; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDevices", function() { return getDevices; });
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const initialState = {
  isFetching: false,
  data: []
};
/* harmony default export */ __webpack_exports__["default"] = ((state, action) => {
  switch (action.type) {
    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["FETCH_AVAILABLE_DEVICES"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        isFetching: true
      });

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["FETCH_AVAILABLE_DEVICES_SUCCESS"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        isFetching: false,
        data: action.list
      });

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["FETCH_AVAILABLE_DEVICES_ERROR"]:
      return initialState;

    default:
      return state ? state : initialState;
  }
});
const getIsFetching = state => {
  return state.isFetching;
};
const getDevices = state => {
  return state.data;
};

/***/ }),

/***/ "./reducers/index.js":
/*!***************************!*\
  !*** ./reducers/index.js ***!
  \***************************/
/*! exports provided: reducers, getDevices, getIsFetchingDevices */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reducers", function() { return reducers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDevices", function() { return getDevices; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getIsFetchingDevices", function() { return getIsFetchingDevices; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _reducers_queueReducer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../reducers/queueReducer */ "./reducers/queueReducer.js");
/* harmony import */ var _reducers_sessionReducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../reducers/sessionReducer */ "./reducers/sessionReducer.js");
/* harmony import */ var _reducers_playbackReducer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../reducers/playbackReducer */ "./reducers/playbackReducer.js");
/* harmony import */ var _reducers_devicesReducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../reducers/devicesReducer */ "./reducers/devicesReducer.js");
/* harmony import */ var _reducers_usersReducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../reducers/usersReducer */ "./reducers/usersReducer.js");
/* harmony import */ var _reducers_searchReducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../reducers/searchReducer */ "./reducers/searchReducer.js");







const reducers = () => Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])({
  queue: _reducers_queueReducer__WEBPACK_IMPORTED_MODULE_1__["default"],
  playback: _reducers_playbackReducer__WEBPACK_IMPORTED_MODULE_3__["default"],
  session: _reducers_sessionReducer__WEBPACK_IMPORTED_MODULE_2__["default"],
  users: _reducers_usersReducer__WEBPACK_IMPORTED_MODULE_5__["default"],
  search: _reducers_searchReducer__WEBPACK_IMPORTED_MODULE_6__["default"],
  devices: _reducers_devicesReducer__WEBPACK_IMPORTED_MODULE_4__["default"]
});
const getDevices = state => _reducers_devicesReducer__WEBPACK_IMPORTED_MODULE_4__["getDevices"](state.devices);
const getIsFetchingDevices = state => _reducers_devicesReducer__WEBPACK_IMPORTED_MODULE_4__["getIsFetching"](state.devices);

/***/ }),

/***/ "./reducers/playbackReducer.js":
/*!*************************************!*\
  !*** ./reducers/playbackReducer.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const initialState = {
  muted: false
};
/* harmony default export */ __webpack_exports__["default"] = ((state, action) => {
  switch (action.type) {
    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["FETCH_PLAYING_CONTEXT_SUCCESS"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        track: action.playingContext.track,
        user: action.playingContext.user,
        position: 0
      });

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["PLAY_TRACK_SUCCESS"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        track: action.track,
        user: action.user,
        position: action.position,
        startTime: new Date()
      });

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["UPDATE_NOW_PLAYING"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        track: action.track,
        user: action.user,
        position: action.position,
        startTime: new Date()
      });

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["QUEUE_ENDED"]:
      {
        return initialState;
      }

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["MUTE_PLAYBACK"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        muted: true
      });

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["UNMUTE_PLAYBACK"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        muted: false
      });

    default:
      return state ? state : initialState;
  }
});

/***/ }),

/***/ "./reducers/queueReducer.js":
/*!**********************************!*\
  !*** ./reducers/queueReducer.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");

const initialState = [];
/* harmony default export */ __webpack_exports__["default"] = ((state, action) => {
  switch (action.type) {
    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["UPDATE_QUEUE"]:
      return action.data;

    default:
      return state ? state : initialState;
  }
});

/***/ }),

/***/ "./reducers/searchReducer.js":
/*!***********************************!*\
  !*** ./reducers/searchReducer.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");

const initialState = {};
/* harmony default export */ __webpack_exports__["default"] = ((state, action) => {
  switch (action.type) {
    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["SEARCH_TRACKS"]:
      return {
        query: action.query
      };

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["SEARCH_TRACKS_SUCCESS"]:
      if (state.query === action.query) {
        return {
          query: action.query,
          results: action.results
        };
      } else {
        return state;
      }

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["SEARCH_TRACKS_RESET"]:
      return initialState;

    default:
      return state ? state : initialState;
  }
});

/***/ }),

/***/ "./reducers/sessionReducer.js":
/*!************************************!*\
  !*** ./reducers/sessionReducer.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");

const initialState = {
  refresh_token: null,
  //'localStorage' in window && localStorage.getItem('refreshToken'),
  user: null
};
/* harmony default export */ __webpack_exports__["default"] = ((state, action) => {
  switch (action.type) {
    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["LOAD"]:
      if (false) {} else {
        return state;
      }

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["UPDATE_TOKEN_SUCCESS"]:
      return Object.assign({}, state, {
        access_token: action.access_token
      });

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["LOGIN_SUCCESS"]:
      if (action.refresh_token) {
        return Object.assign({}, state, {
          refresh_token: action.refresh_token
        });
      }

      return state;

    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["UPDATE_CURRENT_USER"]:
      return Object.assign({}, state, {
        user: action.user
      });

    default:
      return state ? state : initialState;
  }
});

/***/ }),

/***/ "./reducers/usersReducer.js":
/*!**********************************!*\
  !*** ./reducers/usersReducer.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../constants/ActionTypes */ "./constants/ActionTypes.js");

const initialState = [{
  id: 'something',
  name: 'Adrian'
}, {
  id: 'something',
  name: 'Bea'
}, {
  id: 'something',
  name: 'Carlos'
}];
/* harmony default export */ __webpack_exports__["default"] = ((state, action) => {
  switch (action.type) {
    case _constants_ActionTypes__WEBPACK_IMPORTED_MODULE_0__["UPDATE_USERS"]:
      return action.data;

    default:
      return state ? state : initialState;
  }
});

/***/ }),

/***/ "./store/store.js":
/*!************************!*\
  !*** ./store/store.js ***!
  \************************/
/*! exports provided: initStore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initStore", function() { return initStore; });
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux-thunk */ "redux-thunk");
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_thunk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _reducers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../reducers */ "./reducers/index.js");
/* harmony import */ var _middlewares_sessionMiddleware__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../middlewares/sessionMiddleware */ "./middlewares/sessionMiddleware.js");
/* harmony import */ var _middlewares_playbackMiddleware__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../middlewares/playbackMiddleware */ "./middlewares/playbackMiddleware.js");
/* harmony import */ var _middlewares_devicesMiddleware__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../middlewares/devicesMiddleware */ "./middlewares/devicesMiddleware.js");
/* harmony import */ var _middlewares_socketMiddleware__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../middlewares/socketMiddleware */ "./middlewares/socketMiddleware.js");
/* harmony import */ var _middlewares_loggerMiddleware__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../middlewares/loggerMiddleware */ "./middlewares/loggerMiddleware.js");
/* harmony import */ var _middlewares_searchMiddleware__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../middlewares/searchMiddleware */ "./middlewares/searchMiddleware.js");
/* harmony import */ var _actions_sessionActions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../actions/sessionActions */ "./actions/sessionActions.js");











const initStore = (initialState = {}) => {
  const store = Object(redux__WEBPACK_IMPORTED_MODULE_0__["createStore"])(Object(_reducers__WEBPACK_IMPORTED_MODULE_2__["reducers"])(), initialState, Object(redux__WEBPACK_IMPORTED_MODULE_0__["applyMiddleware"])(redux_thunk__WEBPACK_IMPORTED_MODULE_1___default.a, _middlewares_sessionMiddleware__WEBPACK_IMPORTED_MODULE_3__["default"], _middlewares_socketMiddleware__WEBPACK_IMPORTED_MODULE_6__["socketMiddleware"], _middlewares_playbackMiddleware__WEBPACK_IMPORTED_MODULE_4__["default"], _middlewares_devicesMiddleware__WEBPACK_IMPORTED_MODULE_5__["default"], _middlewares_loggerMiddleware__WEBPACK_IMPORTED_MODULE_7__["default"], _middlewares_searchMiddleware__WEBPACK_IMPORTED_MODULE_8__["default"]));
  Object(_middlewares_socketMiddleware__WEBPACK_IMPORTED_MODULE_6__["default"])(store);
  store.dispatch(Object(_actions_sessionActions__WEBPACK_IMPORTED_MODULE_9__["load"])());
  return store;
};

/***/ }),

/***/ "isomorphic-unfetch":
/*!*************************************!*\
  !*** external "isomorphic-unfetch" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("isomorphic-unfetch");

/***/ }),

/***/ "next-redux-wrapper":
/*!*************************************!*\
  !*** external "next-redux-wrapper" ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next-redux-wrapper");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-intl":
/*!*****************************!*\
  !*** external "react-intl" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-intl");

/***/ }),

/***/ "react-is":
/*!***************************!*\
  !*** external "react-is" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-is");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "redux":
/*!************************!*\
  !*** external "redux" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux");

/***/ }),

/***/ "redux-thunk":
/*!******************************!*\
  !*** external "redux-thunk" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-thunk");

/***/ }),

/***/ "socket.io-client":
/*!***********************************!*\
  !*** external "socket.io-client" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("socket.io-client");

/***/ }),

/***/ "styled-jsx/style":
/*!***********************************!*\
  !*** external "styled-jsx/style" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9yb3V0ZXItY29udGV4dC5qc1wiIiwid2VicGFjazovLy8uL2FjdGlvbnMvZGV2aWNlc0FjdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vYWN0aW9ucy9wbGF5YmFja0FjdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vYWN0aW9ucy9xdWV1ZUFjdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vYWN0aW9ucy9zZWFyY2hBY3Rpb25zLmpzIiwid2VicGFjazovLy8uL2FjdGlvbnMvc2Vzc2lvbkFjdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vYWN0aW9ucy91c2Vyc0FjdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vYWN0aW9ucy92b3RlQWN0aW9ucy5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0FkZFRvUXVldWUuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9CdXR0b25EYXJrU3R5bGUuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9CdXR0b25TdHlsZS5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0RldmljZXMuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9IZWFkZXIuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9NeUxheW91dC5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL05vd1BsYXlpbmcuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9QYWdlV2l0aEludGwuanMiLCJ3ZWJwYWNrOi8vLy4vY29tcG9uZW50cy9RdWV1ZS5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL1F1ZXVlSXRlbS5qcyIsIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL1VzZXJzLmpzIiwid2VicGFjazovLy8uL2NvbmZpZy9hcHAuanMiLCJ3ZWJwYWNrOi8vLy4vY29uc3RhbnRzL0FjdGlvblR5cGVzLmpzIiwid2VicGFjazovLy8uL21pZGRsZXdhcmVzL2RldmljZXNNaWRkbGV3YXJlLmpzIiwid2VicGFjazovLy8uL21pZGRsZXdhcmVzL2xvZ2dlck1pZGRsZXdhcmUuanMiLCJ3ZWJwYWNrOi8vLy4vbWlkZGxld2FyZXMvcGxheWJhY2tNaWRkbGV3YXJlLmpzIiwid2VicGFjazovLy8uL21pZGRsZXdhcmVzL3NlYXJjaE1pZGRsZXdhcmUuanMiLCJ3ZWJwYWNrOi8vLy4vbWlkZGxld2FyZXMvc2Vzc2lvbk1pZGRsZXdhcmUuanMiLCJ3ZWJwYWNrOi8vLy4vbWlkZGxld2FyZXMvc29ja2V0TWlkZGxld2FyZS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHQuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVXaWxkY2FyZC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy90eXBlb2YuanMiLCJ3ZWJwYWNrOi8vLy4uLy4uL2NsaWVudC9saW5rLnRzeCIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L25vcm1hbGl6ZS10cmFpbGluZy1zbGFzaC50cyIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3JvdXRlci50cyIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3dpdGgtcm91dGVyLnRzeCIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2NvbXBpbGVkL3BhdGgtdG8tcmVnZXhwL2luZGV4LmpzIiwid2VicGFjazovLy8uLi8uLi8uLi9uZXh0LXNlcnZlci9saWIvbWl0dC50cyIsIndlYnBhY2s6Ly8vLi4vLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci9yb3V0ZXIudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvZXNjYXBlLXBhdGgtZGVsaW1pdGVycy50cyIsIndlYnBhY2s6Ly8vLi4vLi4vLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci91dGlscy9mb3JtYXQtdXJsLnRzIiwid2VicGFjazovLy8uLi8uLi8uLi8uLi8uLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL2lzLWR5bmFtaWMudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvcGFyc2UtcmVsYXRpdmUtdXJsLnRzIiwid2VicGFjazovLy8uLi8uLi8uLi8uLi8uLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL3BhdGgtbWF0Y2gudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvcHJlcGFyZS1kZXN0aW5hdGlvbi50cyIsIndlYnBhY2s6Ly8vLi4vLi4vLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci91dGlscy9xdWVyeXN0cmluZy50cyIsIndlYnBhY2s6Ly8vLi4vLi4vLi4vLi4vLi4vbmV4dC1zZXJ2ZXIvbGliL3JvdXRlci91dGlscy9yZXNvbHZlLXJld3JpdGVzLnRzIiwid2VicGFjazovLy8uLi8uLi8uLi8uLi8uLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3V0aWxzL3JvdXRlLW1hdGNoZXIudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi9yb3V0ZXIvdXRpbHMvcm91dGUtcmVnZXgudHMiLCJ3ZWJwYWNrOi8vLy4uLy4uLy4uL25leHQtc2VydmVyL2xpYi91dGlscy50cyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9kZW5vcm1hbGl6ZS1wYWdlLXBhdGguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL25leHQvbGluay5qcyIsIndlYnBhY2s6Ly8vLi9wYWdlcy9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9yZWR1Y2Vycy9kZXZpY2VzUmVkdWNlci5qcyIsIndlYnBhY2s6Ly8vLi9yZWR1Y2Vycy9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9yZWR1Y2Vycy9wbGF5YmFja1JlZHVjZXIuanMiLCJ3ZWJwYWNrOi8vLy4vcmVkdWNlcnMvcXVldWVSZWR1Y2VyLmpzIiwid2VicGFjazovLy8uL3JlZHVjZXJzL3NlYXJjaFJlZHVjZXIuanMiLCJ3ZWJwYWNrOi8vLy4vcmVkdWNlcnMvc2Vzc2lvblJlZHVjZXIuanMiLCJ3ZWJwYWNrOi8vLy4vcmVkdWNlcnMvdXNlcnNSZWR1Y2VyLmpzIiwid2VicGFjazovLy8uL3N0b3JlL3N0b3JlLmpzIiwid2VicGFjazovLy9leHRlcm5hbCBcImlzb21vcnBoaWMtdW5mZXRjaFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQtcmVkdXgtd3JhcHBlclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QtaW50bFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0LWlzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QtcmVkdXhcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWR1eFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlZHV4LXRodW5rXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwic29ja2V0LmlvLWNsaWVudFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInN0eWxlZC1qc3gvc3R5bGVcIiJdLCJuYW1lcyI6WyJmZXRjaEF2YWlsYWJsZURldmljZXMiLCJ0eXBlIiwidHlwZXMiLCJGRVRDSF9BVkFJTEFCTEVfREVWSUNFUyIsImZldGNoQXZhaWxhYmxlRGV2aWNlc1N1Y2Nlc3MiLCJsaXN0IiwiZmV0Y2hBdmFpbGFibGVEZXZpY2VzRXJyb3IiLCJlcnJvciIsInRyYW5zZmVyUGxheWJhY2tUb0RldmljZSIsImRldmljZUlkIiwidHJhbnNmZXJQbGF5YmFja1RvRGV2aWNlU3VjY2VzcyIsIlRSQU5TRkVSX1BMQVlCQUNLX1RPX0RFVklDRV9TVUNDRVNTIiwidHJhbnNmZXJQbGF5YmFja1RvRGV2aWNlRXJyb3IiLCJwbGF5VHJhY2siLCJ0cmFjayIsInVzZXIiLCJwb3NpdGlvbiIsInVwZGF0ZU5vd1BsYXlpbmciLCJwbGF5VHJhY2tTdWNjZXNzIiwibXV0ZVBsYXliYWNrIiwiTVVURV9QTEFZQkFDSyIsInVubXV0ZVBsYXliYWNrIiwiVU5NVVRFX1BMQVlCQUNLIiwiZmV0Y2hQbGF5aW5nQ29udGV4dFN1Y2Nlc3MiLCJwbGF5aW5nQ29udGV4dCIsImZldGNoUGxheWluZ0NvbnRleHQiLCJkaXNwYXRjaCIsImZldGNoIiwiQ29uZmlnIiwiSE9TVCIsInRoZW4iLCJyZXMiLCJqc29uIiwicXVldWVUcmFjayIsImlkIiwidXBkYXRlUXVldWUiLCJxdWV1ZSIsImRhdGEiLCJxdWV1ZUVuZGVkIiwiUVVFVUVfRU5ERUQiLCJxdWV1ZVJlbW92ZVRyYWNrIiwiZmV0Y2hRdWV1ZSIsInNlYXJjaFRyYWNrcyIsInF1ZXJ5Iiwic2VhcmNoVHJhY2tzU3VjY2VzcyIsInJlc3VsdHMiLCJzZWFyY2hUcmFja3NSZXNldCIsIlNFQVJDSF9UUkFDS1NfUkVTRVQiLCJmZXRjaFRyYWNrIiwiZmV0Y2hUcmFja1N1Y2Nlc3MiLCJsb2FkIiwiTE9BRCIsImxvZ2luIiwiTE9HSU4iLCJsb2dpblN1Y2Nlc3MiLCJMT0dJTl9TVUNDRVNTIiwibG9naW5GYWlsdXJlIiwicmVmcmVzaF90b2tlbiIsInVwZGF0ZVRva2VuIiwicmVmcmVzaFRva2VuIiwidXBkYXRlVG9rZW5TdWNjZXNzIiwiYWNjZXNzX3Rva2VuIiwidXBkYXRlQ3VycmVudFVzZXIiLCJ1cGRhdGVVc2VycyIsInVzZXJzIiwiZmV0Y2hVc2VycyIsInZvdGVVcCIsInZvdGVVcFN1Y2Nlc3MiLCJWT1RFX1VQX1NVQ0NFU1MiLCJSZXN1bHRzTGlzdCIsIkNvbXBvbmVudCIsInJlbmRlciIsImZvY3VzIiwicHJvcHMiLCJtYXAiLCJyIiwiaW5kZXgiLCJpc0ZvY3VzZWQiLCJjbGFzc05hbWUiLCJvblNlbGVjdCIsImFsYnVtIiwiaW1hZ2VzIiwidXJsIiwibmFtZSIsImFydGlzdHMiLCJBZGRUb1F1ZXVlIiwidGV4dCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsInNldFN0YXRlIiwia2V5Q29kZSIsInN0YXRlIiwiY29ycmVjdCIsInNlYXJjaCIsInRyaW0iLCJsZW5ndGgiLCJwbGFjZWhvbGRlciIsImludGwiLCJmb3JtYXRNZXNzYWdlIiwiaGFuZGxlQmx1ciIsImhhbmRsZUNoYW5nZSIsImhhbmRsZUtleURvd24iLCJoYW5kbGVGb2N1cyIsImhhbmRsZVNlbGVjdEVsZW1lbnQiLCJtYXBEaXNwYXRjaFRvUHJvcHMiLCJtYXBTdGF0ZVRvUHJvcHMiLCJjb25uZWN0IiwiaW5qZWN0SW50bCIsIkRldmljZXMiLCJSZWFjdCIsIlB1cmVDb21wb25lbnQiLCJkZXZpY2VzIiwiaXNGZXRjaGluZyIsInBhZGRpbmdCb3R0b20iLCJkZXZpY2UiLCJpc19hY3RpdmUiLCJ2b2x1bWUiLCJnZXRJc0ZldGNoaW5nRGV2aWNlcyIsImdldERldmljZXMiLCJsaW5rU3R5bGUiLCJsaW5lSGVpZ2h0IiwibWFyZ2luUmlnaHQiLCJtYWluTGlua1N0eWxlIiwiZmxvYXQiLCJoZWFkZXJTdHlsZSIsImJhY2tncm91bmRDb2xvciIsInBhZGRpbmciLCJoZWlnaHQiLCJjb2xvciIsImdldE5hbWVGcm9tVXNlciIsImRpc3BsYXlfbmFtZSIsIkhlYWRlciIsInNlc3Npb24iLCJtdXRlZCIsInBsYXliYWNrIiwiTGF5b3V0IiwiY2hpbGRyZW4iLCJOb3dQbGF5aW5nIiwiY29uc3RydWN0b3IiLCJzdGFydCIsIkRhdGUiLCJub3ciLCJjdXJyZW50UG9zaXRpb24iLCJ0aW1lciIsInRpY2siLCJjb21wb25lbnRXaWxsUmVjZWl2ZVByb3BzIiwiY29tcG9uZW50RGlkTW91bnQiLCJzZXRJbnRlcnZhbCIsImNvbXBvbmVudFdpbGxVbm1vdW50IiwiY2xlYXJJbnRlcnZhbCIsInBlcmNlbnRhZ2UiLCJkdXJhdGlvbl9tcyIsInRvRml4ZWQiLCJ1c2VyTmFtZSIsImEiLCJqb2luIiwid2lkdGgiLCJQYWdlIiwiSW50bFBhZ2UiLCJQYWdlV2l0aEludGwiLCJnZXRJbml0aWFsUHJvcHMiLCJjb250ZXh0IiwicmVxIiwibG9jYWxlIiwibWVzc2FnZXMiLCJ3aW5kb3ciLCJfX05FWFRfREFUQV9fIiwiaW5pdGlhbFByb3BzIiwiUXVldWUiLCJpdGVtcyIsImkiLCJpdGVtIiwib25SZW1vdmVJdGVtIiwib25Wb3RlVXAiLCJ2b3RlcnMiLCJmaWx0ZXIiLCJ2IiwiZm9udHNpemUiLCJtYXJnaW5Cb3R0b20iLCJwYWRkaW5nUmlnaHQiLCJkaXNwbGF5IiwiY2xlYXIiLCJtb2R1bGUiLCJleHBvcnRzIiwicHJvY2VzcyIsIlFVRVVFX1RSQUNLIiwiVVBEQVRFX1FVRVVFIiwiUVVFVUVfUkVNT1ZFX1RSQUNLIiwiU0VBUkNIX1RSQUNLUyIsIlNFQVJDSF9UUkFDS1NfU1VDQ0VTUyIsIkZFVENIX1RSQUNLIiwiRkVUQ0hfVFJBQ0tfU1VDQ0VTUyIsIkZFVENIX1BMQVlJTkdfQ09OVEVYVF9TVUNDRVNTIiwiVVBEQVRFX1VTRVJTIiwiTE9HSU5fRkFJTFVSRSIsIlVQREFURV9UT0tFTiIsIlVQREFURV9UT0tFTl9TVUNDRVNTIiwiVVBEQVRFX0NVUlJFTlRfVVNFUiIsIlBMQVlfVFJBQ0siLCJVUERBVEVfTk9XX1BMQVlJTkciLCJQTEFZX1RSQUNLX1NVQ0NFU1MiLCJGRVRDSF9BVkFJTEFCTEVfREVWSUNFU19TVUNDRVNTIiwiRkVUQ0hfQVZBSUxBQkxFX0RFVklDRVNfRVJST1IiLCJUUkFOU0ZFUl9QTEFZQkFDS19UT19ERVZJQ0UiLCJUUkFOU0ZFUl9QTEFZQkFDS19UT19ERVZJQ0VfRVJST1IiLCJWT1RFX1VQIiwiU1BPVElGWV9BUElfQkFTRSIsInN0b3JlIiwibmV4dCIsImFjdGlvbiIsInJlc3VsdCIsIm1ldGhvZCIsImhlYWRlcnMiLCJBdXRob3JpemF0aW9uIiwiZ2V0U3RhdGUiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsImRldmljZV9pZHMiLCJjb25zb2xlIiwibG9nIiwic3RhcnRUaW1lIiwic2hvdWxkQWRkV2lsZGNhcmQiLCJ3b3JkcyIsInNwbGl0IiwibGFzdFdvcmQiLCJ0ZXN0IiwibGFzdEluZGV4T2YiLCJ3aWxkY2FyZFF1ZXJ5IiwiZW5jb2RlVVJJQ29tcG9uZW50IiwidHJhY2tzIiwiZ2V0Q3VycmVudFVzZXIiLCJIZWFkZXJzIiwiZXhwaXJlc0luIiwiZXhwaXJlc19pbiIsIm5lZWRzVG9VcGRhdGUiLCJnZXRMb2dpblVSTCIsInNjb3BlcyIsImxlZnQiLCJzY3JlZW4iLCJ0b3AiLCJtZXNzYWdlRm4iLCJldmVudCIsImhhc2giLCJwYXJzZSIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJhY2Nlc3NUb2tlbiIsImxvY2FsU3RvcmFnZSIsInNldEl0ZW0iLCJhZGRFdmVudExpc3RlbmVyIiwib3BlbiIsInNvY2tldCIsImdldElkRnJvbVRyYWNrU3RyaW5nIiwidHJhY2tTdHJpbmciLCJtYXRjaGVzIiwibWF0Y2giLCJzb2NrZXRNaWRkbGV3YXJlIiwidHJhY2tJZCIsImVtaXQiLCJpbyIsIm9uIiwibGlzdGVuZXJzIiwiSW50ZXJzZWN0aW9uT2JzZXJ2ZXIiLCJwcmVmZXRjaGVkIiwiY2FjaGVkT2JzZXJ2ZXIiLCJlbnRyaWVzIiwiZW50cnkiLCJjYiIsInJvb3RNYXJnaW4iLCJsaXN0ZW5Ub0ludGVyc2VjdGlvbnMiLCJvYnNlcnZlciIsImdldE9ic2VydmVyIiwicm91dGVyIiwiZXJyIiwiaHJlZiIsIm5vZGVOYW1lIiwiaXNNb2RpZmllZEV2ZW50Iiwic2Nyb2xsIiwiYXMiLCJyZXBsYWNlIiwic3VjY2VzcyIsImRvY3VtZW50IiwiYXJncyIsImtleSIsImV4cGVjdGVkIiwiYWN0dWFsIiwicmVxdWlyZWRQcm9wc0d1YXJkIiwicmVxdWlyZWRQcm9wcyIsIk9iamVjdCIsImNyZWF0ZVByb3BFcnJvciIsIl8iLCJvcHRpb25hbFByb3BzR3VhcmQiLCJzaGFsbG93IiwicGFzc0hyZWYiLCJwcmVmZXRjaCIsIm9wdGlvbmFsUHJvcHMiLCJoYXNXYXJuZWQiLCJwIiwicGF0aG5hbWUiLCJyZXNvbHZlZEFzIiwiY2hpbGRFbG0iLCJpc1ByZWZldGNoZWQiLCJjaGlsZCIsIkNoaWxkcmVuIiwiY2hpbGRQcm9wcyIsInJlZiIsImVsIiwic2V0Q2hpbGRFbG0iLCJvbkNsaWNrIiwibGlua0NsaWNrZWQiLCJwcmlvcml0eSIsIkxpbmsiLCJwYXRoIiwibm9ybWFsaXplUGF0aFRyYWlsaW5nU2xhc2giLCJzaW5nbGV0b25Sb3V0ZXIiLCJyZWFkeUNhbGxiYWNrcyIsInJlYWR5IiwidXJsUHJvcGVydHlGaWVsZHMiLCJyb3V0ZXJFdmVudHMiLCJjb3JlTWV0aG9kRmllbGRzIiwiZ2V0IiwiUm91dGVyIiwiZmllbGQiLCJnZXRSb3V0ZXIiLCJldmVudEZpZWxkIiwiX3NpbmdsZXRvblJvdXRlciIsIm1lc3NhZ2UiLCJzdGFjayIsIlJvdXRlckNvbnRleHQiLCJjcmVhdGVSb3V0ZXIiLCJfcm91dGVyIiwiaW5zdGFuY2UiLCJBcnJheSIsIkNvbXBvc2VkQ29tcG9uZW50IiwiV2l0aFJvdXRlcldyYXBwZXIiLCJhbGwiLCJvZmYiLCJoYW5kbGVyIiwiYmFzZVBhdGgiLCJjYW5jZWxsZWQiLCJwcmVmaXgiLCJhZGRQYXRoUHJlZml4IiwibG9jYXRpb25PcmlnaW4iLCJyZXNvbHZlZCIsImhhc0Jhc2VQYXRoIiwiaW50ZXJwb2xhdGVkUm91dGUiLCJkeW5hbWljUmVnZXgiLCJkeW5hbWljR3JvdXBzIiwiZHluYW1pY01hdGNoZXMiLCJhc1BhdGhuYW1lIiwicGFyYW1zIiwicGFyYW0iLCJyZXBsYWNlZCIsInJlcGVhdCIsIm9wdGlvbmFsIiwiZXNjYXBlUGF0aERlbGltaXRlcnMiLCJmaWx0ZXJlZFF1ZXJ5IiwiYmFzZSIsInVybEFzU3RyaW5nIiwiZmluYWxVcmwiLCJpbnRlcnBvbGF0ZWRBcyIsImludGVycG9sYXRlQXMiLCJvbWl0UGFybXNGcm9tUXVlcnkiLCJyZXNvbHZlZEhyZWYiLCJyZXNvbHZlQXMiLCJQQUdFX0xPQURfRVJST1IiLCJTeW1ib2wiLCJhZGRCYXNlUGF0aCIsInJlc29sdmVIcmVmIiwibWFudWFsU2Nyb2xsUmVzdG9yYXRpb24iLCJjcmVkZW50aWFscyIsImF0dGVtcHRzIiwiZmV0Y2hSZXRyeSIsImlzU2VydmVyUmVuZGVyIiwibWFya0xvYWRpbmdFcnJvciIsInJvdXRlIiwiYXNQYXRoIiwiY29tcG9uZW50cyIsInNkYyIsInN1YiIsImNsYyIsInBhZ2VMb2FkZXIiLCJfYnBzIiwiZXZlbnRzIiwiX3dyYXBBcHAiLCJpc1NzciIsImlzRmFsbGJhY2siLCJfaW5GbGlnaHRSb3V0ZSIsIl9zaGFsbG93IiwibG9jYWxlcyIsImRlZmF1bHRMb2NhbGUiLCJvcHRpb25zIiwic3R5bGVTaGVldHMiLCJfX05fU1NHIiwiX19OX1NTUCIsInJlbG9hZCIsImJhY2siLCJwdXNoIiwicHJlcGFyZVVybEFzIiwiaXNMb2NhbFVSTCIsIlNUIiwicGVyZm9ybWFuY2UiLCJhZGRMb2NhbGUiLCJjbGVhbmVkQXMiLCJkZWxMb2NhbGUiLCJkZWxCYXNlUGF0aCIsInBhZ2VzIiwiX19yZXdyaXRlcyIsInBhcnNlZCIsInBvdGVudGlhbEhyZWYiLCJwYXJzZWRBcyIsInJvdXRlUmVnZXgiLCJyb3V0ZU1hdGNoIiwic2hvdWxkSW50ZXJwb2xhdGUiLCJtaXNzaW5nUGFyYW1zIiwicm91dGVJbmZvIiwiZGVzdGluYXRpb24iLCJwYXJzZWRIcmVmIiwiYXBwQ29tcCIsImNoYW5nZVN0YXRlIiwiX19OIiwiYnVpbGRDYW5jZWxsYXRpb25FcnJvciIsInBhZ2UiLCJjYWNoZWRSb3V0ZUluZm8iLCJyZXF1aXJlIiwiaXNWYWxpZEVsZW1lbnRUeXBlIiwiZGF0YUhyZWYiLCJzZXQiLCJiZWZvcmVQb3BTdGF0ZSIsIm9ubHlBSGFzaENoYW5nZSIsIm5ld0hhc2giLCJvbGRVcmxOb0hhc2giLCJvbGRIYXNoIiwic2Nyb2xsVG9IYXNoIiwiaWRFbCIsIm5hbWVFbCIsInVybElzTmV3IiwiX3Jlc29sdmVIcmVmIiwiYXBwbHlCYXNlUGF0aCIsImNsZWFuUGF0aG5hbWUiLCJQcm9taXNlIiwiY2FuY2VsIiwiY29tcG9uZW50UmVzdWx0IiwiX2dldERhdGEiLCJmbiIsIl9nZXRTdGF0aWNEYXRhIiwiZmV0Y2hOZXh0RGF0YSIsIl9nZXRTZXJ2ZXJEYXRhIiwiQXBwVHJlZSIsImN0eCIsImFib3J0Q29tcG9uZW50TG9hZCIsIm5vdGlmeSIsInNlZ21lbnQiLCJjaGFyIiwic2xhc2hlZFByb3RvY29scyIsInByb3RvY29sIiwidXJsT2JqIiwiaG9zdCIsImF1dGgiLCJob3N0bmFtZSIsIlN0cmluZyIsInF1ZXJ5c3RyaW5nIiwiVEVTVF9ST1VURSIsIkRVTU1ZX0JBU0UiLCJyZXNvbHZlZEJhc2UiLCJvcmlnaW4iLCJtYXRjaGVyT3B0aW9ucyIsInNlbnNpdGl2ZSIsImRlbGltaXRlciIsImN1c3RvbVJvdXRlTWF0Y2hlck9wdGlvbnMiLCJzdHJpY3QiLCJjdXN0b21Sb3V0ZSIsImtleXMiLCJtYXRjaGVyUmVnZXgiLCJwYXRoVG9SZWdleHAiLCJtYXRjaGVyIiwicGFyc2VkRGVzdGluYXRpb24iLCJkZXN0UXVlcnkiLCJkZXN0UGF0aCIsImRlc3RQYXRoUGFyYW1LZXlzIiwiZGVzdFBhdGhQYXJhbXMiLCJkZXN0aW5hdGlvbkNvbXBpbGVyIiwidmFsaWRhdGUiLCJzdHJPckFycmF5IiwicXVlcnlDb21waWxlciIsInBhcmFtS2V5cyIsImFwcGVuZFBhcmFtc1RvUXVlcnkiLCJzaG91bGRBZGRCYXNlUGF0aCIsIm5ld1VybCIsInNlYXJjaFBhcmFtcyIsImlzTmFOIiwic3RyaW5naWZ5VXJsUXVlcnlQYXJhbSIsInNlYXJjaFBhcmFtc0xpc3QiLCJjdXN0b21Sb3V0ZU1hdGNoZXIiLCJyZXdyaXRlIiwiZGVzdFJlcyIsInJlIiwiZGVjb2RlIiwiZGVjb2RlVVJJQ29tcG9uZW50Iiwic2x1Z05hbWUiLCJnIiwiZ3JvdXBzIiwibSIsInN0ciIsInNlZ21lbnRzIiwibm9ybWFsaXplZFJvdXRlIiwiZ3JvdXBJbmRleCIsInBhcmFtZXRlcml6ZWRSb3V0ZSIsInBhcnNlUGFyYW1ldGVyIiwicG9zIiwiZXNjYXBlUmVnZXgiLCJyb3V0ZUtleUNoYXJDb2RlIiwicm91dGVLZXlDaGFyTGVuZ3RoIiwiZ2V0U2FmZVJvdXRlS2V5Iiwicm91dGVLZXkiLCJyb3V0ZUtleXMiLCJuYW1lZFBhcmFtZXRlcml6ZWRSb3V0ZSIsImNsZWFuZWRLZXkiLCJpbnZhbGlkS2V5IiwicGFyc2VJbnQiLCJuYW1lZFJlZ2V4IiwidXNlZCIsInBvcnQiLCJnZXRMb2NhdGlvbk9yaWdpbiIsIkFwcCIsImdldERpc3BsYXlOYW1lIiwicGFnZVByb3BzIiwibG9hZEdldEluaXRpYWxQcm9wcyIsImlzUmVzU2VudCIsInVybE9iamVjdEtleXMiLCJTUCIsIk1haW4iLCJpc1NlcnZlciIsInBsYXlpbmciLCJ3aXRoUmVkdXgiLCJpbml0U3RvcmUiLCJpbml0aWFsU3RhdGUiLCJnZXRJc0ZldGNoaW5nIiwicmVkdWNlcnMiLCJjb21iaW5lUmVkdWNlcnMiLCJxdWV1ZVJlZHVjZXIiLCJwbGF5YmFja1JlZHVjZXIiLCJzZXNzaW9uUmVkdWNlciIsInVzZXJzUmVkdWNlciIsInNlYXJjaFJlZHVjZXIiLCJkZXZpY2VzUmVkdWNlciIsImZyb21EZXZpY2VzIiwiYXNzaWduIiwiY3JlYXRlU3RvcmUiLCJhcHBseU1pZGRsZXdhcmUiLCJ0aHVuayIsInNlc3Npb25NaWRkbGV3YXJlIiwicGxheWJhY2tNaWRkbGV3YXJlIiwiZGV2aWNlc01pZGRsZXdhcmUiLCJsb2dnZXJNaWRkbGV3YXJlIiwic2VhcmNoTWlkZGxld2FyZSIsInNvY2tldE1pZGRsZXdhcmVEZWZhdWx0Il0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7QUN4RkEsd0U7Ozs7Ozs7Ozs7OztBQ0FBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVPLE1BQU1BLHFCQUFxQixHQUFHLE9BQU87QUFDMUNDLE1BQUksRUFBRUMsOEVBQTZCQztBQURPLENBQVAsQ0FBOUI7QUFHQSxNQUFNQyw0QkFBNEIsR0FBR0MsSUFBSSxLQUFLO0FBQ25ESixNQUFJLEVBQUVDLHNGQUQ2QztBQUVuREc7QUFGbUQsQ0FBTCxDQUF6QztBQUlBLE1BQU1DLDBCQUEwQixHQUFHQyxLQUFLLEtBQUs7QUFDbEROLE1BQUksRUFBRUMsb0ZBRDRDO0FBRWxESztBQUZrRCxDQUFMLENBQXhDO0FBS0EsTUFBTUMsd0JBQXdCLEdBQUdDLFFBQVEsS0FBSztBQUNuRFIsTUFBSSxFQUFFQyxrRkFENkM7QUFFbkRPO0FBRm1ELENBQUwsQ0FBekM7QUFJQSxNQUFNQywrQkFBK0IsR0FBR0wsSUFBSSxLQUFLO0FBQ3RESixNQUFJLEVBQUVDLDBGQUF5Q1M7QUFETyxDQUFMLENBQTVDO0FBR0EsTUFBTUMsNkJBQTZCLEdBQUdQLElBQUksS0FBSztBQUNwREosTUFBSSxFQUFFQyx3RkFEOEM7QUFFcERLO0FBRm9ELENBQUwsQ0FBMUMsQzs7Ozs7Ozs7Ozs7O0FDckJQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtDQUdBOztBQUNPLE1BQU1NLFNBQVMsR0FBRyxDQUFDQyxLQUFELEVBQVFDLElBQVIsRUFBY0MsUUFBZCxNQUE0QjtBQUNuRGYsTUFBSSxFQUFFQyxpRUFENkM7QUFFbkRZLE9BRm1EO0FBR25EQyxNQUhtRDtBQUluREM7QUFKbUQsQ0FBNUIsQ0FBbEI7QUFNQSxNQUFNQyxnQkFBZ0IsR0FBRyxDQUFDSCxLQUFELEVBQVFDLElBQVIsRUFBY0MsUUFBZCxNQUE0QjtBQUMxRGYsTUFBSSxFQUFFQyx5RUFEb0Q7QUFFMURZLE9BRjBEO0FBRzFEQyxNQUgwRDtBQUkxREM7QUFKMEQsQ0FBNUIsQ0FBekI7QUFNQSxNQUFNRSxnQkFBZ0IsR0FBRyxDQUFDSixLQUFELEVBQVFDLElBQVIsRUFBY0MsUUFBZCxNQUE0QjtBQUMxRGYsTUFBSSxFQUFFQyx5RUFEb0Q7QUFFMURZLE9BRjBEO0FBRzFEQyxNQUgwRDtBQUkxREM7QUFKMEQsQ0FBNUIsQ0FBekI7QUFPQSxNQUFNRyxZQUFZLEdBQUcsT0FBTztBQUFFbEIsTUFBSSxFQUFFQyxvRUFBbUJrQjtBQUEzQixDQUFQLENBQXJCO0FBQ0EsTUFBTUMsY0FBYyxHQUFHLE9BQU87QUFBRXBCLE1BQUksRUFBRUMsc0VBQXFCb0I7QUFBN0IsQ0FBUCxDQUF2QjtBQUVBLE1BQU1DLDBCQUEwQixHQUFHQyxjQUFjLEtBQUs7QUFDM0R2QixNQUFJLEVBQUVDLG9GQURxRDtBQUUzRHNCO0FBRjJELENBQUwsQ0FBakQ7QUFLQSxNQUFNQyxtQkFBbUIsR0FBRyxNQUFNQyxRQUFRLElBQy9DQyx5REFBSyxDQUFFLEdBQUVDLGtEQUFNLENBQUNDLElBQUssa0JBQWhCLENBQUwsQ0FDR0MsSUFESCxDQUNRQyxHQUFHLElBQUlBLEdBQUcsQ0FBQ0MsSUFBSixFQURmLEVBRUdGLElBRkgsQ0FFUUMsR0FBRyxJQUFJTCxRQUFRLENBQUNILDBCQUEwQixDQUFDUSxHQUFELENBQTNCLENBRnZCLENBREssQzs7Ozs7Ozs7Ozs7O0FDakNQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFFTyxNQUFNRSxVQUFVLEdBQUdDLEVBQUUsS0FBSztBQUFFakMsTUFBSSxFQUFFQyxrRUFBUjtBQUEyQmdDO0FBQTNCLENBQUwsQ0FBckI7QUFDQSxNQUFNQyxXQUFXLEdBQUdDLEtBQUssS0FBSztBQUFFbkMsTUFBSSxFQUFFQyxtRUFBUjtBQUE0Qm1DLE1BQUksRUFBRUQ7QUFBbEMsQ0FBTCxDQUF6QjtBQUNBLE1BQU1FLFVBQVUsR0FBRyxPQUFPO0FBQUVyQyxNQUFJLEVBQUVDLGtFQUFpQnFDO0FBQXpCLENBQVAsQ0FBbkI7QUFDQSxNQUFNQyxnQkFBZ0IsR0FBR04sRUFBRSxLQUFLO0FBQ3JDakMsTUFBSSxFQUFFQyx5RUFEK0I7QUFFckNnQztBQUZxQyxDQUFMLENBQTNCO0FBS0EsTUFBTU8sVUFBVSxHQUFHLE1BQU1mLFFBQVEsSUFDdENDLHlEQUFLLENBQUUsR0FBRUMsa0RBQU0sQ0FBQ0MsSUFBSyxZQUFoQixDQUFMLENBQWtDQyxJQUFsQyxDQUF1Q0MsR0FBRyxJQUFJQSxHQUFHLENBQUNDLElBQUosRUFBOUMsRUFBMERGLElBQTFELENBQStEQyxHQUFHLElBQUlMLFFBQVEsQ0FBQ1MsV0FBVyxDQUFDSixHQUFELENBQVosQ0FBOUUsQ0FESyxDOzs7Ozs7Ozs7Ozs7QUNiUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRU8sTUFBTVcsWUFBWSxHQUFHQyxLQUFLLEtBQUs7QUFBRTFDLE1BQUksRUFBRUMsb0VBQVI7QUFBNkJ5QztBQUE3QixDQUFMLENBQTFCO0FBQ0EsTUFBTUMsbUJBQW1CLEdBQUcsQ0FBQ0QsS0FBRCxFQUFRRSxPQUFSLE1BQXFCO0FBQ3RENUMsTUFBSSxFQUFFQyw0RUFEZ0Q7QUFFdER5QyxPQUZzRDtBQUd0REU7QUFIc0QsQ0FBckIsQ0FBNUI7QUFLQSxNQUFNQyxpQkFBaUIsR0FBRyxPQUFPO0FBQUU3QyxNQUFJLEVBQUVDLDBFQUF5QjZDO0FBQWpDLENBQVAsQ0FBMUI7QUFDQSxNQUFNQyxVQUFVLEdBQUdkLEVBQUUsS0FBSztBQUFFakMsTUFBSSxFQUFFQyxrRUFBUjtBQUEyQmdDO0FBQTNCLENBQUwsQ0FBckI7QUFDQSxNQUFNZSxpQkFBaUIsR0FBRyxDQUFDZixFQUFELEVBQUtwQixLQUFMLE1BQWdCO0FBQy9DYixNQUFJLEVBQUVDLDBFQUR5QztBQUUvQ2dDO0FBRitDLENBQWhCLENBQTFCLEM7Ozs7Ozs7Ozs7OztBQ1ZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRU8sTUFBTWdCLElBQUksR0FBRyxPQUFPO0FBQUVqRCxNQUFJLEVBQUVDLDJEQUFVaUQ7QUFBbEIsQ0FBUCxDQUFiO0FBQ0EsTUFBTUMsS0FBSyxHQUFHLE9BQU87QUFBRW5ELE1BQUksRUFBRUMsNERBQVdtRDtBQUFuQixDQUFQLENBQWQ7QUFDQSxNQUFNQyxZQUFZLEdBQUcsT0FBTztBQUNqQ3JELE1BQUksRUFBRUMsb0VBQW1CcUQ7QUFEUSxDQUFQLENBQXJCO0FBR0EsTUFBTUMsWUFBWSxHQUFHQyxhQUFhLEtBQUs7QUFDNUN4RCxNQUFJLEVBQUVDLG9FQURzQztBQUU1Q3VEO0FBRjRDLENBQUwsQ0FBbEM7QUFJQSxNQUFNQyxXQUFXLEdBQUdDLFlBQVksS0FBSztBQUMxQzFELE1BQUksRUFBRUMsbUVBRG9DO0FBRTFDeUQ7QUFGMEMsQ0FBTCxDQUFoQztBQUlBLE1BQU1DLGtCQUFrQixHQUFHQyxZQUFZLEtBQUs7QUFDakQ1RCxNQUFJLEVBQUVDLDJFQUQyQztBQUVqRDJEO0FBRmlELENBQUwsQ0FBdkM7QUFJQSxNQUFNQyxpQkFBaUIsR0FBRy9DLElBQUksS0FBSztBQUN4Q2QsTUFBSSxFQUFFQywwRUFEa0M7QUFFeENhO0FBRndDLENBQUwsQ0FBOUIsQzs7Ozs7Ozs7Ozs7O0FDbkJQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFFTyxNQUFNZ0QsV0FBVyxHQUFHQyxLQUFLLEtBQUs7QUFBRS9ELE1BQUksRUFBRUMsbUVBQVI7QUFBNEJtQyxNQUFJLEVBQUUyQjtBQUFsQyxDQUFMLENBQXpCO0FBRUEsTUFBTUMsVUFBVSxHQUFHLE1BQU12QyxRQUFRLElBQ3RDQyx5REFBSyxDQUFFLEdBQUVDLGtEQUFNLENBQUNDLElBQUssWUFBaEIsQ0FBTCxDQUFrQ0MsSUFBbEMsQ0FBdUNDLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxJQUFKLEVBQTlDLEVBQTBERixJQUExRCxDQUErREMsR0FBRyxJQUFJTCxRQUFRLENBQUNxQyxXQUFXLENBQUNoQyxHQUFELENBQVosQ0FBOUUsQ0FESyxDOzs7Ozs7Ozs7Ozs7QUNQUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRU8sTUFBTW1DLE1BQU0sR0FBR2hDLEVBQUUsS0FBSztBQUMzQmpDLE1BQUksRUFBRUMsOERBRHFCO0FBRTNCZ0M7QUFGMkIsQ0FBTCxDQUFqQjtBQUtBLE1BQU1pQyxhQUFhLEdBQUcsT0FBTztBQUNsQ2xFLE1BQUksRUFBRUMsc0VBQXFCa0U7QUFETyxDQUFQLENBQXRCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQUDtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBLE1BQU1DLFdBQU4sU0FBMEJDLCtDQUExQixDQUFvQztBQUNsQ0MsUUFBTSxHQUFHO0FBQ1AsVUFBTTtBQUFFMUIsYUFBRjtBQUFXMkI7QUFBWCxRQUFxQixLQUFLQyxLQUFoQztBQUNBLFdBQ0U7QUFBQSx5Q0FBYztBQUFkO0FBQUE7QUFBQSxxNFBBOEJHNUIsT0FBTyxDQUFDNkIsR0FBUixDQUFZLENBQUNDLENBQUQsRUFBSUMsS0FBSixLQUFjO0FBQ3pCLFlBQU1DLFNBQVMsR0FBR0wsS0FBSyxLQUFLSSxLQUE1QjtBQUNBLFlBQU1FLFNBQVMsR0FDYix1Q0FBdUNELFNBQVMsR0FBRyw2Q0FBSCxHQUFtRCxFQUFuRyxDQURGO0FBRUEsYUFDRTtBQUFJLFdBQUcsRUFBRUYsQ0FBQyxDQUFDekMsRUFBWDtBQUFxQyxlQUFPLEVBQUUsTUFBTSxLQUFLdUMsS0FBTCxDQUFXTSxRQUFYLENBQW9CSixDQUFDLENBQUN6QyxFQUF0QixDQUFwRDtBQUFBLDRDQUEwQjRDLFNBQTFCO0FBQUEsU0FDRTtBQUFBLDJDQUFlO0FBQWYsU0FDRTtBQUFBLDJDQUFlO0FBQWYsU0FDRTtBQUFLLFdBQUcsRUFBRUgsQ0FBQyxDQUFDSyxLQUFGLENBQVFDLE1BQVIsQ0FBZSxDQUFmLEVBQWtCQyxHQUE1QjtBQUFBO0FBQUEsUUFERixDQURGLEVBSUU7QUFBQSwyQ0FBZTtBQUFmLFNBQ0U7QUFBQSwyQ0FBZTtBQUFmLFNBQTRCUCxDQUFDLENBQUNRLElBQTlCLENBREYsRUFFRTtBQUFBO0FBQUEsU0FBTVIsQ0FBQyxDQUFDUyxPQUFGLENBQVUsQ0FBVixFQUFhRCxJQUFuQixDQUZGLENBSkYsQ0FERixDQURGO0FBYUQsS0FqQkEsQ0E5QkgsQ0FERjtBQW1ERDs7QUF0RGlDOztBQXlEcEMsTUFBTUUsVUFBTixTQUF5QmYsK0NBQXpCLENBQW1DO0FBQUE7QUFBQTs7QUFBQSxtQ0FDekI7QUFDTmdCLFVBQUksRUFBRSxLQUFLYixLQUFMLENBQVdhLElBQVgsSUFBbUIsRUFEbkI7QUFFTmQsV0FBSyxFQUFFLENBQUM7QUFGRixLQUR5Qjs7QUFBQSwwQ0FNbEJlLENBQUMsSUFBSTtBQUNsQixZQUFNRCxJQUFJLEdBQUdDLENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxLQUF0QjtBQUNBLFdBQUtDLFFBQUwsQ0FBYztBQUFFSixZQUFJLEVBQUVBO0FBQVIsT0FBZDs7QUFDQSxVQUFJQSxJQUFJLEtBQUssRUFBYixFQUFpQjtBQUNmLGFBQUtiLEtBQUwsQ0FBVy9CLFlBQVgsQ0FBd0I0QyxJQUF4QjtBQUNELE9BRkQsTUFFTztBQUNMLGFBQUtJLFFBQUwsQ0FBYztBQUFFbEIsZUFBSyxFQUFFLENBQUM7QUFBVixTQUFkO0FBQ0EsYUFBS0MsS0FBTCxDQUFXM0IsaUJBQVg7QUFDRDtBQUNGLEtBZmdDOztBQUFBLGlEQWlCWFosRUFBRSxJQUFJO0FBQzFCLFdBQUt3RCxRQUFMLENBQWM7QUFBRUosWUFBSSxFQUFFO0FBQVIsT0FBZDtBQUNBLFdBQUtiLEtBQUwsQ0FBV3hDLFVBQVgsQ0FBc0JDLEVBQXRCO0FBQ0EsV0FBS3VDLEtBQUwsQ0FBVzNCLGlCQUFYO0FBQ0QsS0FyQmdDOztBQUFBLHdDQXVCcEJ5QyxDQUFDLElBQUksQ0FDaEI7QUFDQTs7QUFDQTtBQUNKO0FBQ0csS0E1QmdDOztBQUFBLHlDQThCbkJBLENBQUMsSUFBSTtBQUNqQixVQUFJQSxDQUFDLENBQUNDLE1BQUYsQ0FBU0MsS0FBVCxLQUFtQixFQUF2QixFQUEyQjtBQUN6QixhQUFLaEIsS0FBTCxDQUFXL0IsWUFBWCxDQUF3QjZDLENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxLQUFqQztBQUNEO0FBQ0YsS0FsQ2dDOztBQUFBLDJDQW9DakJGLENBQUMsSUFBSTtBQUNuQixjQUFRQSxDQUFDLENBQUNJLE9BQVY7QUFDRSxhQUFLLEVBQUw7QUFBUztBQUNQLGVBQUtELFFBQUwsQ0FBYztBQUFFbEIsaUJBQUssRUFBRSxLQUFLb0IsS0FBTCxDQUFXcEIsS0FBWCxHQUFtQjtBQUE1QixXQUFkO0FBQ0E7O0FBQ0YsYUFBSyxFQUFMO0FBQVM7QUFDUCxlQUFLa0IsUUFBTCxDQUFjO0FBQUVsQixpQkFBSyxFQUFFLEtBQUtvQixLQUFMLENBQVdwQixLQUFYLEdBQW1CO0FBQTVCLFdBQWQ7QUFDQTs7QUFDRixhQUFLLEVBQUw7QUFBUztBQUNQLGdCQUFJcUIsT0FBTyxHQUFHLEtBQWQ7O0FBQ0EsZ0JBQUksS0FBS0QsS0FBTCxDQUFXcEIsS0FBWCxLQUFxQixDQUFDLENBQTFCLEVBQTZCO0FBQzNCLG1CQUFLQyxLQUFMLENBQVd4QyxVQUFYLENBQXNCLEtBQUt3QyxLQUFMLENBQVdxQixNQUFYLENBQWtCakQsT0FBbEIsQ0FBMEIsS0FBSytDLEtBQUwsQ0FBV3BCLEtBQXJDLEVBQTRDdEMsRUFBbEU7QUFDQTJELHFCQUFPLEdBQUcsSUFBVjtBQUNELGFBSEQsTUFHTztBQUNMLG9CQUFNUCxJQUFJLEdBQUdDLENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxLQUFULENBQWVNLElBQWYsRUFBYjs7QUFDQSxrQkFBSVQsSUFBSSxDQUFDVSxNQUFMLEtBQWdCLENBQXBCLEVBQXVCO0FBQ3JCLHFCQUFLdkIsS0FBTCxDQUFXeEMsVUFBWCxDQUFzQnFELElBQXRCO0FBQ0FPLHVCQUFPLEdBQUcsSUFBVjtBQUNEO0FBQ0Y7O0FBQ0QsZ0JBQUlBLE9BQUosRUFBYTtBQUNYLG1CQUFLSCxRQUFMLENBQWM7QUFBRUosb0JBQUksRUFBRTtBQUFSLGVBQWQ7QUFDQSxtQkFBS2IsS0FBTCxDQUFXM0IsaUJBQVg7QUFDQSxtQkFBSzRDLFFBQUwsQ0FBYztBQUFFbEIscUJBQUssRUFBRSxDQUFDO0FBQVYsZUFBZDtBQUNEOztBQUNEO0FBQ0Q7QUF6Qkg7QUEyQkQsS0FoRWdDO0FBQUE7O0FBa0VqQ0QsUUFBTSxHQUFHO0FBQ1AsVUFBTTBCLFdBQVcsR0FBRyxLQUFLeEIsS0FBTCxDQUFXeUIsSUFBWCxDQUFnQkMsYUFBaEIsQ0FBOEI7QUFBRWpFLFFBQUUsRUFBRTtBQUFOLEtBQTlCLENBQXBCO0FBQ0EsVUFBTVcsT0FBTyxHQUFHLEtBQUs0QixLQUFMLENBQVdxQixNQUFYLENBQWtCakQsT0FBbEM7QUFDQSxXQUNFO0FBQThCLFlBQU0sRUFBRSxLQUFLdUQsVUFBM0M7QUFBQSwwQ0FBZTtBQUFmO0FBQUE7QUFBQSxpL09BZ0JFO0FBRUUsaUJBQVcsRUFBRUgsV0FGZjtBQUdFLFdBQUssRUFBRSxLQUFLTCxLQUFMLENBQVdOLElBSHBCO0FBSUUsY0FBUSxFQUFFLEtBQUtlLFlBSmpCO0FBS0UsZUFBUyxFQUFFLEtBQUtDLGFBTGxCO0FBTUUsYUFBTyxFQUFFLEtBQUtDLFdBTmhCO0FBQUEsMENBQ1k7QUFEWixNQWhCRixFQXdCRzFELE9BQU8sSUFBSSxNQUFDLFdBQUQ7QUFBYSxhQUFPLEVBQUVBLE9BQXRCO0FBQStCLGNBQVEsRUFBRSxLQUFLMkQsbUJBQTlDO0FBQW1FLFdBQUssRUFBRSxLQUFLWixLQUFMLENBQVdwQjtBQUFyRixNQXhCZCxDQURGO0FBNEJEOztBQWpHZ0M7O0FBb0duQyxNQUFNaUMsa0JBQWtCLEdBQUcvRSxRQUFRLEtBQUs7QUFDdENPLFlBQVUsRUFBRXFELElBQUksSUFBSTVELFFBQVEsQ0FBQ08sd0VBQVUsQ0FBQ3FELElBQUQsQ0FBWCxDQURVO0FBRXRDNUMsY0FBWSxFQUFFQyxLQUFLLElBQUlqQixRQUFRLENBQUNnQiwyRUFBWSxDQUFDQyxLQUFELENBQWIsQ0FGTztBQUd0Q0csbUJBQWlCLEVBQUUsTUFBTXBCLFFBQVEsQ0FBQ29CLGdGQUFpQixFQUFsQjtBQUhLLENBQUwsQ0FBbkM7O0FBTUEsTUFBTTRELGVBQWUsR0FBR2QsS0FBSyxLQUFLO0FBQ2hDRSxRQUFNLEVBQUVGLEtBQUssQ0FBQ0U7QUFEa0IsQ0FBTCxDQUE3Qjs7QUFJZWEsMEhBQU8sQ0FBQ0QsZUFBRCxFQUFrQkQsa0JBQWxCLENBQVAsQ0FBNkNHLDZEQUFVLENBQUN2QixVQUFELENBQXZELENBQWYsRTs7Ozs7Ozs7Ozs7Ozs7OztBQzVLZSwrRTs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBLCtFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGZjtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLE1BQU13QixPQUFOLFNBQXNCQyw0Q0FBSyxDQUFDQyxhQUE1QixDQUEwQztBQUN4Q3hDLFFBQU0sR0FBRztBQUNQLFVBQU07QUFBRXlDLGFBQUY7QUFBV0MsZ0JBQVg7QUFBdUJqSCwyQkFBdkI7QUFBOENRO0FBQTlDLFFBQTJFLEtBQUtpRSxLQUF0RjtBQUNBLFdBQ0U7QUFBSyxXQUFLLEVBQUU7QUFBRXlDLHFCQUFhLEVBQUU7QUFBakIsT0FBWjtBQUFBO0FBQUEsT0FDRTtBQUFBO0FBQUEsT0FBSSxNQUFDLDJEQUFEO0FBQWtCLFFBQUUsRUFBQztBQUFyQixNQUFKLENBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxrRUFRRTtBQUVFLGNBQVEsRUFBRUQsVUFGWjtBQUdFLGFBQU8sRUFBRSxNQUFNO0FBQ2JqSCw2QkFBcUI7QUFDdEIsT0FMSDtBQUFBLHFLQUNZO0FBRFosT0FPRSxNQUFDLDJEQUFEO0FBQWtCLFFBQUUsRUFBQztBQUFyQixNQVBGLENBUkYsRUFpQkdnSCxPQUFPLENBQUNoQixNQUFSLEtBQW1CLENBQW5CLEdBQ0c7QUFBQTtBQUFBLE9BQUcsTUFBQywyREFBRDtBQUFrQixRQUFFLEVBQUM7QUFBckIsTUFBSCxDQURILEdBRUc7QUFBQTtBQUFBLE9BQ0U7QUFBQTtBQUFBLE9BQ0dnQixPQUFPLENBQUN0QyxHQUFSLENBQVl5QyxNQUFNLElBQ2pCO0FBQUE7QUFBQSxPQUNFO0FBQUE7QUFBQSxPQUNHQSxNQUFNLENBQUNDLFNBQVAsR0FDRztBQUFBO0FBQUEsbUJBREgsR0FFRztBQUNFLGFBQU8sRUFBRSxNQUFNO0FBQ2I1RyxnQ0FBd0IsQ0FBQzJHLE1BQU0sQ0FBQ2pGLEVBQVIsQ0FBeEI7QUFDRCxPQUhIO0FBQUE7QUFBQSxPQUtFLE1BQUMsMkRBQUQ7QUFBa0IsUUFBRSxFQUFDO0FBQXJCLE1BTEYsQ0FITixDQURGLEVBWUU7QUFBQTtBQUFBLE9BQ0dpRixNQUFNLENBQUNoQyxJQURWLENBWkYsRUFlRTtBQUFBO0FBQUEsT0FDR2dDLE1BQU0sQ0FBQ2xILElBRFYsQ0FmRixFQWtCRTtBQUFBO0FBQUEsT0FDR2tILE1BQU0sQ0FBQ0UsTUFEVixDQWxCRixDQURELENBREgsQ0FERixDQW5CTixDQURGO0FBa0REOztBQXJEdUM7O0FBd0QxQyxNQUFNWixrQkFBa0IsR0FBRy9FLFFBQVEsS0FBSztBQUN0QzFCLHVCQUFxQixFQUFFNEUsS0FBSyxJQUFJbEQsUUFBUSxDQUFDMUIscUZBQXFCLENBQUM0RSxLQUFELENBQXRCLENBREY7QUFFdENwRSwwQkFBd0IsRUFBRUMsUUFBUSxJQUFJaUIsUUFBUSxDQUFDbEIsd0ZBQXdCLENBQUNDLFFBQUQsQ0FBekI7QUFGUixDQUFMLENBQW5DOztBQUtBLE1BQU1pRyxlQUFlLEdBQUdkLEtBQUssS0FBSztBQUNoQ3FCLFlBQVUsRUFBRUssc0VBQW9CLENBQUMxQixLQUFELENBREE7QUFFaENvQixTQUFPLEVBQUVPLDREQUFVLENBQUMzQixLQUFEO0FBRmEsQ0FBTCxDQUE3Qjs7QUFLZWUsMEhBQU8sQ0FBQ0QsZUFBRCxFQUFrQkQsa0JBQWxCLENBQVAsQ0FBNkNJLE9BQTdDLENBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0VBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTVcsU0FBUyxHQUFHO0FBQ2hCQyxZQUFVLEVBQUUsTUFESTtBQUVoQkMsYUFBVyxFQUFFO0FBRkcsQ0FBbEI7QUFLQSxNQUFNQyxhQUFhLEdBQUc7QUFDcEJDLE9BQUssRUFBRSxNQURhO0FBRXBCRixhQUFXLEVBQUU7QUFGTyxDQUF0QjtBQUtBLE1BQU1HLFdBQVcsR0FBRztBQUNsQkMsaUJBQWUsRUFBRSxTQURDO0FBRWxCQyxTQUFPLEVBQUUsV0FGUztBQUdsQkMsUUFBTSxFQUFFLE1BSFU7QUFJbEJDLE9BQUssRUFBRTtBQUpXLENBQXBCOztBQU9BLE1BQU1DLGVBQWUsR0FBR25ILElBQUksSUFBSTtBQUM5QixTQUFPQSxJQUFJLENBQUNvSCxZQUFMLElBQXFCcEgsSUFBSSxDQUFDbUIsRUFBakM7QUFDRCxDQUZEOztBQUlBLE1BQU1rRyxNQUFNLEdBQUcsQ0FBQztBQUFFQyxTQUFGO0FBQVdDLE9BQVg7QUFBa0JuSCxjQUFsQjtBQUFnQ0UsZ0JBQWhDO0FBQWdEK0I7QUFBaEQsQ0FBRCxLQUNiO0FBQUssT0FBSyxFQUFFeUU7QUFBWixHQUNHUSxPQUFPLENBQUN0SCxJQUFSLEdBQ0M7QUFBQSxvQ0FBZTtBQUFmO0FBQUE7QUFBQSxnbUtBNEJFO0FBQUEsb0NBQWU7QUFBZixHQUNFO0FBRUUsS0FBRyxFQUNBc0gsT0FBTyxDQUFDdEgsSUFBUixDQUFha0UsTUFBYixJQUF1Qm9ELE9BQU8sQ0FBQ3RILElBQVIsQ0FBYWtFLE1BQWIsQ0FBb0JlLE1BQTNDLElBQXFEcUMsT0FBTyxDQUFDdEgsSUFBUixDQUFha0UsTUFBYixDQUFvQixDQUFwQixFQUF1QkMsR0FBN0UsSUFDQSx1QkFKSjtBQU1FLE9BQUssRUFBQyxJQU5SO0FBT0UsUUFBTSxFQUFDLElBUFQ7QUFRRSxLQUFHLEVBQUVnRCxlQUFlLENBQUNHLE9BQU8sQ0FBQ3RILElBQVQsQ0FSdEI7QUFBQSxvQ0FDWTtBQURaLEVBREYsQ0E1QkYsRUF3Q0U7QUFBQSxvQ0FBZTtBQUFmLEdBQXNDbUgsZUFBZSxDQUFDRyxPQUFPLENBQUN0SCxJQUFULENBQXJELENBeENGLENBREQsR0E0Q0M7QUFBNEMsT0FBSyxFQUFFO0FBQUU2RyxTQUFLLEVBQUU7QUFBVCxHQUFuRDtBQUF1RSxTQUFPLEVBQUV4RSxLQUFoRjtBQUFBLGlLQUFrQjtBQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDhEQUdFLE1BQUMsMkRBQUQ7QUFBa0IsSUFBRSxFQUFDO0FBQXJCLEVBSEYsQ0E3Q0osRUFtREdpRixPQUFPLENBQUN0SCxJQUFSLEdBQ0M7QUFBQSxxTEFBZTtBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtxSkFRRTtBQUVFLFNBQU8sRUFBRSxNQUFNO0FBQ2J1SCxTQUFLLEdBQUdqSCxjQUFjLEVBQWpCLEdBQXNCRixZQUFZLEVBQXZDO0FBQ0QsR0FKSDtBQUFBLHFMQUNZO0FBRFosR0FNR21ILEtBQUssR0FBRyxRQUFILEdBQWMsTUFOdEIsQ0FSRixDQURELEdBa0JHLElBckVOLENBREY7O0FBMEVBLE1BQU03QixrQkFBa0IsR0FBRy9FLFFBQVEsS0FBSztBQUN0QzBCLE9BQUssRUFBRSxNQUFNMUIsUUFBUSxDQUFDMEIscUVBQUssRUFBTixDQURpQjtBQUV0Q2pDLGNBQVksRUFBRSxNQUFNTyxRQUFRLENBQUNQLDZFQUFZLEVBQWIsQ0FGVTtBQUd0Q0UsZ0JBQWMsRUFBRSxNQUFNSyxRQUFRLENBQUNMLCtFQUFjLEVBQWY7QUFIUSxDQUFMLENBQW5DOztBQU1BLE1BQU1xRixlQUFlLEdBQUdkLEtBQUssS0FBSztBQUNoQ3lDLFNBQU8sRUFBRXpDLEtBQUssQ0FBQ3lDLE9BRGlCO0FBRWhDQyxPQUFLLEVBQUUxQyxLQUFLLENBQUMyQyxRQUFOLENBQWVEO0FBRlUsQ0FBTCxDQUE3Qjs7QUFLZTNCLDBIQUFPLENBQUNELGVBQUQsRUFBa0JELGtCQUFsQixDQUFQLENBQTZDMkIsTUFBN0MsQ0FBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xIQTtBQUNBOztBQUVBLE1BQU1JLE1BQU0sR0FBRy9ELEtBQUssSUFDbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpbENBUUUsTUFBQywrQ0FBRCxPQVJGLEVBU0U7QUFBQTtBQUFBLEdBQU1BLEtBQUssQ0FBQ2dFLFFBQVosQ0FURixDQURGOztBQWNlRCxxRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakJBOztBQUVBLE1BQU1FLFVBQU4sU0FBeUI1Qiw0Q0FBSyxDQUFDQyxhQUEvQixDQUE2QztBQUMzQzRCLGFBQVcsR0FBRztBQUNaO0FBQ0EsU0FBSy9DLEtBQUwsR0FBYTtBQUNYZ0QsV0FBSyxFQUFFQyxJQUFJLENBQUNDLEdBQUwsRUFESTtBQUVYQyxxQkFBZSxFQUFFO0FBRk4sS0FBYjtBQUlBLFNBQUtDLEtBQUwsR0FBYSxJQUFiOztBQUNBLFNBQUtDLElBQUwsR0FBWSxNQUFNO0FBQ2hCLFdBQUt2RCxRQUFMLENBQWM7QUFDWnFELHVCQUFlLEVBQUVGLElBQUksQ0FBQ0MsR0FBTCxLQUFhLEtBQUtsRCxLQUFMLENBQVdnRCxLQUF4QixJQUFpQyxLQUFLbkUsS0FBTCxDQUFXekQsUUFBWCxJQUF1QixDQUF4RDtBQURMLE9BQWQ7QUFHRCxLQUpEO0FBS0Q7O0FBQ0RrSSwyQkFBeUIsQ0FBQ3pFLEtBQUQsRUFBUTtBQUMvQixRQUFJLEtBQUtBLEtBQUwsQ0FBV3pELFFBQVgsS0FBd0J5RCxLQUFLLENBQUN6RCxRQUE5QixJQUEwQyxLQUFLeUQsS0FBTCxDQUFXM0QsS0FBWCxLQUFxQjJELEtBQUssQ0FBQzNELEtBQXpFLEVBQWdGO0FBQzlFLFdBQUs0RSxRQUFMLENBQWM7QUFDWmtELGFBQUssRUFBRUMsSUFBSSxDQUFDQyxHQUFMLEVBREs7QUFFWkMsdUJBQWUsRUFBRTtBQUZMLE9BQWQ7QUFJRDtBQUNGOztBQUNESSxtQkFBaUIsR0FBRztBQUNsQixTQUFLSCxLQUFMLEdBQWFJLFdBQVcsQ0FBQyxLQUFLSCxJQUFOLEVBQVksR0FBWixDQUF4QjtBQUNEOztBQUNESSxzQkFBb0IsR0FBRztBQUNyQkMsaUJBQWEsQ0FBQyxLQUFLTixLQUFOLENBQWI7QUFDRDs7QUFDRHpFLFFBQU0sR0FBRztBQUNQLFVBQU1nRixVQUFVLEdBQUcsQ0FBQyxDQUFFLEtBQUszRCxLQUFMLENBQVdtRCxlQUFYLEdBQTZCLEdBQTlCLEdBQXFDLEtBQUt0RSxLQUFMLENBQVczRCxLQUFYLENBQWlCMEksV0FBdkQsRUFBb0VDLE9BQXBFLENBQTRFLENBQTVFLENBQUQsR0FBa0YsR0FBckc7QUFDQSxVQUFNQyxRQUFRLEdBQUcsS0FBS2pGLEtBQUwsQ0FBVzFELElBQVgsQ0FBZ0JvSCxZQUFoQixJQUFnQyxLQUFLMUQsS0FBTCxDQUFXMUQsSUFBWCxDQUFnQm1CLEVBQWpFO0FBQ0EsV0FDRTtBQUFBLDBDQUFlO0FBQWY7QUFBQTtBQUFBLHk4T0F3RUU7QUFBQSwwQ0FBZTtBQUFmLE9BQ0U7QUFBQSwwQ0FBZTtBQUFmLE9BQ0U7QUFBSyxTQUFHLEVBQUUsS0FBS3VDLEtBQUwsQ0FBVzNELEtBQVgsQ0FBaUJrRSxLQUFqQixDQUF1QkMsTUFBdkIsQ0FBOEIsQ0FBOUIsRUFBaUNDLEdBQTNDO0FBQWdELFdBQUssRUFBQyxLQUF0RDtBQUE0RCxZQUFNLEVBQUMsS0FBbkU7QUFBQTtBQUFBLE1BREYsQ0FERixFQUlFO0FBQUEsMENBQWU7QUFBZixPQUNFO0FBQUEsMENBQWU7QUFBZixPQUEwQyxLQUFLVCxLQUFMLENBQVczRCxLQUFYLENBQWlCcUUsSUFBM0QsQ0FERixFQUVFO0FBQUEsMENBQWU7QUFBZixPQUEyQyxLQUFLVixLQUFMLENBQVczRCxLQUFYLENBQWlCc0UsT0FBakIsQ0FBeUJWLEdBQXpCLENBQTZCaUYsQ0FBQyxJQUFJQSxDQUFDLENBQUN4RSxJQUFwQyxFQUEwQ3lFLElBQTFDLENBQStDLElBQS9DLENBQTNDLENBRkYsRUFHRTtBQUFBLDBDQUFlO0FBQWYsT0FDRTtBQUVFLFNBQUcsRUFDQSxLQUFLbkYsS0FBTCxDQUFXMUQsSUFBWCxDQUFnQmtFLE1BQWhCLElBQTBCLEtBQUtSLEtBQUwsQ0FBVzFELElBQVgsQ0FBZ0JrRSxNQUFoQixDQUF1QmUsTUFBakQsSUFBMkQsS0FBS3ZCLEtBQUwsQ0FBVzFELElBQVgsQ0FBZ0JrRSxNQUFoQixDQUF1QixDQUF2QixFQUEwQkMsR0FBdEYsSUFDQSx1QkFKSjtBQU1FLFdBQUssRUFBQyxJQU5SO0FBT0UsWUFBTSxFQUFDLElBUFQ7QUFRRSxTQUFHLEVBQUV3RSxRQVJQO0FBU0UsV0FBSyxFQUFFQSxRQVRUO0FBQUEsMENBQ1k7QUFEWixNQURGLENBSEYsRUFnQkU7QUFBQSwwQ0FBZTtBQUFmLE9BQXNDQSxRQUF0QyxDQWhCRixDQUpGLENBeEVGLEVBK0ZFO0FBQUEsMENBQWU7QUFBZixPQUNFO0FBQTJDLFdBQUssRUFBRTtBQUFFRyxhQUFLLEVBQUVOO0FBQVQsT0FBbEQ7QUFBQSwwQ0FBZTtBQUFmLE1BREYsQ0EvRkYsQ0FERjtBQXFHRDs7QUFwSTBDOztBQXVJOUJiLHlFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeklBO0NBR0E7QUFDQTtBQUNBOztBQUNBLElBQUksS0FBSixFQUFpRSxFQUloRTs7QUFFY29CLG1FQUFJLElBQUk7QUFDckIsUUFBTUMsUUFBUSxHQUFHbkQsNkRBQVUsQ0FBQ2tELElBQUQsQ0FBM0I7QUFDQSxTQUFPLE1BQU1FLFlBQU4sU0FBMkIxRiwrQ0FBM0IsQ0FBcUM7QUFDMUMsaUJBQWEyRixlQUFiLENBQTZCQyxPQUE3QixFQUFzQztBQUNwQyxVQUFJekYsS0FBSjs7QUFDQSxVQUFJLE9BQU9xRixJQUFJLENBQUNHLGVBQVosS0FBZ0MsVUFBcEMsRUFBZ0Q7QUFDOUN4RixhQUFLLEdBQUcsTUFBTXFGLElBQUksQ0FBQ0csZUFBTCxDQUFxQkMsT0FBckIsQ0FBZDtBQUNELE9BSm1DLENBTXBDO0FBQ0E7OztBQUNBLFlBQU07QUFBRUM7QUFBRixVQUFVRCxPQUFoQixDQVJvQyxDQVNwQzs7QUFDQSxZQUFNO0FBQUVFLGNBQUY7QUFBVUM7QUFBVixVQUF1QkYsR0FBRyxJQUFJRyxNQUFNLENBQUNDLGFBQVAsQ0FBcUI5RixLQUFyQixDQUEyQitGLFlBQS9ELENBVm9DLENBWXBDO0FBQ0E7O0FBQ0EsWUFBTTFCLEdBQUcsR0FBR0QsSUFBSSxDQUFDQyxHQUFMLEVBQVo7QUFFQSw2Q0FBWXJFLEtBQVo7QUFBbUIyRixjQUFuQjtBQUEyQkMsZ0JBQTNCO0FBQXFDdkI7QUFBckM7QUFDRDs7QUFFRHZFLFVBQU0sR0FBRztBQUNQLDBCQUE0QyxLQUFLRSxLQUFqRDtBQUFBLFlBQU07QUFBRTJGLGNBQUY7QUFBVUMsZ0JBQVY7QUFBb0J2QjtBQUFwQixPQUFOO0FBQUEsWUFBa0NyRSxLQUFsQzs7QUFDQSxhQUNFLE1BQUMsdURBQUQ7QUFBYyxjQUFNLEVBQUUyRixNQUF0QjtBQUE4QixnQkFBUSxFQUFFQyxRQUF4QztBQUFrRCxrQkFBVSxFQUFFdkI7QUFBOUQsU0FDRSxNQUFDLFFBQUQsRUFBY3JFLEtBQWQsQ0FERixDQURGO0FBS0Q7O0FBM0J5QyxHQUE1QztBQTZCRCxDQS9CRCxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1pBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNZ0csS0FBTixTQUFvQjNELDRDQUFLLENBQUNDLGFBQTFCLENBQXdDO0FBQ3RDeEMsUUFBTSxHQUFHO0FBQ1AsVUFBTTtBQUFFbUcsV0FBRjtBQUFTckM7QUFBVCxRQUFxQixLQUFLNUQsS0FBaEM7QUFDQSxXQUNFO0FBQUssV0FBSyxFQUFFO0FBQUV5QyxxQkFBYSxFQUFFO0FBQWpCO0FBQVosT0FDRSxrQkFBSSxNQUFDLDJEQUFEO0FBQWtCLFFBQUUsRUFBQztBQUFyQixNQUFKLENBREYsRUFFR3dELEtBQUssQ0FBQzFFLE1BQU4sS0FBaUIsQ0FBakIsR0FDRyxpQkFBRyxNQUFDLDJEQUFEO0FBQWtCLFFBQUUsRUFBQztBQUFyQixNQUFILENBREgsR0FFRztBQUFBLDBDQUFpQjtBQUFqQjtBQUFBO0FBQUEsNGhGQU1FO0FBQUE7QUFBQSxPQUNHMEUsS0FBSyxDQUFDaEcsR0FBTixDQUFVLENBQUNpRyxDQUFELEVBQUkvRixLQUFKLEtBQ1QsTUFBQyxrREFBRDtBQUNFLFVBQUksRUFBRStGLENBRFI7QUFFRSxhQUFPLEVBQUV0QyxPQUZYO0FBR0UsV0FBSyxFQUFFekQsS0FIVDtBQUlFLFNBQUcsRUFBRUEsS0FKUDtBQUtFLGNBQVEsRUFBRSxNQUFNLEtBQUtILEtBQUwsQ0FBV1AsTUFBWCxDQUFrQnlHLENBQUMsQ0FBQ3pJLEVBQXBCLENBTGxCO0FBTUUsa0JBQVksRUFBRSxNQUFNLEtBQUt1QyxLQUFMLENBQVdqQyxnQkFBWCxDQUE0Qm1JLENBQUMsQ0FBQ3pJLEVBQTlCO0FBTnRCLE1BREQsQ0FESCxDQU5GLENBSk4sQ0FERjtBQTBCRDs7QUE3QnFDOztBQWdDeEMsTUFBTXVFLGtCQUFrQixHQUFHL0UsUUFBUSxLQUFLO0FBQ3RDd0MsUUFBTSxFQUFFaEMsRUFBRSxJQUFJUixRQUFRLENBQUN3QyxtRUFBTSxDQUFDaEMsRUFBRCxDQUFQLENBRGdCO0FBRXRDTSxrQkFBZ0IsRUFBRU4sRUFBRSxJQUFJUixRQUFRLENBQUNjLDhFQUFnQixDQUFDTixFQUFELENBQWpCO0FBRk0sQ0FBTCxDQUFuQzs7QUFLQSxNQUFNd0UsZUFBZSxHQUFHZCxLQUFLLEtBQUs7QUFDaEN4RCxPQUFLLEVBQUV3RCxLQUFLLENBQUN4RDtBQURtQixDQUFMLENBQTdCOztBQUlldUUsMEhBQU8sQ0FBQ0QsZUFBRCxFQUFrQkQsa0JBQWxCLENBQVAsQ0FBNkNnRSxLQUE3QyxDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqREE7QUFFZSxnRUFBQztBQUFFN0YsT0FBRjtBQUFTZ0csTUFBVDtBQUFldkMsU0FBZjtBQUF3QndDLGNBQXhCO0FBQXNDQztBQUF0QyxDQUFELEtBQXNEO0FBQ25FLFFBQU01RyxNQUFNLEdBQUcwRyxJQUFJLENBQUNHLE1BQUwsSUFBZTFDLE9BQU8sQ0FBQ3RILElBQXZCLElBQStCNkosSUFBSSxDQUFDRyxNQUFMLENBQVlDLE1BQVosQ0FBbUJDLENBQUMsSUFBSUEsQ0FBQyxDQUFDL0ksRUFBRixLQUFTbUcsT0FBTyxDQUFDdEgsSUFBUixDQUFhbUIsRUFBOUMsRUFBa0Q4RCxNQUFsRCxLQUE2RCxDQUE1RixHQUNYO0FBQVEsV0FBTyxFQUFFOEU7QUFBakIsY0FEVyxHQUVYLElBRko7QUFHQSxTQUNFO0FBQUssU0FBSyxFQUFFO0FBQUVJLGNBQVEsRUFBRSxNQUFaO0FBQW9CQyxrQkFBWSxFQUFFLE1BQWxDO0FBQTBDdkQsV0FBSyxFQUFDLE1BQWhEO0FBQXdEaUMsV0FBSyxFQUFFO0FBQS9EO0FBQVosS0FDRTtBQUFLLFNBQUssRUFBRTtBQUFFdUIsa0JBQVksRUFBRSxNQUFoQjtBQUF3QnhELFdBQUssRUFBRTtBQUEvQjtBQUFaLEtBQ0U7QUFBSyxPQUFHLEVBQUVnRCxJQUFJLENBQUM5SixLQUFMLENBQVdrRSxLQUFYLENBQWlCQyxNQUFqQixDQUF3QixDQUF4QixFQUEyQkMsR0FBckM7QUFBMEMsU0FBSyxFQUFDLElBQWhEO0FBQXFELFVBQU0sRUFBQztBQUE1RCxJQURGLENBREYsRUFJRTtBQUFLLFNBQUssRUFBRTtBQUFFa0csa0JBQVksRUFBRSxNQUFoQjtBQUF5QnhELFdBQUssRUFBRTtBQUFoQztBQUFaLEtBQ0doRCxLQUFLLEdBQUcsQ0FEWCxDQUpGLEVBT0U7QUFBSyxTQUFLLEVBQUU7QUFBRXdHLGtCQUFZLEVBQUUsTUFBaEI7QUFBd0J4RCxXQUFLLEVBQUU7QUFBL0I7QUFBWixLQUNHZ0QsSUFBSSxDQUFDOUosS0FBTCxDQUFXcUUsSUFEZCxFQUNtQixpQkFEbkIsRUFFR3lGLElBQUksQ0FBQzlKLEtBQUwsQ0FBV3NFLE9BQVgsQ0FBbUJWLEdBQW5CLENBQXVCaUYsQ0FBQyxJQUFJQSxDQUFDLENBQUN4RSxJQUE5QixFQUFvQ3lFLElBQXBDLENBQXlDLElBQXpDLENBRkgsRUFFa0QsaUJBRmxELENBUEYsRUFZRTtBQUFLLFNBQUssRUFBRTtBQUFFd0Isa0JBQVksRUFBRSxNQUFoQjtBQUF3QnhELFdBQUssRUFBRSxNQUEvQjtBQUF1Q3lELGFBQU8sRUFBRTtBQUFoRDtBQUFaLEtBQ0dULElBQUksQ0FBQzdKLElBQUwsS0FBYzZKLElBQUksQ0FBQzdKLElBQUwsQ0FBVW9ILFlBQVYsSUFBMEJ5QyxJQUFJLENBQUM3SixJQUFMLENBQVVtQixFQUFsRCxDQURILENBWkYsRUFlRTtBQUFLLFNBQUssRUFBRTtBQUFFa0osa0JBQVksRUFBRSxNQUFoQjtBQUF3QnhELFdBQUssRUFBRTtBQUEvQjtBQUFaLEtBQ0dnRCxJQUFJLENBQUM3SixJQUFMLElBQWFzSCxPQUFPLENBQUN0SCxJQUFyQixJQUE2QjZKLElBQUksQ0FBQzdKLElBQUwsQ0FBVW1CLEVBQVYsS0FBaUJtRyxPQUFPLENBQUN0SCxJQUFSLENBQWFtQixFQUEzRCxHQUNHO0FBQ0UsV0FBTyxFQUFFLE1BQU07QUFDYjJJLGtCQUFZLENBQUNELElBQUksQ0FBQzFJLEVBQU4sQ0FBWjtBQUNEO0FBSEgsU0FESCxHQVFHZ0MsTUFUTixDQWZGLEVBMEJFO0FBQUssU0FBSyxFQUFFO0FBQUVrSCxrQkFBWSxFQUFFLE1BQWhCO0FBQXdCeEQsV0FBSyxFQUFFO0FBQS9CO0FBQVosS0FDR2dELElBQUksQ0FBQ0csTUFBTCxJQUFlSCxJQUFJLENBQUNHLE1BQUwsQ0FBWS9FLE1BQVosR0FBcUIsQ0FBcEMsR0FDRyxvQkFDRzRFLElBQUksQ0FBQ0csTUFBTCxDQUFZL0UsTUFBWixLQUF1QixDQUF2QixHQUEyQixRQUEzQixHQUFzQzRFLElBQUksQ0FBQ0csTUFBTCxDQUFZL0UsTUFBWixHQUFxQixRQUQ5RCxDQURILEdBSUcsRUFMTixDQTFCRixDQURGO0FBb0NELENBeENELEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZBO0FBQ0E7QUFFZSxnRUFBQztBQUFFMEU7QUFBRixDQUFELEtBQWU7QUFDNUIsU0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9pSEFpQ0U7QUFBQSx3Q0FBYztBQUFkLEtBQXlCLE1BQUMsMkRBQUQ7QUFBa0IsTUFBRSxFQUFDO0FBQXJCLElBQXpCLENBakNGLEVBa0NFO0FBQUEsd0NBQWM7QUFBZCxLQUNHQSxLQUFLLENBQUNoRyxHQUFOLENBQVUsQ0FBQ2lHLENBQUQsRUFBSS9GLEtBQUosS0FBYztBQUN2QixVQUFNOEUsUUFBUSxHQUFHaUIsQ0FBQyxDQUFDeEMsWUFBRixJQUFrQndDLENBQUMsQ0FBQ3pJLEVBQXJDO0FBQ0EsV0FDRTtBQUFJLFNBQUcsRUFBRTBDLEtBQVQ7QUFBQSwwQ0FBMEI7QUFBMUIsT0FDRTtBQUFBLDBDQUFlO0FBQWYsT0FDRTtBQUVFLFNBQUcsRUFBRytGLENBQUMsQ0FBQzFGLE1BQUYsSUFBWTBGLENBQUMsQ0FBQzFGLE1BQUYsQ0FBU2UsTUFBckIsSUFBK0IyRSxDQUFDLENBQUMxRixNQUFGLENBQVMsQ0FBVCxFQUFZQyxHQUE1QyxJQUFvRCx1QkFGM0Q7QUFHRSxXQUFLLEVBQUMsSUFIUjtBQUlFLFlBQU0sRUFBQyxJQUpUO0FBS0UsU0FBRyxFQUFFd0UsUUFMUDtBQU1FLFdBQUssRUFBRUEsUUFOVDtBQUFBLDBDQUNZO0FBRFosTUFERixDQURGLEVBV0U7QUFBQSwwQ0FBZTtBQUFmLE9BQ0dBLFFBREgsQ0FYRixDQURGO0FBaUJELEdBbkJBLENBREgsQ0FsQ0YsRUF3REU7QUFBSyxTQUFLLEVBQUU7QUFBRTRCLFdBQUssRUFBRTtBQUFULEtBQVo7QUFBQTtBQUFBLElBeERGLENBREY7QUE0REQsQ0E3REQsRTs7Ozs7Ozs7Ozs7QUNIQUMsTUFBTSxDQUFDQyxPQUFQLEdBQWlCO0FBQ2YzSixNQUFJLEVBQUU0Six1QkFBZ0I1SjtBQURQLENBQWpCLEM7Ozs7Ozs7Ozs7OztBQ0FBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTyxNQUFNNkosV0FBVyxHQUFHLGFBQXBCO0FBQ0EsTUFBTUMsWUFBWSxHQUFHLGNBQXJCO0FBQ0EsTUFBTXBKLFdBQVcsR0FBRyxhQUFwQjtBQUNBLE1BQU1xSixrQkFBa0IsR0FBRyxvQkFBM0I7QUFFQSxNQUFNQyxhQUFhLEdBQUcsZUFBdEI7QUFDQSxNQUFNQyxxQkFBcUIsR0FBRyx1QkFBOUI7QUFDQSxNQUFNL0ksbUJBQW1CLEdBQUcscUJBQTVCO0FBRUEsTUFBTWdKLFdBQVcsR0FBRyxhQUFwQjtBQUNBLE1BQU1DLG1CQUFtQixHQUFHLHFCQUE1QjtBQUNBLE1BQU1DLDZCQUE2QixHQUFHLCtCQUF0QztBQUVBLE1BQU1DLFlBQVksR0FBRyxjQUFyQjtBQUVBLE1BQU0vSSxJQUFJLEdBQUcsTUFBYjtBQUNBLE1BQU1FLEtBQUssR0FBRyxPQUFkO0FBQ0EsTUFBTUUsYUFBYSxHQUFHLGVBQXRCO0FBQ0EsTUFBTTRJLGFBQWEsR0FBRyxlQUF0QjtBQUVBLE1BQU1DLFlBQVksR0FBRyxjQUFyQjtBQUNBLE1BQU1DLG9CQUFvQixHQUFHLHNCQUE3QjtBQUNBLE1BQU1DLG1CQUFtQixHQUFHLHFCQUE1QjtBQUNBLE1BQU1DLFVBQVUsR0FBRyxZQUFuQjtBQUNBLE1BQU1DLGtCQUFrQixHQUFHLG9CQUEzQjtBQUNBLE1BQU1DLGtCQUFrQixHQUFHLG9CQUEzQjtBQUVBLE1BQU1yTCxhQUFhLEdBQUcsZUFBdEI7QUFDQSxNQUFNRSxlQUFlLEdBQUcsaUJBQXhCO0FBRUEsTUFBTW5CLHVCQUF1QixHQUFHLHlCQUFoQztBQUNBLE1BQU11TSwrQkFBK0IsR0FBRyxpQ0FBeEM7QUFDQSxNQUFNQyw2QkFBNkIsR0FBRywrQkFBdEM7QUFFQSxNQUFNQywyQkFBMkIsR0FBRyw2QkFBcEM7QUFDQSxNQUFNak0sbUNBQW1DLEdBQUcscUNBQTVDO0FBQ0EsTUFBTWtNLGlDQUFpQyxHQUFHLG1DQUExQztBQUVBLE1BQU1DLE9BQU8sR0FBRyxTQUFoQjtBQUNBLE1BQU0xSSxlQUFlLEdBQUcsaUJBQXhCLEM7Ozs7Ozs7Ozs7OztBQ3ZDUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFQTtBQUNBO0FBUUEsTUFBTTJJLGdCQUFnQixHQUFHLDRCQUF6QjtBQUVlQyxvRUFBSyxJQUFJQyxJQUFJLElBQUlDLE1BQU0sSUFBSTtBQUN4QyxRQUFNQyxNQUFNLEdBQUdGLElBQUksQ0FBQ0MsTUFBRCxDQUFuQjs7QUFDQSxVQUFRQSxNQUFNLENBQUNqTixJQUFmO0FBQ0UsU0FBS0UsOEVBQUw7QUFBOEI7QUFDNUJ3QixpRUFBSyxDQUFFLEdBQUVvTCxnQkFBaUIsb0JBQXJCLEVBQTBDO0FBQzdDSyxnQkFBTSxFQUFFLEtBRHFDO0FBRTdDQyxpQkFBTyxFQUFFO0FBQ1BDLHlCQUFhLEVBQUcsVUFBU04sS0FBSyxDQUFDTyxRQUFOLEdBQWlCbEYsT0FBakIsQ0FBeUJ4RSxZQUFhO0FBRHhEO0FBRm9DLFNBQTFDLENBQUwsQ0FNRy9CLElBTkgsQ0FNUTZDLENBQUMsSUFBSUEsQ0FBQyxDQUFDM0MsSUFBRixFQU5iLEVBT0dGLElBUEgsQ0FPUTZDLENBQUMsSUFBSTtBQUNULGNBQUlBLENBQUMsQ0FBQ3BFLEtBQU4sRUFBYTtBQUNYeU0saUJBQUssQ0FBQ3RMLFFBQU4sQ0FBZXBCLDBGQUEwQixDQUFDcUUsQ0FBQyxDQUFDcEUsS0FBSCxDQUF6QztBQUNELFdBRkQsTUFFTztBQUNMeU0saUJBQUssQ0FBQ3RMLFFBQU4sQ0FBZXRCLDRGQUE0QixDQUFDdUUsQ0FBQyxDQUFDcUMsT0FBSCxDQUEzQztBQUNEO0FBQ0YsU0FiSDtBQWNBO0FBQ0Q7O0FBQ0QsU0FBSzRGLGtGQUFMO0FBQWtDO0FBQ2hDakwsaUVBQUssQ0FBRSxHQUFFb0wsZ0JBQWlCLFlBQXJCLEVBQWtDO0FBQ3JDSyxnQkFBTSxFQUFFLEtBRDZCO0FBRXJDQyxpQkFBTyxFQUFFO0FBQ1BDLHlCQUFhLEVBQUcsVUFBU04sS0FBSyxDQUFDTyxRQUFOLEdBQWlCbEYsT0FBakIsQ0FBeUJ4RSxZQUFhO0FBRHhELFdBRjRCO0FBS3JDMkosY0FBSSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNuQkMsc0JBQVUsRUFBRSxDQUFDVCxNQUFNLENBQUN6TSxRQUFSO0FBRE8sV0FBZjtBQUwrQixTQUFsQyxDQUFMLENBU0dxQixJQVRILENBU1E2QyxDQUFDLElBQUlBLENBQUMsQ0FBQzNDLElBQUYsRUFUYixFQVVHRixJQVZILENBVVE2QyxDQUFDLElBQUk7QUFDVCxjQUFJQSxDQUFDLENBQUNwRSxLQUFOLEVBQWE7QUFDWHlNLGlCQUFLLENBQUN0TCxRQUFOLENBQWVkLDZGQUE2QixDQUFDK0QsQ0FBQyxDQUFDcEUsS0FBSCxDQUE1QztBQUNELFdBRkQsTUFFTztBQUNMeU0saUJBQUssQ0FBQ3RMLFFBQU4sQ0FBZWhCLCtGQUErQixFQUE5QztBQUNBc00saUJBQUssQ0FBQ3RMLFFBQU4sQ0FBZTFCLHFGQUFxQixFQUFwQztBQUNEO0FBQ0YsU0FqQkg7QUFrQkE7QUFDRDs7QUFFRDtBQUNFO0FBekNKOztBQTRDQSxTQUFPbU4sTUFBUDtBQUNELENBL0NELEU7Ozs7Ozs7Ozs7OztBQ2JBO0FBQWVILG9FQUFLLElBQUlDLElBQUksSUFBSUMsTUFBTSxJQUFJO0FBQ3hDLFFBQU1DLE1BQU0sR0FBR0YsSUFBSSxDQUFDQyxNQUFELENBQW5CO0FBQ0FVLFNBQU8sQ0FBQ0MsR0FBUixDQUFZWCxNQUFaO0FBQ0QsQ0FIRCxFOzs7Ozs7Ozs7Ozs7QUNBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFDQTtBQUVBLE1BQU1ILGdCQUFnQixHQUFHLDRCQUF6QjtBQUVlQyxvRUFBSyxJQUFJQyxJQUFJLElBQUlDLE1BQU0sSUFBSTtBQUN4QyxRQUFNQyxNQUFNLEdBQUdGLElBQUksQ0FBQ0MsTUFBRCxDQUFuQjs7QUFDQSxVQUFRQSxNQUFNLENBQUNqTixJQUFmO0FBQ0UsU0FBS3NNLGlFQUFMO0FBQWlCO0FBQ2YsWUFBSSxLQUFKLEVBQXlELEVBdUJ4RDs7QUFDRDtBQUNEOztBQUNELFNBQUtqTCxzRUFBTDtBQUFzQjtBQUNwQixjQUFNO0FBQUVSLGVBQUY7QUFBU0MsY0FBVDtBQUFlQyxrQkFBZjtBQUF5QjhNO0FBQXpCLFlBQXVDZCxLQUFLLENBQUNPLFFBQU4sR0FBaUJoRixRQUE5RDtBQUNBLGNBQU1RLGVBQWUsR0FBR0YsSUFBSSxDQUFDQyxHQUFMLEtBQWFnRixTQUFiLEdBQXlCOU0sUUFBakQ7QUFDQWdNLGFBQUssQ0FBQ3RMLFFBQU4sQ0FBZWIsMEVBQVMsQ0FBQ0MsS0FBRCxFQUFRQyxJQUFSLEVBQWNnSSxlQUFkLENBQXhCO0FBQ0E7QUFDRDs7QUFDRDtBQUNFO0FBbkNKOztBQXNDQSxTQUFPb0UsTUFBUDtBQUNELENBekNELEU7Ozs7Ozs7Ozs7OztBQ1JBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFFQSxNQUFNSixnQkFBZ0IsR0FBRyw0QkFBekI7O0FBRUEsTUFBTXJLLFlBQVksR0FBR0MsS0FBSyxJQUFJLENBQUNqQixRQUFELEVBQVc2TCxRQUFYLEtBQXdCO0FBQ3BELE1BQUlRLGlCQUFpQixHQUFHLEtBQXhCOztBQUNBLE1BQUlwTCxLQUFLLENBQUNxRCxNQUFOLEdBQWUsQ0FBbkIsRUFBc0I7QUFDcEIsVUFBTWdJLEtBQUssR0FBR3JMLEtBQUssQ0FBQ3NMLEtBQU4sQ0FBWSxHQUFaLENBQWQ7QUFDQSxVQUFNQyxRQUFRLEdBQUdGLEtBQUssQ0FBQ0EsS0FBSyxDQUFDaEksTUFBTixHQUFlLENBQWhCLENBQXRCOztBQUNBLFFBQUksaUJBQWlCbUksSUFBakIsQ0FBc0JELFFBQXRCLEtBQW1DdkwsS0FBSyxDQUFDeUwsV0FBTixDQUFrQixHQUFsQixNQUEyQnpMLEtBQUssQ0FBQ3FELE1BQU4sR0FBZSxDQUFqRixFQUFvRjtBQUNsRitILHVCQUFpQixHQUFHLElBQXBCO0FBQ0Q7QUFDRjs7QUFFRCxRQUFNTSxhQUFhLEdBQUksR0FBRTFMLEtBQU0sR0FBRW9MLGlCQUFpQixHQUFHLEdBQUgsR0FBUyxFQUFHLEVBQTlELENBVm9ELENBVWE7O0FBRWpFLFNBQU9wTSx5REFBSyxDQUFFLEdBQUVvTCxnQkFBaUIsYUFBWXVCLGtCQUFrQixDQUFDRCxhQUFELENBQWdCLHNCQUFuRSxFQUEwRjtBQUNwR2hCLFdBQU8sRUFBRTtBQUNQQyxtQkFBYSxFQUFFLFlBQVlDLFFBQVEsR0FBR2xGLE9BQVgsQ0FBbUJ4RTtBQUR2QztBQUQyRixHQUExRixDQUFMLENBS0ovQixJQUxJLENBS0NDLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxJQUFKLEVBTFIsRUFNSkYsSUFOSSxDQU1DQyxHQUFHLElBQUk7QUFDWEwsWUFBUSxDQUFDa0Isa0ZBQW1CLENBQUNELEtBQUQsRUFBUVosR0FBRyxDQUFDd00sTUFBSixDQUFXN0QsS0FBbkIsQ0FBcEIsQ0FBUjtBQUNELEdBUkksQ0FBUDtBQVNELENBckJEOztBQXVCZXNDLG9FQUFLLElBQUlDLElBQUksSUFBSUMsTUFBTSxJQUFJO0FBQ3hDLFFBQU1DLE1BQU0sR0FBR0YsSUFBSSxDQUFDQyxNQUFELENBQW5COztBQUNBLFVBQVFBLE1BQU0sQ0FBQ2pOLElBQWY7QUFDRSxTQUFLNEwsb0VBQUw7QUFBb0I7QUFDbEIsZUFBT21CLEtBQUssQ0FBQ3RMLFFBQU4sQ0FBZWdCLFlBQVksQ0FBQ3dLLE1BQU0sQ0FBQ3ZLLEtBQVIsQ0FBM0IsQ0FBUDtBQUNBO0FBQ0Q7O0FBQ0Q7QUFDRTtBQU5KOztBQVFBLFNBQU93SyxNQUFQO0FBQ0QsQ0FYRCxFOzs7Ozs7Ozs7Ozs7QUM5QkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVBO0FBQ0E7QUFFQTtBQUVBLE1BQU1KLGdCQUFnQixHQUFHLDRCQUF6Qjs7QUFFQSxNQUFNeUIsY0FBYyxHQUFHLE1BQU0sQ0FBQzlNLFFBQUQsRUFBVzZMLFFBQVgsS0FDM0I1TCx5REFBSyxDQUFFLEdBQUVvTCxnQkFBaUIsS0FBckIsRUFBMkI7QUFDOUJNLFNBQU8sRUFBRTtBQUNQQyxpQkFBYSxFQUFFLFlBQVlDLFFBQVEsR0FBR2xGLE9BQVgsQ0FBbUJ4RTtBQUR2QztBQURxQixDQUEzQixDQUFMLENBS0cvQixJQUxILENBS1FDLEdBQUcsSUFBSUEsR0FBRyxDQUFDQyxJQUFKLEVBTGYsRUFNR0YsSUFOSCxDQU1RQyxHQUFHLElBQUk7QUFDWEwsVUFBUSxDQUFDb0MsaUZBQWlCLENBQUMvQixHQUFELENBQWxCLENBQVI7QUFDRCxDQVJILENBREY7O0FBV0EsTUFBTTJCLFdBQVcsR0FBRyxNQUFNLENBQUNoQyxRQUFELEVBQVc2TCxRQUFYLEtBQXdCO0FBQ2hELFNBQU81TCx5REFBSyxDQUFFLEdBQUVDLGdEQUFZLGFBQWhCLEVBQThCO0FBQ3hDd0wsVUFBTSxFQUFFLE1BRGdDO0FBRXhDSSxRQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ25CakssbUJBQWEsRUFBRThKLFFBQVEsR0FBR2xGLE9BQVgsQ0FBbUI1RTtBQURmLEtBQWYsQ0FGa0M7QUFLeEM0SixXQUFPLEVBQUUsSUFBSW9CLE9BQUosQ0FBWTtBQUNuQixzQkFBZ0I7QUFERyxLQUFaO0FBTCtCLEdBQTlCLENBQUwsQ0FTSjNNLElBVEksQ0FTQ0MsR0FBRyxJQUFJQSxHQUFHLENBQUNDLElBQUosRUFUUixFQVVKRixJQVZJLENBVUNDLEdBQUcsSUFBSTtBQUNYNkwsV0FBTyxDQUFDQyxHQUFSLENBQVk5TCxHQUFaO0FBQ0FMLFlBQVEsQ0FBQ2tDLGtGQUFrQixDQUFDN0IsR0FBRyxDQUFDOEIsWUFBTCxDQUFuQixDQUFSO0FBQ0QsR0FiSSxDQUFQO0FBY0QsQ0FmRCxDLENBaUJBOzs7QUFFZW1KLG9FQUFLLElBQUlDLElBQUksSUFBSUMsTUFBTSxJQUFJO0FBQ3hDLFFBQU1DLE1BQU0sR0FBR0YsSUFBSSxDQUFDQyxNQUFELENBQW5COztBQUNBLFVBQVFBLE1BQU0sQ0FBQ2pOLElBQWY7QUFDRSxTQUFLa0QsMkRBQUw7QUFBVztBQUNULGNBQU1rRixPQUFPLEdBQUcyRSxLQUFLLENBQUNPLFFBQU4sR0FBaUJsRixPQUFqQztBQUNBLGNBQU1xRyxTQUFTLEdBQUdyRyxPQUFPLENBQUNzRyxVQUExQjtBQUNBLGNBQU1DLGFBQWEsR0FBRyxDQUFDRixTQUFELElBQWNBLFNBQVMsR0FBRzdGLElBQUksQ0FBQ0MsR0FBTCxFQUFaLEdBQXlCLEtBQUssRUFBTCxHQUFVLElBQXZFOztBQUNBLFlBQUk4RixhQUFKLEVBQW1CO0FBQ2pCaEIsaUJBQU8sQ0FBQ0MsR0FBUixDQUFZLGtEQUFaO0FBQ0EsZ0JBQU1sSyxZQUFZLEdBQUcwRSxPQUFPLENBQUM1RSxhQUE3Qjs7QUFDQSxjQUFJRSxZQUFKLEVBQWtCO0FBQ2hCaUssbUJBQU8sQ0FBQ0MsR0FBUixDQUFZLHlDQUFaO0FBQ0FiLGlCQUFLLENBQ0Z0TCxRQURILENBQ1lnQyxXQUFXLEVBRHZCLEVBRUc1QixJQUZILENBRVEsTUFBTTtBQUNWLHFCQUFPa0wsS0FBSyxDQUFDdEwsUUFBTixDQUFlOE0sY0FBYyxFQUE3QixDQUFQO0FBQ0QsYUFKSCxFQUtHMU0sSUFMSCxDQUtRLE1BQU07QUFDVmtMLG1CQUFLLENBQUN0TCxRQUFOLENBQWU0Qiw0RUFBWSxFQUEzQjtBQUNELGFBUEg7QUFRRDtBQUNGLFNBZEQsTUFjTztBQUNMc0ssaUJBQU8sQ0FBQ0MsR0FBUixDQUFZLG9EQUFaO0FBQ0FiLGVBQUssQ0FBQ3RMLFFBQU4sQ0FBZThNLGNBQWMsRUFBN0IsRUFBaUMxTSxJQUFqQyxDQUFzQyxNQUFNO0FBQzFDa0wsaUJBQUssQ0FBQ3RMLFFBQU4sQ0FBZTRCLDRFQUFZLEVBQTNCO0FBQ0QsV0FGRDtBQUdEOztBQUNEO0FBQ0Q7O0FBQ0QsU0FBS0QsNERBQUw7QUFBWTtBQUNWLGNBQU13TCxXQUFXLEdBQUdDLE1BQU0sSUFBSTtBQUM1QixpQkFBUSxHQUFFbE4sZ0RBQVkscUJBQW9CME0sa0JBQWtCLENBQUNRLE1BQU0sQ0FBQ2xGLElBQVAsQ0FBWSxHQUFaLENBQUQsQ0FBbUIsRUFBL0U7QUFDRCxTQUZEOztBQUlBLGNBQU1DLEtBQUssR0FBRyxHQUFkO0FBQUEsY0FDRTdCLE1BQU0sR0FBRyxHQURYO0FBQUEsY0FFRStHLElBQUksR0FBR3pFLE1BQU0sQ0FBQzBFLE1BQVAsQ0FBY25GLEtBQWQsR0FBc0IsQ0FBdEIsR0FBMEJBLEtBQUssR0FBRyxDQUYzQztBQUFBLGNBR0VvRixHQUFHLEdBQUczRSxNQUFNLENBQUMwRSxNQUFQLENBQWNoSCxNQUFkLEdBQXVCLENBQXZCLEdBQTJCQSxNQUFNLEdBQUcsQ0FINUM7O0FBS0EsY0FBTWtILFNBQVMsR0FBR0MsS0FBSyxJQUFJO0FBQ3pCLGNBQUk7QUFDRixrQkFBTUMsSUFBSSxHQUFHM0IsSUFBSSxDQUFDNEIsS0FBTCxDQUFXRixLQUFLLENBQUM5TSxJQUFqQixDQUFiOztBQUNBLGdCQUFJK00sSUFBSSxDQUFDblAsSUFBTCxLQUFjLGNBQWxCLEVBQWtDO0FBQ2hDcUssb0JBQU0sQ0FBQ2dGLG1CQUFQLENBQTJCLFNBQTNCLEVBQXNDSixTQUF0QyxFQUFpRCxLQUFqRDtBQUNBLG9CQUFNSyxXQUFXLEdBQUdILElBQUksQ0FBQ3ZMLFlBQXpCO0FBQ0Esb0JBQU02SyxTQUFTLEdBQUdVLElBQUksQ0FBQ1QsVUFBdkI7O0FBQ0Esa0JBQUlZLFdBQVcsS0FBSyxFQUFwQixFQUF3QixDQUN0QjtBQUNELGVBRkQsTUFFTztBQUNMLHNCQUFNNUwsWUFBWSxHQUFHeUwsSUFBSSxDQUFDM0wsYUFBMUI7QUFDQStMLDRCQUFZLENBQUNDLE9BQWIsQ0FBcUIsY0FBckIsRUFBcUM5TCxZQUFyQztBQUNBNkwsNEJBQVksQ0FBQ0MsT0FBYixDQUFxQixhQUFyQixFQUFvQ0YsV0FBcEM7QUFDQUMsNEJBQVksQ0FBQ0MsT0FBYixDQUFxQixXQUFyQixFQUFrQzVHLElBQUksQ0FBQ0MsR0FBTCxLQUFhNEYsU0FBUyxHQUFHLElBQTNEO0FBQ0ExQixxQkFBSyxDQUFDdEwsUUFBTixDQUFla0Msa0ZBQWtCLENBQUMyTCxXQUFELENBQWpDO0FBQ0F2QyxxQkFBSyxDQUFDdEwsUUFBTixDQUFlOE0sY0FBYyxFQUE3QixFQUFpQzFNLElBQWpDLENBQXNDLE1BQU1rTCxLQUFLLENBQUN0TCxRQUFOLENBQWU0Qiw0RUFBWSxFQUEzQixDQUE1QztBQUNEO0FBQ0Y7QUFDRixXQWpCRCxDQWlCRSxPQUFPaUMsQ0FBUCxFQUFVO0FBQ1Y7QUFDQXFJLG1CQUFPLENBQUNyTixLQUFSLENBQWNnRixDQUFkO0FBQ0Q7QUFDRixTQXRCRDs7QUF1QkErRSxjQUFNLENBQUNvRixnQkFBUCxDQUF3QixTQUF4QixFQUFtQ1IsU0FBbkMsRUFBOEMsS0FBOUM7QUFFQSxjQUFNaEssR0FBRyxHQUFHMkosV0FBVyxDQUFDLENBQUMsMEJBQUQsRUFBNkIsNEJBQTdCLENBQUQsQ0FBdkI7QUFDQXZFLGNBQU0sQ0FBQ3FGLElBQVAsQ0FDRXpLLEdBREYsRUFFRSxTQUZGLEVBR0Usd0VBQ0UyRSxLQURGLEdBRUUsV0FGRixHQUdFN0IsTUFIRixHQUlFLFFBSkYsR0FLRWlILEdBTEYsR0FNRSxTQU5GLEdBT0VGLElBVko7QUFhQTtBQUNEOztBQUNEO0FBQ0U7QUEvRUo7O0FBaUZBLFNBQU81QixNQUFQO0FBQ0QsQ0FwRkQsRTs7Ozs7Ozs7Ozs7O0FDdkNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUEsSUFBSXlDLE1BQU0sR0FBRyxJQUFiOztBQUVBLE1BQU1DLG9CQUFvQixHQUFHLENBQUNDLFdBQVcsR0FBRyxFQUFmLEtBQXNCO0FBQ2pELE1BQUlDLE9BQU8sR0FBR0QsV0FBVyxDQUFDRSxLQUFaLENBQWtCLDRDQUFsQixDQUFkOztBQUNBLE1BQUlELE9BQUosRUFBYTtBQUNYLFdBQU9BLE9BQU8sQ0FBQyxDQUFELENBQWQ7QUFDRDs7QUFFREEsU0FBTyxHQUFHRCxXQUFXLENBQUNFLEtBQVosQ0FBa0IsNENBQWxCLENBQVY7O0FBQ0EsTUFBSUQsT0FBSixFQUFhO0FBQ1gsV0FBT0EsT0FBTyxDQUFDLENBQUQsQ0FBZDtBQUNEOztBQUVEQSxTQUFPLEdBQUdELFdBQVcsQ0FBQ0UsS0FBWixDQUFrQixxQkFBbEIsQ0FBVjs7QUFDQSxNQUFJRCxPQUFKLEVBQWE7QUFDWCxXQUFPQSxPQUFPLENBQUMsQ0FBRCxDQUFkO0FBQ0Q7O0FBRUQsU0FBTyxJQUFQO0FBQ0QsQ0FqQkQ7O0FBbUJPLFNBQVNFLGdCQUFULENBQTBCakQsS0FBMUIsRUFBaUM7QUFDdEMsU0FBT0MsSUFBSSxJQUFJQyxNQUFNLElBQUk7QUFDdkIsVUFBTUMsTUFBTSxHQUFHRixJQUFJLENBQUNDLE1BQUQsQ0FBbkI7O0FBRUEsUUFBSTBDLE1BQUosRUFBWTtBQUNWLGNBQVExQyxNQUFNLENBQUNqTixJQUFmO0FBQ0UsYUFBS3lMLGtFQUFMO0FBQWtCO0FBQ2hCLGdCQUFJd0UsT0FBTyxHQUFHTCxvQkFBb0IsQ0FBQzNDLE1BQU0sQ0FBQ2hMLEVBQVIsQ0FBbEM7O0FBQ0EsZ0JBQUlnTyxPQUFPLEtBQUssSUFBaEIsRUFBc0I7QUFDcEJBLHFCQUFPLEdBQUdoRCxNQUFNLENBQUNoTCxFQUFqQjtBQUNEOztBQUNEME4sa0JBQU0sQ0FBQ08sSUFBUCxDQUFZLGFBQVosRUFBMkJELE9BQTNCO0FBQ0E7QUFDRDs7QUFDRCxhQUFLdEUseUVBQUw7QUFBeUI7QUFDdkJnRSxrQkFBTSxDQUFDTyxJQUFQLENBQVksY0FBWixFQUE0QmpELE1BQU0sQ0FBQ2hMLEVBQW5DO0FBQ0E7QUFDRDs7QUFDRCxhQUFLcUIsb0VBQUw7QUFDRSxnQkFBTXhDLElBQUksR0FBR2lNLEtBQUssQ0FBQ08sUUFBTixHQUFpQmxGLE9BQWpCLENBQXlCdEgsSUFBdEM7QUFDQTZPLGdCQUFNLENBQUNPLElBQVAsQ0FBWSxZQUFaLEVBQTBCcFAsSUFBMUI7QUFDQTs7QUFDRixhQUFLK0wsOERBQUw7QUFDRThDLGdCQUFNLENBQUNPLElBQVAsQ0FBWSxTQUFaLEVBQXVCakQsTUFBTSxDQUFDaEwsRUFBOUI7QUFDQTs7QUFDRjtBQUNFO0FBckJKO0FBdUJEOztBQUVELFdBQU9pTCxNQUFQO0FBQ0QsR0E5QkQ7QUErQkQ7QUFDYyx5RUFBU0gsS0FBVCxFQUFnQjtBQUM3QjRDLFFBQU0sR0FBR1EsdURBQUUsQ0FBQ3pKLE9BQUgsQ0FBVy9FLGtEQUFNLENBQUNDLElBQWxCLENBQVQ7QUFFQStOLFFBQU0sQ0FBQ1MsRUFBUCxDQUFVLGNBQVYsRUFBMEJoTyxJQUFJLElBQUk7QUFDaEMySyxTQUFLLENBQUN0TCxRQUFOLENBQWVTLHlFQUFXLENBQUNFLElBQUQsQ0FBMUI7QUFDRCxHQUZEO0FBSUF1TixRQUFNLENBQUNTLEVBQVAsQ0FBVSxhQUFWLEVBQXlCLE1BQU07QUFDN0JyRCxTQUFLLENBQUN0TCxRQUFOLENBQWVZLHdFQUFVLEVBQXpCO0FBQ0QsR0FGRDtBQUlBc04sUUFBTSxDQUFDUyxFQUFQLENBQVUsWUFBVixFQUF3QixDQUFDdlAsS0FBRCxFQUFRQyxJQUFSLEVBQWNDLFFBQWQsS0FBMkI7QUFDakQ7QUFDQWdNLFNBQUssQ0FBQ3RMLFFBQU4sQ0FBZWIsMEVBQVMsQ0FBQ0MsS0FBRCxFQUFRQyxJQUFSLEVBQWNDLFFBQWQsQ0FBeEI7QUFDRCxHQUhEO0FBS0E0TyxRQUFNLENBQUNTLEVBQVAsQ0FBVSxjQUFWLEVBQTBCaE8sSUFBSSxJQUFJO0FBQ2hDMkssU0FBSyxDQUFDdEwsUUFBTixDQUFlcUMseUVBQVcsQ0FBQzFCLElBQUQsQ0FBMUI7QUFDRCxHQUZEO0FBSUF1TixRQUFNLENBQUNTLEVBQVAsQ0FBVSxvQkFBVixFQUFnQyxDQUFDdlAsS0FBRCxFQUFRQyxJQUFSLEVBQWNDLFFBQWQsS0FBMkI7QUFDekRnTSxTQUFLLENBQUN0TCxRQUFOLENBQWVULGlGQUFnQixDQUFDSCxLQUFELEVBQVFDLElBQVIsRUFBY0MsUUFBZCxDQUEvQjtBQUNELEdBRkQsRUFwQjZCLENBd0I3QjtBQUNELEM7Ozs7Ozs7Ozs7O0FDdkZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsd0M7Ozs7Ozs7Ozs7O0FDTkEsY0FBYyxtQkFBTyxDQUFDLDBFQUFtQjs7QUFFekM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEseUM7Ozs7Ozs7Ozs7O0FDdERBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSx5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hCQTs7QUFFQTs7QUFRQTs7QUFzQkE7QUFDQSxNQUFNc1AsU0FBUyxHQUFHLElBQWxCLEdBQWtCLEVBQWxCO0FBQ0EsTUFBTUMsb0JBQW9CLEdBQ3hCLFFBQWdDakcsU0FBaEMsR0FERjtBQUVBLE1BQU1rRyxVQUEyQyxHQUFqRDs7QUFFQSx1QkFBeUQ7QUFDdkQ7QUFDQSxzQkFBb0I7QUFDbEI7QUFHRixHQU51RCxDQU12RDs7O0FBQ0EsTUFBSSxDQUFKLHNCQUEyQjtBQUN6QjtBQUdGOztBQUFBLFNBQVFDLGNBQWMsR0FBRyx5QkFDdEJDLE9BQUQsSUFBYTtBQUNYQSxXQUFPLENBQVBBLFFBQWlCQyxLQUFELElBQVc7QUFDekIsVUFBSSxDQUFDTCxTQUFTLENBQVRBLElBQWNLLEtBQUssQ0FBeEIsTUFBS0wsQ0FBTCxFQUFrQztBQUNoQztBQUdGOztBQUFBLFlBQU1NLEVBQUUsR0FBR04sU0FBUyxDQUFUQSxJQUFjSyxLQUFLLENBQTlCLE1BQVdMLENBQVg7O0FBQ0EsVUFBSUssS0FBSyxDQUFMQSxrQkFBd0JBLEtBQUssQ0FBTEEsb0JBQTVCLEdBQXlEO0FBQ3ZERixzQkFBYyxDQUFkQSxVQUF5QkUsS0FBSyxDQUE5QkY7QUFDQUgsaUJBQVMsQ0FBVEEsT0FBaUJLLEtBQUssQ0FBdEJMO0FBQ0FNLFVBQUU7QUFFTDtBQVhERjtBQUZxQixLQWV2QjtBQUFFRyxjQUFVLEVBZmQ7QUFlRSxHQWZ1QixDQUF6QjtBQW1CRjs7QUFBQSxNQUFNQyxxQkFBcUIsR0FBRyxZQUFpQztBQUM3RCxRQUFNQyxRQUFRLEdBQUdDLFdBQWpCOztBQUNBLE1BQUksQ0FBSixVQUFlO0FBQ2IsV0FBTyxNQUFNLENBQWI7QUFHRkQ7O0FBQUFBLFVBQVEsQ0FBUkE7QUFDQVQsV0FBUyxDQUFUQTtBQUNBLFNBQU8sTUFBTTtBQUNYLFFBQUk7QUFDRlMsY0FBUSxDQUFSQTtBQUNBLEtBRkYsQ0FFRSxZQUFZO0FBQ1puRCxhQUFPLENBQVBBO0FBRUYwQzs7QUFBQUEsYUFBUyxDQUFUQTtBQU5GO0FBUkY7O0FBa0JBLDZDQUtRO0FBQ04sWUFBbUM7QUFDbkMsTUFBSSxDQUFDLHdCQUFMLElBQUssQ0FBTCxFQUF1QixPQUZqQixDQUdOO0FBQ0E7QUFDQTtBQUNBOztBQUNBVyxRQUFNLENBQU5BLGtDQUEwQ0MsR0FBRCxJQUFTO0FBQ2hELGNBQTJDO0FBQ3pDO0FBQ0E7QUFFSDtBQUxERCxLQVBNLENBYU47O0FBQ0FULFlBQVUsQ0FBQ1csSUFBSSxHQUFKQSxNQUFYWCxFQUFVLENBQVZBO0FBR0Y7O0FBQUEsZ0NBQWtEO0FBQ2hELFFBQU07QUFBQTtBQUFBLE1BQWFyQixLQUFLLENBQXhCO0FBQ0EsU0FDRzNKLE1BQU0sSUFBSUEsTUFBTSxLQUFqQixPQUFDQSxJQUNEMkosS0FBSyxDQURMLE9BQUMzSixJQUVEMkosS0FBSyxDQUZMLE9BQUMzSixJQUdEMkosS0FBSyxDQUhMLFFBQUMzSixJQUlEMkosS0FBSyxDQUpMLE1BQUMzSixJQUllO0FBQ2YySixPQUFLLENBQUxBLGVBQXFCQSxLQUFLLENBQUxBLHNCQU54QjtBQVVGOztBQUFBLG9FQVFRO0FBQ04sUUFBTTtBQUFBO0FBQUEsTUFBZTVKLENBQUMsQ0FBdEI7O0FBRUEsTUFBSTZMLFFBQVEsS0FBUkEsUUFBcUJDLGVBQWUsQ0FBZkEsQ0FBZSxDQUFmQSxJQUFzQixDQUFDLHdCQUFoRCxJQUFnRCxDQUE1Q0QsQ0FBSixFQUFtRTtBQUNqRTtBQUNBO0FBR0Y3TDs7QUFBQUEsR0FBQyxDQUFEQSxpQkFSTSxDQVVOOztBQUNBLE1BQUkrTCxNQUFNLElBQVYsTUFBb0I7QUFDbEJBLFVBQU0sR0FBR0MsRUFBRSxDQUFGQSxlQUFURDtBQUdGLEdBZk0sQ0FlTjs7O0FBQ0FMLFFBQU0sQ0FBQ08sT0FBTyxlQUFkUCxNQUFNLENBQU5BLFdBQStDO0FBQS9DQTtBQUErQyxHQUEvQ0EsT0FDR1EsT0FBRCxJQUFzQjtBQUNwQixRQUFJLENBQUosU0FBYzs7QUFDZCxnQkFBWTtBQUNWbkgsWUFBTSxDQUFOQTtBQUNBb0gsY0FBUSxDQUFSQTtBQUVIO0FBUEhUO0FBV0Y7O0FBQUEscUJBQXlEO0FBQ3ZELFlBQTJDO0FBQ3pDLG1DQUlHO0FBQ0QsYUFBTyxVQUNKLGdDQUErQlUsSUFBSSxDQUFDQyxHQUFJLGdCQUFlRCxJQUFJLENBQUNFLFFBQVMsNkJBQTRCRixJQUFJLENBQUNHLE1BQXZHLGFBQUMsSUFDRSxvQkFGTCxFQUNHLENBREksQ0FBUDtBQVFGLEtBZHlDLENBY3pDOzs7QUFDQSxVQUFNQyxrQkFBbUQsR0FBRztBQUMxRFosVUFBSSxFQUROO0FBQTRELEtBQTVEO0FBR0EsVUFBTWEsYUFBa0MsR0FBR0MsTUFBTSxDQUFOQSxLQUEzQyxrQkFBMkNBLENBQTNDO0FBR0EsaUJBQWEsQ0FBYixRQUF1QkwsR0FBRCxJQUE0QjtBQUNoRCxVQUFJQSxHQUFHLEtBQVAsUUFBb0I7QUFDbEIsWUFDRW5OLEtBQUssQ0FBTEEsR0FBSyxDQUFMQSxZQUNDLE9BQU9BLEtBQUssQ0FBWixHQUFZLENBQVosaUJBQWtDLE9BQU9BLEtBQUssQ0FBWixHQUFZLENBQVosS0FGckMsVUFHRTtBQUNBLGdCQUFNeU4sZUFBZSxDQUFDO0FBQUE7QUFFcEJMLG9CQUFRLEVBRlk7QUFHcEJDLGtCQUFNLEVBQUVyTixLQUFLLENBQUxBLEdBQUssQ0FBTEEscUJBQStCLE9BQU9BLEtBQUssQ0FIckQsR0FHcUQ7QUFIL0IsV0FBRCxDQUFyQjtBQU1IO0FBWEQsYUFXTztBQUNMO0FBQ0E7QUFDQSxjQUFNME4sQ0FBUSxHQUFkO0FBRUg7QUFqQkQsT0FyQnlDLENBd0N6Qzs7QUFDQSxVQUFNQyxrQkFBbUQsR0FBRztBQUMxRGIsUUFBRSxFQUR3RDtBQUUxREMsYUFBTyxFQUZtRDtBQUcxREYsWUFBTSxFQUhvRDtBQUkxRGUsYUFBTyxFQUptRDtBQUsxREMsY0FBUSxFQUxrRDtBQU0xREMsY0FBUSxFQU5WO0FBQTRELEtBQTVEO0FBUUEsVUFBTUMsYUFBa0MsR0FBR1AsTUFBTSxDQUFOQSxLQUEzQyxrQkFBMkNBLENBQTNDO0FBR0EsaUJBQWEsQ0FBYixRQUF1QkwsR0FBRCxJQUE0QjtBQUNoRCxVQUFJQSxHQUFHLEtBQVAsTUFBa0I7QUFDaEIsWUFDRW5OLEtBQUssQ0FBTEEsR0FBSyxDQUFMQSxJQUNBLE9BQU9BLEtBQUssQ0FBWixHQUFZLENBQVosS0FEQUEsWUFFQSxPQUFPQSxLQUFLLENBQVosR0FBWSxDQUFaLEtBSEYsVUFJRTtBQUNBLGdCQUFNeU4sZUFBZSxDQUFDO0FBQUE7QUFFcEJMLG9CQUFRLEVBRlk7QUFHcEJDLGtCQUFNLEVBQUUsT0FBT3JOLEtBQUssQ0FIdEIsR0FHc0I7QUFIQSxXQUFELENBQXJCO0FBTUg7QUFaRCxhQVlPLElBQ0xtTixHQUFHLEtBQUhBLGFBQ0FBLEdBQUcsS0FESEEsWUFFQUEsR0FBRyxLQUZIQSxhQUdBQSxHQUFHLEtBSEhBLGNBSUFBLEdBQUcsS0FMRSxZQU1MO0FBQ0EsWUFBSW5OLEtBQUssQ0FBTEEsR0FBSyxDQUFMQSxZQUFzQixPQUFPQSxLQUFLLENBQVosR0FBWSxDQUFaLEtBQTFCLFdBQTJEO0FBQ3pELGdCQUFNeU4sZUFBZSxDQUFDO0FBQUE7QUFFcEJMLG9CQUFRLEVBRlk7QUFHcEJDLGtCQUFNLEVBQUUsT0FBT3JOLEtBQUssQ0FIdEIsR0FHc0I7QUFIQSxXQUFELENBQXJCO0FBTUg7QUFkTSxhQWNBO0FBQ0w7QUFDQTtBQUNBLGNBQU0wTixDQUFRLEdBQWQ7QUFFSDtBQWhDRCxPQXBEeUMsQ0FzRnpDO0FBQ0E7O0FBQ0EsVUFBTU0sU0FBUyxHQUFHM0wsc0JBQWxCLEtBQWtCQSxDQUFsQjs7QUFDQSxRQUFJckMsS0FBSyxDQUFMQSxZQUFrQixDQUFDZ08sU0FBUyxDQUFoQyxTQUEwQztBQUN4Q0EsZUFBUyxDQUFUQTtBQUNBN0UsYUFBTyxDQUFQQTtBQUlIO0FBQ0Q7O0FBQUEsUUFBTThFLENBQUMsR0FBR2pPLEtBQUssQ0FBTEEsYUFBVjs7QUFFQSxRQUFNLDBCQUEwQnFDLGVBQWhDLFFBQWdDQSxFQUFoQzs7QUFFQSxRQUFNbUssTUFBTSxHQUFHLGFBQWYsU0FBZSxHQUFmO0FBQ0EsUUFBTTBCLFFBQVEsR0FBSTFCLE1BQU0sSUFBSUEsTUFBTSxDQUFqQixRQUFDQSxJQUFsQjs7QUFFQSxRQUFNO0FBQUE7QUFBQTtBQUFBLE1BQWVuSyx1QkFBYyxNQUFNO0FBQ3ZDLFVBQU0sNkJBQTZCLG1DQUFzQnJDLEtBQUssQ0FBM0IsTUFBbkMsSUFBbUMsQ0FBbkM7QUFDQSxXQUFPO0FBQ0wwTSxVQUFJLEVBREM7QUFFTEksUUFBRSxFQUFFOU0sS0FBSyxDQUFMQSxLQUNBLG1DQUFzQkEsS0FBSyxDQUQzQkEsRUFDQSxDQURBQSxHQUVBbU8sVUFBVSxJQUpoQjtBQUFPLEtBQVA7QUFGbUI5TCxLQVFsQixXQUFXckMsS0FBSyxDQUFoQixNQUF1QkEsS0FBSyxDQVIvQixFQVFHLENBUmtCcUMsQ0FBckI7O0FBVUEsMkJBQWdCLE1BQU07QUFDcEIsUUFDRTRMLENBQUMsSUFBREEsb0NBR0FHLFFBQVEsQ0FIUkgsV0FJQSx3QkFMRixJQUtFLENBTEYsRUFNRTtBQUNBO0FBQ0EsWUFBTUksWUFBWSxHQUFHdEMsVUFBVSxDQUFDVyxJQUFJLEdBQUpBLE1BQWhDLEVBQStCLENBQS9COztBQUNBLFVBQUksQ0FBSixjQUFtQjtBQUNqQixlQUFPTCxxQkFBcUIsV0FBVyxNQUFNO0FBQzNDeUIsa0JBQVEsZUFBUkEsRUFBUSxDQUFSQTtBQURGLFNBQTRCLENBQTVCO0FBSUg7QUFDRjtBQWhCRCxLQWdCRyx3QkFoQkgsTUFnQkcsQ0FoQkg7O0FBa0JBLE1BQUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQUosTUFwSXVELENBcUl2RDs7QUFDQSxNQUFJLG9CQUFKLFVBQWtDO0FBQ2hDOUosWUFBUSxnQkFBRyx3Q0FBWEEsUUFBVyxDQUFYQTtBQUdGLEdBMUl1RCxDQTBJdkQ7OztBQUNBLFFBQU1zSyxLQUFVLEdBQUdDLHFCQUFuQixRQUFtQkEsQ0FBbkI7O0FBQ0EsUUFBTUMsVUFLTCxHQUFHO0FBQ0ZDLE9BQUcsRUFBR0MsRUFBRCxJQUFhO0FBQ2hCLGNBQVFDLFdBQVcsQ0FBWEEsRUFBVyxDQUFYQTs7QUFFUixVQUFJTCxLQUFLLElBQUksaUJBQVRBLFlBQXNDQSxLQUFLLENBQS9DLEtBQXFEO0FBQ25ELFlBQUksT0FBT0EsS0FBSyxDQUFaLFFBQUosWUFBcUNBLEtBQUssQ0FBTEEsSUFBckMsRUFBcUNBLEVBQXJDLEtBQ0ssSUFBSSxPQUFPQSxLQUFLLENBQVosUUFBSixVQUFtQztBQUN0Q0EsZUFBSyxDQUFMQTtBQUVIO0FBQ0Y7QUFWQztBQVdGTSxXQUFPLEVBQUc5TixDQUFELElBQXlCO0FBQ2hDLFVBQUl3TixLQUFLLENBQUxBLFNBQWUsT0FBT0EsS0FBSyxDQUFMQSxNQUFQLFlBQW5CLFlBQThEO0FBQzVEQSxhQUFLLENBQUxBO0FBRUY7O0FBQUEsVUFBSSxDQUFDeE4sQ0FBQyxDQUFOLGtCQUF5QjtBQUN2QitOLG1CQUFXLHdDQUFYQSxNQUFXLENBQVhBO0FBRUg7QUF2Qkg7QUFLSSxHQUxKOztBQTBCQSxTQUFPO0FBQ0xMLGNBQVUsQ0FBVkEsZUFBMkIxTixDQUFELElBQXlCO0FBQ2pELFVBQUksQ0FBQyx3QkFBTCxJQUFLLENBQUwsRUFBdUI7O0FBQ3ZCLFVBQUl3TixLQUFLLENBQUxBLFNBQWUsT0FBT0EsS0FBSyxDQUFMQSxNQUFQLGlCQUFuQixZQUFtRTtBQUNqRUEsYUFBSyxDQUFMQTtBQUVGUjs7QUFBQUEsY0FBUSxtQkFBbUI7QUFBRWdCLGdCQUFRLEVBQXJDaEI7QUFBMkIsT0FBbkIsQ0FBUkE7QUFMRlU7QUFTRixHQWhMdUQsQ0FnTHZEO0FBQ0E7OztBQUNBLE1BQUl4TyxLQUFLLENBQUxBLFlBQW1Cc08sS0FBSyxDQUFMQSxnQkFBc0IsRUFBRSxVQUFVQSxLQUFLLENBQTlELEtBQTZDLENBQTdDLEVBQXdFO0FBQ3RFRSxjQUFVLENBQVZBLE9BQWtCLHlCQUNoQiwyQkFBY2hDLE1BQU0sSUFBSUEsTUFBTSxDQUE5QixRQUF1Q0EsTUFBTSxJQUFJQSxNQUFNLENBRHpEZ0MsYUFDRSxDQURnQixDQUFsQkE7QUFLRjs7QUFBQSxzQkFBT25NLG1DQUFQLFVBQU9BLENBQVA7OztlQUdhME0sSTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdFZmOzs7O0FBR08sdUNBQXVEO0FBQzVELFNBQU9DLElBQUksQ0FBSkEsaUJBQXNCQSxJQUFJLEtBQTFCQSxNQUFxQ0EsSUFBSSxDQUFKQSxTQUFjLENBQW5EQSxDQUFxQ0EsQ0FBckNBLEdBQVA7QUFHRjtBQUFBOzs7Ozs7QUFJTyxNQUFNQywwQkFBMEIsR0FBR2pJLFNBQ3JDZ0ksU0FEcUNoSSxHQUFuQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVlA7O0FBQ0E7Ozs7O0FBQ0E7O0FBc0hBOzs7QUF6SEE7O0FBbUJBLE1BQU1rSSxlQUFvQyxHQUFHO0FBQzNDMUMsUUFBTSxFQURxQztBQUM3QjtBQUNkMkMsZ0JBQWMsRUFGNkI7O0FBRzNDQyxPQUFLLEtBQWlCO0FBQ3BCLFFBQUksS0FBSixRQUFpQixPQUFPakQsRUFBUDs7QUFDakIsZUFBbUMsRUFHcEM7QUFSSDs7QUFBNkMsQ0FBN0MsQyxDQVdBOztBQUNBLE1BQU1rRCxpQkFBaUIsR0FBRyxzR0FBMUIsZUFBMEIsQ0FBMUI7QUFZQSxNQUFNQyxZQUFZLEdBQUcsMEdBQXJCLG9CQUFxQixDQUFyQjtBQVFBLE1BQU1DLGdCQUFnQixHQUFHLGtEQUF6QixnQkFBeUIsQ0FBekIsQyxDQVNBOztBQUNBL0IsTUFBTSxDQUFOQSwwQ0FBaUQ7QUFDL0NnQyxLQUFHLEdBQUc7QUFDSixXQUFPQyxpQkFBUDtBQUZKakM7O0FBQWlELENBQWpEQTtBQU1BNkIsaUJBQWlCLENBQWpCQSxRQUEyQkssS0FBRCxJQUFXO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0FsQyxRQUFNLENBQU5BLHVDQUE4QztBQUM1Q2dDLE9BQUcsR0FBRztBQUNKLFlBQU1oRCxNQUFNLEdBQUdtRCxTQUFmO0FBQ0EsYUFBT25ELE1BQU0sQ0FBYixLQUFhLENBQWI7QUFISmdCOztBQUE4QyxHQUE5Q0E7QUFMRjZCO0FBYUEsZ0JBQWdCLENBQWhCLFFBQTBCSyxLQUFELElBQVc7QUFDbEM7QUFDQTs7QUFBRVIsaUJBQUQsT0FBQ0EsR0FBaUMsQ0FBQyxHQUFELFNBQW9CO0FBQ3JELFVBQU0xQyxNQUFNLEdBQUdtRCxTQUFmO0FBQ0EsV0FBT25ELE1BQU0sQ0FBTkEsS0FBTSxDQUFOQSxDQUFjLEdBQXJCLElBQU9BLENBQVA7QUFGRCxHQUFDMEM7QUFGSjtBQVFBSSxZQUFZLENBQVpBLFFBQXNCNUUsS0FBRCxJQUFXO0FBQzlCd0UsaUJBQWUsQ0FBZkEsTUFBc0IsTUFBTTtBQUMxQk8sc0NBQXdCLENBQUMsR0FBRCxTQUFhO0FBQ25DLFlBQU1HLFVBQVUsR0FBSSxLQUFJbEYsS0FBSyxDQUFMQSx1QkFBOEIsR0FBRUEsS0FBSyxDQUFMQSxZQUF4RDtBQUdBLFlBQU1tRixnQkFBZ0IsR0FBdEI7O0FBQ0EsVUFBSUEsZ0JBQWdCLENBQXBCLFVBQW9CLENBQXBCLEVBQWtDO0FBQ2hDLFlBQUk7QUFDRkEsMEJBQWdCLENBQWhCQSxVQUFnQixDQUFoQkEsQ0FBNkIsR0FBN0JBO0FBQ0EsU0FGRixDQUVFLFlBQVk7QUFDWjFHLGlCQUFPLENBQVBBLE1BQWUsd0NBQXVDeUcsVUFBdER6RztBQUNBQSxpQkFBTyxDQUFQQSxNQUFlLEdBQUVzRCxHQUFHLENBQUNxRCxPQUFRLEtBQUlyRCxHQUFHLENBQUNzRCxLQUFyQzVHO0FBRUg7QUFDRjtBQWJEc0c7QUFERlA7QUFERkk7O0FBbUJBLHFCQUE2QjtBQUMzQixNQUFJLENBQUNKLGVBQWUsQ0FBcEIsUUFBNkI7QUFDM0IsVUFBTVksT0FBTyxHQUNYLGdDQURGO0FBR0EsVUFBTSxVQUFOLE9BQU0sQ0FBTjtBQUVGOztBQUFBLFNBQU9aLGVBQWUsQ0FBdEI7QUFHRixDLENBQUE7OztlQUNlQSxlLEVBRWY7Ozs7QUFHTyxxQkFBaUM7QUFDdEMsU0FBTzdNLDBCQUFpQjJOLGVBQXhCLGFBQU8zTixDQUFQO0FBR0YsQyxDQUFBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTs7O0FBQ08sTUFBTTROLFlBQVksR0FBRyxDQUFDLEdBQUQsU0FBaUM7QUFDM0RmLGlCQUFlLENBQWZBLFNBQXlCLElBQUlPLFNBQUosUUFBVyxHQUFwQ1AsSUFBeUIsQ0FBekJBO0FBQ0FBLGlCQUFlLENBQWZBLHVCQUF3Qy9DLEVBQUQsSUFBUUEsRUFBL0MrQztBQUNBQSxpQkFBZSxDQUFmQTtBQUVBLFNBQU9BLGVBQWUsQ0FBdEI7QUFMSyxFLENBUVA7Ozs7O0FBQ08sMENBQThEO0FBQ25FLFFBQU1nQixPQUFPLEdBQWI7QUFDQSxRQUFNQyxRQUFRLEdBQWQ7O0FBRUEsT0FBSyxNQUFMLCtCQUEwQztBQUN4QyxRQUFJLE9BQU9ELE9BQU8sQ0FBZCxRQUFjLENBQWQsS0FBSixVQUEyQztBQUN6Q0MsY0FBUSxDQUFSQSxRQUFRLENBQVJBLEdBQXFCM0MsTUFBTSxDQUFOQSxPQUNuQjRDLEtBQUssQ0FBTEEsUUFBY0YsT0FBTyxDQUFyQkUsUUFBcUIsQ0FBckJBLFNBRG1CNUMsSUFFbkIwQyxPQUFPLENBRlRDLFFBRVMsQ0FGWTNDLENBQXJCMkMsQ0FEeUMsQ0FJdkM7O0FBQ0Y7QUFHRkE7O0FBQUFBLFlBQVEsQ0FBUkEsUUFBUSxDQUFSQSxHQUFxQkQsT0FBTyxDQUE1QkMsUUFBNEIsQ0FBNUJBO0FBR0YsR0FoQm1FLENBZ0JuRTs7O0FBQ0FBLFVBQVEsQ0FBUkEsU0FBa0JWLGlCQUFsQlU7QUFFQVosa0JBQWdCLENBQWhCQSxRQUEwQkcsS0FBRCxJQUFXO0FBQ2xDUyxZQUFRLENBQVJBLEtBQVEsQ0FBUkEsR0FBa0IsQ0FBQyxHQUFELFNBQW9CO0FBQ3BDLGFBQU9ELE9BQU8sQ0FBUEEsS0FBTyxDQUFQQSxDQUFlLEdBQXRCLElBQU9BLENBQVA7QUFERkM7QUFERlo7QUFNQTtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6S0Q7O0FBRUE7O0FBV2UsdUNBSytCO0FBQzVDLG9DQUF1QztBQUNyQyx3QkFBTztBQUFtQixZQUFNLEVBQUUsWUFBM0IsU0FBMkI7QUFBM0IsT0FBUCxLQUFPLEVBQVA7QUFHRjs7QUFBQSxtQkFBaUIsQ0FBakIsa0JBQW9DYyxpQkFBaUIsQ0FBQzdLLGVBQXRELENBQ0E7QUFEQTtBQUVFOEssbUJBQUQsb0JBQUNBLEdBQWlERCxpQkFBRCxDQUFqRCxtQkFBQ0M7O0FBQ0YsWUFBMkM7QUFDekMsVUFBTTVQLElBQUksR0FDUjJQLGlCQUFpQixDQUFqQkEsZUFBaUNBLGlCQUFpQixDQUFsREEsUUFERjtBQUVBQyxxQkFBaUIsQ0FBakJBLGNBQWlDLGNBQWE1UCxJQUE5QzRQO0FBR0Y7O0FBQUE7QUFDRCxDOzs7Ozs7Ozs7Ozs7QUNqQ1k7QUFDYiw4Q0FBOEMsY0FBYztBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUIsOENBQThDO0FBQ3ZFO0FBQ0E7QUFDQTtBQUNBLHlCQUF5QixvREFBb0Q7QUFDN0U7QUFDQTtBQUNBLHVCQUF1QjtBQUN2Qix5QkFBeUIsMENBQTBDO0FBQ25FO0FBQ0E7QUFDQSx1QkFBdUI7QUFDdkIseUJBQXlCLDJDQUEyQztBQUNwRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLHNDQUFzQztBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlCQUF5Qiw0Q0FBNEM7QUFDckU7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLDBDQUEwQztBQUMvRDtBQUNBLGlCQUFpQixtQ0FBbUM7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLGNBQWM7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLGNBQWM7QUFDM0M7QUFDQSxvRUFBb0UsVUFBVSxFQUFFO0FBQ2hGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLHVCQUF1QixtQkFBbUI7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixrQkFBa0I7QUFDakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZCQUE2QixjQUFjO0FBQzNDLG9FQUFvRSxVQUFVLEVBQUU7QUFDaEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUJBQXVCLGNBQWM7QUFDckM7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQztBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVCQUF1QixtQkFBbUI7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQ0FBMkMsaURBQWlELEVBQUU7QUFDOUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLGNBQWM7QUFDM0Msd09BQXdPLFVBQVUsRUFBRTtBQUNwUDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVDQUF1QyxzQkFBc0I7QUFDN0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYyw2REFBNkQ7QUFDM0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyWkE7Ozs7Ozs7QUFZQTtBQUNBO0FBQ0E7O0FBVWUsZ0JBQTZCO0FBQzFDLFFBQU1DLEdBQStCLEdBQUcvQyxNQUFNLENBQU5BLE9BQXhDLElBQXdDQSxDQUF4QztBQUVBLFNBQU87QUFDTDVCLE1BQUUsZ0JBQWlDO0FBQ2pDO0FBQUMsT0FBQzJFLEdBQUcsQ0FBSEEsSUFBRyxDQUFIQSxLQUFjQSxHQUFHLENBQUhBLElBQUcsQ0FBSEEsR0FBZixFQUFDQSxDQUFEO0FBRkU7O0FBS0xDLE9BQUcsZ0JBQWlDO0FBQ2xDLFVBQUlELEdBQUcsQ0FBUCxJQUFPLENBQVAsRUFBZTtBQUNiQSxXQUFHLENBQUhBLElBQUcsQ0FBSEEsUUFBaUJBLEdBQUcsQ0FBSEEsSUFBRyxDQUFIQSxzQkFBakJBO0FBRUg7QUFUSTs7QUFXTDdFLFFBQUksT0FBZSxHQUFmLE1BQStCO0FBQ2pDO0FBQ0E7QUFBQyxPQUFDNkUsR0FBRyxDQUFIQSxJQUFHLENBQUhBLElBQUQsZ0JBQStCRSxPQUFELElBQXNCO0FBQ25EQSxlQUFPLENBQUMsR0FBUkEsSUFBTyxDQUFQQTtBQUREO0FBYkw7O0FBQU8sR0FBUDtBQWtCRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hDRDs7QUFLQTs7QUFDQTs7QUFDQTs7QUFTQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7Ozs7O0FBM0JBO0FBQUE7QUFDQTs7O0FBd0NBLE1BQU1DLFFBQVEsR0FBSTFKLFVBQWxCOztBQUVBLGtDQUFrQztBQUNoQyxTQUFPd0csTUFBTSxDQUFOQSxPQUFjLFVBQWRBLGlCQUFjLENBQWRBLEVBQTRDO0FBQ2pEbUQsYUFBUyxFQURYO0FBQW1ELEdBQTVDbkQsQ0FBUDtBQUtGOztBQUFBLHFDQUFzRDtBQUNwRCxTQUFPb0QsTUFBTSxJQUFJNUIsSUFBSSxDQUFKQSxXQUFWNEIsR0FBVTVCLENBQVY0QixHQUNINUIsSUFBSSxLQUFKQSxNQUNFLHdEQURGQSxNQUNFLENBREZBLEdBRUcsR0FBRTRCLE1BQU8sR0FBRTVCLElBSFg0QixLQUFQO0FBT0s7O0FBQUEsZ0RBSUw7QUFDQSxNQUFJNUosS0FBSixFQUFxQyxFQUtyQzs7QUFBQTtBQUdLOztBQUFBLGlDQUFrRDtBQUN2RCxNQUFJQSxLQUFKLEVBQXFDLEVBS3JDOztBQUFBO0FBR0s7O0FBQUEsMkJBQTRDO0FBQ2pELFNBQU9nSSxJQUFJLEtBQUpBLFlBQXFCQSxJQUFJLENBQUpBLFdBQWdCMEIsUUFBUSxHQUFwRCxHQUE0QjFCLENBQTVCO0FBR0s7O0FBQUEsMkJBQTJDO0FBQ2hEO0FBQ0EsU0FBTzZCLGFBQWEsT0FBcEIsUUFBb0IsQ0FBcEI7QUFHSzs7QUFBQSwyQkFBMkM7QUFDaEQsU0FBTzdCLElBQUksQ0FBSkEsTUFBVzBCLFFBQVEsQ0FBbkIxQixXQUFQO0FBR0Y7QUFBQTs7Ozs7QUFHTyx5QkFBMEM7QUFDL0MsTUFBSXZPLEdBQUcsQ0FBSEEsV0FBSixHQUFJQSxDQUFKLEVBQXlCOztBQUN6QixNQUFJO0FBQ0Y7QUFDQSxVQUFNcVEsY0FBYyxHQUFHLFdBQXZCLGlCQUF1QixHQUF2QjtBQUNBLFVBQU1DLFFBQVEsR0FBRyxhQUFqQixjQUFpQixDQUFqQjtBQUNBLFdBQU9BLFFBQVEsQ0FBUkEsNkJBQXNDQyxXQUFXLENBQUNELFFBQVEsQ0FBakUsUUFBd0QsQ0FBeEQ7QUFDQSxHQUxGLENBS0UsVUFBVTtBQUNWO0FBRUg7QUFJTTs7QUFBQSxpREFJTDtBQUNBLE1BQUlFLGlCQUFpQixHQUFyQjtBQUVBLFFBQU1DLFlBQVksR0FBRywrQkFBckIsS0FBcUIsQ0FBckI7QUFDQSxRQUFNQyxhQUFhLEdBQUdELFlBQVksQ0FBbEM7QUFDQSxRQUFNRSxjQUFjLEdBQ2xCO0FBQ0EsR0FBQ0MsVUFBVSxLQUFWQSxRQUF1QixpREFBdkJBLFVBQXVCLENBQXZCQSxHQUFELE9BQ0E7QUFDQTtBQUpGO0FBT0FKLG1CQUFpQixHQUFqQkE7QUFDQSxRQUFNSyxNQUFNLEdBQUc5RCxNQUFNLENBQU5BLEtBQWYsYUFBZUEsQ0FBZjs7QUFFQSxNQUNFLENBQUM4RCxNQUFNLENBQU5BLE1BQWNDLEtBQUQsSUFBVztBQUN2QixRQUFJdlEsS0FBSyxHQUFHb1EsY0FBYyxDQUFkQSxLQUFjLENBQWRBLElBQVo7QUFDQSxVQUFNO0FBQUE7QUFBQTtBQUFBLFFBQXVCRCxhQUFhLENBQTFDLEtBQTBDLENBQTFDLENBRnVCLENBSXZCO0FBQ0E7O0FBQ0EsUUFBSUssUUFBUSxHQUFJLElBQUdDLE1BQU0sV0FBVyxFQUFHLEdBQUVGLEtBQXpDOztBQUNBLGtCQUFjO0FBQ1pDLGNBQVEsR0FBSSxHQUFFLGVBQWUsRUFBRyxJQUFHQSxRQUFuQ0E7QUFFRjs7QUFBQSxRQUFJQyxNQUFNLElBQUksQ0FBQ3JCLEtBQUssQ0FBTEEsUUFBZixLQUFlQSxDQUFmLEVBQXFDcFAsS0FBSyxHQUFHLENBQVJBLEtBQVEsQ0FBUkE7QUFFckMsV0FDRSxDQUFDMFEsUUFBUSxJQUFJSCxLQUFLLElBQWxCLHFCQUNBO0FBQ0NOLHFCQUFpQixHQUNoQkEsaUJBQWlCLENBQWpCQSxrQkFFRVEsTUFBTSxHQUNEelEsS0FBRCxJQUFDQSxDQUF1QjJRLHNCQUF4QixPQUFDM1EsRUFBRCxJQUFDQSxDQURDLEdBQ0RBLENBREMsR0FFRixtQ0FKTmlRLEtBSU0sQ0FKTkEsS0FKSixHQUNFLENBREY7QUFiSixHQUNHSyxDQURILEVBeUJFO0FBQ0FMLHFCQUFpQixHQUFqQkEsR0FEQSxDQUN1QjtBQUV2QjtBQUNBO0FBRUY7O0FBQUEsU0FBTztBQUFBO0FBRUx2SSxVQUFNLEVBRlI7QUFBTyxHQUFQO0FBTUY7O0FBQUEsMkNBQXFFO0FBQ25FLFFBQU1rSixhQUE2QixHQUFuQztBQUVBcEUsUUFBTSxDQUFOQSxvQkFBNEJMLEdBQUQsSUFBUztBQUNsQyxRQUFJLENBQUNtRSxNQUFNLENBQU5BLFNBQUwsR0FBS0EsQ0FBTCxFQUEyQjtBQUN6Qk0sbUJBQWEsQ0FBYkEsR0FBYSxDQUFiQSxHQUFxQjFULEtBQUssQ0FBMUIwVCxHQUEwQixDQUExQkE7QUFFSDtBQUpEcEU7QUFLQTtBQUdGO0FBQUE7Ozs7OztBQUlPLG1EQUlHO0FBQ1I7QUFDQSxRQUFNcUUsSUFBSSxHQUFHLHFCQUFiLFVBQWEsQ0FBYjtBQUNBLFFBQU1DLFdBQVcsR0FDZixrQ0FBa0MsaUNBRHBDLElBQ29DLENBRHBDOztBQUVBLE1BQUk7QUFDRixVQUFNQyxRQUFRLEdBQUcscUJBQWpCLElBQWlCLENBQWpCO0FBQ0FBLFlBQVEsQ0FBUkEsV0FBb0Isd0RBQTJCQSxRQUFRLENBQXZEQSxRQUFvQixDQUFwQkE7QUFDQSxRQUFJQyxjQUFjLEdBQWxCOztBQUVBLFFBQ0UsK0JBQWVELFFBQVEsQ0FBdkIsYUFDQUEsUUFBUSxDQURSLGdCQURGLFdBSUU7QUFDQSxZQUFNN1QsS0FBSyxHQUFHLHlDQUF1QjZULFFBQVEsQ0FBN0MsWUFBYyxDQUFkO0FBRUEsWUFBTTtBQUFBO0FBQUE7QUFBQSxVQUFxQkUsYUFBYSxDQUN0Q0YsUUFBUSxDQUQ4QixVQUV0Q0EsUUFBUSxDQUY4QixVQUF4QyxLQUF3QyxDQUF4Qzs7QUFNQSxrQkFBWTtBQUNWQyxzQkFBYyxHQUFHLGlDQUFxQjtBQUNwQzlELGtCQUFRLEVBRDRCO0FBRXBDdkQsY0FBSSxFQUFFb0gsUUFBUSxDQUZzQjtBQUdwQzdULGVBQUssRUFBRWdVLGtCQUFrQixRQUgzQkYsTUFHMkI7QUFIVyxTQUFyQixDQUFqQkE7QUFNSDtBQUVELEtBM0JFLENBMkJGOzs7QUFDQSxVQUFNRyxZQUFZLEdBQ2hCSixRQUFRLENBQVJBLFdBQW9CRixJQUFJLENBQXhCRSxTQUNJQSxRQUFRLENBQVJBLFdBQW9CQSxRQUFRLENBQVJBLE9BRHhCQSxNQUNJQSxDQURKQSxHQUVJQSxRQUFRLENBSGQ7QUFLQSxXQUFRSyxTQUFTLEdBQ2IsZUFBZUosY0FBYyxJQURoQixZQUNiLENBRGEsR0FBakI7QUFHQSxHQXBDRixDQW9DRSxVQUFVO0FBQ1YsV0FBUUksU0FBUyxHQUFHLENBQUgsV0FBRyxDQUFILEdBQWpCO0FBRUg7QUFFRDs7QUFBQSxNQUFNQyxlQUFlLEdBQUdDLE1BQU0sQ0FBOUIsaUJBQThCLENBQTlCOztBQUNPLCtCQUE2QztBQUNsRCxTQUFPOUUsTUFBTSxDQUFOQSxxQ0FBUCxFQUFPQSxDQUFQO0FBR0Y7O0FBQUEsdUNBQTZEO0FBQzNEO0FBQ0E7QUFDQSxTQUFPO0FBQ0wvTSxPQUFHLEVBQUU4UixXQUFXLENBQUNDLFdBQVcsQ0FBQ2hHLE1BQU0sQ0FBUCxVQUR2QixHQUN1QixDQUFaLENBRFg7QUFFTE0sTUFBRSxFQUFFQSxFQUFFLEdBQUd5RixXQUFXLENBQUNDLFdBQVcsQ0FBQ2hHLE1BQU0sQ0FBUCxVQUExQixFQUEwQixDQUFaLENBQWQsR0FGUjtBQUFPLEdBQVA7QUF5REY7O0FBQUEsTUFBTWlHLHVCQUF1QixHQUMzQnpMLFVBRUEsS0FIRjs7QUFLQSxtQ0FBaUU7QUFDL0QsU0FBTyxLQUFLLE1BQU07QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBMEwsZUFBVyxFQVpOO0FBQVcsR0FBTixDQUFMLE1BYUVwVixHQUFELElBQVM7QUFDZixRQUFJLENBQUNBLEdBQUcsQ0FBUixJQUFhO0FBQ1gsVUFBSXFWLFFBQVEsR0FBUkEsS0FBZ0JyVixHQUFHLENBQUhBLFVBQXBCLEtBQXVDO0FBQ3JDLGVBQU9zVixVQUFVLE1BQU1ELFFBQVEsR0FBL0IsQ0FBaUIsQ0FBakI7QUFFRjs7QUFBQSxZQUFNLFVBQU4sNkJBQU0sQ0FBTjtBQUdGOztBQUFBLFdBQU9yVixHQUFHLENBQVYsSUFBT0EsRUFBUDtBQXJCRixHQUFPLENBQVA7QUF5QkY7O0FBQUEsaURBQWtFO0FBQ2hFLFNBQU8sVUFBVSxXQUFXdVYsY0FBYyxPQUFuQyxDQUFVLENBQVYsT0FBb0RwRyxHQUFELElBQWdCO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBLFFBQUksQ0FBSixnQkFBcUI7QUFDbkJxRyxzQkFBZ0IsQ0FBaEJBLEdBQWdCLENBQWhCQTtBQUVGOztBQUFBO0FBUEYsR0FBTyxDQUFQO0FBV2E7O0FBQUEsTUFBTXJELE1BQU4sQ0FBbUM7QUFPaEQ7O0FBUGdEO0FBV2hEO0FBa0JBdkwsYUFBVyx5QkFJVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKUztBQUlULEdBSlMsRUErQlQ7QUFBQSxTQTNERjZPLEtBMkRFO0FBQUEsU0ExREY3RSxRQTBERTtBQUFBLFNBekRGaFEsS0F5REU7QUFBQSxTQXhERjhVLE1Bd0RFO0FBQUEsU0F2REZ0QyxRQXVERTtBQUFBLFNBbERGdUMsVUFrREU7QUFBQSxTQWhERkMsR0FnREUsR0FoRGtDLEVBZ0RsQztBQUFBLFNBL0NGQyxHQStDRTtBQUFBLFNBOUNGQyxHQThDRTtBQUFBLFNBN0NGQyxVQTZDRTtBQUFBLFNBNUNGQyxJQTRDRTtBQUFBLFNBM0NGQyxNQTJDRTtBQUFBLFNBMUNGQyxRQTBDRTtBQUFBLFNBekNGQyxLQXlDRTtBQUFBLFNBeENGQyxVQXdDRTtBQUFBLFNBdkNGQyxjQXVDRTtBQUFBLFNBdENGQyxRQXNDRTtBQUFBLFNBckNGak8sTUFxQ0U7QUFBQSxTQXBDRmtPLE9Bb0NFO0FBQUEsU0FuQ0ZDLGFBbUNFOztBQUFBLHNCQXFHWWhULENBQUQsSUFBNEI7QUFDdkMsWUFBTUssS0FBSyxHQUFHTCxDQUFDLENBQWY7O0FBRUEsVUFBSSxDQUFKLE9BQVk7QUFDVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUFNO0FBQUE7QUFBQTtBQUFBLFlBQU47QUFDQSx5Q0FFRSxpQ0FBcUI7QUFBRW9OLGtCQUFRLEVBQUVxRSxXQUFXLENBQXZCLFFBQXVCLENBQXZCO0FBRnZCO0FBRXVCLFNBQXJCLENBRkYsRUFHRSxXQUhGLE1BR0UsR0FIRjtBQUtBO0FBR0Y7O0FBQUEsVUFBSSxDQUFDcFIsS0FBSyxDQUFWLEtBQWdCO0FBQ2Q7QUFHRjs7QUFBQSxZQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBTjtBQUVBLFlBQU07QUFBQTtBQUFBLFVBQWUsd0NBQXJCLEdBQXFCLENBQXJCLENBNUJ1QyxDQThCdkM7QUFDQTs7QUFDQSxVQUFJLGNBQWMyTCxFQUFFLEtBQUssS0FBckIsVUFBb0NvQixRQUFRLEtBQUssS0FBckQsVUFBb0U7QUFDbEU7QUFHRixPQXBDdUMsQ0FvQ3ZDO0FBQ0E7OztBQUNBLFVBQUksYUFBYSxDQUFDLFVBQWxCLEtBQWtCLENBQWxCLEVBQW9DO0FBQ2xDO0FBR0Y7O0FBQUEsMkNBSUVWLE1BQU0sQ0FBTkEsb0JBQTJCO0FBQ3pCSSxlQUFPLEVBQUVtRyxPQUFPLENBQVBBLFdBQW1CLEtBTGhDO0FBSTZCLE9BQTNCdkcsQ0FKRjtBQS9JQSxPQUNBOzs7QUFDQSxpQkFBYSxxREFBYixTQUFhLENBQWIsQ0FGQSxDQUlBOztBQUNBLHlCQUxBLENBTUE7QUFDQTtBQUNBOztBQUNBLFFBQUlVLFNBQVEsS0FBWixXQUE0QjtBQUMxQixzQkFBZ0IsS0FBaEIsU0FBOEI7QUFBQTtBQUU1QjhGLG1CQUFXLEVBRmlCO0FBRzVCaFUsYUFBSyxFQUh1QjtBQUFBO0FBSzVCaVUsZUFBTyxFQUFFbE8sWUFBWSxJQUFJQSxZQUFZLENBTFQ7QUFNNUJtTyxlQUFPLEVBQUVuTyxZQUFZLElBQUlBLFlBQVksQ0FOdkM7QUFBOEIsT0FBOUI7QUFVRjs7QUFBQSwrQkFBMkI7QUFDekJsRyxlQUFTLEVBRGdCO0FBRXpCbVUsaUJBQVcsRUFBRTtBQUZmO0FBRWU7QUFGWSxLQUEzQixDQXBCQSxDQTJCQTtBQUNBOztBQUNBLGtCQUFjdkUsTUFBTSxDQUFwQjtBQUVBO0FBQ0E7QUFDQSx3QkFqQ0EsQ0FrQ0E7QUFDQTs7QUFDQSxrQkFDRTtBQUNBLGlEQUE0QjNKLGFBQWEsQ0FBekMseUJBRkY7QUFHQTtBQUNBO0FBQ0E7QUFDQSw0QkExQ0EsQ0EyQ0E7QUFDQTs7QUFDQTtBQUVBOztBQUVBLFFBQUlrQixLQUFKLEVBQXFDLEVBTXJDOztBQUFBLGVBQW1DLEVBNENwQztBQXNERG1OOztBQUFBQSxRQUFNLEdBQVM7QUFDYnRPLFVBQU0sQ0FBTkE7QUFHRjtBQUFBOzs7OztBQUdBdU8sTUFBSSxHQUFHO0FBQ0x2TyxVQUFNLENBQU5BO0FBR0Y7QUFBQTs7Ozs7Ozs7QUFNQXdPLE1BQUksTUFBV3ZILEVBQU8sR0FBbEIsS0FBMEJpSCxPQUEwQixHQUFwRCxJQUEyRDtBQUM3RDtBQUFDLEtBQUM7QUFBQTtBQUFBO0FBQUEsUUFBY08sWUFBWSxZQUEzQixFQUEyQixDQUEzQjtBQUNELFdBQU8sa0NBQVAsT0FBTyxDQUFQO0FBR0Y7QUFBQTs7Ozs7Ozs7QUFNQXZILFNBQU8sTUFBV0QsRUFBTyxHQUFsQixLQUEwQmlILE9BQTBCLEdBQXBELElBQTJEO0FBQ2hFO0FBQUMsS0FBQztBQUFBO0FBQUE7QUFBQSxRQUFjTyxZQUFZLFlBQTNCLEVBQTJCLENBQTNCO0FBQ0QsV0FBTyxxQ0FBUCxPQUFPLENBQVA7QUFHRjs7QUFBQSx5Q0FLb0I7QUFDbEIsUUFBSSxDQUFDQyxVQUFVLENBQWYsR0FBZSxDQUFmLEVBQXNCO0FBQ3BCMU8sWUFBTSxDQUFOQTtBQUNBO0FBR0Y7O0FBQUEsUUFBSSxDQUFFa08sT0FBRCxDQUFMLElBQTBCO0FBQ3hCO0FBRUYsS0FUa0IsQ0FTbEI7OztBQUNBLFFBQUlTLE9BQUosSUFBUTtBQUNOQyxpQkFBVyxDQUFYQTtBQUdGOztBQUFBLFFBQUksS0FBSixnQkFBeUI7QUFDdkIsOEJBQXdCLEtBQXhCO0FBR0YzSDs7QUFBQUEsTUFBRSxHQUFHNEgsU0FBUyxLQUFLLEtBQUwsUUFBa0IsS0FBaEM1SCxhQUFjLENBQWRBO0FBQ0EsVUFBTTZILFNBQVMsR0FBR0MsU0FBUyxDQUN6QjVELFdBQVcsQ0FBWEEsRUFBVyxDQUFYQSxHQUFrQjZELFdBQVcsQ0FBN0I3RCxFQUE2QixDQUE3QkEsR0FEeUIsSUFFekIsS0FGRixNQUEyQixDQUEzQjtBQUlBLDZCQXZCa0IsQ0F5QmxCO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsUUFBSSxDQUFFK0MsT0FBRCxDQUFELE1BQXdCLHFCQUE1QixTQUE0QixDQUE1QixFQUE2RDtBQUMzRDtBQUNBdEUsWUFBTSxDQUFOQSxtQ0FGMkQsQ0FHM0Q7O0FBQ0E7QUFDQTtBQUNBLGtCQUFZLGdCQUFnQixLQUE1QixLQUFZLENBQVo7QUFDQUEsWUFBTSxDQUFOQTtBQUNBO0FBR0YsS0ExQ2tCLENBMENsQjtBQUNBO0FBQ0E7OztBQUNBLFVBQU1xRixLQUFLLEdBQUcsTUFBTSxnQkFBcEIsV0FBb0IsRUFBcEI7QUFDQSxVQUFNO0FBQUVDLGdCQUFVLEVBQVo7QUFBQSxRQUEyQixNQUFNLGdCQUF2QztBQUVBLFFBQUlDLE1BQU0sR0FBRyx3Q0FBYixHQUFhLENBQWI7QUFFQSxRQUFJO0FBQUE7QUFBQTtBQUFBLFFBQUo7QUFFQUEsVUFBTSxHQUFHLDBCQUFUQSxLQUFTLENBQVRBOztBQUVBLFFBQUlBLE1BQU0sQ0FBTkEsYUFBSixVQUFrQztBQUNoQzlHLGNBQVEsR0FBRzhHLE1BQU0sQ0FBakI5RztBQUNBek4sU0FBRyxHQUFHLGlDQUFOQSxNQUFNLENBQU5BO0FBR0YsS0EzRGtCLENBMkRsQjtBQUNBO0FBQ0E7OztBQUNBeU4sWUFBUSxHQUFHQSxRQUFRLEdBQ2YscURBQXdCMkcsV0FBVyxDQURwQixRQUNvQixDQUFuQyxDQURlLEdBQW5CM0csU0E5RGtCLENBa0VsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFFBQUksQ0FBQyxjQUFMLFNBQUssQ0FBTCxFQUErQjtBQUM3QnZGLFlBQU0sR0FBTkE7QUFHRjs7QUFBQSxRQUFJb0ssS0FBSyxHQUFHLHFEQUFaLFFBQVksQ0FBWjtBQUNBLFVBQU07QUFBRW5GLGFBQU8sR0FBVDtBQUFBLFFBQU4sUUE1RWtCLENBOEVsQjtBQUNBOztBQUNBLFFBQUlPLFVBQVUsR0FBZDs7QUFFQSxRQUFJbkgsSUFBSixFQUFxQztBQUNuQ21ILGdCQUFVLEdBQUcsOEJBQ1gsNENBRFcsNENBTVZGLENBQUQsSUFBZSxrQkFBa0I7QUFBRUMsZ0JBQVEsRUFBNUI7QUFBa0IsT0FBbEIsU0FOakJDLFFBQWEsQ0FBYkE7O0FBU0EsVUFBSUEsVUFBVSxLQUFkLElBQXVCO0FBQ3JCLGNBQU04RyxhQUFhLEdBQUcscURBQ3BCLGtCQUNFekgsTUFBTSxDQUFOQSxtQkFBMEI7QUFBRVUsa0JBQVEsRUFEdEM7QUFDNEIsU0FBMUJWLENBREYsZ0JBREYsUUFBc0IsQ0FBdEIsQ0FEcUIsQ0FTckI7QUFDQTs7QUFDQSxZQUFJc0gsS0FBSyxDQUFMQSxTQUFKLGFBQUlBLENBQUosRUFBbUM7QUFDakMvQixlQUFLLEdBQUxBO0FBQ0E3RSxrQkFBUSxHQUFSQTtBQUNBOEcsZ0JBQU0sQ0FBTkE7QUFDQXZVLGFBQUcsR0FBRyxpQ0FBTkEsTUFBTSxDQUFOQTtBQUVIO0FBQ0Y7QUFDRDBOOztBQUFBQSxjQUFVLEdBQUd5RyxTQUFTLENBQUNDLFdBQVcsQ0FBWixVQUFZLENBQVosRUFBMEIsS0FBaEQxRyxNQUFzQixDQUF0QkE7O0FBRUEsUUFBSSwrQkFBSixLQUFJLENBQUosRUFBMkI7QUFDekIsWUFBTStHLFFBQVEsR0FBRyx3Q0FBakIsVUFBaUIsQ0FBakI7QUFDQSxZQUFNN0QsVUFBVSxHQUFHNkQsUUFBUSxDQUEzQjtBQUVBLFlBQU1DLFVBQVUsR0FBRywrQkFBbkIsS0FBbUIsQ0FBbkI7QUFDQSxZQUFNQyxVQUFVLEdBQUcsK0NBQW5CLFVBQW1CLENBQW5CO0FBQ0EsWUFBTUMsaUJBQWlCLEdBQUd0QyxLQUFLLEtBQS9CO0FBQ0EsWUFBTWYsY0FBYyxHQUFHcUQsaUJBQWlCLEdBQ3BDcEQsYUFBYSxvQkFEdUIsS0FDdkIsQ0FEdUIsR0FBeEM7O0FBSUEsVUFBSSxlQUFnQm9ELGlCQUFpQixJQUFJLENBQUNyRCxjQUFjLENBQXhELFFBQWtFO0FBQ2hFLGNBQU1zRCxhQUFhLEdBQUc5SCxNQUFNLENBQU5BLEtBQVkySCxVQUFVLENBQXRCM0gsZUFDbkIrRCxLQUFELElBQVcsQ0FBQ3JULEtBQUssQ0FEbkIsS0FDbUIsQ0FER3NQLENBQXRCOztBQUlBLFlBQUk4SCxhQUFhLENBQWJBLFNBQUosR0FBOEI7QUFDNUIsb0JBQTJDO0FBQ3pDbk0sbUJBQU8sQ0FBUEEsS0FDRyxHQUNDa00saUJBQWlCLDBCQUVaLGlDQUhQLDhCQUFDLEdBS0UsZUFBY0MsYUFBYSxDQUFiQSxVQU5uQm5NO0FBWUY7O0FBQUEsZ0JBQU0sVUFDSixDQUFDa00saUJBQWlCLEdBQ2IsMEJBQXlCNVUsR0FBSSxvQ0FBbUM2VSxhQUFhLENBQWJBLFVBRG5ELG9DQUliLDhCQUE2QmpFLFVBQVcsOENBQTZDMEIsS0FKMUYsU0FLRyw0Q0FDQ3NDLGlCQUFpQixpQ0FFYixzQkFUVixFQUFNLENBQU47QUFhSDtBQWhDRCxhQWdDTyx1QkFBdUI7QUFDNUJ2SSxVQUFFLEdBQUcsaUNBQ0hVLE1BQU0sQ0FBTkEscUJBQTRCO0FBQzFCVSxrQkFBUSxFQUFFOEQsY0FBYyxDQURFO0FBRTFCOVQsZUFBSyxFQUFFZ1Usa0JBQWtCLFFBQVFGLGNBQWMsQ0FIbkRsRixNQUc2QjtBQUZDLFNBQTVCVSxDQURHLENBQUxWO0FBREssYUFPQTtBQUNMO0FBQ0FVLGNBQU0sQ0FBTkE7QUFFSDtBQUVEaUM7O0FBQUFBLFVBQU0sQ0FBTkE7O0FBRUEsUUFBSTtBQUNGLFlBQU04RixTQUFTLEdBQUcsTUFBTSw4Q0FBeEIsT0FBd0IsQ0FBeEI7QUFPQSxVQUFJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFKLFVBUkUsQ0FVRjs7QUFDQSxVQUNFLENBQUN0QixPQUFPLElBQVIscUJBRUNqVSxLQUFELENBRkEsYUFHQ0EsS0FBRCxVQUFDQSxDQUpILGNBS0U7QUFDQSxjQUFNd1YsV0FBVyxHQUFJeFYsS0FBRCxVQUFDQSxDQUFyQixhQURBLENBR0E7QUFDQTtBQUNBOztBQUNBLFlBQUl3VixXQUFXLENBQVhBLFdBQUosR0FBSUEsQ0FBSixFQUFpQztBQUMvQixnQkFBTUMsVUFBVSxHQUFHLHdDQUFuQixXQUFtQixDQUFuQjs7QUFDQTs7QUFFQSxjQUFJWCxLQUFLLENBQUxBLFNBQWVXLFVBQVUsQ0FBN0IsUUFBSVgsQ0FBSixFQUF5QztBQUN2QyxtQkFBTyxzREFBUCxPQUFPLENBQVA7QUFPSDtBQUVEalA7O0FBQUFBLGNBQU0sQ0FBTkE7QUFDQSxlQUFPLFlBQVksTUFBTSxDQUF6QixDQUFPLENBQVA7QUFHRjRKOztBQUFBQSxZQUFNLENBQU5BO0FBQ0Esb0NBR0VpRixTQUFTLEtBQUssS0FBTCxRQUFrQixLQUg3QixhQUdXLENBSFg7O0FBT0EsZ0JBQTJDO0FBQ3pDLGNBQU1nQixPQUFZLEdBQUcseUJBQXJCO0FBQ0U3UCxjQUFELEtBQUNBLENBQUQsYUFBQ0EsR0FDQTZQLE9BQU8sQ0FBUEEsb0JBQTRCQSxPQUFPLENBQW5DQSx1QkFDQSxDQUFFSCxTQUFTLENBQVYsU0FBQ0EsQ0FGSCxlQUFDMVA7QUFLSjs7QUFBQSxZQUFNLDZEQUNIL0UsQ0FBRCxJQUFPO0FBQ0wsWUFBSUEsQ0FBQyxDQUFMLFdBQWlCaEYsS0FBSyxHQUFHQSxLQUFLLElBQTlCLENBQWlCQSxDQUFqQixLQUNLO0FBSFQsT0FBTSxDQUFOOztBQU9BLGlCQUFXO0FBQ1QyVCxjQUFNLENBQU5BO0FBQ0E7QUFHRjs7QUFBQSxVQUFJekksS0FBSixFQUEyQyxFQUszQ3lJOztBQUFBQSxZQUFNLENBQU5BO0FBRUE7QUFDQSxLQTNFRixDQTJFRSxZQUFZO0FBQ1osVUFBSWhELEdBQUcsQ0FBUCxXQUFtQjtBQUNqQjtBQUVGOztBQUFBO0FBRUg7QUFFRGtKOztBQUFBQSxhQUFXLGtCQUlUNUIsT0FBMEIsR0FKakIsSUFLSDtBQUNOLGNBQTJDO0FBQ3pDLFVBQUksT0FBT2xPLE1BQU0sQ0FBYixZQUFKLGFBQTJDO0FBQ3pDc0QsZUFBTyxDQUFQQTtBQUNBO0FBR0Y7O0FBQUEsVUFBSSxPQUFPdEQsTUFBTSxDQUFOQSxRQUFQLE1BQU9BLENBQVAsS0FBSixhQUFtRDtBQUNqRHNELGVBQU8sQ0FBUEEsTUFBZSwyQkFBMEJSLE1BQXpDUTtBQUNBO0FBRUg7QUFFRDs7QUFBQSxRQUFJUixNQUFNLEtBQU5BLGVBQTBCLHlCQUE5QixJQUErQztBQUM3QyxzQkFBZ0JvTCxPQUFPLENBQXZCO0FBQ0EsWUFBTSxDQUFOLGdCQUNFO0FBQUE7QUFBQTtBQUFBO0FBSUU2QixXQUFHLEVBTFA7QUFDRSxPQURGLEVBT0U7QUFDQTtBQUNBO0FBVEY7QUFjSDtBQUVEOztBQUFBLHNFQU02QjtBQUMzQixRQUFJbkosR0FBRyxDQUFQLFdBQW1CO0FBQ2pCO0FBQ0E7QUFHRjs7QUFBQSxRQUFJNEYsZUFBZSxJQUFmQSxPQUFKLGVBQTZDO0FBQzNDNUMsWUFBTSxDQUFOQSx5Q0FEMkMsQ0FHM0M7QUFDQTtBQUNBO0FBQ0E7QUFFQTs7QUFDQTVKLFlBQU0sQ0FBTkEsbUJBVDJDLENBVzNDO0FBQ0E7O0FBQ0EsWUFBTWdRLHNCQUFOO0FBR0Y7O0FBQUEsUUFBSTtBQUNGLFlBQU07QUFBRUMsWUFBSSxFQUFOO0FBQUE7QUFBQSxVQUFtQyxNQUFNLG9CQUEvQyxTQUErQyxDQUEvQztBQUdBLFlBQU1QLFNBQTJCLEdBQUc7QUFBQTtBQUFBO0FBQUE7QUFJbEN6WixhQUFLLEVBSlA7QUFBb0MsT0FBcEM7O0FBT0EsVUFBSTtBQUNGeVosaUJBQVMsQ0FBVEEsUUFBa0IsTUFBTSxnQ0FBZ0M7QUFBQTtBQUFBO0FBQXhEQTtBQUF3RCxTQUFoQyxDQUF4QkE7QUFLQSxPQU5GLENBTUUsZUFBZTtBQUNmcE0sZUFBTyxDQUFQQTtBQUNBb00saUJBQVMsQ0FBVEE7QUFHRjs7QUFBQTtBQUNBLEtBdkJGLENBdUJFLHFCQUFxQjtBQUNyQixhQUFPLDZEQUFQLElBQU8sQ0FBUDtBQUVIO0FBRUQ7O0FBQUEsaURBS0UzSCxPQUFnQixHQUxsQixPQU02QjtBQUMzQixRQUFJO0FBQ0YsWUFBTW1JLGVBQWUsR0FBRyxnQkFBeEIsS0FBd0IsQ0FBeEI7O0FBRUEsVUFBSW5JLE9BQU8sSUFBUEEsbUJBQThCLGVBQWxDLE9BQXdEO0FBQ3REO0FBR0Y7O0FBQUEsWUFBTTJILFNBQTJCLEdBQUdRLGVBQWUscUJBRS9DLE1BQU0sZ0NBQWlDelksR0FBRCxLQUFVO0FBQzlDdUMsaUJBQVMsRUFBRXZDLEdBQUcsQ0FEZ0M7QUFFOUMwVyxtQkFBVyxFQUFFMVcsR0FBRyxDQUY4QjtBQUc5QzJXLGVBQU8sRUFBRTNXLEdBQUcsQ0FBSEEsSUFIcUM7QUFJOUM0VyxlQUFPLEVBQUU1VyxHQUFHLENBQUhBLElBTmY7QUFFb0QsT0FBVixDQUFoQyxDQUZWO0FBU0EsWUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBQU47O0FBRUEsZ0JBQTJDO0FBQ3pDLGNBQU07QUFBQTtBQUFBLFlBQXlCMFksbUJBQU8sQ0FBdEMsMEJBQXNDLENBQXRDOztBQUNBLFlBQUksQ0FBQ0Msa0JBQWtCLENBQXZCLFNBQXVCLENBQXZCLEVBQW9DO0FBQ2xDLGdCQUFNLFVBQ0gseURBQXdEL0gsUUFEM0QsR0FBTSxDQUFOO0FBSUg7QUFFRDs7QUFBQTs7QUFFQSxVQUFJK0YsT0FBTyxJQUFYLFNBQXdCO0FBQ3RCaUMsZ0JBQVEsR0FBRyw0QkFDVCxpQ0FBcUI7QUFBQTtBQURaO0FBQ1ksU0FBckIsQ0FEUyxFQUVUckIsV0FBVyxDQUZGLEVBRUUsQ0FGRixXQUlULEtBSlMsUUFLVCxLQUxGcUIsYUFBVyxDQUFYQTtBQVNGOztBQUFBLFlBQU1sVyxLQUFLLEdBQUcsTUFBTSxjQUFnQyxNQUNsRGlVLE9BQU8sR0FDSCxvQkFERyxRQUNILENBREcsR0FFSEMsT0FBTyxHQUNQLG9CQURPLFFBQ1AsQ0FETyxHQUVQLGdDQUVFO0FBQ0E7QUFBQTtBQUFBO0FBR0VsQixjQUFNLEVBWGhCO0FBUVEsT0FIRixDQUxjLENBQXBCO0FBZ0JBdUMsZUFBUyxDQUFUQTtBQUNBO0FBQ0E7QUFDQSxLQTFERixDQTBERSxZQUFZO0FBQ1osYUFBTyxnREFBUCxFQUFPLENBQVA7QUFFSDtBQUVEWTs7QUFBQUEsS0FBRyxtQ0FNYztBQUNmO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFPLFlBQVAsSUFBTyxDQUFQO0FBR0Y7QUFBQTs7Ozs7O0FBSUFDLGdCQUFjLEtBQTZCO0FBQ3pDO0FBR0ZDOztBQUFBQSxpQkFBZSxLQUFzQjtBQUNuQyxRQUFJLENBQUMsS0FBTCxRQUFrQjtBQUNsQixVQUFNLDBCQUEwQixrQkFBaEMsR0FBZ0MsQ0FBaEM7QUFDQSxVQUFNLDBCQUEwQnZKLEVBQUUsQ0FBRkEsTUFBaEMsR0FBZ0NBLENBQWhDLENBSG1DLENBS25DOztBQUNBLFFBQUl3SixPQUFPLElBQUlDLFlBQVksS0FBdkJELGdCQUE0Q0UsT0FBTyxLQUF2RCxTQUFxRTtBQUNuRTtBQUdGLEtBVm1DLENBVW5DOzs7QUFDQSxRQUFJRCxZQUFZLEtBQWhCLGNBQW1DO0FBQ2pDO0FBR0YsS0FmbUMsQ0FlbkM7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFdBQU9DLE9BQU8sS0FBZDtBQUdGQzs7QUFBQUEsY0FBWSxLQUFtQjtBQUM3QixVQUFNLFdBQVczSixFQUFFLENBQUZBLE1BQWpCLEdBQWlCQSxDQUFqQixDQUQ2QixDQUU3Qjs7QUFDQSxRQUFJbkMsSUFBSSxLQUFSLElBQWlCO0FBQ2Y5RSxZQUFNLENBQU5BO0FBQ0E7QUFHRixLQVI2QixDQVE3Qjs7O0FBQ0EsVUFBTTZRLElBQUksR0FBR3pKLFFBQVEsQ0FBUkEsZUFBYixJQUFhQSxDQUFiOztBQUNBLGNBQVU7QUFDUnlKLFVBQUksQ0FBSkE7QUFDQTtBQUVGLEtBZDZCLENBYzdCO0FBQ0E7OztBQUNBLFVBQU1DLE1BQU0sR0FBRzFKLFFBQVEsQ0FBUkEsd0JBQWYsQ0FBZUEsQ0FBZjs7QUFDQSxnQkFBWTtBQUNWMEosWUFBTSxDQUFOQTtBQUVIO0FBRURDOztBQUFBQSxVQUFRLFNBQTBCO0FBQ2hDLFdBQU8sZ0JBQVA7QUFHRkM7O0FBQUFBLGNBQVksb0JBQXlDQyxhQUFhLEdBQXRELE1BQStEO0FBQ3pFLFVBQU07QUFBQTtBQUFBLFFBQU47QUFDQSxVQUFNQyxhQUFhLEdBQUcscURBQ3BCLDhDQUFvQkQsYUFBYSxHQUFHakMsV0FBVyxDQUFkLFFBQWMsQ0FBZCxHQURuQyxRQUNFLENBRG9CLENBQXRCOztBQUlBLFFBQUlrQyxhQUFhLEtBQWJBLFVBQTRCQSxhQUFhLEtBQTdDLFdBQTZEO0FBQzNEO0FBR0YsS0FWeUUsQ0FVekU7OztBQUNBLFFBQUksQ0FBQ2pDLEtBQUssQ0FBTEEsU0FBTCxhQUFLQSxDQUFMLEVBQXFDO0FBQ25DO0FBQ0FBLFdBQUssQ0FBTEEsS0FBWWdCLElBQUQsSUFBVTtBQUNuQixZQUNFLHdDQUNBLDZDQUZGLGFBRUUsQ0FGRixFQUdFO0FBQ0FMLG9CQUFVLENBQVZBLFdBQXNCcUIsYUFBYSxHQUFHdkUsV0FBVyxDQUFkLElBQWMsQ0FBZCxHQUFuQ2tEO0FBQ0E7QUFFSDtBQVJEWDtBQVVGOztBQUFBO0FBR0Y7QUFBQTs7Ozs7Ozs7QUFNQSxzQkFFRTlCLE1BQWMsR0FGaEIsS0FHRWUsT0FBd0IsR0FIMUIsSUFJaUI7QUFDZixRQUFJaUIsTUFBTSxHQUFHLHdDQUFiLEdBQWEsQ0FBYjtBQUVBLFFBQUk7QUFBQTtBQUFBLFFBQUo7QUFFQSxVQUFNRixLQUFLLEdBQUcsTUFBTSxnQkFBcEIsV0FBb0IsRUFBcEI7QUFFQUUsVUFBTSxHQUFHLDBCQUFUQSxLQUFTLENBQVRBOztBQUVBLFFBQUlBLE1BQU0sQ0FBTkEsYUFBSixVQUFrQztBQUNoQzlHLGNBQVEsR0FBRzhHLE1BQU0sQ0FBakI5RztBQUNBek4sU0FBRyxHQUFHLGlDQUFOQSxNQUFNLENBQU5BO0FBR0YsS0FkZSxDQWNmOzs7QUFDQSxjQUEyQztBQUN6QztBQUdGOztBQUFBLFVBQU1zUyxLQUFLLEdBQUcscURBQWQsUUFBYyxDQUFkO0FBQ0EsVUFBTWlFLE9BQU8sQ0FBUEEsSUFBWSxDQUNoQiwwQ0FHRSxLQUhGLFFBSUUsS0FMYyxhQUNoQixDQURnQixFQU9oQixnQkFBZ0JqRCxPQUFPLENBQVBBLHdCQUFoQixZQVBGLEtBT0UsQ0FQZ0IsQ0FBWmlELENBQU47QUFXRjs7QUFBQSw4QkFBNEQ7QUFDMUQsUUFBSXJHLFNBQVMsR0FBYjs7QUFDQSxVQUFNc0csTUFBTSxHQUFJLFdBQVcsTUFBTTtBQUMvQnRHLGVBQVMsR0FBVEE7QUFERjs7QUFJQSxVQUFNdUcsZUFBZSxHQUFHLE1BQU0seUJBQTlCLEtBQThCLENBQTlCOztBQUVBLG1CQUFlO0FBQ2IsWUFBTXBiLEtBQVUsR0FBRyxVQUNoQix3Q0FBdUNpWCxLQUQxQyxHQUFtQixDQUFuQjtBQUdBalgsV0FBSyxDQUFMQTtBQUNBO0FBR0Y7O0FBQUEsUUFBSW1iLE1BQU0sS0FBSyxLQUFmLEtBQXlCO0FBQ3ZCO0FBR0Y7O0FBQUE7QUFHRkU7O0FBQUFBLFVBQVEsS0FBc0M7QUFDNUMsUUFBSXhHLFNBQVMsR0FBYjs7QUFDQSxVQUFNc0csTUFBTSxHQUFHLE1BQU07QUFDbkJ0RyxlQUFTLEdBQVRBO0FBREY7O0FBR0E7QUFDQSxXQUFPeUcsRUFBRSxHQUFGQSxLQUFXeFosSUFBRCxJQUFVO0FBQ3pCLFVBQUlxWixNQUFNLEtBQUssS0FBZixLQUF5QjtBQUN2QjtBQUdGOztBQUFBLHFCQUFlO0FBQ2IsY0FBTXhLLEdBQVEsR0FBRyxVQUFqQixpQ0FBaUIsQ0FBakI7QUFDQUEsV0FBRyxDQUFIQTtBQUNBO0FBR0Y7O0FBQUE7QUFYRixLQUFPMkssQ0FBUDtBQWVGQzs7QUFBQUEsZ0JBQWMsV0FBb0M7QUFDaEQsVUFBTTtBQUFFM0ssVUFBSSxFQUFOO0FBQUEsUUFBcUIsa0JBQWtCN0csTUFBTSxDQUFOQSxTQUE3QyxJQUEyQixDQUEzQjs7QUFDQSxRQUFJbUIsS0FBSixFQUFpRSxFQUdqRTs7QUFBQSxXQUFPc1EsYUFBYSxXQUFXLEtBQXhCQSxLQUFhLENBQWJBLE1BQTBDMVosSUFBRCxJQUFVO0FBQ3hEO0FBQ0E7QUFGRixLQUFPMFosQ0FBUDtBQU1GQzs7QUFBQUEsZ0JBQWMsV0FBb0M7QUFDaEQsV0FBT0QsYUFBYSxXQUFXLEtBQS9CLEtBQW9CLENBQXBCO0FBR0Y5Ujs7QUFBQUEsaUJBQWUsaUJBR0M7QUFDZCxVQUFNO0FBQUUzRixlQUFTLEVBQVg7QUFBQSxRQUFxQixnQkFBM0IsT0FBMkIsQ0FBM0I7O0FBQ0EsVUFBTTJYLE9BQU8sR0FBRyxjQUFoQixHQUFnQixDQUFoQjs7QUFDQUMsT0FBRyxDQUFIQTtBQUNBLFdBQU8scUNBQWlEO0FBQUE7QUFBQTtBQUd0RGpMLFlBQU0sRUFIZ0Q7QUFBeEQ7QUFBd0QsS0FBakQsQ0FBUDtBQVFGa0w7O0FBQUFBLG9CQUFrQixLQUFtQjtBQUNuQyxRQUFJLEtBQUosS0FBYztBQUNaakksWUFBTSxDQUFOQSxnQ0FBdUNvRyxzQkFBdkNwRztBQUNBO0FBQ0E7QUFFSDtBQUVEa0k7O0FBQUFBLFFBQU0sT0FBd0M7QUFDNUMsV0FBTyxlQUFlLHlCQUF0QixTQUFPLENBQVA7QUF6M0I4Qzs7QUFBQTs7O0FBQTdCbEksTSxDQTJCWjhELE1BM0JZOUQsR0EyQlUsb0JBM0JWQSxDOzs7Ozs7Ozs7Ozs7Ozs7d0NDbFZyQjs7QUFDZSx1Q0FBdUQ7QUFDcEUsU0FBT21JLE9BQU8sQ0FBUEEsa0JBQTJCQyxJQUFELElBQWtCaE8sa0JBQWtCLENBQXJFLElBQXFFLENBQTlEK04sQ0FBUDtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcUJEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBeEJBLEMsQ0FBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQU1BLE1BQU1FLGdCQUFnQixHQUF0Qjs7QUFFTywyQkFBc0M7QUFDM0MsTUFBSTtBQUFBO0FBQUE7QUFBQSxNQUFKO0FBQ0EsTUFBSUMsUUFBUSxHQUFHQyxNQUFNLENBQU5BLFlBQWY7QUFDQSxNQUFJOUosUUFBUSxHQUFHOEosTUFBTSxDQUFOQSxZQUFmO0FBQ0EsTUFBSXJOLElBQUksR0FBR3FOLE1BQU0sQ0FBTkEsUUFBWDtBQUNBLE1BQUk5WixLQUFLLEdBQUc4WixNQUFNLENBQU5BLFNBQVo7QUFDQSxNQUFJQyxJQUFvQixHQUF4QjtBQUVBQyxNQUFJLEdBQUdBLElBQUksR0FBR3JPLGtCQUFrQixDQUFsQkEsSUFBa0IsQ0FBbEJBLHdCQUFILE1BQVhxTzs7QUFFQSxNQUFJRixNQUFNLENBQVYsTUFBaUI7QUFDZkMsUUFBSSxHQUFHQyxJQUFJLEdBQUdGLE1BQU0sQ0FBcEJDO0FBREYsU0FFTyxjQUFjO0FBQ25CQSxRQUFJLEdBQUdDLElBQUksSUFBSSxDQUFDQyxRQUFRLENBQVJBLFFBQUQsR0FBQ0EsQ0FBRCxHQUEwQixJQUFHQSxRQUE3QixNQUFmRixRQUFXLENBQVhBOztBQUNBLFFBQUlELE1BQU0sQ0FBVixNQUFpQjtBQUNmQyxVQUFJLElBQUksTUFBTUQsTUFBTSxDQUFwQkM7QUFFSDtBQUVEOztBQUFBLE1BQUkvWixLQUFLLElBQUksaUJBQWIsVUFBd0M7QUFDdENBLFNBQUssR0FBR2thLE1BQU0sQ0FBQ0MsV0FBVyxDQUFYQSx1QkFBZm5hLEtBQWVtYSxDQUFELENBQWRuYTtBQUdGOztBQUFBLE1BQUltRCxNQUFNLEdBQUcyVyxNQUFNLENBQU5BLFVBQWtCOVosS0FBSyxJQUFLLElBQUdBLEtBQS9COFosTUFBYjtBQUVBLE1BQUlELFFBQVEsSUFBSUEsUUFBUSxDQUFSQSxPQUFnQixDQUFoQkEsT0FBaEIsS0FBNkNBLFFBQVEsSUFBUkE7O0FBRTdDLE1BQ0VDLE1BQU0sQ0FBTkEsV0FDQyxDQUFDLGFBQWFGLGdCQUFnQixDQUFoQkEsS0FBZCxRQUFjQSxDQUFkLEtBQWtERyxJQUFJLEtBRnpELE9BR0U7QUFDQUEsUUFBSSxHQUFHLFFBQVFBLElBQUksSUFBbkJBLEVBQU8sQ0FBUEE7QUFDQSxRQUFJL0osUUFBUSxJQUFJQSxRQUFRLENBQVJBLENBQVEsQ0FBUkEsS0FBaEIsS0FBcUNBLFFBQVEsR0FBRyxNQUFYQTtBQUx2QyxTQU1PLElBQUksQ0FBSixNQUFXO0FBQ2hCK0osUUFBSSxHQUFKQTtBQUdGOztBQUFBLE1BQUl0TixJQUFJLElBQUlBLElBQUksQ0FBSkEsQ0FBSSxDQUFKQSxLQUFaLEtBQTZCQSxJQUFJLEdBQUcsTUFBUEE7QUFDN0IsTUFBSXRKLE1BQU0sSUFBSUEsTUFBTSxDQUFOQSxDQUFNLENBQU5BLEtBQWQsS0FBaUNBLE1BQU0sR0FBRyxNQUFUQTtBQUVqQzZNLFVBQVEsR0FBR0EsUUFBUSxDQUFSQSxpQkFBWEEsa0JBQVdBLENBQVhBO0FBQ0E3TSxRQUFNLEdBQUdBLE1BQU0sQ0FBTkEsYUFBVEEsS0FBU0EsQ0FBVEE7QUFFQSxTQUFRLEdBQUUwVyxRQUFTLEdBQUVFLElBQUssR0FBRS9KLFFBQVMsR0FBRTdNLE1BQU8sR0FBRXNKLElBQWhEO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7O3lDQ3hFRDs7QUFDQSxNQUFNMk4sVUFBVSxHQUFoQjs7QUFFTywrQkFBZ0Q7QUFDckQsU0FBT0EsVUFBVSxDQUFWQSxLQUFQLEtBQU9BLENBQVA7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0xEOztBQUNBOztBQUVBLE1BQU1DLFVBQVUsR0FBRyxRQUNqQixvQkFBNkMsU0FENUIsQ0FBbkI7QUFJQTs7Ozs7OztBQU1PLHFDQUFzRDtBQUMzRCxRQUFNQyxZQUFZLEdBQUczRyxJQUFJLEdBQUcsY0FBSCxVQUFHLENBQUgsR0FBekI7QUFDQSxRQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVFGLGFBUkosWUFRSSxDQVJKOztBQVNBLE1BQ0U0RyxNQUFNLEtBQUtGLFVBQVUsQ0FBckJFLFVBQ0NWLFFBQVEsS0FBUkEsV0FBd0JBLFFBQVEsS0FGbkMsVUFHRTtBQUNBLFVBQU0sVUFBTixpQ0FBTSxDQUFOO0FBRUY7O0FBQUEsU0FBTztBQUFBO0FBRUw3WixTQUFLLEVBQUUseUNBRkYsWUFFRSxDQUZGO0FBQUE7QUFBQTtBQUtMd08sUUFBSSxFQUFFQSxJQUFJLENBQUpBLE1BQVc2TCxVQUFVLENBQVZBLE9BTG5CLE1BS1E3TDtBQUxELEdBQVA7QUFPRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSU87O0FBQUEsTUFBTWdNLGNBQ2MsR0FBRztBQUM1QkMsV0FBUyxFQURtQjtBQUU1QkMsV0FBUyxFQUhKO0FBQ3VCLENBRHZCOzs7QUFNQSxNQUFNQyx5QkFDYyxtQ0FBRyxjQUFIO0FBRXpCQyxRQUFNLEVBSEQ7QUFDb0IsRUFEcEI7Ozs7ZUFNUSxDQUFDQyxXQUFXLEdBQVosVUFBeUI7QUFDdEMsU0FBUS9KLElBQUQsSUFBa0I7QUFDdkIsVUFBTWdLLElBQXdCLEdBQTlCO0FBQ0EsVUFBTUMsWUFBWSxHQUFHQyxZQUFZLENBQVpBLHlCQUduQkgsV0FBVywrQkFIYixjQUFxQkcsQ0FBckI7QUFLQSxVQUFNQyxPQUFPLEdBQUdELFlBQVksQ0FBWkEsK0JBQWhCLElBQWdCQSxDQUFoQjtBQUVBLFdBQU8sc0JBQXVEO0FBQzVELFlBQU01YixHQUFHLEdBQUc0USxRQUFRLElBQVJBLGVBQTJCaUwsT0FBTyxDQUE5QyxRQUE4QyxDQUE5Qzs7QUFDQSxVQUFJLENBQUosS0FBVTtBQUNSO0FBR0Y7O0FBQUEsdUJBQWlCO0FBQ2YsYUFBSyxNQUFMLGFBQXdCO0FBQ3RCO0FBQ0E7QUFDQSxjQUFJLE9BQU9oTSxHQUFHLENBQVYsU0FBSixVQUFrQztBQUNoQyxtQkFBUTdQLEdBQUcsQ0FBSixNQUFDQSxDQUFtQjZQLEdBQUcsQ0FBOUIsSUFBUTdQLENBQVI7QUFFSDtBQUNGO0FBRUQ7O0FBQUEsNkNBQU8sTUFBUCxHQUF1QkEsR0FBRyxDQUExQjtBQWhCRjtBQVRGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hCRjs7QUFDQTs7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUllOztBQUFBLHVGQU1iO0FBQ0EsTUFBSThiLGlCQUttQyxHQUx2Qzs7QUFPQSxNQUFJNUQsV0FBVyxDQUFYQSxXQUFKLEdBQUlBLENBQUosRUFBaUM7QUFDL0I0RCxxQkFBaUIsR0FBRyx3Q0FBcEJBLFdBQW9CLENBQXBCQTtBQURGLFNBRU87QUFDTCxVQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU0YsUUFUSixXQVNJLENBVEo7QUFXQUEscUJBQWlCLEdBQUc7QUFBQTtBQUVsQmxiLFdBQUssRUFBRSx5Q0FGVyxZQUVYLENBRlc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXBCa2I7QUFBb0IsS0FBcEJBO0FBWUY7O0FBQUEsUUFBTUMsU0FBUyxHQUFHRCxpQkFBaUIsQ0FBbkM7QUFDQSxRQUFNRSxRQUFRLEdBQUksR0FBRUYsaUJBQWlCLENBQUNsTCxRQUFVLEdBQzlDa0wsaUJBQWlCLENBQWpCQSxRQUEwQixFQUQ1QjtBQUdBLFFBQU1HLGlCQUFxQyxHQUEzQztBQUNBTCxjQUFZLENBQVpBO0FBRUEsUUFBTU0sY0FBYyxHQUFHRCxpQkFBaUIsQ0FBakJBLElBQXVCcE0sR0FBRCxJQUFTQSxHQUFHLENBQXpELElBQXVCb00sQ0FBdkI7QUFFQSxNQUFJRSxtQkFBbUIsR0FBRyxZQUFZLENBQVosa0JBRXhCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUVDLFlBQVEsRUFSWjtBQVFFLEdBUndCLENBQTFCO0FBVUEsYUFyREEsQ0F1REE7O0FBQ0EsT0FBSyxNQUFNLE1BQVgsVUFBVyxDQUFYLElBQWdDbE0sTUFBTSxDQUFOQSxRQUFoQyxTQUFnQ0EsQ0FBaEMsRUFBMkQ7QUFDekQsUUFBSXhNLEtBQUssR0FBR29QLEtBQUssQ0FBTEEsc0JBQTRCdUosVUFBVSxDQUF0Q3ZKLENBQXNDLENBQXRDQSxHQUFaOztBQUNBLGVBQVc7QUFDVDtBQUNBO0FBQ0FwUCxXQUFLLEdBQUksSUFBR0EsS0FBWkE7QUFDQSxZQUFNNFksYUFBYSxHQUFHVixZQUFZLENBQVpBLGVBQTRCO0FBQUVRLGdCQUFRLEVBQTVEO0FBQWtELE9BQTVCUixDQUF0QjtBQUNBbFksV0FBSyxHQUFHNFksYUFBYSxDQUFiQSxNQUFhLENBQWJBLFFBQVI1WSxDQUFRNFksQ0FBUjVZO0FBRUZxWTs7QUFBQUEsYUFBUyxDQUFUQSxHQUFTLENBQVRBO0FBR0YsR0FwRUEsQ0FvRUE7QUFDQTs7O0FBQ0EsUUFBTVEsU0FBUyxHQUFHck0sTUFBTSxDQUFOQSxLQUFsQixNQUFrQkEsQ0FBbEI7O0FBRUEsTUFDRXNNLG1CQUFtQixJQUNuQixDQUFDRCxTQUFTLENBQVRBLEtBQWdCMU0sR0FBRCxJQUFTcU0sY0FBYyxDQUFkQSxTQUYzQixHQUUyQkEsQ0FBeEJLLENBRkgsRUFHRTtBQUNBLFNBQUssTUFBTCxrQkFBNkI7QUFDM0IsVUFBSSxFQUFFMU0sR0FBRyxJQUFULFNBQUksQ0FBSixFQUF5QjtBQUN2QmtNLGlCQUFTLENBQVRBLEdBQVMsQ0FBVEEsR0FBaUIvSCxNQUFNLENBQXZCK0gsR0FBdUIsQ0FBdkJBO0FBRUg7QUFDRjtBQUVEOztBQUFBLFFBQU1VLGlCQUFpQixHQUFHdkUsV0FBVyxDQUFYQSxtQkFBMUI7O0FBRUEsTUFBSTtBQUNGd0UsVUFBTSxHQUFJLEdBQUVELGlCQUFpQixjQUFjLEVBQUcsR0FBRU4sbUJBQW1CLFFBQW5FTztBQUlBLFVBQU0sbUJBQW1CQSxNQUFNLENBQU5BLE1BQXpCLEdBQXlCQSxDQUF6QjtBQUNBWixxQkFBaUIsQ0FBakJBO0FBQ0FBLHFCQUFpQixDQUFqQkEsT0FBMEIsR0FBRXpPLElBQUksU0FBUyxFQUFHLEdBQUVBLElBQUksSUFBSSxFQUF0RHlPO0FBQ0EsV0FBT0EsaUJBQWlCLENBQXhCO0FBQ0EsR0FURixDQVNFLFlBQVk7QUFDWixRQUFJM00sR0FBRyxDQUFIQSxjQUFKLDhDQUFJQSxDQUFKLEVBQXVFO0FBQ3JFLFlBQU0sVUFBTix3S0FBTSxDQUFOO0FBSUY7O0FBQUE7QUFHRixHQXZHQSxDQXVHQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EyTSxtQkFBaUIsQ0FBakJBLHdDQUEwQixLQUExQkEsR0FFS0EsaUJBQWlCLENBRnRCQTtBQUtBLFNBQU87QUFBQTtBQUFQO0FBQU8sR0FBUDtBQUlELEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvSE0sOENBRVc7QUFDaEIsUUFBTWxiLEtBQXFCLEdBQTNCO0FBQ0ErYixjQUFZLENBQVpBLFFBQXFCLGdCQUFnQjtBQUNuQyxRQUFJLE9BQU8vYixLQUFLLENBQVosR0FBWSxDQUFaLEtBQUosYUFBdUM7QUFDckNBLFdBQUssQ0FBTEEsR0FBSyxDQUFMQTtBQURGLFdBRU8sSUFBSWtTLEtBQUssQ0FBTEEsUUFBY2xTLEtBQUssQ0FBdkIsR0FBdUIsQ0FBbkJrUyxDQUFKLEVBQStCO0FBQ3BDO0FBQUVsUyxXQUFLLENBQU4sR0FBTSxDQUFMQSxDQUFELElBQUNBLENBQUQsS0FBQ0E7QUFERyxXQUVBO0FBQ0xBLFdBQUssQ0FBTEEsR0FBSyxDQUFMQSxHQUFhLENBQUNBLEtBQUssQ0FBTixHQUFNLENBQU4sRUFBYkEsS0FBYSxDQUFiQTtBQUVIO0FBUkQrYjtBQVNBO0FBR0Y7O0FBQUEsdUNBQXVEO0FBQ3JELE1BQ0UsNkJBQ0MsNkJBQTZCLENBQUNDLEtBQUssQ0FEcEMsS0FDb0MsQ0FEcEMsSUFFQSxpQkFIRixXQUlFO0FBQ0EsV0FBTzlCLE1BQU0sQ0FBYixLQUFhLENBQWI7QUFMRixTQU1PO0FBQ0w7QUFFSDtBQUVNOztBQUFBLDBDQUVZO0FBQ2pCLFFBQU0xUCxNQUFNLEdBQUcsSUFBZixlQUFlLEVBQWY7QUFDQThFLFFBQU0sQ0FBTkEsMEJBQWlDLENBQUMsTUFBRCxLQUFDLENBQUQsS0FBa0I7QUFDakQsUUFBSTRDLEtBQUssQ0FBTEEsUUFBSixLQUFJQSxDQUFKLEVBQTBCO0FBQ3hCcFAsV0FBSyxDQUFMQSxRQUFlbUYsSUFBRCxJQUFVdUMsTUFBTSxDQUFOQSxZQUFtQnlSLHNCQUFzQixDQUFqRW5aLElBQWlFLENBQXpDMEgsQ0FBeEIxSDtBQURGLFdBRU87QUFDTDBILFlBQU0sQ0FBTkEsU0FBZ0J5UixzQkFBc0IsQ0FBdEN6UixLQUFzQyxDQUF0Q0E7QUFFSDtBQU5EOEU7QUFPQTtBQUdLOztBQUFBLHdCQUVMLEdBRkssa0JBR1k7QUFDakI0TSxrQkFBZ0IsQ0FBaEJBLFFBQTBCSCxZQUFELElBQWtCO0FBQ3pDN0osU0FBSyxDQUFMQSxLQUFXNkosWUFBWSxDQUF2QjdKLElBQVc2SixFQUFYN0osVUFBeUNqRCxHQUFELElBQVNwTSxNQUFNLENBQU5BLE9BQWpEcVAsR0FBaURyUCxDQUFqRHFQO0FBQ0E2SixnQkFBWSxDQUFaQSxRQUFxQixnQkFBZ0JsWixNQUFNLENBQU5BLFlBQXJDa1osS0FBcUNsWixDQUFyQ2taO0FBRkZHO0FBSUE7QUFDRCxDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3BERDs7QUFDQTs7QUFFQTs7Ozs7O0FBRUE7O0FBQUEsTUFBTUMsa0JBQWtCLEdBQUcsd0JBQTNCLElBQTJCLENBQTNCOztBQUVlLGdGQU9iO0FBQ0EsTUFBSSxDQUFDdkYsS0FBSyxDQUFMQSxTQUFMLE1BQUtBLENBQUwsRUFBNkI7QUFDM0IsU0FBSyxNQUFMLHFCQUFnQztBQUM5QixZQUFNcUUsT0FBTyxHQUFHa0Isa0JBQWtCLENBQUNDLE9BQU8sQ0FBMUMsTUFBa0MsQ0FBbEM7QUFDQSxZQUFNaEosTUFBTSxHQUFHNkgsT0FBTyxDQUF0QixNQUFzQixDQUF0Qjs7QUFFQSxrQkFBWTtBQUNWLFlBQUksQ0FBQ21CLE9BQU8sQ0FBWixhQUEwQjtBQUN4QjtBQUNBO0FBRUY7O0FBQUEsY0FBTUMsT0FBTyxHQUFHLGlDQUNkRCxPQUFPLENBRE8sa0NBS2RBLE9BQU8sQ0FBUEEsMEJBTEYsUUFBZ0IsQ0FBaEI7QUFPQXRILGNBQU0sR0FBR3VILE9BQU8sQ0FBUEEsa0JBQVR2SDtBQUNBeEYsY0FBTSxDQUFOQSxjQUFxQitNLE9BQU8sQ0FBUEEsa0JBQXJCL007O0FBRUEsWUFBSXNILEtBQUssQ0FBTEEsU0FBZSxxREFBbkIsTUFBbUIsQ0FBZkEsQ0FBSixFQUFxRDtBQUNuRDtBQUNBO0FBQ0E7QUFHRixTQXJCVSxDQXFCVjs7O0FBQ0EsY0FBTTNDLFlBQVksR0FBR0ssV0FBVyxDQUFoQyxNQUFnQyxDQUFoQzs7QUFFQSxZQUFJTCxZQUFZLEtBQVpBLFVBQTJCMkMsS0FBSyxDQUFMQSxTQUEvQixZQUErQkEsQ0FBL0IsRUFBNkQ7QUFDM0Q7QUFFSDtBQUNGO0FBQ0Y7QUFDRDs7QUFBQTtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbERNLHFDQUF1RTtBQUM1RSxRQUFNO0FBQUE7QUFBQTtBQUFBLE1BQU47QUFDQSxTQUFRNUcsUUFBRCxJQUF5QztBQUM5QyxVQUFNa0gsVUFBVSxHQUFHb0YsRUFBRSxDQUFGQSxLQUFuQixRQUFtQkEsQ0FBbkI7O0FBQ0EsUUFBSSxDQUFKLFlBQWlCO0FBQ2Y7QUFHRjs7QUFBQSxVQUFNQyxNQUFNLEdBQUlsSixLQUFELElBQW1CO0FBQ2hDLFVBQUk7QUFDRixlQUFPbUosa0JBQWtCLENBQXpCLEtBQXlCLENBQXpCO0FBQ0EsT0FGRixDQUVFLFVBQVU7QUFDVixjQUFNak8sR0FBOEIsR0FBRyxVQUF2Qyx3QkFBdUMsQ0FBdkM7QUFHQUEsV0FBRyxDQUFIQTtBQUNBO0FBRUg7QUFWRDs7QUFXQSxVQUFNNkUsTUFBa0QsR0FBeEQ7QUFFQTlELFVBQU0sQ0FBTkEscUJBQTZCbU4sUUFBRCxJQUFzQjtBQUNoRCxZQUFNQyxDQUFDLEdBQUdDLE1BQU0sQ0FBaEIsUUFBZ0IsQ0FBaEI7QUFDQSxZQUFNQyxDQUFDLEdBQUcxRixVQUFVLENBQUN3RixDQUFDLENBQXRCLEdBQW9CLENBQXBCOztBQUNBLFVBQUlFLENBQUMsS0FBTCxXQUFxQjtBQUNuQnhKLGNBQU0sQ0FBTkEsUUFBTSxDQUFOQSxHQUFtQixDQUFDd0osQ0FBQyxDQUFEQSxRQUFELEdBQUNBLENBQUQsR0FDZkEsQ0FBQyxDQUFEQSxlQUFrQjVPLEtBQUQsSUFBV3VPLE1BQU0sQ0FEbkIsS0FDbUIsQ0FBbENLLENBRGUsR0FFZkYsQ0FBQyxDQUFEQSxTQUNBLENBQUNILE1BQU0sQ0FEUEcsQ0FDTyxDQUFQLENBREFBLEdBRUFILE1BQU0sQ0FKVm5KLENBSVUsQ0FKVkE7QUFNSDtBQVZEOUQ7QUFXQTtBQTlCRjtBQWdDRCxDOzs7Ozs7Ozs7Ozs7Ozs7dUNDOUJEO0FBQ0E7O0FBQ0EsMEJBQWtDO0FBQ2hDLFNBQU91TixHQUFHLENBQUhBLGdDQUFQLE1BQU9BLENBQVA7QUFHRjs7QUFBQSwrQkFBdUM7QUFDckMsUUFBTXJKLFFBQVEsR0FBR0gsS0FBSyxDQUFMQSxtQkFBeUJBLEtBQUssQ0FBTEEsU0FBMUMsR0FBMENBLENBQTFDOztBQUNBLGdCQUFjO0FBQ1pBLFNBQUssR0FBR0EsS0FBSyxDQUFMQSxTQUFlLENBQXZCQSxDQUFRQSxDQUFSQTtBQUVGOztBQUFBLFFBQU1FLE1BQU0sR0FBR0YsS0FBSyxDQUFMQSxXQUFmLEtBQWVBLENBQWY7O0FBQ0EsY0FBWTtBQUNWQSxTQUFLLEdBQUdBLEtBQUssQ0FBTEEsTUFBUkEsQ0FBUUEsQ0FBUkE7QUFFRjs7QUFBQSxTQUFPO0FBQUVwRSxPQUFHLEVBQUw7QUFBQTtBQUFQO0FBQU8sR0FBUDtBQUdLOztBQUFBLHdDQU9MO0FBQ0EsUUFBTTZOLFFBQVEsR0FBRyxDQUFDQyxlQUFlLENBQWZBLHNCQUFELG9CQUFqQixHQUFpQixDQUFqQjtBQUlBLFFBQU1KLE1BQXNDLEdBQTVDO0FBQ0EsTUFBSUssVUFBVSxHQUFkO0FBQ0EsUUFBTUMsa0JBQWtCLEdBQUdILFFBQVEsQ0FBUkEsSUFDbkJwRCxPQUFELElBQWE7QUFDaEIsUUFBSUEsT0FBTyxDQUFQQSxtQkFBMkJBLE9BQU8sQ0FBUEEsU0FBL0IsR0FBK0JBLENBQS9CLEVBQXNEO0FBQ3BELFlBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUE0QndELGNBQWMsQ0FBQ3hELE9BQU8sQ0FBUEEsU0FBaUIsQ0FBbEUsQ0FBaURBLENBQUQsQ0FBaEQ7QUFDQWlELFlBQU0sQ0FBTkEsR0FBTSxDQUFOQSxHQUFjO0FBQUVRLFdBQUcsRUFBRUgsVUFBUDtBQUFBO0FBQWRMO0FBQWMsT0FBZEE7QUFDQSxhQUFPcEosTUFBTSxHQUFJQyxRQUFRLG1CQUFaLFdBQWI7QUFIRixXQUlPO0FBQ0wsYUFBUSxJQUFHNEosV0FBVyxTQUF0QjtBQUVIO0FBVHdCTixVQUEzQixFQUEyQkEsQ0FBM0IsQ0FQQSxDQW1CQTtBQUNBOztBQUNBLFlBQW1DO0FBQ2pDLFFBQUlPLGdCQUFnQixHQUFwQjtBQUNBLFFBQUlDLGtCQUFrQixHQUF0QixFQUZpQyxDQUlqQzs7QUFDQSxVQUFNQyxlQUFlLEdBQUcsTUFBTTtBQUM1QixVQUFJQyxRQUFRLEdBQVo7O0FBRUEsV0FBSyxJQUFJeFYsQ0FBQyxHQUFWLEdBQWdCQSxDQUFDLEdBQWpCLG9CQUF3Q0EsQ0FBeEMsSUFBNkM7QUFDM0N3VixnQkFBUSxJQUFJdEQsTUFBTSxDQUFOQSxhQUFac0QsZ0JBQVl0RCxDQUFac0Q7QUFDQUgsd0JBQWdCOztBQUVoQixZQUFJQSxnQkFBZ0IsR0FBcEIsS0FBNEI7QUFDMUJDLDRCQUFrQjtBQUNsQkQsMEJBQWdCLEdBQWhCQTtBQUVIO0FBQ0Q7O0FBQUE7QUFaRjs7QUFlQSxVQUFNSSxTQUFzQyxHQUE1QztBQUVBLFFBQUlDLHVCQUF1QixHQUFHWixRQUFRLENBQVJBLElBQ3RCcEQsT0FBRCxJQUFhO0FBQ2hCLFVBQUlBLE9BQU8sQ0FBUEEsbUJBQTJCQSxPQUFPLENBQVBBLFNBQS9CLEdBQStCQSxDQUEvQixFQUFzRDtBQUNwRCxjQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFBNEJ3RCxjQUFjLENBQUN4RCxPQUFPLENBQVBBLFNBQWlCLENBQWxFLENBQWlEQSxDQUFELENBQWhELENBRG9ELENBRXBEO0FBQ0E7O0FBQ0EsWUFBSWlFLFVBQVUsR0FBRzFPLEdBQUcsQ0FBSEEsZUFBakIsRUFBaUJBLENBQWpCO0FBQ0EsWUFBSTJPLFVBQVUsR0FBZCxNQUxvRCxDQU9wRDtBQUNBOztBQUNBLFlBQUlELFVBQVUsQ0FBVkEsZ0JBQTJCQSxVQUFVLENBQVZBLFNBQS9CLElBQXVEO0FBQ3JEQyxvQkFBVSxHQUFWQTtBQUVGOztBQUFBLFlBQUksQ0FBQzVCLEtBQUssQ0FBQzZCLFFBQVEsQ0FBQ0YsVUFBVSxDQUFWQSxVQUFwQixDQUFvQkEsQ0FBRCxDQUFULENBQVYsRUFBK0M7QUFDN0NDLG9CQUFVLEdBQVZBO0FBR0Y7O0FBQUEsd0JBQWdCO0FBQ2RELG9CQUFVLEdBQUdKLGVBQWJJO0FBR0ZGOztBQUFBQSxpQkFBUyxDQUFUQSxVQUFTLENBQVRBO0FBQ0EsZUFBT2xLLE1BQU0sR0FDVEMsUUFBUSxHQUNMLFVBQVNtSyxVQURKLFlBRUwsT0FBTUEsVUFIQSxVQUlSLE9BQU1BLFVBSlg7QUFyQkYsYUEwQk87QUFDTCxlQUFRLElBQUdQLFdBQVcsU0FBdEI7QUFFSDtBQS9CMkJOLFlBQTlCLEVBQThCQSxDQUE5QjtBQWtDQSxXQUFPO0FBQ0xSLFFBQUUsRUFBRSxXQUFZLElBQUdXLGtCQURkLFNBQ0QsQ0FEQztBQUFBO0FBQUE7QUFJTGEsZ0JBQVUsRUFBRyxJQUFHSix1QkFKbEI7QUFBTyxLQUFQO0FBUUY7O0FBQUEsU0FBTztBQUNMcEIsTUFBRSxFQUFFLFdBQVksSUFBR1csa0JBRGQsU0FDRCxDQURDO0FBQVA7QUFBTyxHQUFQO0FBSUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEhEO0FBeVFBOzs7OztBQUdPLHNCQUVGO0FBQ0gsTUFBSWMsSUFBSSxHQUFSO0FBQ0E7QUFFQSxTQUFRLENBQUMsR0FBRCxTQUFvQjtBQUMxQixRQUFJLENBQUosTUFBVztBQUNUQSxVQUFJLEdBQUpBO0FBQ0F2VCxZQUFNLEdBQUcwTyxFQUFFLENBQUMsR0FBWjFPLElBQVcsQ0FBWEE7QUFFRjs7QUFBQTtBQUxGO0FBU0s7O0FBQUEsNkJBQTZCO0FBQ2xDLFFBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUErQjdDLE1BQU0sQ0FBM0M7QUFDQSxTQUFRLEdBQUVrUyxRQUFTLEtBQUlJLFFBQVMsR0FBRStELElBQUksR0FBRyxNQUFILE9BQWdCLEVBQXREO0FBR0s7O0FBQUEsa0JBQWtCO0FBQ3ZCLFFBQU07QUFBQTtBQUFBLE1BQVdyVyxNQUFNLENBQXZCO0FBQ0EsUUFBTTRTLE1BQU0sR0FBRzBELGlCQUFmO0FBQ0EsU0FBT3pQLElBQUksQ0FBSkEsVUFBZStMLE1BQU0sQ0FBNUIsTUFBTy9MLENBQVA7QUFHSzs7QUFBQSxtQ0FBd0Q7QUFDN0QsU0FBTyw0Q0FFSDdNLFNBQVMsQ0FBVEEsZUFBeUJBLFNBQVMsQ0FBbENBLFFBRko7QUFLSzs7QUFBQSx3QkFBd0M7QUFDN0MsU0FBT3ZDLEdBQUcsQ0FBSEEsWUFBZ0JBLEdBQUcsQ0FBMUI7QUFHSzs7QUFBQSw2Q0FJa0Q7QUFDdkQsWUFBMkM7QUFBQTs7QUFDekMsMEJBQUk4ZSxHQUFHLENBQVAsOEJBQUlBLGVBQUosaUJBQW9DO0FBQ2xDLFlBQU10TSxPQUFPLEdBQUksSUFBR3VNLGNBQWMsS0FBbEM7QUFHQSxZQUFNLFVBQU4sT0FBTSxDQUFOO0FBRUg7QUFDRCxHQVR1RCxDQVN2RDs7O0FBQ0EsUUFBTS9lLEdBQUcsR0FBR21hLEdBQUcsQ0FBSEEsT0FBWUEsR0FBRyxDQUFIQSxPQUFXQSxHQUFHLENBQUhBLElBQW5DOztBQUVBLE1BQUksQ0FBQzJFLEdBQUcsQ0FBUixpQkFBMEI7QUFDeEIsUUFBSTNFLEdBQUcsQ0FBSEEsT0FBV0EsR0FBRyxDQUFsQixXQUE4QjtBQUM1QjtBQUNBLGFBQU87QUFDTDZFLGlCQUFTLEVBQUUsTUFBTUMsbUJBQW1CLENBQUM5RSxHQUFHLENBQUosV0FBZ0JBLEdBQUcsQ0FEekQsR0FDc0M7QUFEL0IsT0FBUDtBQUlGOztBQUFBO0FBR0Y7O0FBQUEsUUFBTXpYLEtBQUssR0FBRyxNQUFNb2MsR0FBRyxDQUFIQSxnQkFBcEIsR0FBb0JBLENBQXBCOztBQUVBLE1BQUk5ZSxHQUFHLElBQUlrZixTQUFTLENBQXBCLEdBQW9CLENBQXBCLEVBQTJCO0FBQ3pCO0FBR0Y7O0FBQUEsTUFBSSxDQUFKLE9BQVk7QUFDVixVQUFNMU0sT0FBTyxHQUFJLElBQUd1TSxjQUFjLEtBRWhDLCtEQUE4RHJjLEtBRmhFO0FBR0EsVUFBTSxVQUFOLE9BQU0sQ0FBTjtBQUdGOztBQUFBLFlBQTJDO0FBQ3pDLFFBQUl3TixNQUFNLENBQU5BLDRCQUFtQyxDQUFDaUssR0FBRyxDQUEzQyxLQUFpRDtBQUMvQ3RPLGFBQU8sQ0FBUEEsS0FDRyxHQUFFa1QsY0FBYyxLQURuQmxUO0FBTUg7QUFFRDs7QUFBQTtBQUdLOztBQUFBLE1BQU1zVCxhQUFhLEdBQUcsd0dBQXRCLFNBQXNCLENBQXRCOzs7QUFlQSxtQ0FBc0Q7QUFDM0QsWUFBNEM7QUFDMUMsUUFBSWhjLEdBQUcsS0FBSEEsUUFBZ0IsZUFBcEIsVUFBNkM7QUFDM0MrTSxZQUFNLENBQU5BLGtCQUEwQkwsR0FBRCxJQUFTO0FBQ2hDLFlBQUlzUCxhQUFhLENBQWJBLGlCQUErQixDQUFuQyxHQUF1QztBQUNyQ3RULGlCQUFPLENBQVBBLEtBQ0cscURBQW9EZ0UsR0FEdkRoRTtBQUlIO0FBTkRxRTtBQVFIO0FBRUQ7O0FBQUEsU0FBTywwQkFBUCxHQUFPLENBQVA7QUFHSzs7QUFBQSxNQUFNa1AsRUFBRSxHQUFHLHVCQUFYOztBQUNBLE1BQU1sSSxFQUFFLEdBQ2JrSSxFQUFFLElBQ0YsT0FBT2pJLFdBQVcsQ0FBbEIsU0FEQWlJLGNBRUEsT0FBT2pJLFdBQVcsQ0FBbEIsWUFISzs7Ozs7Ozs7Ozs7OztBQ3hZTSx3QkFBd0IsMENBQTBDLGdEQUFnRCxnQ0FBZ0MsZ0NBQWdDLG1DQUFtQyw0QkFBNEIsK0JBQStCLG9CQUFvQix5QkFBeUIsVUFBVTtBQUNwVixpRDs7Ozs7Ozs7Ozs7QUNEQSxpQkFBaUIsbUJBQU8sQ0FBQyxtRUFBb0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1rSSxJQUFOLFNBQW1CdGEsNENBQUssQ0FBQ3hDLFNBQXpCLENBQW1DO0FBQ2pDLFNBQU8yRixlQUFQLENBQXVCO0FBQUVFLE9BQUY7QUFBTzZDLFNBQVA7QUFBY3FVO0FBQWQsR0FBdkIsRUFBaUQ7QUFDL0MsV0FBTzVGLE9BQU8sQ0FBQ3pHLEdBQVIsQ0FBWSxDQUNqQmhJLEtBQUssQ0FBQ3RMLFFBQU4sQ0FBZWUsd0VBQVUsRUFBekIsQ0FEaUIsRUFFakJ1SyxLQUFLLENBQUN0TCxRQUFOLENBQWV1Qyx3RUFBVSxFQUF6QixDQUZpQixFQUdqQitJLEtBQUssQ0FBQ3RMLFFBQU4sQ0FBZUQsb0ZBQW1CLEVBQWxDLENBSGlCLENBQVosQ0FBUDtBQUtEOztBQUNEOEMsUUFBTSxHQUFHO0FBQ1AsV0FDRSxNQUFDLCtEQUFELFFBQ0csS0FBS0UsS0FBTCxDQUFXNmMsT0FBWCxDQUFtQnhnQixLQUFuQixHQUNDLE1BQUMsK0RBQUQ7QUFDRSxXQUFLLEVBQUUsS0FBSzJELEtBQUwsQ0FBVzZjLE9BQVgsQ0FBbUJ4Z0IsS0FENUI7QUFFRSxVQUFJLEVBQUUsS0FBSzJELEtBQUwsQ0FBVzZjLE9BQVgsQ0FBbUJ2Z0IsSUFGM0I7QUFHRSxjQUFRLEVBQUUsS0FBSzBELEtBQUwsQ0FBVzZjLE9BQVgsQ0FBbUJ0Z0I7QUFIL0IsTUFERCxHQU1HLElBUE4sRUFRRTtBQUFBLDBDQUFlO0FBQWY7QUFBQTtBQUFBLGswR0FTRTtBQUFLLFdBQUssRUFBRTtBQUFFNEcsYUFBSyxFQUFFO0FBQVQsT0FBWjtBQUFBO0FBQUEsT0FDRSxNQUFDLDBEQUFEO0FBQU8sV0FBSyxFQUFFLEtBQUtuRCxLQUFMLENBQVdyQyxLQUF6QjtBQUFnQyxhQUFPLEVBQUUsS0FBS3FDLEtBQUwsQ0FBVzREO0FBQXBELE1BREYsRUFFRyxLQUFLNUQsS0FBTCxDQUFXNEQsT0FBWCxDQUFtQnRILElBQW5CLEtBQTRCLElBQTVCLEdBQW1DLE1BQUMsK0RBQUQsT0FBbkMsR0FBb0QsSUFGdkQsRUFHRyxLQUFLMEQsS0FBTCxDQUFXNEQsT0FBWCxDQUFtQnRILElBQW5CLEtBQTRCLElBQTVCLEdBQW1DLE1BQUMsNERBQUQsT0FBbkMsR0FBaUQsSUFIcEQsQ0FURixFQWNFO0FBQUssV0FBSyxFQUFFO0FBQUU2RyxhQUFLLEVBQUUsTUFBVDtBQUFpQmlDLGFBQUssRUFBRTtBQUF4QixPQUFaO0FBQUE7QUFBQSxPQUNFLE1BQUMseURBQUQ7QUFBTyxXQUFLLEVBQUUsS0FBS3BGLEtBQUwsQ0FBV1Q7QUFBekIsTUFERixDQWRGLENBUkYsQ0FERjtBQTZCRDs7QUF0Q2dDOztBQXlDbkMsTUFBTTBDLGVBQWUsR0FBR2QsS0FBSyxLQUFLO0FBQ2hDMGIsU0FBTyxFQUFFMWIsS0FBSyxDQUFDMkMsUUFEaUI7QUFFaENuRyxPQUFLLEVBQUV3RCxLQUFLLENBQUN4RCxLQUZtQjtBQUdoQzRCLE9BQUssRUFBRTRCLEtBQUssQ0FBQzVCLEtBSG1CO0FBSWhDcUUsU0FBTyxFQUFFekMsS0FBSyxDQUFDeUM7QUFKaUIsQ0FBTCxDQUE3Qjs7QUFPZWtaLHdIQUFTLENBQUNDLHNEQUFELEVBQVk5YSxlQUFaLEVBQTZCLElBQTdCLENBQVQsQ0FBNENzRCx5RUFBWSxDQUFDb1gsSUFBRCxDQUF4RCxDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoRUE7QUFNQSxNQUFNSyxZQUFZLEdBQUc7QUFDbkJ4YSxZQUFVLEVBQUUsS0FETztBQUVuQjVFLE1BQUksRUFBRTtBQUZhLENBQXJCO0FBS2UsZ0VBQUN1RCxLQUFELEVBQVFzSCxNQUFSLEtBQW1CO0FBQ2hDLFVBQVFBLE1BQU0sQ0FBQ2pOLElBQWY7QUFDRSxTQUFLRSw4RUFBTDtBQUNFLDZDQUNLeUYsS0FETDtBQUVFcUIsa0JBQVUsRUFBRTtBQUZkOztBQUlGLFNBQUt5RixzRkFBTDtBQUNFLDZDQUNLOUcsS0FETDtBQUVFcUIsa0JBQVUsRUFBRSxLQUZkO0FBR0U1RSxZQUFJLEVBQUU2SyxNQUFNLENBQUM3TTtBQUhmOztBQUtGLFNBQUtzTSxvRkFBTDtBQUNFLGFBQU84VSxZQUFQOztBQUNGO0FBQ0UsYUFBTzdiLEtBQUssR0FBR0EsS0FBSCxHQUFXNmIsWUFBdkI7QUFmSjtBQWlCRCxDQWxCRDtBQW9CTyxNQUFNQyxhQUFhLEdBQUc5YixLQUFLLElBQUk7QUFDcEMsU0FBT0EsS0FBSyxDQUFDcUIsVUFBYjtBQUNELENBRk07QUFJQSxNQUFNTSxVQUFVLEdBQUczQixLQUFLLElBQUk7QUFDakMsU0FBT0EsS0FBSyxDQUFDdkQsSUFBYjtBQUNELENBRk0sQzs7Ozs7Ozs7Ozs7O0FDbkNQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRU8sTUFBTXNmLFFBQVEsR0FBRyxNQUN0QkMsNkRBQWUsQ0FBQztBQUNkeGYsT0FBSyxFQUFFeWYsOERBRE87QUFFZHRaLFVBQVEsRUFBRXVaLGlFQUZJO0FBR2R6WixTQUFPLEVBQUUwWixnRUFISztBQUlkL2QsT0FBSyxFQUFFZ2UsOERBSk87QUFLZGxjLFFBQU0sRUFBRW1jLCtEQUxNO0FBTWRqYixTQUFPLEVBQUVrYixnRUFBY0E7QUFOVCxDQUFELENBRFY7QUFVQSxNQUFNM2EsVUFBVSxHQUFHM0IsS0FBSyxJQUFJdWMsbUVBQUEsQ0FBdUJ2YyxLQUFLLENBQUNvQixPQUE3QixDQUE1QjtBQUVBLE1BQU1NLG9CQUFvQixHQUFHMUIsS0FBSyxJQUFJdWMsc0VBQUEsQ0FBMEJ2YyxLQUFLLENBQUNvQixPQUFoQyxDQUF0QyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3JCUDtBQVNBLE1BQU15YSxZQUFZLEdBQUc7QUFDbkJuWixPQUFLLEVBQUU7QUFEWSxDQUFyQjtBQUllLGdFQUFDMUMsS0FBRCxFQUFRc0gsTUFBUixLQUFtQjtBQUNoQyxVQUFRQSxNQUFNLENBQUNqTixJQUFmO0FBQ0UsU0FBS2dNLG9GQUFMO0FBQ0UsNkNBQ0tyRyxLQURMO0FBRUU5RSxhQUFLLEVBQUVvTSxNQUFNLENBQUMxTCxjQUFQLENBQXNCVixLQUYvQjtBQUdFQyxZQUFJLEVBQUVtTSxNQUFNLENBQUMxTCxjQUFQLENBQXNCVCxJQUg5QjtBQUlFQyxnQkFBUSxFQUFFO0FBSlo7O0FBTUYsU0FBS3lMLHlFQUFMO0FBQ0UsNkNBQ0s3RyxLQURMO0FBRUU5RSxhQUFLLEVBQUVvTSxNQUFNLENBQUNwTSxLQUZoQjtBQUdFQyxZQUFJLEVBQUVtTSxNQUFNLENBQUNuTSxJQUhmO0FBSUVDLGdCQUFRLEVBQUVrTSxNQUFNLENBQUNsTSxRQUpuQjtBQUtFOE0saUJBQVMsRUFBRSxJQUFJakYsSUFBSjtBQUxiOztBQU9GLFNBQUsyRCx5RUFBTDtBQUNFLDZDQUNLNUcsS0FETDtBQUVFOUUsYUFBSyxFQUFFb00sTUFBTSxDQUFDcE0sS0FGaEI7QUFHRUMsWUFBSSxFQUFFbU0sTUFBTSxDQUFDbk0sSUFIZjtBQUlFQyxnQkFBUSxFQUFFa00sTUFBTSxDQUFDbE0sUUFKbkI7QUFLRThNLGlCQUFTLEVBQUUsSUFBSWpGLElBQUo7QUFMYjs7QUFPRixTQUFLdEcsa0VBQUw7QUFBa0I7QUFDaEIsZUFBT2tmLFlBQVA7QUFDRDs7QUFDRCxTQUFLcmdCLG9FQUFMO0FBQ0UsNkNBQVl3RSxLQUFaO0FBQW1CMEMsYUFBSyxFQUFFO0FBQTFCOztBQUNGLFNBQUtoSCxzRUFBTDtBQUNFLDZDQUFZc0UsS0FBWjtBQUFtQjBDLGFBQUssRUFBRTtBQUExQjs7QUFDRjtBQUNFLGFBQU8xQyxLQUFLLEdBQUdBLEtBQUgsR0FBVzZiLFlBQXZCO0FBaENKO0FBa0NELENBbkNELEU7Ozs7Ozs7Ozs7OztBQ2JBO0FBQUE7QUFBQTtBQUVBLE1BQU1BLFlBQVksR0FBRyxFQUFyQjtBQUVlLGdFQUFDN2IsS0FBRCxFQUFRc0gsTUFBUixLQUFtQjtBQUNoQyxVQUFRQSxNQUFNLENBQUNqTixJQUFmO0FBQ0UsU0FBSzBMLG1FQUFMO0FBQ0UsYUFBT3VCLE1BQU0sQ0FBQzdLLElBQWQ7O0FBQ0Y7QUFDRSxhQUFPdUQsS0FBSyxHQUFHQSxLQUFILEdBQVc2YixZQUF2QjtBQUpKO0FBTUQsQ0FQRCxFOzs7Ozs7Ozs7Ozs7QUNKQTtBQUFBO0FBQUE7QUFFQSxNQUFNQSxZQUFZLEdBQUcsRUFBckI7QUFFZSxnRUFBQzdiLEtBQUQsRUFBUXNILE1BQVIsS0FBbUI7QUFDaEMsVUFBUUEsTUFBTSxDQUFDak4sSUFBZjtBQUNFLFNBQUs0TCxvRUFBTDtBQUNFLGFBQU87QUFBRWxKLGFBQUssRUFBRXVLLE1BQU0sQ0FBQ3ZLO0FBQWhCLE9BQVA7O0FBQ0YsU0FBS21KLDRFQUFMO0FBQ0UsVUFBSWxHLEtBQUssQ0FBQ2pELEtBQU4sS0FBZ0J1SyxNQUFNLENBQUN2SyxLQUEzQixFQUFrQztBQUNoQyxlQUFPO0FBQ0xBLGVBQUssRUFBRXVLLE1BQU0sQ0FBQ3ZLLEtBRFQ7QUFFTEUsaUJBQU8sRUFBRXFLLE1BQU0sQ0FBQ3JLO0FBRlgsU0FBUDtBQUlELE9BTEQsTUFLTztBQUNMLGVBQU8rQyxLQUFQO0FBQ0Q7O0FBQ0gsU0FBSzdDLDBFQUFMO0FBQ0UsYUFBTzBlLFlBQVA7O0FBRUY7QUFDRSxhQUFPN2IsS0FBSyxHQUFHQSxLQUFILEdBQVc2YixZQUF2QjtBQWhCSjtBQWtCRCxDQW5CRCxFOzs7Ozs7Ozs7Ozs7QUNKQTtBQUFBO0FBQUE7QUFFQSxNQUFNQSxZQUFZLEdBQUc7QUFDbkJoZSxlQUFhLEVBQUUsSUFESTtBQUNFO0FBQ3JCMUMsTUFBSSxFQUFFO0FBRmEsQ0FBckI7QUFLZSxnRUFBQzZFLEtBQUQsRUFBUXNILE1BQVIsS0FBbUI7QUFDaEMsVUFBUUEsTUFBTSxDQUFDak4sSUFBZjtBQUNFLFNBQUtrRCwyREFBTDtBQUNFLGlCQUFxQixFQUFyQixNQVNPO0FBQ0wsZUFBT3lDLEtBQVA7QUFDRDs7QUFDSCxTQUFLeUcsMkVBQUw7QUFDRSxhQUFPNEYsTUFBTSxDQUFDbVEsTUFBUCxDQUFjLEVBQWQsRUFBa0J4YyxLQUFsQixFQUF5QjtBQUFFL0Isb0JBQVksRUFBRXFKLE1BQU0sQ0FBQ3JKO0FBQXZCLE9BQXpCLENBQVA7O0FBQ0YsU0FBS04sb0VBQUw7QUFDRSxVQUFJMkosTUFBTSxDQUFDekosYUFBWCxFQUEwQjtBQUN4QixlQUFPd08sTUFBTSxDQUFDbVEsTUFBUCxDQUFjLEVBQWQsRUFBa0J4YyxLQUFsQixFQUF5QjtBQUM5Qm5DLHVCQUFhLEVBQUV5SixNQUFNLENBQUN6SjtBQURRLFNBQXpCLENBQVA7QUFHRDs7QUFDRCxhQUFPbUMsS0FBUDs7QUFDRixTQUFLMEcsMEVBQUw7QUFDRSxhQUFPMkYsTUFBTSxDQUFDbVEsTUFBUCxDQUFjLEVBQWQsRUFBa0J4YyxLQUFsQixFQUF5QjtBQUFFN0UsWUFBSSxFQUFFbU0sTUFBTSxDQUFDbk07QUFBZixPQUF6QixDQUFQOztBQUNGO0FBQ0UsYUFBTzZFLEtBQUssR0FBR0EsS0FBSCxHQUFXNmIsWUFBdkI7QUExQko7QUE0QkQsQ0E3QkQsRTs7Ozs7Ozs7Ozs7O0FDUEE7QUFBQTtBQUFBO0FBRUEsTUFBTUEsWUFBWSxHQUFHLENBQ25CO0FBQ0V2ZixJQUFFLEVBQUUsV0FETjtBQUVFaUQsTUFBSSxFQUFFO0FBRlIsQ0FEbUIsRUFLbkI7QUFDRWpELElBQUUsRUFBRSxXQUROO0FBRUVpRCxNQUFJLEVBQUU7QUFGUixDQUxtQixFQVNuQjtBQUNFakQsSUFBRSxFQUFFLFdBRE47QUFFRWlELE1BQUksRUFBRTtBQUZSLENBVG1CLENBQXJCO0FBZWUsZ0VBQUNTLEtBQUQsRUFBUXNILE1BQVIsS0FBbUI7QUFDaEMsVUFBUUEsTUFBTSxDQUFDak4sSUFBZjtBQUNFLFNBQUtpTSxtRUFBTDtBQUNFLGFBQU9nQixNQUFNLENBQUM3SyxJQUFkOztBQUNGO0FBQ0UsYUFBT3VELEtBQUssR0FBR0EsS0FBSCxHQUFXNmIsWUFBdkI7QUFKSjtBQU1ELENBUEQsRTs7Ozs7Ozs7Ozs7O0FDakJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRU8sTUFBTUQsU0FBUyxHQUFHLENBQUNDLFlBQVksR0FBRyxFQUFoQixLQUF1QjtBQUM5QyxRQUFNelUsS0FBSyxHQUFHcVYseURBQVcsQ0FDdkJWLDBEQUFRLEVBRGUsRUFFdkJGLFlBRnVCLEVBR3ZCYSw2REFBZSxDQUNiQyxrREFEYSxFQUViQyxzRUFGYSxFQUdidlMsOEVBSGEsRUFJYndTLHVFQUphLEVBS2JDLHNFQUxhLEVBTWJDLHFFQU5hLEVBT2JDLHFFQVBhLENBSFEsQ0FBekI7QUFhQUMsK0VBQXVCLENBQUM3VixLQUFELENBQXZCO0FBQ0FBLE9BQUssQ0FBQ3RMLFFBQU4sQ0FBZXdCLG9FQUFJLEVBQW5CO0FBQ0EsU0FBTzhKLEtBQVA7QUFDRCxDQWpCTSxDOzs7Ozs7Ozs7OztBQ2ZQLCtDOzs7Ozs7Ozs7OztBQ0FBLCtDOzs7Ozs7Ozs7OztBQ0FBLHNDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLHVDOzs7Ozs7Ozs7OztBQ0FBLHFDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLDZDOzs7Ozs7Ozs7OztBQ0FBLDZDIiwiZmlsZSI6InBhZ2VzL2luZGV4LmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSByZXF1aXJlKCcuLi9zc3ItbW9kdWxlLWNhY2hlLmpzJyk7XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdHZhciB0aHJldyA9IHRydWU7XG4gXHRcdHRyeSB7XG4gXHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG4gXHRcdFx0dGhyZXcgPSBmYWxzZTtcbiBcdFx0fSBmaW5hbGx5IHtcbiBcdFx0XHRpZih0aHJldykgZGVsZXRlIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHR9XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9wYWdlcy9pbmRleC5qc1wiKTtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvcm91dGVyLWNvbnRleHQuanNcIik7IiwiaW1wb3J0ICogYXMgdHlwZXMgZnJvbSAnLi4vY29uc3RhbnRzL0FjdGlvblR5cGVzJztcclxuXHJcbmV4cG9ydCBjb25zdCBmZXRjaEF2YWlsYWJsZURldmljZXMgPSAoKSA9PiAoe1xyXG4gIHR5cGU6IHR5cGVzLkZFVENIX0FWQUlMQUJMRV9ERVZJQ0VTXHJcbn0pO1xyXG5leHBvcnQgY29uc3QgZmV0Y2hBdmFpbGFibGVEZXZpY2VzU3VjY2VzcyA9IGxpc3QgPT4gKHtcclxuICB0eXBlOiB0eXBlcy5GRVRDSF9BVkFJTEFCTEVfREVWSUNFU19TVUNDRVNTLFxyXG4gIGxpc3RcclxufSk7XHJcbmV4cG9ydCBjb25zdCBmZXRjaEF2YWlsYWJsZURldmljZXNFcnJvciA9IGVycm9yID0+ICh7XHJcbiAgdHlwZTogdHlwZXMuRkVUQ0hfQVZBSUxBQkxFX0RFVklDRVNfRVJST1IsXHJcbiAgZXJyb3JcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3QgdHJhbnNmZXJQbGF5YmFja1RvRGV2aWNlID0gZGV2aWNlSWQgPT4gKHtcclxuICB0eXBlOiB0eXBlcy5UUkFOU0ZFUl9QTEFZQkFDS19UT19ERVZJQ0UsXHJcbiAgZGV2aWNlSWRcclxufSk7XHJcbmV4cG9ydCBjb25zdCB0cmFuc2ZlclBsYXliYWNrVG9EZXZpY2VTdWNjZXNzID0gbGlzdCA9PiAoe1xyXG4gIHR5cGU6IHR5cGVzLlRSQU5TRkVSX1BMQVlCQUNLX1RPX0RFVklDRV9TVUNDRVNTXHJcbn0pO1xyXG5leHBvcnQgY29uc3QgdHJhbnNmZXJQbGF5YmFja1RvRGV2aWNlRXJyb3IgPSBsaXN0ID0+ICh7XHJcbiAgdHlwZTogdHlwZXMuVFJBTlNGRVJfUExBWUJBQ0tfVE9fREVWSUNFX0VSUk9SLFxyXG4gIGVycm9yXHJcbn0pO1xyXG4iLCJpbXBvcnQgZmV0Y2ggZnJvbSAnaXNvbW9ycGhpYy11bmZldGNoJztcclxuXHJcbmltcG9ydCBDb25maWcgZnJvbSAnLi4vY29uZmlnL2FwcCc7XHJcbmltcG9ydCAqIGFzIHR5cGVzIGZyb20gJy4uL2NvbnN0YW50cy9BY3Rpb25UeXBlcyc7XHJcblxyXG4vLyBwbGF5YmFja1xyXG5leHBvcnQgY29uc3QgcGxheVRyYWNrID0gKHRyYWNrLCB1c2VyLCBwb3NpdGlvbikgPT4gKHtcclxuICB0eXBlOiB0eXBlcy5QTEFZX1RSQUNLLFxyXG4gIHRyYWNrLFxyXG4gIHVzZXIsXHJcbiAgcG9zaXRpb25cclxufSk7XHJcbmV4cG9ydCBjb25zdCB1cGRhdGVOb3dQbGF5aW5nID0gKHRyYWNrLCB1c2VyLCBwb3NpdGlvbikgPT4gKHtcclxuICB0eXBlOiB0eXBlcy5VUERBVEVfTk9XX1BMQVlJTkcsXHJcbiAgdHJhY2ssXHJcbiAgdXNlcixcclxuICBwb3NpdGlvblxyXG59KTtcclxuZXhwb3J0IGNvbnN0IHBsYXlUcmFja1N1Y2Nlc3MgPSAodHJhY2ssIHVzZXIsIHBvc2l0aW9uKSA9PiAoe1xyXG4gIHR5cGU6IHR5cGVzLlBMQVlfVFJBQ0tfU1VDQ0VTUyxcclxuICB0cmFjayxcclxuICB1c2VyLFxyXG4gIHBvc2l0aW9uXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IG11dGVQbGF5YmFjayA9ICgpID0+ICh7IHR5cGU6IHR5cGVzLk1VVEVfUExBWUJBQ0sgfSk7XHJcbmV4cG9ydCBjb25zdCB1bm11dGVQbGF5YmFjayA9ICgpID0+ICh7IHR5cGU6IHR5cGVzLlVOTVVURV9QTEFZQkFDSyB9KTtcclxuXHJcbmV4cG9ydCBjb25zdCBmZXRjaFBsYXlpbmdDb250ZXh0U3VjY2VzcyA9IHBsYXlpbmdDb250ZXh0ID0+ICh7XHJcbiAgdHlwZTogdHlwZXMuRkVUQ0hfUExBWUlOR19DT05URVhUX1NVQ0NFU1MsXHJcbiAgcGxheWluZ0NvbnRleHRcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3QgZmV0Y2hQbGF5aW5nQ29udGV4dCA9ICgpID0+IGRpc3BhdGNoID0+XHJcbiAgZmV0Y2goYCR7Q29uZmlnLkhPU1R9L2FwaS9ub3ctcGxheWluZ2ApXHJcbiAgICAudGhlbihyZXMgPT4gcmVzLmpzb24oKSlcclxuICAgIC50aGVuKHJlcyA9PiBkaXNwYXRjaChmZXRjaFBsYXlpbmdDb250ZXh0U3VjY2VzcyhyZXMpKSk7XHJcbiIsImltcG9ydCBmZXRjaCBmcm9tICdpc29tb3JwaGljLXVuZmV0Y2gnO1xyXG5cclxuaW1wb3J0IENvbmZpZyBmcm9tICcuLi9jb25maWcvYXBwJztcclxuaW1wb3J0ICogYXMgdHlwZXMgZnJvbSAnLi4vY29uc3RhbnRzL0FjdGlvblR5cGVzJztcclxuXHJcbmV4cG9ydCBjb25zdCBxdWV1ZVRyYWNrID0gaWQgPT4gKHsgdHlwZTogdHlwZXMuUVVFVUVfVFJBQ0ssIGlkIH0pO1xyXG5leHBvcnQgY29uc3QgdXBkYXRlUXVldWUgPSBxdWV1ZSA9PiAoeyB0eXBlOiB0eXBlcy5VUERBVEVfUVVFVUUsIGRhdGE6IHF1ZXVlIH0pO1xyXG5leHBvcnQgY29uc3QgcXVldWVFbmRlZCA9ICgpID0+ICh7IHR5cGU6IHR5cGVzLlFVRVVFX0VOREVEIH0pO1xyXG5leHBvcnQgY29uc3QgcXVldWVSZW1vdmVUcmFjayA9IGlkID0+ICh7XHJcbiAgdHlwZTogdHlwZXMuUVVFVUVfUkVNT1ZFX1RSQUNLLFxyXG4gIGlkXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IGZldGNoUXVldWUgPSAoKSA9PiBkaXNwYXRjaCA9PlxyXG4gIGZldGNoKGAke0NvbmZpZy5IT1NUfS9hcGkvcXVldWVgKS50aGVuKHJlcyA9PiByZXMuanNvbigpKS50aGVuKHJlcyA9PiBkaXNwYXRjaCh1cGRhdGVRdWV1ZShyZXMpKSk7XHJcbiIsImltcG9ydCAqIGFzIHR5cGVzIGZyb20gJy4uL2NvbnN0YW50cy9BY3Rpb25UeXBlcyc7XHJcblxyXG5leHBvcnQgY29uc3Qgc2VhcmNoVHJhY2tzID0gcXVlcnkgPT4gKHsgdHlwZTogdHlwZXMuU0VBUkNIX1RSQUNLUywgcXVlcnkgfSk7XHJcbmV4cG9ydCBjb25zdCBzZWFyY2hUcmFja3NTdWNjZXNzID0gKHF1ZXJ5LCByZXN1bHRzKSA9PiAoe1xyXG4gIHR5cGU6IHR5cGVzLlNFQVJDSF9UUkFDS1NfU1VDQ0VTUyxcclxuICBxdWVyeSxcclxuICByZXN1bHRzXHJcbn0pO1xyXG5leHBvcnQgY29uc3Qgc2VhcmNoVHJhY2tzUmVzZXQgPSAoKSA9PiAoeyB0eXBlOiB0eXBlcy5TRUFSQ0hfVFJBQ0tTX1JFU0VUIH0pO1xyXG5leHBvcnQgY29uc3QgZmV0Y2hUcmFjayA9IGlkID0+ICh7IHR5cGU6IHR5cGVzLkZFVENIX1RSQUNLLCBpZCB9KTtcclxuZXhwb3J0IGNvbnN0IGZldGNoVHJhY2tTdWNjZXNzID0gKGlkLCB0cmFjaykgPT4gKHtcclxuICB0eXBlOiB0eXBlcy5GRVRDSF9UUkFDS19TVUNDRVNTLFxyXG4gIGlkXHJcbn0pO1xyXG4iLCJpbXBvcnQgKiBhcyB0eXBlcyBmcm9tICcuLi9jb25zdGFudHMvQWN0aW9uVHlwZXMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IGxvYWQgPSAoKSA9PiAoeyB0eXBlOiB0eXBlcy5MT0FEIH0pO1xyXG5leHBvcnQgY29uc3QgbG9naW4gPSAoKSA9PiAoeyB0eXBlOiB0eXBlcy5MT0dJTiB9KTtcclxuZXhwb3J0IGNvbnN0IGxvZ2luU3VjY2VzcyA9ICgpID0+ICh7XHJcbiAgdHlwZTogdHlwZXMuTE9HSU5fU1VDQ0VTU1xyXG59KTtcclxuZXhwb3J0IGNvbnN0IGxvZ2luRmFpbHVyZSA9IHJlZnJlc2hfdG9rZW4gPT4gKHtcclxuICB0eXBlOiB0eXBlcy5MT0dJTl9GQUlMVVJFLFxyXG4gIHJlZnJlc2hfdG9rZW5cclxufSk7XHJcbmV4cG9ydCBjb25zdCB1cGRhdGVUb2tlbiA9IHJlZnJlc2hUb2tlbiA9PiAoe1xyXG4gIHR5cGU6IHR5cGVzLlVQREFURV9UT0tFTixcclxuICByZWZyZXNoVG9rZW5cclxufSk7XHJcbmV4cG9ydCBjb25zdCB1cGRhdGVUb2tlblN1Y2Nlc3MgPSBhY2Nlc3NfdG9rZW4gPT4gKHtcclxuICB0eXBlOiB0eXBlcy5VUERBVEVfVE9LRU5fU1VDQ0VTUyxcclxuICBhY2Nlc3NfdG9rZW5cclxufSk7XHJcbmV4cG9ydCBjb25zdCB1cGRhdGVDdXJyZW50VXNlciA9IHVzZXIgPT4gKHtcclxuICB0eXBlOiB0eXBlcy5VUERBVEVfQ1VSUkVOVF9VU0VSLFxyXG4gIHVzZXJcclxufSk7XHJcbiIsImltcG9ydCBmZXRjaCBmcm9tICdpc29tb3JwaGljLXVuZmV0Y2gnO1xyXG5cclxuaW1wb3J0IENvbmZpZyBmcm9tICcuLi9jb25maWcvYXBwJztcclxuaW1wb3J0ICogYXMgdHlwZXMgZnJvbSAnLi4vY29uc3RhbnRzL0FjdGlvblR5cGVzJztcclxuXHJcbmV4cG9ydCBjb25zdCB1cGRhdGVVc2VycyA9IHVzZXJzID0+ICh7IHR5cGU6IHR5cGVzLlVQREFURV9VU0VSUywgZGF0YTogdXNlcnMgfSk7XHJcblxyXG5leHBvcnQgY29uc3QgZmV0Y2hVc2VycyA9ICgpID0+IGRpc3BhdGNoID0+XHJcbiAgZmV0Y2goYCR7Q29uZmlnLkhPU1R9L2FwaS91c2Vyc2ApLnRoZW4ocmVzID0+IHJlcy5qc29uKCkpLnRoZW4ocmVzID0+IGRpc3BhdGNoKHVwZGF0ZVVzZXJzKHJlcykpKTtcclxuIiwiaW1wb3J0ICogYXMgdHlwZXMgZnJvbSAnLi4vY29uc3RhbnRzL0FjdGlvblR5cGVzJztcclxuXHJcbmV4cG9ydCBjb25zdCB2b3RlVXAgPSBpZCA9PiAoe1xyXG4gIHR5cGU6IHR5cGVzLlZPVEVfVVAsXHJcbiAgaWRcclxufSk7XHJcblxyXG5leHBvcnQgY29uc3Qgdm90ZVVwU3VjY2VzcyA9ICgpID0+ICh7XHJcbiAgdHlwZTogdHlwZXMuVk9URV9VUF9TVUNDRVNTXHJcbn0pO1xyXG4iLCJpbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gJ3JlYWN0LXJlZHV4JztcbmltcG9ydCB7IGluamVjdEludGwgfSBmcm9tICdyZWFjdC1pbnRsJztcblxuaW1wb3J0IHsgc2VhcmNoVHJhY2tzLCBzZWFyY2hUcmFja3NSZXNldCB9IGZyb20gJy4uL2FjdGlvbnMvc2VhcmNoQWN0aW9ucyc7XG5pbXBvcnQgeyBxdWV1ZVRyYWNrIH0gZnJvbSAnLi4vYWN0aW9ucy9xdWV1ZUFjdGlvbnMnO1xuXG5jbGFzcyBSZXN1bHRzTGlzdCBleHRlbmRzIENvbXBvbmVudCB7XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IHJlc3VsdHMsIGZvY3VzIH0gPSB0aGlzLnByb3BzO1xuICAgIHJldHVybiAoXG4gICAgICA8dWwgY2xhc3NOYW1lPVwiYWRkLXRvLXF1ZXVlX19zZWFyY2gtcmVzdWx0c1wiPlxuICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgLmFkZC10by1xdWV1ZV9fc2VhcmNoLXJlc3VsdHMge1xuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgIzk5OTtcbiAgICAgICAgICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICAgIH1cbiAgICAgICAgICAuYWRkLXRvLXF1ZXVlX19zZWFyY2gtcmVzdWx0cy1pdGVtIHtcbiAgICAgICAgICAgIHBhZGRpbmc6IDVweCAwIDVweCA1cHg7XG4gICAgICAgICAgfVxuICAgICAgICAgIC5hZGQtdG8tcXVldWVfX3NlYXJjaC1yZXN1bHRzLWl0ZW0tLWZvY3VzZWQge1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICAgICAgICB9XG4gICAgICAgICAgLmNvbnRhaW5lciB7XG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICAgIH1cbiAgICAgICAgICAuYWxidW0taW1nIHtcbiAgICAgICAgICAgIHdpZHRoOiA2NDtcbiAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDFlbTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLmZsZXgtaXRlbSB7XG4gICAgICAgICAgICBmbGV4LWdyb3c6IDE7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLnNvbmctbmFtZSB7XG4gICAgICAgICAgICBmb250LXNpemU6IDEuM2VtO1xuICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMC4zZW07XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICAgIHtyZXN1bHRzLm1hcCgociwgaW5kZXgpID0+IHtcbiAgICAgICAgICBjb25zdCBpc0ZvY3VzZWQgPSBmb2N1cyA9PT0gaW5kZXg7XG4gICAgICAgICAgY29uc3QgY2xhc3NOYW1lID1cbiAgICAgICAgICAgICdhZGQtdG8tcXVldWVfX3NlYXJjaC1yZXN1bHRzLWl0ZW0nICsgKGlzRm9jdXNlZCA/ICcgYWRkLXRvLXF1ZXVlX19zZWFyY2gtcmVzdWx0cy1pdGVtLS1mb2N1c2VkJyA6ICcnKTtcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGxpIGtleT17ci5pZH0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IG9uQ2xpY2s9eygpID0+IHRoaXMucHJvcHMub25TZWxlY3Qoci5pZCl9PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWxidW0taW1nXCI+XG4gICAgICAgICAgICAgICAgICA8aW1nIHNyYz17ci5hbGJ1bS5pbWFnZXNbMl0udXJsfSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1pdGVtXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvbmctbmFtZVwiPntyLm5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PntyLmFydGlzdHNbMF0ubmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICk7XG4gICAgICAgIH0pfVxuICAgICAgPC91bD5cbiAgICApO1xuICB9XG59XG5cbmNsYXNzIEFkZFRvUXVldWUgZXh0ZW5kcyBDb21wb25lbnQge1xuICBzdGF0ZSA9IHtcbiAgICB0ZXh0OiB0aGlzLnByb3BzLnRleHQgfHwgJycsXG4gICAgZm9jdXM6IC0xXG4gIH07XG5cbiAgaGFuZGxlQ2hhbmdlID0gZSA9PiB7XG4gICAgY29uc3QgdGV4dCA9IGUudGFyZ2V0LnZhbHVlO1xuICAgIHRoaXMuc2V0U3RhdGUoeyB0ZXh0OiB0ZXh0IH0pO1xuICAgIGlmICh0ZXh0ICE9PSAnJykge1xuICAgICAgdGhpcy5wcm9wcy5zZWFyY2hUcmFja3ModGV4dCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuc2V0U3RhdGUoeyBmb2N1czogLTEgfSk7XG4gICAgICB0aGlzLnByb3BzLnNlYXJjaFRyYWNrc1Jlc2V0KCk7XG4gICAgfVxuICB9O1xuXG4gIGhhbmRsZVNlbGVjdEVsZW1lbnQgPSBpZCA9PiB7XG4gICAgdGhpcy5zZXRTdGF0ZSh7IHRleHQ6ICcnIH0pO1xuICAgIHRoaXMucHJvcHMucXVldWVUcmFjayhpZCk7XG4gICAgdGhpcy5wcm9wcy5zZWFyY2hUcmFja3NSZXNldCgpO1xuICB9O1xuXG4gIGhhbmRsZUJsdXIgPSBlID0+IHtcbiAgICAvLyB0b2RvOiB0aGlzIGhhcHBlbnMgYmVmb3JlIHRoZSBpdGVtIGZyb20gdGhlIGxpc3QgaXMgc2VsZWN0ZWQsIGhpZGluZyB0aGVcbiAgICAvLyBsaXN0IG9mIHJlc3VsdHMuIFdlIG5lZWQgdG8gZG8gdGhpcyBpbiBhIGRpZmZlcmVudCB3YXkuXG4gICAgLyogICAgdGhpcy5zZXRTdGF0ZSh7IGZvY3VzOiAtMSB9KTtcbiAgICB0aGlzLnByb3BzLnNlYXJjaFRyYWNrc1Jlc2V0KCk7ICovXG4gIH07XG5cbiAgaGFuZGxlRm9jdXMgPSBlID0+IHtcbiAgICBpZiAoZS50YXJnZXQudmFsdWUgIT09ICcnKSB7XG4gICAgICB0aGlzLnByb3BzLnNlYXJjaFRyYWNrcyhlLnRhcmdldC52YWx1ZSk7XG4gICAgfVxuICB9O1xuXG4gIGhhbmRsZUtleURvd24gPSBlID0+IHtcbiAgICBzd2l0Y2ggKGUua2V5Q29kZSkge1xuICAgICAgY2FzZSAzODogLy8gdXBcbiAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGZvY3VzOiB0aGlzLnN0YXRlLmZvY3VzIC0gMSB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDQwOiAvLyBkb3duXG4gICAgICAgIHRoaXMuc2V0U3RhdGUoeyBmb2N1czogdGhpcy5zdGF0ZS5mb2N1cyArIDEgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAxMzoge1xuICAgICAgICBsZXQgY29ycmVjdCA9IGZhbHNlO1xuICAgICAgICBpZiAodGhpcy5zdGF0ZS5mb2N1cyAhPT0gLTEpIHtcbiAgICAgICAgICB0aGlzLnByb3BzLnF1ZXVlVHJhY2sodGhpcy5wcm9wcy5zZWFyY2gucmVzdWx0c1t0aGlzLnN0YXRlLmZvY3VzXS5pZCk7XG4gICAgICAgICAgY29ycmVjdCA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgdGV4dCA9IGUudGFyZ2V0LnZhbHVlLnRyaW0oKTtcbiAgICAgICAgICBpZiAodGV4dC5sZW5ndGggIT09IDApIHtcbiAgICAgICAgICAgIHRoaXMucHJvcHMucXVldWVUcmFjayh0ZXh0KTtcbiAgICAgICAgICAgIGNvcnJlY3QgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoY29ycmVjdCkge1xuICAgICAgICAgIHRoaXMuc2V0U3RhdGUoeyB0ZXh0OiAnJyB9KTtcbiAgICAgICAgICB0aGlzLnByb3BzLnNlYXJjaFRyYWNrc1Jlc2V0KCk7XG4gICAgICAgICAgdGhpcy5zZXRTdGF0ZSh7IGZvY3VzOiAtMSB9KTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgcmVuZGVyKCkge1xuICAgIGNvbnN0IHBsYWNlaG9sZGVyID0gdGhpcy5wcm9wcy5pbnRsLmZvcm1hdE1lc3NhZ2UoeyBpZDogJ3F1ZXVlLmFkZCcgfSk7XG4gICAgY29uc3QgcmVzdWx0cyA9IHRoaXMucHJvcHMuc2VhcmNoLnJlc3VsdHM7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWRkLXRvLXF1ZXVlXCIgb25CbHVyPXt0aGlzLmhhbmRsZUJsdXJ9PlxuICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgLmFkZC10by1xdWV1ZV9faW5wdXQge1xuICAgICAgICAgICAgIHdpZHRoOiAzMDBweDtcbiAgICAgICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgICAgICAgaGVpZ2h0OiAzN3B4O1xuICAgICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDlweDtcbiAgICAgICAgICAgICAgYm9yZGVyOiBub25lO1xuICAgICAgICAgICAgICBmb250LXNpemU6IDExcHg7XG4gICAgICAgICAgICAgIGNvbG9yOiAjQjJCMkIyO1xuICAgICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMTVweDtcbiAgICAgICAgICB9XG4gICAgICAgIGB9PC9zdHlsZT5cbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWRkLXRvLXF1ZXVlX19pbnB1dFwiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9e3BsYWNlaG9sZGVyfVxuICAgICAgICAgIHZhbHVlPXt0aGlzLnN0YXRlLnRleHR9XG4gICAgICAgICAgb25DaGFuZ2U9e3RoaXMuaGFuZGxlQ2hhbmdlfVxuICAgICAgICAgIG9uS2V5RG93bj17dGhpcy5oYW5kbGVLZXlEb3dufVxuICAgICAgICAgIG9uRm9jdXM9e3RoaXMuaGFuZGxlRm9jdXN9XG4gICAgICAgIC8+XG4gICAgICAgIHtyZXN1bHRzICYmIDxSZXN1bHRzTGlzdCByZXN1bHRzPXtyZXN1bHRzfSBvblNlbGVjdD17dGhpcy5oYW5kbGVTZWxlY3RFbGVtZW50fSBmb2N1cz17dGhpcy5zdGF0ZS5mb2N1c30gLz59XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG59XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IGRpc3BhdGNoID0+ICh7XG4gIHF1ZXVlVHJhY2s6IHRleHQgPT4gZGlzcGF0Y2gocXVldWVUcmFjayh0ZXh0KSksXG4gIHNlYXJjaFRyYWNrczogcXVlcnkgPT4gZGlzcGF0Y2goc2VhcmNoVHJhY2tzKHF1ZXJ5KSksXG4gIHNlYXJjaFRyYWNrc1Jlc2V0OiAoKSA9PiBkaXNwYXRjaChzZWFyY2hUcmFja3NSZXNldCgpKVxufSk7XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IHN0YXRlID0+ICh7XG4gIHNlYXJjaDogc3RhdGUuc2VhcmNoXG59KTtcblxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdChtYXBTdGF0ZVRvUHJvcHMsIG1hcERpc3BhdGNoVG9Qcm9wcykoaW5qZWN0SW50bChBZGRUb1F1ZXVlKSk7XG4iLCJpbXBvcnQgY3NzIGZyb20gJ3N0eWxlZC1qc3gvY3NzJztcblxuZXhwb3J0IGRlZmF1bHQgY3NzYC5idG4tLWRhcmsge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICBib3JkZXI6IDBweCBzb2xpZCAjYmJjOGQ1O1xuICBjb2xvcjogIzBEMEMwQztcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGZvbnQtZmFtaWx5OiAnU29maWEgUHJvJztcbiAgZm9udC1zaXplOiAxNHB4O1xufWA7XG4iLCJpbXBvcnQgY3NzIGZyb20gJ3N0eWxlZC1qc3gvY3NzJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNzc2AuYnRuIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjNjY2O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgY29sb3I6ICM2NjY7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGxpbmUtaGVpZ2h0OiAyOHB4O1xyXG4gIHBhZGRpbmc6IDAgMTVweDtcclxufWA7XHJcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBjb25uZWN0IH0gZnJvbSAncmVhY3QtcmVkdXgnO1xuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xuXG5pbXBvcnQgQnV0dG9uU3R5bGUgZnJvbSAnLi9CdXR0b25TdHlsZSc7XG5pbXBvcnQgQnV0dG9uRGFya1N0eWxlIGZyb20gJy4vQnV0dG9uRGFya1N0eWxlJztcbmltcG9ydCB7IGZldGNoQXZhaWxhYmxlRGV2aWNlcywgdHJhbnNmZXJQbGF5YmFja1RvRGV2aWNlIH0gZnJvbSAnLi4vYWN0aW9ucy9kZXZpY2VzQWN0aW9ucyc7XG5pbXBvcnQgeyBnZXRJc0ZldGNoaW5nRGV2aWNlcyB9IGZyb20gJy4uL3JlZHVjZXJzJztcbmltcG9ydCB7IGdldERldmljZXMgfSBmcm9tICcuLi9yZWR1Y2Vycyc7XG5jbGFzcyBEZXZpY2VzIGV4dGVuZHMgUmVhY3QuUHVyZUNvbXBvbmVudCB7XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IGRldmljZXMsIGlzRmV0Y2hpbmcsIGZldGNoQXZhaWxhYmxlRGV2aWNlcywgdHJhbnNmZXJQbGF5YmFja1RvRGV2aWNlIH0gPSB0aGlzLnByb3BzO1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmdCb3R0b206ICcxMHB4J319PlxuICAgICAgICA8aDI+PEZvcm1hdHRlZE1lc3NhZ2UgaWQ9XCJkZXZpY2VzLnRpdGxlXCIgLz48L2gyPlxuICAgICAgICA8c3R5bGUganN4PlxuICAgICAgICAgIHtCdXR0b25TdHlsZX1cbiAgICAgICAgPC9zdHlsZT5cbiAgICAgICAgPHN0eWxlIGpzeD5cbiAgICAgICAgICB7QnV0dG9uRGFya1N0eWxlfVxuICAgICAgICA8L3N0eWxlPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuIGJ0bi0tZGFya1wiXG4gICAgICAgICAgZGlzYWJsZWQ9e2lzRmV0Y2hpbmd9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgZmV0Y2hBdmFpbGFibGVEZXZpY2VzKCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIDxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwiZGV2aWNlcy5mZXRjaFwiIC8+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICB7ZGV2aWNlcy5sZW5ndGggPT09IDBcbiAgICAgICAgICA/IDxwPjxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwiZGV2aWNlcy5lbXB0eVwiIC8+PC9wPlxuICAgICAgICAgIDogPHRhYmxlPlxuICAgICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgICAge2RldmljZXMubWFwKGRldmljZSA9PiAoXG4gICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgICAgICAgICAgICB7ZGV2aWNlLmlzX2FjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAgICAgPyA8c3Ryb25nPkFjdGl2ZSAtJmd0Ozwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgOiA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNmZXJQbGF5YmFja1RvRGV2aWNlKGRldmljZS5pZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwiZGV2aWNlcy50cmFuc2ZlclwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPn1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgIHtkZXZpY2UubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgIHtkZXZpY2UudHlwZX1cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgICAgIHtkZXZpY2Uudm9sdW1lfVxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgIDwvdGFibGU+fVxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxufVxuXG5jb25zdCBtYXBEaXNwYXRjaFRvUHJvcHMgPSBkaXNwYXRjaCA9PiAoe1xuICBmZXRjaEF2YWlsYWJsZURldmljZXM6IGluZGV4ID0+IGRpc3BhdGNoKGZldGNoQXZhaWxhYmxlRGV2aWNlcyhpbmRleCkpLFxuICB0cmFuc2ZlclBsYXliYWNrVG9EZXZpY2U6IGRldmljZUlkID0+IGRpc3BhdGNoKHRyYW5zZmVyUGxheWJhY2tUb0RldmljZShkZXZpY2VJZCkpXG59KTtcblxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gc3RhdGUgPT4gKHtcbiAgaXNGZXRjaGluZzogZ2V0SXNGZXRjaGluZ0RldmljZXMoc3RhdGUpLFxuICBkZXZpY2VzOiBnZXREZXZpY2VzKHN0YXRlKVxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKERldmljZXMpO1xuIiwiaW1wb3J0IExpbmsgZnJvbSAnbmV4dC9saW5rJztcbmltcG9ydCB7IGNvbm5lY3QgfSBmcm9tICdyZWFjdC1yZWR1eCc7XG5pbXBvcnQgeyBGb3JtYXR0ZWRNZXNzYWdlIH0gZnJvbSAncmVhY3QtaW50bCc7XG5pbXBvcnQgeyBsb2dpbiB9IGZyb20gJy4uL2FjdGlvbnMvc2Vzc2lvbkFjdGlvbnMnO1xuaW1wb3J0IHsgbXV0ZVBsYXliYWNrLCB1bm11dGVQbGF5YmFjayB9IGZyb20gJy4uL2FjdGlvbnMvcGxheWJhY2tBY3Rpb25zJztcbmltcG9ydCBCdXR0b25TdHlsZSBmcm9tICcuL0J1dHRvblN0eWxlJztcbmltcG9ydCBCdXR0b25EYXJrU3R5bGUgZnJvbSAnLi9CdXR0b25EYXJrU3R5bGUnO1xuXG5jb25zdCBsaW5rU3R5bGUgPSB7XG4gIGxpbmVIZWlnaHQ6ICczMHB4JyxcbiAgbWFyZ2luUmlnaHQ6IDE1XG59O1xuXG5jb25zdCBtYWluTGlua1N0eWxlID0ge1xuICBmbG9hdDogJ2xlZnQnLFxuICBtYXJnaW5SaWdodDogJzEwcHgnXG59O1xuXG5jb25zdCBoZWFkZXJTdHlsZSA9IHtcbiAgYmFja2dyb3VuZENvbG9yOiAnIzBEMEMwQycsXG4gIHBhZGRpbmc6ICczMHB4IDQwcHgnLFxuICBoZWlnaHQ6ICczMHB4JyxcbiAgY29sb3I6ICcjMzMzJ1xufTtcblxuY29uc3QgZ2V0TmFtZUZyb21Vc2VyID0gdXNlciA9PiB7XG4gIHJldHVybiB1c2VyLmRpc3BsYXlfbmFtZSB8fCB1c2VyLmlkO1xufTtcblxuY29uc3QgSGVhZGVyID0gKHsgc2Vzc2lvbiwgbXV0ZWQsIG11dGVQbGF5YmFjaywgdW5tdXRlUGxheWJhY2ssIGxvZ2luIH0pID0+IChcbiAgPGRpdiBzdHlsZT17aGVhZGVyU3R5bGV9PlxuICAgIHtzZXNzaW9uLnVzZXIgPyAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhIHVzZXItaGVhZGVyXCI+XG4gICAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgICAudXNlci1oZWFkZXIge1xuICAgICAgICAgICAgZmxvYXQ6IHJpZ2h0O1xuICAgICAgICAgICAgd2lkdGg6IDE1MHB4O1xuICAgICAgICAgIH1cbiAgICAgICAgICAudXNlci1pbWFnZSB7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgfVxuICAgICAgICAgIC51c2VyLW5hbWUge1xuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDMwcHg7XG4gICAgICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgICB9XG4gICAgICAgICAgLm1lZGlhLFxuICAgICAgICAgIC5tZWRpYV9fYmQge1xuICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgICAgIF9vdmVyZmxvdzogdmlzaWJsZTtcbiAgICAgICAgICAgIHpvb206IDE7XG4gICAgICAgICAgfVxuICAgICAgICAgIC5tZWRpYSAubWVkaWFfX2ltZyB7XG4gICAgICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICB9XG4gICAgICAgICAgLmJ0bi1zY2FmZSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiMwRDBDMEM7XG4gICAgICAgICAgICBjb2xvcjojZmZmO1xuICAgICAgICAgIH1cbiAgICAgICAgYH08L3N0eWxlPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhX19pbWdcIj5cbiAgICAgICAgICA8aW1nXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ1c2VyLWltYWdlXCJcbiAgICAgICAgICAgIHNyYz17XG4gICAgICAgICAgICAgIChzZXNzaW9uLnVzZXIuaW1hZ2VzICYmIHNlc3Npb24udXNlci5pbWFnZXMubGVuZ3RoICYmIHNlc3Npb24udXNlci5pbWFnZXNbMF0udXJsKSB8fFxuICAgICAgICAgICAgICAnL3N0YXRpYy91c2VyLWljb24ucG5nJ1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgd2lkdGg9XCIzMFwiXG4gICAgICAgICAgICBoZWlnaHQ9XCIzMFwiXG4gICAgICAgICAgICBhbHQ9e2dldE5hbWVGcm9tVXNlcihzZXNzaW9uLnVzZXIpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVzZXItbmFtZSBtZWRpYV9fYmRcIj57Z2V0TmFtZUZyb21Vc2VyKHNlc3Npb24udXNlcil9PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICApIDogKFxuICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJidG4gYnRuLS1kYXJrIGJ0bi1zY2FmZVwiIHN0eWxlPXt7IGZsb2F0OiAncmlnaHQnIH19IG9uQ2xpY2s9e2xvZ2lufT5cbiAgICAgICAgPHN0eWxlIGpzeD57QnV0dG9uU3R5bGV9PC9zdHlsZT5cbiAgICAgICAgPHN0eWxlIGpzeD57QnV0dG9uRGFya1N0eWxlfTwvc3R5bGU+XG4gICAgICAgIDxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwibG9naW5cIiAvPlxuICAgICAgPC9idXR0b24+XG4gICAgKX1cbiAgICB7c2Vzc2lvbi51c2VyID8gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwbGF5YmFjay1jb250cm9sXCI+XG4gICAgICAgIDxzdHlsZSBqc3g+e0J1dHRvblN0eWxlfTwvc3R5bGU+XG4gICAgICAgIDxzdHlsZSBqc3g+e0J1dHRvbkRhcmtTdHlsZX08L3N0eWxlPlxuICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgLnBsYXliYWNrLWNvbnRyb2wge1xuICAgICAgICAgICAgZmxvYXQ6IGxlZnQ7XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBjbGFzc05hbWU9XCJidG4gYnRuLS1kYXJrIGJ0bi1zY2FmZVwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgbXV0ZWQgPyB1bm11dGVQbGF5YmFjaygpIDogbXV0ZVBsYXliYWNrKCk7XG4gICAgICAgICAgfX1cbiAgICAgICAgPlxuICAgICAgICAgIHttdXRlZCA/ICdVbm11dGUnIDogJ011dGUnfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICkgOiBudWxsfVxuICA8L2Rpdj5cbik7XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IGRpc3BhdGNoID0+ICh7XG4gIGxvZ2luOiAoKSA9PiBkaXNwYXRjaChsb2dpbigpKSxcbiAgbXV0ZVBsYXliYWNrOiAoKSA9PiBkaXNwYXRjaChtdXRlUGxheWJhY2soKSksXG4gIHVubXV0ZVBsYXliYWNrOiAoKSA9PiBkaXNwYXRjaCh1bm11dGVQbGF5YmFjaygpKVxufSk7XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IHN0YXRlID0+ICh7XG4gIHNlc3Npb246IHN0YXRlLnNlc3Npb24sXG4gIG11dGVkOiBzdGF0ZS5wbGF5YmFjay5tdXRlZFxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKEhlYWRlcik7XG4iLCJpbXBvcnQgSGVhZGVyIGZyb20gJy4vSGVhZGVyJztcbmltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCc7XG5cbmNvbnN0IExheW91dCA9IHByb3BzID0+IChcbiAgPGRpdj5cbiAgICA8c3R5bGUganN4PntgXG4gICAgICBkaXYge1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgICAgZm9udC1mYW1pbHk6ICdTb2ZpYSBQcm8nLCBIZWx2ZXRpY2EsIEFyaWFsLCBzYW5zLXNlcmlmO1xuICAgICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICB9XG4gICAgYH08L3N0eWxlPlxuICAgIDxIZWFkZXIgLz5cbiAgICA8ZGl2Pntwcm9wcy5jaGlsZHJlbn08L2Rpdj5cbiAgPC9kaXY+XG4pO1xuXG5leHBvcnQgZGVmYXVsdCBMYXlvdXQ7XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG5jbGFzcyBOb3dQbGF5aW5nIGV4dGVuZHMgUmVhY3QuUHVyZUNvbXBvbmVudCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5zdGF0ZSA9IHtcbiAgICAgIHN0YXJ0OiBEYXRlLm5vdygpLFxuICAgICAgY3VycmVudFBvc2l0aW9uOiAwXG4gICAgfTtcbiAgICB0aGlzLnRpbWVyID0gbnVsbDtcbiAgICB0aGlzLnRpY2sgPSAoKSA9PiB7XG4gICAgICB0aGlzLnNldFN0YXRlKHtcbiAgICAgICAgY3VycmVudFBvc2l0aW9uOiBEYXRlLm5vdygpIC0gdGhpcy5zdGF0ZS5zdGFydCArICh0aGlzLnByb3BzLnBvc2l0aW9uIHx8IDApXG4gICAgICB9KTtcbiAgICB9O1xuICB9XG4gIGNvbXBvbmVudFdpbGxSZWNlaXZlUHJvcHMocHJvcHMpIHtcbiAgICBpZiAodGhpcy5wcm9wcy5wb3NpdGlvbiAhPT0gcHJvcHMucG9zaXRpb24gfHwgdGhpcy5wcm9wcy50cmFjayAhPT0gcHJvcHMudHJhY2spIHtcbiAgICAgIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgICBzdGFydDogRGF0ZS5ub3coKSxcbiAgICAgICAgY3VycmVudFBvc2l0aW9uOiAwXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgdGhpcy50aW1lciA9IHNldEludGVydmFsKHRoaXMudGljaywgMzAwKTtcbiAgfVxuICBjb21wb25lbnRXaWxsVW5tb3VudCgpIHtcbiAgICBjbGVhckludGVydmFsKHRoaXMudGltZXIpO1xuICB9XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCBwZXJjZW50YWdlID0gKygodGhpcy5zdGF0ZS5jdXJyZW50UG9zaXRpb24gKiAxMDApIC8gdGhpcy5wcm9wcy50cmFjay5kdXJhdGlvbl9tcykudG9GaXhlZCgyKSArICclJztcbiAgICBjb25zdCB1c2VyTmFtZSA9IHRoaXMucHJvcHMudXNlci5kaXNwbGF5X25hbWUgfHwgdGhpcy5wcm9wcy51c2VyLmlkO1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdy1wbGF5aW5nXCI+XG4gICAgICAgIDxzdHlsZSBqc3g+e2BcbiAgICAgICAgICAubm93LXBsYXlpbmcge1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzBEMEMwQztcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgICAgaGVpZ2h0OiAyNTBweDtcbiAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgIH1cbiAgICAgICAgICAubm93LXBsYXlpbmdfX3RleHQge1xuICAgICAgICAgICAgcGFkZGluZzogMHB4IDQwcHg7XG4gICAgICAgICAgfVxuICAgICAgICAgIC5ub3ctcGxheWluZ19fYmQge1xuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAzMHB4O1xuICAgICAgICAgIH1cbiAgICAgICAgICAubm93LXBsYXlpbmdfX3RyYWNrLW5hbWUge1xuICAgICAgICAgICAgZm9udC1zaXplOiAxZW07XG4gICAgICAgICAgICBwYWRkaW5nLXRvcDogMS4yZW07XG4gICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgICAgICB9XG4gICAgICAgICAgLm5vdy1wbGF5aW5nX19hcnRpc3QtbmFtZSB7XG4gICAgICAgICAgICBmb250LXNpemU6IDAuOGVtO1xuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDJlbTtcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiAwLjVlbTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLm5vdy1wbGF5aW5nX191c2VyIHtcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiAwLjVlbTtcbiAgICAgICAgICB9XG4gICAgICAgICAgLm5vdy1wbGF5aW5nX19wcm9ncmVzcyB7XG4gICAgICAgICAgZmxvYXQ6bGVmdDtcbiAgICAgICAgICB3aWR0aDogNzUlO1xuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMzMzMyMzI7XG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogMjNweDtcbiAgICAgICAgICBoZWlnaHQ6IDhweDtcbiAgICAgICAgICBwYWRkaW5nOiA0cHg7XG4gICAgICAgICAgbWFyZ2luOiAwcHggNDBweDtcbiAgICAgICAgICB9XG4gICAgICAgICAgLm5vdy1wbGF5aW5nX19wcm9ncmVzc19iYXIge1xuICAgICAgICAgICAgLy9ib3R0b206IDA7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgICAgICAgICAgaGVpZ2h0OiA4cHg7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICAgICAgICAgICAvLyBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgICAvL3RvcDozNTJweDtcbiAgICAgICAgICB9XG4gICAgICAgICAgLm1lZGlhLFxuICAgICAgICAgIC5tZWRpYV9fYmQge1xuICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICAgICAgICAgIF9vdmVyZmxvdzogdmlzaWJsZTtcbiAgICAgICAgICAgIHpvb206IDE7XG4gICAgICAgICAgICBmbG9hdDpsZWZ0O1xuICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDZweDtcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgICAgIHdpZHRoOiA3NSU7XG4gICAgICAgICAgfVxuICAgICAgICAgIC5tZWRpYSAubWVkaWFfX2ltZyB7XG4gICAgICAgICAgICBmbG9hdDogbGVmdDtcbiAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICB9XG4gICAgICAgICAgIC5tZWRpYSAubWVkaWFfX2ltZyBpbWcge1xuICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgIH1cbiAgICAgICAgICAudXNlci1pbWFnZSB7XG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgICAgICAgfVxuICAgICAgICAgIC51c2VyLW5hbWUge1xuICAgICAgICAgICAgbGluZS1oZWlnaHQ6IDE4cHg7XG4gICAgICAgICAgfVxuICAgICAgICBgfTwvc3R5bGU+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm93LXBsYXlpbmdfX3RleHQgbWVkaWFcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhX19pbWdcIj5cbiAgICAgICAgICAgIDxpbWcgc3JjPXt0aGlzLnByb3BzLnRyYWNrLmFsYnVtLmltYWdlc1sxXS51cmx9IHdpZHRoPVwiMjgwXCIgaGVpZ2h0PVwiMjgwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdy1wbGF5aW5nX19iZCBtZWRpYV9fYmRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm93LXBsYXlpbmdfX3RyYWNrLW5hbWVcIj57dGhpcy5wcm9wcy50cmFjay5uYW1lfTwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJub3ctcGxheWluZ19fYXJ0aXN0LW5hbWVcIj57dGhpcy5wcm9wcy50cmFjay5hcnRpc3RzLm1hcChhID0+IGEubmFtZSkuam9pbignLCAnKX08L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVkaWFfX2ltZ1wiPlxuICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidXNlci1pbWFnZVwiXG4gICAgICAgICAgICAgICAgc3JjPXtcbiAgICAgICAgICAgICAgICAgICh0aGlzLnByb3BzLnVzZXIuaW1hZ2VzICYmIHRoaXMucHJvcHMudXNlci5pbWFnZXMubGVuZ3RoICYmIHRoaXMucHJvcHMudXNlci5pbWFnZXNbMF0udXJsKSB8fFxuICAgICAgICAgICAgICAgICAgJy9zdGF0aWMvdXNlci1pY29uLnBuZydcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgd2lkdGg9XCIzMFwiXG4gICAgICAgICAgICAgICAgaGVpZ2h0PVwiMzBcIlxuICAgICAgICAgICAgICAgIGFsdD17dXNlck5hbWV9XG4gICAgICAgICAgICAgICAgdGl0bGU9e3VzZXJOYW1lfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInVzZXItbmFtZSBtZWRpYV9fYmRcIj57dXNlck5hbWV9PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm5vdy1wbGF5aW5nX19wcm9ncmVzc1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibm93LXBsYXlpbmdfX3Byb2dyZXNzX2JhclwiIHN0eWxlPXt7IHdpZHRoOiBwZXJjZW50YWdlIH19IC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgKTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBOb3dQbGF5aW5nO1xuIiwiaW1wb3J0IFJlYWN0LCB7IENvbXBvbmVudCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgSW50bFByb3ZpZGVyLCBhZGRMb2NhbGVEYXRhLCBpbmplY3RJbnRsIH0gZnJvbSAncmVhY3QtaW50bCc7XHJcblxyXG4vLyBSZWdpc3RlciBSZWFjdCBJbnRsJ3MgbG9jYWxlIGRhdGEgZm9yIHRoZSB1c2VyJ3MgbG9jYWxlIGluIHRoZSBicm93c2VyLiBUaGlzXHJcbi8vIGxvY2FsZSBkYXRhIHdhcyBhZGRlZCB0byB0aGUgcGFnZSBieSBgcGFnZXMvX2RvY3VtZW50LmpzYC4gVGhpcyBvbmx5IGhhcHBlbnNcclxuLy8gb25jZSwgb24gaW5pdGlhbCBwYWdlIGxvYWQgaW4gdGhlIGJyb3dzZXIuXHJcbmlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB3aW5kb3cuUmVhY3RJbnRsTG9jYWxlRGF0YSkge1xyXG4gIE9iamVjdC5rZXlzKHdpbmRvdy5SZWFjdEludGxMb2NhbGVEYXRhKS5mb3JFYWNoKGxhbmcgPT4ge1xyXG4gICAgYWRkTG9jYWxlRGF0YSh3aW5kb3cuUmVhY3RJbnRsTG9jYWxlRGF0YVtsYW5nXSk7XHJcbiAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBhZ2UgPT4ge1xyXG4gIGNvbnN0IEludGxQYWdlID0gaW5qZWN0SW50bChQYWdlKTtcclxuICByZXR1cm4gY2xhc3MgUGFnZVdpdGhJbnRsIGV4dGVuZHMgQ29tcG9uZW50IHtcclxuICAgIHN0YXRpYyBhc3luYyBnZXRJbml0aWFsUHJvcHMoY29udGV4dCkge1xyXG4gICAgICBsZXQgcHJvcHM7XHJcbiAgICAgIGlmICh0eXBlb2YgUGFnZS5nZXRJbml0aWFsUHJvcHMgPT09ICdmdW5jdGlvbicpIHtcclxuICAgICAgICBwcm9wcyA9IGF3YWl0IFBhZ2UuZ2V0SW5pdGlhbFByb3BzKGNvbnRleHQpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBHZXQgdGhlIGBsb2NhbGVgIGFuZCBgbWVzc2FnZXNgIGZyb20gdGhlIHJlcXVlc3Qgb2JqZWN0IG9uIHRoZSBzZXJ2ZXIuXHJcbiAgICAgIC8vIEluIHRoZSBicm93c2VyLCB1c2UgdGhlIHNhbWUgdmFsdWVzIHRoYXQgdGhlIHNlcnZlciBzZXJpYWxpemVkLlxyXG4gICAgICBjb25zdCB7IHJlcSB9ID0gY29udGV4dDtcclxuICAgICAgLy8gdG9kbzogZm9yIHNvbWUgcmVhc29uIGl0IGlzIG5vdCBwcm9wcy5pbml0aWFsUHJvcHMsIGJ1dCBwcm9wcyBpbiB0aGUgZXhhbXBsZVxyXG4gICAgICBjb25zdCB7IGxvY2FsZSwgbWVzc2FnZXMgfSA9IHJlcSB8fCB3aW5kb3cuX19ORVhUX0RBVEFfXy5wcm9wcy5pbml0aWFsUHJvcHM7XHJcblxyXG4gICAgICAvLyBBbHdheXMgdXBkYXRlIHRoZSBjdXJyZW50IHRpbWUgb24gcGFnZSBsb2FkL3RyYW5zaXRpb24gYmVjYXVzZSB0aGVcclxuICAgICAgLy8gPEludGxQcm92aWRlcj4gd2lsbCBiZSBhIG5ldyBpbnN0YW5jZSBldmVuIHdpdGggcHVzaFN0YXRlIHJvdXRpbmcuXHJcbiAgICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XHJcblxyXG4gICAgICByZXR1cm4geyAuLi5wcm9wcywgbG9jYWxlLCBtZXNzYWdlcywgbm93IH07XHJcbiAgICB9XHJcblxyXG4gICAgcmVuZGVyKCkge1xyXG4gICAgICBjb25zdCB7IGxvY2FsZSwgbWVzc2FnZXMsIG5vdywgLi4ucHJvcHMgfSA9IHRoaXMucHJvcHM7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPEludGxQcm92aWRlciBsb2NhbGU9e2xvY2FsZX0gbWVzc2FnZXM9e21lc3NhZ2VzfSBpbml0aWFsTm93PXtub3d9PlxyXG4gICAgICAgICAgPEludGxQYWdlIHsuLi5wcm9wc30gLz5cclxuICAgICAgICA8L0ludGxQcm92aWRlcj5cclxuICAgICAgKTtcclxuICAgIH1cclxuICB9O1xyXG59O1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgY29ubmVjdCB9IGZyb20gJ3JlYWN0LXJlZHV4JztcbmltcG9ydCB7IEZvcm1hdHRlZE1lc3NhZ2UgfSBmcm9tICdyZWFjdC1pbnRsJztcblxuaW1wb3J0IFF1ZXVlSXRlbSBmcm9tICcuL1F1ZXVlSXRlbSc7XG5pbXBvcnQgeyBxdWV1ZVJlbW92ZVRyYWNrIH0gZnJvbSAnLi4vYWN0aW9ucy9xdWV1ZUFjdGlvbnMnO1xuaW1wb3J0IHsgdm90ZVVwIH0gZnJvbSAnLi4vYWN0aW9ucy92b3RlQWN0aW9ucyc7XG5cbmNsYXNzIFF1ZXVlIGV4dGVuZHMgUmVhY3QuUHVyZUNvbXBvbmVudCB7XG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IGl0ZW1zLCBzZXNzaW9uIH0gPSB0aGlzLnByb3BzO1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmdCb3R0b206ICcxMHB4JyB9fT5cbiAgICAgICAgPGgyPjxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwicXVldWUudGl0bGVcIiAvPjwvaDI+XG4gICAgICAgIHtpdGVtcy5sZW5ndGggPT09IDBcbiAgICAgICAgICA/IDxwPjxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwicXVldWUuZW1wdHlcIiAvPjwvcD5cbiAgICAgICAgICA6IDx0YWJsZSBjbGFzc05hbWU9XCJxdWV1ZVwiPlxuICAgICAgICAgICAgICA8c3R5bGUganN4PntgXG4gICAgICAgICAgICAgICAgLnF1ZXVlIHtcbiAgICAgICAgICAgICAgICAgIG1heC13aWR0aDogNTUwcHg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBgfTwvc3R5bGU+XG4gICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICB7aXRlbXMubWFwKChpLCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPFF1ZXVlSXRlbVxuICAgICAgICAgICAgICAgICAgICBpdGVtPXtpfVxuICAgICAgICAgICAgICAgICAgICBzZXNzaW9uPXtzZXNzaW9ufVxuICAgICAgICAgICAgICAgICAgICBpbmRleD17aW5kZXh9XG4gICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgICAgICAgICAgICAgIG9uVm90ZVVwPXsoKSA9PiB0aGlzLnByb3BzLnZvdGVVcChpLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgb25SZW1vdmVJdGVtPXsoKSA9PiB0aGlzLnByb3BzLnF1ZXVlUmVtb3ZlVHJhY2soaS5pZCl9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgPC90YWJsZT59XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG59XG5cbmNvbnN0IG1hcERpc3BhdGNoVG9Qcm9wcyA9IGRpc3BhdGNoID0+ICh7XG4gIHZvdGVVcDogaWQgPT4gZGlzcGF0Y2godm90ZVVwKGlkKSksXG4gIHF1ZXVlUmVtb3ZlVHJhY2s6IGlkID0+IGRpc3BhdGNoKHF1ZXVlUmVtb3ZlVHJhY2soaWQpKVxufSk7XG5cbmNvbnN0IG1hcFN0YXRlVG9Qcm9wcyA9IHN0YXRlID0+ICh7XG4gIHF1ZXVlOiBzdGF0ZS5xdWV1ZVxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IGNvbm5lY3QobWFwU3RhdGVUb1Byb3BzLCBtYXBEaXNwYXRjaFRvUHJvcHMpKFF1ZXVlKTtcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0ICh7IGluZGV4LCBpdGVtLCBzZXNzaW9uLCBvblJlbW92ZUl0ZW0sIG9uVm90ZVVwIH0pID0+IHtcbiAgY29uc3Qgdm90ZVVwID0gaXRlbS52b3RlcnMgJiYgc2Vzc2lvbi51c2VyICYmIGl0ZW0udm90ZXJzLmZpbHRlcih2ID0+IHYuaWQgPT09IHNlc3Npb24udXNlci5pZCkubGVuZ3RoID09PSAwXG4gICAgPyA8YnV0dG9uIG9uQ2xpY2s9e29uVm90ZVVwfT7ilrI8L2J1dHRvbj5cbiAgICA6IG51bGw7XG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17eyBmb250c2l6ZTogJzExcHgnLCBtYXJnaW5Cb3R0b206ICcxNXB4JywgZmxvYXQ6XCJsZWZ0XCIsIHdpZHRoOiAnMjk3cHgnfX0+XG4gICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmdSaWdodDogJzEwcHgnLCBmbG9hdDogXCJsZWZ0XCJ9fT5cbiAgICAgICAgPGltZyBzcmM9e2l0ZW0udHJhY2suYWxidW0uaW1hZ2VzWzJdLnVybH0gd2lkdGg9XCI0MFwiIGhlaWdodD1cIjQwXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nUmlnaHQ6ICcxMHB4JyAsIGZsb2F0OiBcImxlZnRcIn19PlxuICAgICAgICB7aW5kZXggKyAxfVxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IHN0eWxlPXt7IHBhZGRpbmdSaWdodDogJzEwcHgnLCBmbG9hdDogXCJsZWZ0XCIgfX0+XG4gICAgICAgIHtpdGVtLnRyYWNrLm5hbWV9PGJyPjwvYnI+XG4gICAgICAgIHtpdGVtLnRyYWNrLmFydGlzdHMubWFwKGEgPT4gYS5uYW1lKS5qb2luKCcsICcpfTxicj48L2JyPlxuXG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZ1JpZ2h0OiAnMTBweCcsIGZsb2F0OiBcImxlZnRcIiwgZGlzcGxheTogXCJub25lXCIgfX0+XG4gICAgICAgIHtpdGVtLnVzZXIgJiYgKGl0ZW0udXNlci5kaXNwbGF5X25hbWUgfHwgaXRlbS51c2VyLmlkKX1cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBzdHlsZT17eyBwYWRkaW5nUmlnaHQ6ICcxMHB4JywgZmxvYXQ6IFwicmlnaHRcIiB9fT5cbiAgICAgICAge2l0ZW0udXNlciAmJiBzZXNzaW9uLnVzZXIgJiYgaXRlbS51c2VyLmlkID09PSBzZXNzaW9uLnVzZXIuaWRcbiAgICAgICAgICA/IDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgIG9uUmVtb3ZlSXRlbShpdGVtLmlkKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgWFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgOiB2b3RlVXB9XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgc3R5bGU9e3sgcGFkZGluZ1JpZ2h0OiAnMTBweCcsIGZsb2F0OiBcImxlZnRcIiB9fT5cbiAgICAgICAge2l0ZW0udm90ZXJzICYmIGl0ZW0udm90ZXJzLmxlbmd0aCA+IDBcbiAgICAgICAgICA/IDxzcGFuPlxuICAgICAgICAgICAgICB7aXRlbS52b3RlcnMubGVuZ3RoID09PSAxID8gJzEgdm90ZScgOiBpdGVtLnZvdGVycy5sZW5ndGggKyAnIHZvdGVzJ31cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA6ICcnfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgKHsgaXRlbXMgfSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8c3R5bGUganN4PntgXHJcbiAgICAgICAgLnVzZXItbGlzdCB7XHJcbiAgICAgICAgICBsaXN0LXN0eWxlOiBub25lO1xyXG4gICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnVzZXItbGlzdF9faXRlbSB7XHJcbiAgICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDAuNWVtO1xyXG4gICAgICAgIH1cclxuICAgICAgICAudXNlci1pbWFnZSB7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC51c2VyLW5hbWUge1xyXG4gICAgICAgICAgbGluZS1oZWlnaHQ6IDMwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5tZWRpYSxcclxuICAgICAgICAubWVkaWFfX2JkIHtcclxuICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICBfb3ZlcmZsb3c6IHZpc2libGU7XHJcbiAgICAgICAgICB6b29tOiAxO1xyXG4gICAgICAgIH1cclxuICAgICAgICAubWVkaWEgLm1lZGlhX19pbWcge1xyXG4gICAgICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5oZWFkZXItMiB7XHJcbiAgICAgICAgICBjb2xvcjogIzk5OTtcclxuICAgICAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICAgICAgfVxyXG4gICAgICBgfTwvc3R5bGU+XHJcbiAgICAgIDxoMiBjbGFzc05hbWU9XCJoZWFkZXItMlwiPjxGb3JtYXR0ZWRNZXNzYWdlIGlkPVwib25saW5lXCIgLz48L2gyPlxyXG4gICAgICA8dWwgY2xhc3NOYW1lPVwidXNlci1saXN0XCI+XHJcbiAgICAgICAge2l0ZW1zLm1hcCgoaSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHVzZXJOYW1lID0gaS5kaXNwbGF5X25hbWUgfHwgaS5pZDtcclxuICAgICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxsaSBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJ1c2VyLWxpc3RfX2l0ZW0gbWVkaWFcIj5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1lZGlhX19pbWdcIj5cclxuICAgICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidXNlci1pbWFnZVwiXHJcbiAgICAgICAgICAgICAgICAgIHNyYz17KGkuaW1hZ2VzICYmIGkuaW1hZ2VzLmxlbmd0aCAmJiBpLmltYWdlc1swXS51cmwpIHx8ICcvc3RhdGljL3VzZXItaWNvbi5wbmcnfVxyXG4gICAgICAgICAgICAgICAgICB3aWR0aD1cIjMwXCJcclxuICAgICAgICAgICAgICAgICAgaGVpZ2h0PVwiMzBcIlxyXG4gICAgICAgICAgICAgICAgICBhbHQ9e3VzZXJOYW1lfVxyXG4gICAgICAgICAgICAgICAgICB0aXRsZT17dXNlck5hbWV9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidXNlci1uYW1lIG1lZGlhX19iZFwiPlxyXG4gICAgICAgICAgICAgICAge3VzZXJOYW1lfVxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9KX1cclxuICAgICAgPC91bD5cclxuICAgICAgPGRpdiBzdHlsZT17eyBjbGVhcjogJ2JvdGgnIH19IC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59O1xyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHtcclxuICBIT1NUOiBwcm9jZXNzLmVudi5IT1NUXHJcbn07XHJcbiIsImV4cG9ydCBjb25zdCBRVUVVRV9UUkFDSyA9ICdRVUVVRV9UUkFDSyc7XHJcbmV4cG9ydCBjb25zdCBVUERBVEVfUVVFVUUgPSAnVVBEQVRFX1FVRVVFJztcclxuZXhwb3J0IGNvbnN0IFFVRVVFX0VOREVEID0gJ1FVRVVFX0VOREVEJztcclxuZXhwb3J0IGNvbnN0IFFVRVVFX1JFTU9WRV9UUkFDSyA9ICdRVUVVRV9SRU1PVkVfVFJBQ0snO1xyXG5cclxuZXhwb3J0IGNvbnN0IFNFQVJDSF9UUkFDS1MgPSAnU0VBUkNIX1RSQUNLUyc7XHJcbmV4cG9ydCBjb25zdCBTRUFSQ0hfVFJBQ0tTX1NVQ0NFU1MgPSAnU0VBUkNIX1RSQUNLU19TVUNDRVNTJztcclxuZXhwb3J0IGNvbnN0IFNFQVJDSF9UUkFDS1NfUkVTRVQgPSAnU0VBUkNIX1RSQUNLU19SRVNFVCc7XHJcblxyXG5leHBvcnQgY29uc3QgRkVUQ0hfVFJBQ0sgPSAnRkVUQ0hfVFJBQ0snO1xyXG5leHBvcnQgY29uc3QgRkVUQ0hfVFJBQ0tfU1VDQ0VTUyA9ICdGRVRDSF9UUkFDS19TVUNDRVNTJztcclxuZXhwb3J0IGNvbnN0IEZFVENIX1BMQVlJTkdfQ09OVEVYVF9TVUNDRVNTID0gJ0ZFVENIX1BMQVlJTkdfQ09OVEVYVF9TVUNDRVNTJztcclxuXHJcbmV4cG9ydCBjb25zdCBVUERBVEVfVVNFUlMgPSAnVVBEQVRFX1VTRVJTJztcclxuXHJcbmV4cG9ydCBjb25zdCBMT0FEID0gJ0xPQUQnO1xyXG5leHBvcnQgY29uc3QgTE9HSU4gPSAnTE9HSU4nO1xyXG5leHBvcnQgY29uc3QgTE9HSU5fU1VDQ0VTUyA9ICdMT0dJTl9TVUNDRVNTJztcclxuZXhwb3J0IGNvbnN0IExPR0lOX0ZBSUxVUkUgPSAnTE9HSU5fRkFJTFVSRSc7XHJcblxyXG5leHBvcnQgY29uc3QgVVBEQVRFX1RPS0VOID0gJ1VQREFURV9UT0tFTic7XHJcbmV4cG9ydCBjb25zdCBVUERBVEVfVE9LRU5fU1VDQ0VTUyA9ICdVUERBVEVfVE9LRU5fU1VDQ0VTUyc7XHJcbmV4cG9ydCBjb25zdCBVUERBVEVfQ1VSUkVOVF9VU0VSID0gJ1VQREFURV9DVVJSRU5UX1VTRVInO1xyXG5leHBvcnQgY29uc3QgUExBWV9UUkFDSyA9ICdQTEFZX1RSQUNLJztcclxuZXhwb3J0IGNvbnN0IFVQREFURV9OT1dfUExBWUlORyA9ICdVUERBVEVfTk9XX1BMQVlJTkcnO1xyXG5leHBvcnQgY29uc3QgUExBWV9UUkFDS19TVUNDRVNTID0gJ1BMQVlfVFJBQ0tfU1VDQ0VTUyc7XHJcblxyXG5leHBvcnQgY29uc3QgTVVURV9QTEFZQkFDSyA9ICdNVVRFX1BMQVlCQUNLJztcclxuZXhwb3J0IGNvbnN0IFVOTVVURV9QTEFZQkFDSyA9ICdVTk1VVEVfUExBWUJBQ0snO1xyXG5cclxuZXhwb3J0IGNvbnN0IEZFVENIX0FWQUlMQUJMRV9ERVZJQ0VTID0gJ0ZFVENIX0FWQUlMQUJMRV9ERVZJQ0VTJztcclxuZXhwb3J0IGNvbnN0IEZFVENIX0FWQUlMQUJMRV9ERVZJQ0VTX1NVQ0NFU1MgPSAnRkVUQ0hfQVZBSUxBQkxFX0RFVklDRVNfU1VDQ0VTUyc7XHJcbmV4cG9ydCBjb25zdCBGRVRDSF9BVkFJTEFCTEVfREVWSUNFU19FUlJPUiA9ICdGRVRDSF9BVkFJTEFCTEVfREVWSUNFU19FUlJPUic7XHJcblxyXG5leHBvcnQgY29uc3QgVFJBTlNGRVJfUExBWUJBQ0tfVE9fREVWSUNFID0gJ1RSQU5TRkVSX1BMQVlCQUNLX1RPX0RFVklDRSc7XHJcbmV4cG9ydCBjb25zdCBUUkFOU0ZFUl9QTEFZQkFDS19UT19ERVZJQ0VfU1VDQ0VTUyA9ICdUUkFOU0ZFUl9QTEFZQkFDS19UT19ERVZJQ0VfU1VDQ0VTUyc7XHJcbmV4cG9ydCBjb25zdCBUUkFOU0ZFUl9QTEFZQkFDS19UT19ERVZJQ0VfRVJST1IgPSAnVFJBTlNGRVJfUExBWUJBQ0tfVE9fREVWSUNFX0VSUk9SJztcclxuXHJcbmV4cG9ydCBjb25zdCBWT1RFX1VQID0gJ1ZPVEVfVVAnO1xyXG5leHBvcnQgY29uc3QgVk9URV9VUF9TVUNDRVNTID0gJ1ZPVEVfVVBfU1VDQ0VTUyc7XHJcbiIsImltcG9ydCBmZXRjaCBmcm9tICdpc29tb3JwaGljLXVuZmV0Y2gnO1xyXG5cclxuaW1wb3J0IHsgRkVUQ0hfQVZBSUxBQkxFX0RFVklDRVMsIFRSQU5TRkVSX1BMQVlCQUNLX1RPX0RFVklDRSB9IGZyb20gJy4uL2NvbnN0YW50cy9BY3Rpb25UeXBlcyc7XHJcbmltcG9ydCB7XHJcbiAgZmV0Y2hBdmFpbGFibGVEZXZpY2VzLFxyXG4gIGZldGNoQXZhaWxhYmxlRGV2aWNlc1N1Y2Nlc3MsXHJcbiAgZmV0Y2hBdmFpbGFibGVEZXZpY2VzRXJyb3IsXHJcbiAgdHJhbnNmZXJQbGF5YmFja1RvRGV2aWNlU3VjY2VzcyxcclxuICB0cmFuc2ZlclBsYXliYWNrVG9EZXZpY2VFcnJvclxyXG59IGZyb20gJy4uL2FjdGlvbnMvZGV2aWNlc0FjdGlvbnMnO1xyXG5cclxuY29uc3QgU1BPVElGWV9BUElfQkFTRSA9ICdodHRwczovL2FwaS5zcG90aWZ5LmNvbS92MSc7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBzdG9yZSA9PiBuZXh0ID0+IGFjdGlvbiA9PiB7XHJcbiAgY29uc3QgcmVzdWx0ID0gbmV4dChhY3Rpb24pO1xyXG4gIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgIGNhc2UgRkVUQ0hfQVZBSUxBQkxFX0RFVklDRVM6IHtcclxuICAgICAgZmV0Y2goYCR7U1BPVElGWV9BUElfQkFTRX0vbWUvcGxheWVyL2RldmljZXNgLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnR0VUJyxcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7c3RvcmUuZ2V0U3RhdGUoKS5zZXNzaW9uLmFjY2Vzc190b2tlbn1gXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICAgIC50aGVuKHIgPT4gci5qc29uKCkpXHJcbiAgICAgICAgLnRoZW4ociA9PiB7XHJcbiAgICAgICAgICBpZiAoci5lcnJvcikge1xyXG4gICAgICAgICAgICBzdG9yZS5kaXNwYXRjaChmZXRjaEF2YWlsYWJsZURldmljZXNFcnJvcihyLmVycm9yKSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzdG9yZS5kaXNwYXRjaChmZXRjaEF2YWlsYWJsZURldmljZXNTdWNjZXNzKHIuZGV2aWNlcykpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICBicmVhaztcclxuICAgIH1cclxuICAgIGNhc2UgVFJBTlNGRVJfUExBWUJBQ0tfVE9fREVWSUNFOiB7XHJcbiAgICAgIGZldGNoKGAke1NQT1RJRllfQVBJX0JBU0V9L21lL3BsYXllcmAsIHtcclxuICAgICAgICBtZXRob2Q6ICdQVVQnLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtzdG9yZS5nZXRTdGF0ZSgpLnNlc3Npb24uYWNjZXNzX3Rva2VufWBcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgIGRldmljZV9pZHM6IFthY3Rpb24uZGV2aWNlSWRdXHJcbiAgICAgICAgfSlcclxuICAgICAgfSlcclxuICAgICAgICAudGhlbihyID0+IHIuanNvbigpKVxyXG4gICAgICAgIC50aGVuKHIgPT4ge1xyXG4gICAgICAgICAgaWYgKHIuZXJyb3IpIHtcclxuICAgICAgICAgICAgc3RvcmUuZGlzcGF0Y2godHJhbnNmZXJQbGF5YmFja1RvRGV2aWNlRXJyb3Ioci5lcnJvcikpO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgc3RvcmUuZGlzcGF0Y2godHJhbnNmZXJQbGF5YmFja1RvRGV2aWNlU3VjY2VzcygpKTtcclxuICAgICAgICAgICAgc3RvcmUuZGlzcGF0Y2goZmV0Y2hBdmFpbGFibGVEZXZpY2VzKCkpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICBicmVhaztcclxuICAgIH1cclxuXHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICBicmVhaztcclxuICB9XHJcblxyXG4gIHJldHVybiByZXN1bHQ7XHJcbn07XHJcbiIsImV4cG9ydCBkZWZhdWx0IHN0b3JlID0+IG5leHQgPT4gYWN0aW9uID0+IHtcclxuICBjb25zdCByZXN1bHQgPSBuZXh0KGFjdGlvbik7XHJcbiAgY29uc29sZS5sb2coYWN0aW9uKTtcclxufTtcclxuIiwiaW1wb3J0IGZldGNoIGZyb20gJ2lzb21vcnBoaWMtdW5mZXRjaCc7XHJcblxyXG5pbXBvcnQgeyBQTEFZX1RSQUNLLCBVTk1VVEVfUExBWUJBQ0sgfSBmcm9tICcuLi9jb25zdGFudHMvQWN0aW9uVHlwZXMnO1xyXG5pbXBvcnQgeyBwbGF5VHJhY2ssIHBsYXlUcmFja1N1Y2Nlc3MgfSBmcm9tICcuLi9hY3Rpb25zL3BsYXliYWNrQWN0aW9ucyc7XHJcbmltcG9ydCB7IGZldGNoQXZhaWxhYmxlRGV2aWNlc0Vycm9yLCBmZXRjaEF2YWlsYWJsZURldmljZXNTdWNjZXNzIH0gZnJvbSAnLi4vYWN0aW9ucy9kZXZpY2VzQWN0aW9ucyc7XHJcblxyXG5jb25zdCBTUE9USUZZX0FQSV9CQVNFID0gJ2h0dHBzOi8vYXBpLnNwb3RpZnkuY29tL3YxJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHN0b3JlID0+IG5leHQgPT4gYWN0aW9uID0+IHtcclxuICBjb25zdCByZXN1bHQgPSBuZXh0KGFjdGlvbik7XHJcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgY2FzZSBQTEFZX1RSQUNLOiB7XHJcbiAgICAgIGlmIChwcm9jZXNzLmJyb3dzZXIgJiYgIXN0b3JlLmdldFN0YXRlKCkucGxheWJhY2subXV0ZWQpIHtcclxuICAgICAgICBmZXRjaChgJHtTUE9USUZZX0FQSV9CQVNFfS9tZS9wbGF5ZXIvcGxheWAsIHtcclxuICAgICAgICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHtzdG9yZS5nZXRTdGF0ZSgpLnNlc3Npb24uYWNjZXNzX3Rva2VufWBcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgIHVyaXM6IFtgc3BvdGlmeTp0cmFjazoke2FjdGlvbi50cmFjay5pZH1gXVxyXG4gICAgICAgICAgfSlcclxuICAgICAgICB9KS50aGVuKCgpID0+IHtcclxuICAgICAgICAgIGlmIChhY3Rpb24ucG9zaXRpb24pIHtcclxuICAgICAgICAgICAgZmV0Y2goYCR7U1BPVElGWV9BUElfQkFTRX0vbWUvcGxheWVyL3NlZWs/cG9zaXRpb25fbXM9JHthY3Rpb24ucG9zaXRpb259YCwge1xyXG4gICAgICAgICAgICAgIG1ldGhvZDogJ1BVVCcsXHJcbiAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3N0b3JlLmdldFN0YXRlKCkuc2Vzc2lvbi5hY2Nlc3NfdG9rZW59YFxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSkudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgc3RvcmUuZGlzcGF0Y2gocGxheVRyYWNrU3VjY2VzcyhhY3Rpb24udHJhY2ssIGFjdGlvbi51c2VyLCBhY3Rpb24ucG9zaXRpb24pKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzdG9yZS5kaXNwYXRjaChwbGF5VHJhY2tTdWNjZXNzKGFjdGlvbi50cmFjaywgYWN0aW9uLnVzZXIpKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICBicmVhaztcclxuICAgIH1cclxuICAgIGNhc2UgVU5NVVRFX1BMQVlCQUNLOiB7XHJcbiAgICAgIGNvbnN0IHsgdHJhY2ssIHVzZXIsIHBvc2l0aW9uLCBzdGFydFRpbWUgfSA9IHN0b3JlLmdldFN0YXRlKCkucGxheWJhY2s7XHJcbiAgICAgIGNvbnN0IGN1cnJlbnRQb3NpdGlvbiA9IERhdGUubm93KCkgLSBzdGFydFRpbWUgKyBwb3NpdGlvbjtcclxuICAgICAgc3RvcmUuZGlzcGF0Y2gocGxheVRyYWNrKHRyYWNrLCB1c2VyLCBjdXJyZW50UG9zaXRpb24pKTtcclxuICAgICAgYnJlYWs7XHJcbiAgICB9XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICBicmVhaztcclxuICB9XHJcblxyXG4gIHJldHVybiByZXN1bHQ7XHJcbn07XHJcbiIsImltcG9ydCBmZXRjaCBmcm9tICdpc29tb3JwaGljLXVuZmV0Y2gnO1xyXG5cclxuaW1wb3J0IHsgU0VBUkNIX1RSQUNLUyB9IGZyb20gJy4uL2NvbnN0YW50cy9BY3Rpb25UeXBlcyc7XHJcbmltcG9ydCB7IHNlYXJjaFRyYWNrc1N1Y2Nlc3MgfSBmcm9tICcuLi9hY3Rpb25zL3NlYXJjaEFjdGlvbnMnO1xyXG5cclxuY29uc3QgU1BPVElGWV9BUElfQkFTRSA9ICdodHRwczovL2FwaS5zcG90aWZ5LmNvbS92MSc7XHJcblxyXG5jb25zdCBzZWFyY2hUcmFja3MgPSBxdWVyeSA9PiAoZGlzcGF0Y2gsIGdldFN0YXRlKSA9PiB7XHJcbiAgbGV0IHNob3VsZEFkZFdpbGRjYXJkID0gZmFsc2U7XHJcbiAgaWYgKHF1ZXJ5Lmxlbmd0aCA+IDEpIHtcclxuICAgIGNvbnN0IHdvcmRzID0gcXVlcnkuc3BsaXQoJyAnKTtcclxuICAgIGNvbnN0IGxhc3RXb3JkID0gd29yZHNbd29yZHMubGVuZ3RoIC0gMV07XHJcbiAgICBpZiAoL15bYS16MC05XFxzXSskL2kudGVzdChsYXN0V29yZCkgJiYgcXVlcnkubGFzdEluZGV4T2YoJyonKSAhPT0gcXVlcnkubGVuZ3RoIC0gMSkge1xyXG4gICAgICBzaG91bGRBZGRXaWxkY2FyZCA9IHRydWU7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCB3aWxkY2FyZFF1ZXJ5ID0gYCR7cXVlcnl9JHtzaG91bGRBZGRXaWxkY2FyZCA/ICcqJyA6ICcnfWA7IC8vIFRyaWNrIHRvIGltcHJvdmUgc2VhcmNoIHJlc3VsdHNcclxuXHJcbiAgcmV0dXJuIGZldGNoKGAke1NQT1RJRllfQVBJX0JBU0V9L3NlYXJjaD9xPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHdpbGRjYXJkUXVlcnkpfSZ0eXBlPXRyYWNrJmxpbWl0PTEwYCwge1xyXG4gICAgaGVhZGVyczoge1xyXG4gICAgICBBdXRob3JpemF0aW9uOiAnQmVhcmVyICcgKyBnZXRTdGF0ZSgpLnNlc3Npb24uYWNjZXNzX3Rva2VuXHJcbiAgICB9XHJcbiAgfSlcclxuICAgIC50aGVuKHJlcyA9PiByZXMuanNvbigpKVxyXG4gICAgLnRoZW4ocmVzID0+IHtcclxuICAgICAgZGlzcGF0Y2goc2VhcmNoVHJhY2tzU3VjY2VzcyhxdWVyeSwgcmVzLnRyYWNrcy5pdGVtcykpO1xyXG4gICAgfSk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBzdG9yZSA9PiBuZXh0ID0+IGFjdGlvbiA9PiB7XHJcbiAgY29uc3QgcmVzdWx0ID0gbmV4dChhY3Rpb24pO1xyXG4gIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgIGNhc2UgU0VBUkNIX1RSQUNLUzoge1xyXG4gICAgICByZXR1cm4gc3RvcmUuZGlzcGF0Y2goc2VhcmNoVHJhY2tzKGFjdGlvbi5xdWVyeSkpO1xyXG4gICAgICBicmVhaztcclxuICAgIH1cclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIGJyZWFrO1xyXG4gIH1cclxuICByZXR1cm4gcmVzdWx0O1xyXG59O1xyXG4iLCJpbXBvcnQgZmV0Y2ggZnJvbSAnaXNvbW9ycGhpYy11bmZldGNoJztcclxuXHJcbmltcG9ydCB7IExPQUQsIExPR0lOIH0gZnJvbSAnLi4vY29uc3RhbnRzL0FjdGlvblR5cGVzJztcclxuaW1wb3J0IHsgbG9naW5TdWNjZXNzLCB1cGRhdGVDdXJyZW50VXNlciwgdXBkYXRlVG9rZW5TdWNjZXNzIH0gZnJvbSAnLi4vYWN0aW9ucy9zZXNzaW9uQWN0aW9ucyc7XHJcblxyXG5pbXBvcnQgKiBhcyBDb25maWcgZnJvbSAnLi4vY29uZmlnL2FwcCc7XHJcblxyXG5jb25zdCBTUE9USUZZX0FQSV9CQVNFID0gJ2h0dHBzOi8vYXBpLnNwb3RpZnkuY29tL3YxJztcclxuXHJcbmNvbnN0IGdldEN1cnJlbnRVc2VyID0gKCkgPT4gKGRpc3BhdGNoLCBnZXRTdGF0ZSkgPT5cclxuICBmZXRjaChgJHtTUE9USUZZX0FQSV9CQVNFfS9tZWAsIHtcclxuICAgIGhlYWRlcnM6IHtcclxuICAgICAgQXV0aG9yaXphdGlvbjogJ0JlYXJlciAnICsgZ2V0U3RhdGUoKS5zZXNzaW9uLmFjY2Vzc190b2tlblxyXG4gICAgfVxyXG4gIH0pXHJcbiAgICAudGhlbihyZXMgPT4gcmVzLmpzb24oKSlcclxuICAgIC50aGVuKHJlcyA9PiB7XHJcbiAgICAgIGRpc3BhdGNoKHVwZGF0ZUN1cnJlbnRVc2VyKHJlcykpO1xyXG4gICAgfSk7XHJcblxyXG5jb25zdCB1cGRhdGVUb2tlbiA9ICgpID0+IChkaXNwYXRjaCwgZ2V0U3RhdGUpID0+IHtcclxuICByZXR1cm4gZmV0Y2goYCR7Q29uZmlnLkhPU1R9L2F1dGgvdG9rZW5gLCB7XHJcbiAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgcmVmcmVzaF90b2tlbjogZ2V0U3RhdGUoKS5zZXNzaW9uLnJlZnJlc2hfdG9rZW5cclxuICAgIH0pLFxyXG4gICAgaGVhZGVyczogbmV3IEhlYWRlcnMoe1xyXG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nXHJcbiAgICB9KVxyXG4gIH0pXHJcbiAgICAudGhlbihyZXMgPT4gcmVzLmpzb24oKSlcclxuICAgIC50aGVuKHJlcyA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKHJlcyk7XHJcbiAgICAgIGRpc3BhdGNoKHVwZGF0ZVRva2VuU3VjY2VzcyhyZXMuYWNjZXNzX3Rva2VuKSk7XHJcbiAgICB9KTtcclxufTtcclxuXHJcbi8vIHRvZG86IHNldCBhIHRpbWVyLCBib3RoIGNsaWVudC1zaWRlIGFuZCBzZXJ2ZXItc2lkZVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgc3RvcmUgPT4gbmV4dCA9PiBhY3Rpb24gPT4ge1xyXG4gIGNvbnN0IHJlc3VsdCA9IG5leHQoYWN0aW9uKTtcclxuICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XHJcbiAgICBjYXNlIExPQUQ6IHtcclxuICAgICAgY29uc3Qgc2Vzc2lvbiA9IHN0b3JlLmdldFN0YXRlKCkuc2Vzc2lvbjtcclxuICAgICAgY29uc3QgZXhwaXJlc0luID0gc2Vzc2lvbi5leHBpcmVzX2luO1xyXG4gICAgICBjb25zdCBuZWVkc1RvVXBkYXRlID0gIWV4cGlyZXNJbiB8fCBleHBpcmVzSW4gLSBEYXRlLm5vdygpIDwgMTAgKiA2MCAqIDEwMDA7XHJcbiAgICAgIGlmIChuZWVkc1RvVXBkYXRlKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ3Nlc3Npb25NaWRkbGV3YXJlID4gbmVlZHMgdG8gdXBkYXRlIGFjY2VzcyB0b2tlbicpO1xyXG4gICAgICAgIGNvbnN0IHJlZnJlc2hUb2tlbiA9IHNlc3Npb24ucmVmcmVzaF90b2tlbjtcclxuICAgICAgICBpZiAocmVmcmVzaFRva2VuKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygnc2Vzc2lvbk1pZGRsZXdhcmUgPiB1c2luZyByZWZyZXNoIHRva2VuJyk7XHJcbiAgICAgICAgICBzdG9yZVxyXG4gICAgICAgICAgICAuZGlzcGF0Y2godXBkYXRlVG9rZW4oKSlcclxuICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgIHJldHVybiBzdG9yZS5kaXNwYXRjaChnZXRDdXJyZW50VXNlcigpKTtcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgIHN0b3JlLmRpc3BhdGNoKGxvZ2luU3VjY2VzcygpKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdzZXNzaW9uTWlkZGxld2FyZSA+IG5vIG5lZWQgdG8gdXBkYXRlIGFjY2VzcyB0b2tlbicpO1xyXG4gICAgICAgIHN0b3JlLmRpc3BhdGNoKGdldEN1cnJlbnRVc2VyKCkpLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgc3RvcmUuZGlzcGF0Y2gobG9naW5TdWNjZXNzKCkpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgfVxyXG4gICAgY2FzZSBMT0dJTjoge1xyXG4gICAgICBjb25zdCBnZXRMb2dpblVSTCA9IHNjb3BlcyA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGAke0NvbmZpZy5IT1NUfS9hdXRoL2xvZ2luP3Njb3BlPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHNjb3Blcy5qb2luKCcgJykpfWA7XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCB3aWR0aCA9IDQ1MCxcclxuICAgICAgICBoZWlnaHQgPSA3MzAsXHJcbiAgICAgICAgbGVmdCA9IHdpbmRvdy5zY3JlZW4ud2lkdGggLyAyIC0gd2lkdGggLyAyLFxyXG4gICAgICAgIHRvcCA9IHdpbmRvdy5zY3JlZW4uaGVpZ2h0IC8gMiAtIGhlaWdodCAvIDI7XHJcblxyXG4gICAgICBjb25zdCBtZXNzYWdlRm4gPSBldmVudCA9PiB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGNvbnN0IGhhc2ggPSBKU09OLnBhcnNlKGV2ZW50LmRhdGEpO1xyXG4gICAgICAgICAgaWYgKGhhc2gudHlwZSA9PT0gJ2FjY2Vzc190b2tlbicpIHtcclxuICAgICAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCBtZXNzYWdlRm4sIGZhbHNlKTtcclxuICAgICAgICAgICAgY29uc3QgYWNjZXNzVG9rZW4gPSBoYXNoLmFjY2Vzc190b2tlbjtcclxuICAgICAgICAgICAgY29uc3QgZXhwaXJlc0luID0gaGFzaC5leHBpcmVzX2luO1xyXG4gICAgICAgICAgICBpZiAoYWNjZXNzVG9rZW4gPT09ICcnKSB7XHJcbiAgICAgICAgICAgICAgLy8gdG9kbzogaW1wbGVtZW50IGxvZ2luIGVycm9yXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgcmVmcmVzaFRva2VuID0gaGFzaC5yZWZyZXNoX3Rva2VuO1xyXG4gICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdyZWZyZXNoVG9rZW4nLCByZWZyZXNoVG9rZW4pO1xyXG4gICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdhY2Nlc3NUb2tlbicsIGFjY2Vzc1Rva2VuKTtcclxuICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnZXhwaXJlc0luJywgRGF0ZS5ub3coKSArIGV4cGlyZXNJbiAqIDEwMDApO1xyXG4gICAgICAgICAgICAgIHN0b3JlLmRpc3BhdGNoKHVwZGF0ZVRva2VuU3VjY2VzcyhhY2Nlc3NUb2tlbikpO1xyXG4gICAgICAgICAgICAgIHN0b3JlLmRpc3BhdGNoKGdldEN1cnJlbnRVc2VyKCkpLnRoZW4oKCkgPT4gc3RvcmUuZGlzcGF0Y2gobG9naW5TdWNjZXNzKCkpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIC8vIGRvIG5vdGhpbmdcclxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9O1xyXG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbWVzc2FnZScsIG1lc3NhZ2VGbiwgZmFsc2UpO1xyXG5cclxuICAgICAgY29uc3QgdXJsID0gZ2V0TG9naW5VUkwoWyd1c2VyLXJlYWQtcGxheWJhY2stc3RhdGUnLCAndXNlci1tb2RpZnktcGxheWJhY2stc3RhdGUnXSk7XHJcbiAgICAgIHdpbmRvdy5vcGVuKFxyXG4gICAgICAgIHVybCxcclxuICAgICAgICAnU3BvdGlmeScsXHJcbiAgICAgICAgJ21lbnViYXI9bm8sbG9jYXRpb249bm8scmVzaXphYmxlPW5vLHNjcm9sbGJhcnM9bm8sc3RhdHVzPW5vLCB3aWR0aD0nICtcclxuICAgICAgICAgIHdpZHRoICtcclxuICAgICAgICAgICcsIGhlaWdodD0nICtcclxuICAgICAgICAgIGhlaWdodCArXHJcbiAgICAgICAgICAnLCB0b3A9JyArXHJcbiAgICAgICAgICB0b3AgK1xyXG4gICAgICAgICAgJywgbGVmdD0nICtcclxuICAgICAgICAgIGxlZnRcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGJyZWFrO1xyXG4gICAgfVxyXG4gICAgZGVmYXVsdDpcclxuICAgICAgYnJlYWs7XHJcbiAgfVxyXG4gIHJldHVybiByZXN1bHQ7XHJcbn07XHJcbiIsImltcG9ydCB7IFZPVEVfVVAsIExPR0lOX1NVQ0NFU1MsIFFVRVVFX1JFTU9WRV9UUkFDSywgUVVFVUVfVFJBQ0sgfSBmcm9tICcuLi9jb25zdGFudHMvQWN0aW9uVHlwZXMnO1xyXG5pbXBvcnQgeyB1cGRhdGVVc2VycyB9IGZyb20gJy4uL2FjdGlvbnMvdXNlcnNBY3Rpb25zJztcclxuaW1wb3J0IHsgdXBkYXRlUXVldWUsIHF1ZXVlRW5kZWQgfSBmcm9tICcuLi9hY3Rpb25zL3F1ZXVlQWN0aW9ucyc7XHJcbmltcG9ydCB7IHBsYXlUcmFjaywgdXBkYXRlTm93UGxheWluZyB9IGZyb20gJy4uL2FjdGlvbnMvcGxheWJhY2tBY3Rpb25zJztcclxuaW1wb3J0IENvbmZpZyBmcm9tICcuLi9jb25maWcvYXBwJztcclxuXHJcbmltcG9ydCBpbyBmcm9tICdzb2NrZXQuaW8tY2xpZW50JztcclxuXHJcbnZhciBzb2NrZXQgPSBudWxsO1xyXG5cclxuY29uc3QgZ2V0SWRGcm9tVHJhY2tTdHJpbmcgPSAodHJhY2tTdHJpbmcgPSAnJykgPT4ge1xyXG4gIGxldCBtYXRjaGVzID0gdHJhY2tTdHJpbmcubWF0Y2goL15odHRwczpcXC9cXC9vcGVuXFwuc3BvdGlmeVxcLmNvbVxcL3RyYWNrXFwvKC4qKS8pO1xyXG4gIGlmIChtYXRjaGVzKSB7XHJcbiAgICByZXR1cm4gbWF0Y2hlc1sxXTtcclxuICB9XHJcblxyXG4gIG1hdGNoZXMgPSB0cmFja1N0cmluZy5tYXRjaCgvXmh0dHBzOlxcL1xcL3BsYXlcXC5zcG90aWZ5XFwuY29tXFwvdHJhY2tcXC8oLiopLyk7XHJcbiAgaWYgKG1hdGNoZXMpIHtcclxuICAgIHJldHVybiBtYXRjaGVzWzFdO1xyXG4gIH1cclxuXHJcbiAgbWF0Y2hlcyA9IHRyYWNrU3RyaW5nLm1hdGNoKC9ec3BvdGlmeTp0cmFjazooLiopLyk7XHJcbiAgaWYgKG1hdGNoZXMpIHtcclxuICAgIHJldHVybiBtYXRjaGVzWzFdO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIG51bGw7XHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc29ja2V0TWlkZGxld2FyZShzdG9yZSkge1xyXG4gIHJldHVybiBuZXh0ID0+IGFjdGlvbiA9PiB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBuZXh0KGFjdGlvbik7XHJcblxyXG4gICAgaWYgKHNvY2tldCkge1xyXG4gICAgICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XHJcbiAgICAgICAgY2FzZSBRVUVVRV9UUkFDSzoge1xyXG4gICAgICAgICAgbGV0IHRyYWNrSWQgPSBnZXRJZEZyb21UcmFja1N0cmluZyhhY3Rpb24uaWQpO1xyXG4gICAgICAgICAgaWYgKHRyYWNrSWQgPT09IG51bGwpIHtcclxuICAgICAgICAgICAgdHJhY2tJZCA9IGFjdGlvbi5pZDtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHNvY2tldC5lbWl0KCdxdWV1ZSB0cmFjaycsIHRyYWNrSWQpO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgUVVFVUVfUkVNT1ZFX1RSQUNLOiB7XHJcbiAgICAgICAgICBzb2NrZXQuZW1pdCgncmVtb3ZlIHRyYWNrJywgYWN0aW9uLmlkKTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIExPR0lOX1NVQ0NFU1M6XHJcbiAgICAgICAgICBjb25zdCB1c2VyID0gc3RvcmUuZ2V0U3RhdGUoKS5zZXNzaW9uLnVzZXI7XHJcbiAgICAgICAgICBzb2NrZXQuZW1pdCgndXNlciBsb2dpbicsIHVzZXIpO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSBWT1RFX1VQOlxyXG4gICAgICAgICAgc29ja2V0LmVtaXQoJ3ZvdGUgdXAnLCBhY3Rpb24uaWQpO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuICB9O1xyXG59XHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uKHN0b3JlKSB7XHJcbiAgc29ja2V0ID0gaW8uY29ubmVjdChDb25maWcuSE9TVCk7XHJcblxyXG4gIHNvY2tldC5vbigndXBkYXRlIHF1ZXVlJywgZGF0YSA9PiB7XHJcbiAgICBzdG9yZS5kaXNwYXRjaCh1cGRhdGVRdWV1ZShkYXRhKSk7XHJcbiAgfSk7XHJcblxyXG4gIHNvY2tldC5vbigncXVldWUgZW5kZWQnLCAoKSA9PiB7XHJcbiAgICBzdG9yZS5kaXNwYXRjaChxdWV1ZUVuZGVkKCkpO1xyXG4gIH0pO1xyXG5cclxuICBzb2NrZXQub24oJ3BsYXkgdHJhY2snLCAodHJhY2ssIHVzZXIsIHBvc2l0aW9uKSA9PiB7XHJcbiAgICAvLyB3ZSBzaG91bGQgYWxzbyBzZXQgcmVwZWF0IHRvIGZhbHNlIVxyXG4gICAgc3RvcmUuZGlzcGF0Y2gocGxheVRyYWNrKHRyYWNrLCB1c2VyLCBwb3NpdGlvbikpO1xyXG4gIH0pO1xyXG5cclxuICBzb2NrZXQub24oJ3VwZGF0ZSB1c2VycycsIGRhdGEgPT4ge1xyXG4gICAgc3RvcmUuZGlzcGF0Y2godXBkYXRlVXNlcnMoZGF0YSkpO1xyXG4gIH0pO1xyXG5cclxuICBzb2NrZXQub24oJ3VwZGF0ZSBub3cgcGxheWluZycsICh0cmFjaywgdXNlciwgcG9zaXRpb24pID0+IHtcclxuICAgIHN0b3JlLmRpc3BhdGNoKHVwZGF0ZU5vd1BsYXlpbmcodHJhY2ssIHVzZXIsIHBvc2l0aW9uKSk7XHJcbiAgfSk7XHJcblxyXG4gIC8vIHRvZG86IG1hbmFnZSBlbmQgc29uZywgZW5kIHF1ZXVlXHJcbn1cclxuIiwiZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICBcImRlZmF1bHRcIjogb2JqXG4gIH07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdDsiLCJ2YXIgX3R5cGVvZiA9IHJlcXVpcmUoXCIuLi9oZWxwZXJzL3R5cGVvZlwiKTtcblxuZnVuY3Rpb24gX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlKCkge1xuICBpZiAodHlwZW9mIFdlYWtNYXAgIT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIG51bGw7XG4gIHZhciBjYWNoZSA9IG5ldyBXZWFrTWFwKCk7XG5cbiAgX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlID0gZnVuY3Rpb24gX2dldFJlcXVpcmVXaWxkY2FyZENhY2hlKCkge1xuICAgIHJldHVybiBjYWNoZTtcbiAgfTtcblxuICByZXR1cm4gY2FjaGU7XG59XG5cbmZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkKG9iaikge1xuICBpZiAob2JqICYmIG9iai5fX2VzTW9kdWxlKSB7XG4gICAgcmV0dXJuIG9iajtcbiAgfVxuXG4gIGlmIChvYmogPT09IG51bGwgfHwgX3R5cGVvZihvYmopICE9PSBcIm9iamVjdFwiICYmIHR5cGVvZiBvYmogIT09IFwiZnVuY3Rpb25cIikge1xuICAgIHJldHVybiB7XG4gICAgICBcImRlZmF1bHRcIjogb2JqXG4gICAgfTtcbiAgfVxuXG4gIHZhciBjYWNoZSA9IF9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSgpO1xuXG4gIGlmIChjYWNoZSAmJiBjYWNoZS5oYXMob2JqKSkge1xuICAgIHJldHVybiBjYWNoZS5nZXQob2JqKTtcbiAgfVxuXG4gIHZhciBuZXdPYmogPSB7fTtcbiAgdmFyIGhhc1Byb3BlcnR5RGVzY3JpcHRvciA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSAmJiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yO1xuXG4gIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwga2V5KSkge1xuICAgICAgdmFyIGRlc2MgPSBoYXNQcm9wZXJ0eURlc2NyaXB0b3IgPyBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG9iaiwga2V5KSA6IG51bGw7XG5cbiAgICAgIGlmIChkZXNjICYmIChkZXNjLmdldCB8fCBkZXNjLnNldCkpIHtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG5ld09iaiwga2V5LCBkZXNjKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG5ld09ialtrZXldID0gb2JqW2tleV07XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgbmV3T2JqW1wiZGVmYXVsdFwiXSA9IG9iajtcblxuICBpZiAoY2FjaGUpIHtcbiAgICBjYWNoZS5zZXQob2JqLCBuZXdPYmopO1xuICB9XG5cbiAgcmV0dXJuIG5ld09iajtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZDsiLCJmdW5jdGlvbiBfdHlwZW9mKG9iaikge1xuICBcIkBiYWJlbC9oZWxwZXJzIC0gdHlwZW9mXCI7XG5cbiAgaWYgKHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgU3ltYm9sLml0ZXJhdG9yID09PSBcInN5bWJvbFwiKSB7XG4gICAgbW9kdWxlLmV4cG9ydHMgPSBfdHlwZW9mID0gZnVuY3Rpb24gX3R5cGVvZihvYmopIHtcbiAgICAgIHJldHVybiB0eXBlb2Ygb2JqO1xuICAgIH07XG4gIH0gZWxzZSB7XG4gICAgbW9kdWxlLmV4cG9ydHMgPSBfdHlwZW9mID0gZnVuY3Rpb24gX3R5cGVvZihvYmopIHtcbiAgICAgIHJldHVybiBvYmogJiYgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9iai5jb25zdHJ1Y3RvciA9PT0gU3ltYm9sICYmIG9iaiAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2Ygb2JqO1xuICAgIH07XG4gIH1cblxuICByZXR1cm4gX3R5cGVvZihvYmopO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF90eXBlb2Y7IiwiaW1wb3J0IFJlYWN0LCB7IENoaWxkcmVuIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBVcmxPYmplY3QgfSBmcm9tICd1cmwnXG5pbXBvcnQge1xuICBhZGRCYXNlUGF0aCxcbiAgYWRkTG9jYWxlLFxuICBpc0xvY2FsVVJMLFxuICBOZXh0Um91dGVyLFxuICBQcmVmZXRjaE9wdGlvbnMsXG4gIHJlc29sdmVIcmVmLFxufSBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3JvdXRlcidcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJy4vcm91dGVyJ1xuXG50eXBlIFVybCA9IHN0cmluZyB8IFVybE9iamVjdFxudHlwZSBSZXF1aXJlZEtleXM8VD4gPSB7XG4gIFtLIGluIGtleW9mIFRdLT86IHt9IGV4dGVuZHMgUGljazxULCBLPiA/IG5ldmVyIDogS1xufVtrZXlvZiBUXVxudHlwZSBPcHRpb25hbEtleXM8VD4gPSB7XG4gIFtLIGluIGtleW9mIFRdLT86IHt9IGV4dGVuZHMgUGljazxULCBLPiA/IEsgOiBuZXZlclxufVtrZXlvZiBUXVxuXG5leHBvcnQgdHlwZSBMaW5rUHJvcHMgPSB7XG4gIGhyZWY6IFVybFxuICBhcz86IFVybFxuICByZXBsYWNlPzogYm9vbGVhblxuICBzY3JvbGw/OiBib29sZWFuXG4gIHNoYWxsb3c/OiBib29sZWFuXG4gIHBhc3NIcmVmPzogYm9vbGVhblxuICBwcmVmZXRjaD86IGJvb2xlYW5cbn1cbnR5cGUgTGlua1Byb3BzUmVxdWlyZWQgPSBSZXF1aXJlZEtleXM8TGlua1Byb3BzPlxudHlwZSBMaW5rUHJvcHNPcHRpb25hbCA9IE9wdGlvbmFsS2V5czxMaW5rUHJvcHM+XG5cbmxldCBjYWNoZWRPYnNlcnZlcjogSW50ZXJzZWN0aW9uT2JzZXJ2ZXJcbmNvbnN0IGxpc3RlbmVycyA9IG5ldyBNYXA8RWxlbWVudCwgKCkgPT4gdm9pZD4oKVxuY29uc3QgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPVxuICB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyA/IHdpbmRvdy5JbnRlcnNlY3Rpb25PYnNlcnZlciA6IG51bGxcbmNvbnN0IHByZWZldGNoZWQ6IHsgW2NhY2hlS2V5OiBzdHJpbmddOiBib29sZWFuIH0gPSB7fVxuXG5mdW5jdGlvbiBnZXRPYnNlcnZlcigpOiBJbnRlcnNlY3Rpb25PYnNlcnZlciB8IHVuZGVmaW5lZCB7XG4gIC8vIFJldHVybiBzaGFyZWQgaW5zdGFuY2Ugb2YgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgaWYgYWxyZWFkeSBjcmVhdGVkXG4gIGlmIChjYWNoZWRPYnNlcnZlcikge1xuICAgIHJldHVybiBjYWNoZWRPYnNlcnZlclxuICB9XG5cbiAgLy8gT25seSBjcmVhdGUgc2hhcmVkIEludGVyc2VjdGlvbk9ic2VydmVyIGlmIHN1cHBvcnRlZCBpbiBicm93c2VyXG4gIGlmICghSW50ZXJzZWN0aW9uT2JzZXJ2ZXIpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkXG4gIH1cblxuICByZXR1cm4gKGNhY2hlZE9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKFxuICAgIChlbnRyaWVzKSA9PiB7XG4gICAgICBlbnRyaWVzLmZvckVhY2goKGVudHJ5KSA9PiB7XG4gICAgICAgIGlmICghbGlzdGVuZXJzLmhhcyhlbnRyeS50YXJnZXQpKSB7XG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBjYiA9IGxpc3RlbmVycy5nZXQoZW50cnkudGFyZ2V0KSFcbiAgICAgICAgaWYgKGVudHJ5LmlzSW50ZXJzZWN0aW5nIHx8IGVudHJ5LmludGVyc2VjdGlvblJhdGlvID4gMCkge1xuICAgICAgICAgIGNhY2hlZE9ic2VydmVyLnVub2JzZXJ2ZShlbnRyeS50YXJnZXQpXG4gICAgICAgICAgbGlzdGVuZXJzLmRlbGV0ZShlbnRyeS50YXJnZXQpXG4gICAgICAgICAgY2IoKVxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH0sXG4gICAgeyByb290TWFyZ2luOiAnMjAwcHgnIH1cbiAgKSlcbn1cblxuY29uc3QgbGlzdGVuVG9JbnRlcnNlY3Rpb25zID0gKGVsOiBFbGVtZW50LCBjYjogKCkgPT4gdm9pZCkgPT4ge1xuICBjb25zdCBvYnNlcnZlciA9IGdldE9ic2VydmVyKClcbiAgaWYgKCFvYnNlcnZlcikge1xuICAgIHJldHVybiAoKSA9PiB7fVxuICB9XG5cbiAgb2JzZXJ2ZXIub2JzZXJ2ZShlbClcbiAgbGlzdGVuZXJzLnNldChlbCwgY2IpXG4gIHJldHVybiAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIG9ic2VydmVyLnVub2JzZXJ2ZShlbClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxuICAgIH1cbiAgICBsaXN0ZW5lcnMuZGVsZXRlKGVsKVxuICB9XG59XG5cbmZ1bmN0aW9uIHByZWZldGNoKFxuICByb3V0ZXI6IE5leHRSb3V0ZXIsXG4gIGhyZWY6IHN0cmluZyxcbiAgYXM6IHN0cmluZyxcbiAgb3B0aW9ucz86IFByZWZldGNoT3B0aW9uc1xuKTogdm9pZCB7XG4gIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykgcmV0dXJuXG4gIGlmICghaXNMb2NhbFVSTChocmVmKSkgcmV0dXJuXG4gIC8vIFByZWZldGNoIHRoZSBKU09OIHBhZ2UgaWYgYXNrZWQgKG9ubHkgaW4gdGhlIGNsaWVudClcbiAgLy8gV2UgbmVlZCB0byBoYW5kbGUgYSBwcmVmZXRjaCBlcnJvciBoZXJlIHNpbmNlIHdlIG1heSBiZVxuICAvLyBsb2FkaW5nIHdpdGggcHJpb3JpdHkgd2hpY2ggY2FuIHJlamVjdCBidXQgd2UgZG9uJ3RcbiAgLy8gd2FudCB0byBmb3JjZSBuYXZpZ2F0aW9uIHNpbmNlIHRoaXMgaXMgb25seSBhIHByZWZldGNoXG4gIHJvdXRlci5wcmVmZXRjaChocmVmLCBhcywgb3B0aW9ucykuY2F0Y2goKGVycikgPT4ge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAvLyByZXRocm93IHRvIHNob3cgaW52YWxpZCBVUkwgZXJyb3JzXG4gICAgICB0aHJvdyBlcnJcbiAgICB9XG4gIH0pXG4gIC8vIEpvaW4gb24gYW4gaW52YWxpZCBVUkkgY2hhcmFjdGVyXG4gIHByZWZldGNoZWRbaHJlZiArICclJyArIGFzXSA9IHRydWVcbn1cblxuZnVuY3Rpb24gaXNNb2RpZmllZEV2ZW50KGV2ZW50OiBSZWFjdC5Nb3VzZUV2ZW50KSB7XG4gIGNvbnN0IHsgdGFyZ2V0IH0gPSBldmVudC5jdXJyZW50VGFyZ2V0IGFzIEhUTUxBbmNob3JFbGVtZW50XG4gIHJldHVybiAoXG4gICAgKHRhcmdldCAmJiB0YXJnZXQgIT09ICdfc2VsZicpIHx8XG4gICAgZXZlbnQubWV0YUtleSB8fFxuICAgIGV2ZW50LmN0cmxLZXkgfHxcbiAgICBldmVudC5zaGlmdEtleSB8fFxuICAgIGV2ZW50LmFsdEtleSB8fCAvLyB0cmlnZ2VycyByZXNvdXJjZSBkb3dubG9hZFxuICAgIChldmVudC5uYXRpdmVFdmVudCAmJiBldmVudC5uYXRpdmVFdmVudC53aGljaCA9PT0gMilcbiAgKVxufVxuXG5mdW5jdGlvbiBsaW5rQ2xpY2tlZChcbiAgZTogUmVhY3QuTW91c2VFdmVudCxcbiAgcm91dGVyOiBOZXh0Um91dGVyLFxuICBocmVmOiBzdHJpbmcsXG4gIGFzOiBzdHJpbmcsXG4gIHJlcGxhY2U/OiBib29sZWFuLFxuICBzaGFsbG93PzogYm9vbGVhbixcbiAgc2Nyb2xsPzogYm9vbGVhblxuKTogdm9pZCB7XG4gIGNvbnN0IHsgbm9kZU5hbWUgfSA9IGUuY3VycmVudFRhcmdldFxuXG4gIGlmIChub2RlTmFtZSA9PT0gJ0EnICYmIChpc01vZGlmaWVkRXZlbnQoZSkgfHwgIWlzTG9jYWxVUkwoaHJlZikpKSB7XG4gICAgLy8gaWdub3JlIGNsaWNrIGZvciBicm93c2Vy4oCZcyBkZWZhdWx0IGJlaGF2aW9yXG4gICAgcmV0dXJuXG4gIH1cblxuICBlLnByZXZlbnREZWZhdWx0KClcblxuICAvLyAgYXZvaWQgc2Nyb2xsIGZvciB1cmxzIHdpdGggYW5jaG9yIHJlZnNcbiAgaWYgKHNjcm9sbCA9PSBudWxsKSB7XG4gICAgc2Nyb2xsID0gYXMuaW5kZXhPZignIycpIDwgMFxuICB9XG5cbiAgLy8gcmVwbGFjZSBzdGF0ZSBpbnN0ZWFkIG9mIHB1c2ggaWYgcHJvcCBpcyBwcmVzZW50XG4gIHJvdXRlcltyZXBsYWNlID8gJ3JlcGxhY2UnIDogJ3B1c2gnXShocmVmLCBhcywgeyBzaGFsbG93IH0pLnRoZW4oXG4gICAgKHN1Y2Nlc3M6IGJvb2xlYW4pID0+IHtcbiAgICAgIGlmICghc3VjY2VzcykgcmV0dXJuXG4gICAgICBpZiAoc2Nyb2xsKSB7XG4gICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCAwKVxuICAgICAgICBkb2N1bWVudC5ib2R5LmZvY3VzKClcbiAgICAgIH1cbiAgICB9XG4gIClcbn1cblxuZnVuY3Rpb24gTGluayhwcm9wczogUmVhY3QuUHJvcHNXaXRoQ2hpbGRyZW48TGlua1Byb3BzPikge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGZ1bmN0aW9uIGNyZWF0ZVByb3BFcnJvcihhcmdzOiB7XG4gICAgICBrZXk6IHN0cmluZ1xuICAgICAgZXhwZWN0ZWQ6IHN0cmluZ1xuICAgICAgYWN0dWFsOiBzdHJpbmdcbiAgICB9KSB7XG4gICAgICByZXR1cm4gbmV3IEVycm9yKFxuICAgICAgICBgRmFpbGVkIHByb3AgdHlwZTogVGhlIHByb3AgXFxgJHthcmdzLmtleX1cXGAgZXhwZWN0cyBhICR7YXJncy5leHBlY3RlZH0gaW4gXFxgPExpbms+XFxgLCBidXQgZ290IFxcYCR7YXJncy5hY3R1YWx9XFxgIGluc3RlYWQuYCArXG4gICAgICAgICAgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnXG4gICAgICAgICAgICA/IFwiXFxuT3BlbiB5b3VyIGJyb3dzZXIncyBjb25zb2xlIHRvIHZpZXcgdGhlIENvbXBvbmVudCBzdGFjayB0cmFjZS5cIlxuICAgICAgICAgICAgOiAnJylcbiAgICAgIClcbiAgICB9XG5cbiAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgIGNvbnN0IHJlcXVpcmVkUHJvcHNHdWFyZDogUmVjb3JkPExpbmtQcm9wc1JlcXVpcmVkLCB0cnVlPiA9IHtcbiAgICAgIGhyZWY6IHRydWUsXG4gICAgfSBhcyBjb25zdFxuICAgIGNvbnN0IHJlcXVpcmVkUHJvcHM6IExpbmtQcm9wc1JlcXVpcmVkW10gPSBPYmplY3Qua2V5cyhcbiAgICAgIHJlcXVpcmVkUHJvcHNHdWFyZFxuICAgICkgYXMgTGlua1Byb3BzUmVxdWlyZWRbXVxuICAgIHJlcXVpcmVkUHJvcHMuZm9yRWFjaCgoa2V5OiBMaW5rUHJvcHNSZXF1aXJlZCkgPT4ge1xuICAgICAgaWYgKGtleSA9PT0gJ2hyZWYnKSB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICBwcm9wc1trZXldID09IG51bGwgfHxcbiAgICAgICAgICAodHlwZW9mIHByb3BzW2tleV0gIT09ICdzdHJpbmcnICYmIHR5cGVvZiBwcm9wc1trZXldICE9PSAnb2JqZWN0JylcbiAgICAgICAgKSB7XG4gICAgICAgICAgdGhyb3cgY3JlYXRlUHJvcEVycm9yKHtcbiAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgIGV4cGVjdGVkOiAnYHN0cmluZ2Agb3IgYG9iamVjdGAnLFxuICAgICAgICAgICAgYWN0dWFsOiBwcm9wc1trZXldID09PSBudWxsID8gJ251bGwnIDogdHlwZW9mIHByb3BzW2tleV0sXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gVHlwZVNjcmlwdCB0cmljayBmb3IgdHlwZS1ndWFyZGluZzpcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgICAgICBjb25zdCBfOiBuZXZlciA9IGtleVxuICAgICAgfVxuICAgIH0pXG5cbiAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgIGNvbnN0IG9wdGlvbmFsUHJvcHNHdWFyZDogUmVjb3JkPExpbmtQcm9wc09wdGlvbmFsLCB0cnVlPiA9IHtcbiAgICAgIGFzOiB0cnVlLFxuICAgICAgcmVwbGFjZTogdHJ1ZSxcbiAgICAgIHNjcm9sbDogdHJ1ZSxcbiAgICAgIHNoYWxsb3c6IHRydWUsXG4gICAgICBwYXNzSHJlZjogdHJ1ZSxcbiAgICAgIHByZWZldGNoOiB0cnVlLFxuICAgIH0gYXMgY29uc3RcbiAgICBjb25zdCBvcHRpb25hbFByb3BzOiBMaW5rUHJvcHNPcHRpb25hbFtdID0gT2JqZWN0LmtleXMoXG4gICAgICBvcHRpb25hbFByb3BzR3VhcmRcbiAgICApIGFzIExpbmtQcm9wc09wdGlvbmFsW11cbiAgICBvcHRpb25hbFByb3BzLmZvckVhY2goKGtleTogTGlua1Byb3BzT3B0aW9uYWwpID0+IHtcbiAgICAgIGlmIChrZXkgPT09ICdhcycpIHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgIHByb3BzW2tleV0gJiZcbiAgICAgICAgICB0eXBlb2YgcHJvcHNba2V5XSAhPT0gJ3N0cmluZycgJiZcbiAgICAgICAgICB0eXBlb2YgcHJvcHNba2V5XSAhPT0gJ29iamVjdCdcbiAgICAgICAgKSB7XG4gICAgICAgICAgdGhyb3cgY3JlYXRlUHJvcEVycm9yKHtcbiAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgIGV4cGVjdGVkOiAnYHN0cmluZ2Agb3IgYG9iamVjdGAnLFxuICAgICAgICAgICAgYWN0dWFsOiB0eXBlb2YgcHJvcHNba2V5XSxcbiAgICAgICAgICB9KVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKFxuICAgICAgICBrZXkgPT09ICdyZXBsYWNlJyB8fFxuICAgICAgICBrZXkgPT09ICdzY3JvbGwnIHx8XG4gICAgICAgIGtleSA9PT0gJ3NoYWxsb3cnIHx8XG4gICAgICAgIGtleSA9PT0gJ3Bhc3NIcmVmJyB8fFxuICAgICAgICBrZXkgPT09ICdwcmVmZXRjaCdcbiAgICAgICkge1xuICAgICAgICBpZiAocHJvcHNba2V5XSAhPSBudWxsICYmIHR5cGVvZiBwcm9wc1trZXldICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICB0aHJvdyBjcmVhdGVQcm9wRXJyb3Ioe1xuICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgZXhwZWN0ZWQ6ICdgYm9vbGVhbmAnLFxuICAgICAgICAgICAgYWN0dWFsOiB0eXBlb2YgcHJvcHNba2V5XSxcbiAgICAgICAgICB9KVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBUeXBlU2NyaXB0IHRyaWNrIGZvciB0eXBlLWd1YXJkaW5nOlxuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVudXNlZC12YXJzXG4gICAgICAgIGNvbnN0IF86IG5ldmVyID0ga2V5XG4gICAgICB9XG4gICAgfSlcblxuICAgIC8vIFRoaXMgaG9vayBpcyBpbiBhIGNvbmRpdGlvbmFsIGJ1dCB0aGF0IGlzIG9rIGJlY2F1c2UgYHByb2Nlc3MuZW52Lk5PREVfRU5WYCBuZXZlciBjaGFuZ2VzXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgY29uc3QgaGFzV2FybmVkID0gUmVhY3QudXNlUmVmKGZhbHNlKVxuICAgIGlmIChwcm9wcy5wcmVmZXRjaCAmJiAhaGFzV2FybmVkLmN1cnJlbnQpIHtcbiAgICAgIGhhc1dhcm5lZC5jdXJyZW50ID0gdHJ1ZVxuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAnTmV4dC5qcyBhdXRvLXByZWZldGNoZXMgYXV0b21hdGljYWxseSBiYXNlZCBvbiB2aWV3cG9ydC4gVGhlIHByZWZldGNoIGF0dHJpYnV0ZSBpcyBubyBsb25nZXIgbmVlZGVkLiBNb3JlOiBodHRwczovL2Vyci5zaC92ZXJjZWwvbmV4dC5qcy9wcmVmZXRjaC10cnVlLWRlcHJlY2F0ZWQnXG4gICAgICApXG4gICAgfVxuICB9XG4gIGNvbnN0IHAgPSBwcm9wcy5wcmVmZXRjaCAhPT0gZmFsc2VcblxuICBjb25zdCBbY2hpbGRFbG0sIHNldENoaWxkRWxtXSA9IFJlYWN0LnVzZVN0YXRlPEVsZW1lbnQ+KClcblxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxuICBjb25zdCBwYXRobmFtZSA9IChyb3V0ZXIgJiYgcm91dGVyLnBhdGhuYW1lKSB8fCAnLydcblxuICBjb25zdCB7IGhyZWYsIGFzIH0gPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBbcmVzb2x2ZWRIcmVmLCByZXNvbHZlZEFzXSA9IHJlc29sdmVIcmVmKHBhdGhuYW1lLCBwcm9wcy5ocmVmLCB0cnVlKVxuICAgIHJldHVybiB7XG4gICAgICBocmVmOiByZXNvbHZlZEhyZWYsXG4gICAgICBhczogcHJvcHMuYXNcbiAgICAgICAgPyByZXNvbHZlSHJlZihwYXRobmFtZSwgcHJvcHMuYXMpXG4gICAgICAgIDogcmVzb2x2ZWRBcyB8fCByZXNvbHZlZEhyZWYsXG4gICAgfVxuICB9LCBbcGF0aG5hbWUsIHByb3BzLmhyZWYsIHByb3BzLmFzXSlcblxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChcbiAgICAgIHAgJiZcbiAgICAgIEludGVyc2VjdGlvbk9ic2VydmVyICYmXG4gICAgICBjaGlsZEVsbSAmJlxuICAgICAgY2hpbGRFbG0udGFnTmFtZSAmJlxuICAgICAgaXNMb2NhbFVSTChocmVmKVxuICAgICkge1xuICAgICAgLy8gSm9pbiBvbiBhbiBpbnZhbGlkIFVSSSBjaGFyYWN0ZXJcbiAgICAgIGNvbnN0IGlzUHJlZmV0Y2hlZCA9IHByZWZldGNoZWRbaHJlZiArICclJyArIGFzXVxuICAgICAgaWYgKCFpc1ByZWZldGNoZWQpIHtcbiAgICAgICAgcmV0dXJuIGxpc3RlblRvSW50ZXJzZWN0aW9ucyhjaGlsZEVsbSwgKCkgPT4ge1xuICAgICAgICAgIHByZWZldGNoKHJvdXRlciwgaHJlZiwgYXMpXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfVxuICB9LCBbcCwgY2hpbGRFbG0sIGhyZWYsIGFzLCByb3V0ZXJdKVxuXG4gIGxldCB7IGNoaWxkcmVuLCByZXBsYWNlLCBzaGFsbG93LCBzY3JvbGwgfSA9IHByb3BzXG4gIC8vIERlcHJlY2F0ZWQuIFdhcm5pbmcgc2hvd24gYnkgcHJvcFR5cGUgY2hlY2suIElmIHRoZSBjaGlsZHJlbiBwcm92aWRlZCBpcyBhIHN0cmluZyAoPExpbms+ZXhhbXBsZTwvTGluaz4pIHdlIHdyYXAgaXQgaW4gYW4gPGE+IHRhZ1xuICBpZiAodHlwZW9mIGNoaWxkcmVuID09PSAnc3RyaW5nJykge1xuICAgIGNoaWxkcmVuID0gPGE+e2NoaWxkcmVufTwvYT5cbiAgfVxuXG4gIC8vIFRoaXMgd2lsbCByZXR1cm4gdGhlIGZpcnN0IGNoaWxkLCBpZiBtdWx0aXBsZSBhcmUgcHJvdmlkZWQgaXQgd2lsbCB0aHJvdyBhbiBlcnJvclxuICBjb25zdCBjaGlsZDogYW55ID0gQ2hpbGRyZW4ub25seShjaGlsZHJlbilcbiAgY29uc3QgY2hpbGRQcm9wczoge1xuICAgIG9uTW91c2VFbnRlcj86IFJlYWN0Lk1vdXNlRXZlbnRIYW5kbGVyXG4gICAgb25DbGljazogUmVhY3QuTW91c2VFdmVudEhhbmRsZXJcbiAgICBocmVmPzogc3RyaW5nXG4gICAgcmVmPzogYW55XG4gIH0gPSB7XG4gICAgcmVmOiAoZWw6IGFueSkgPT4ge1xuICAgICAgaWYgKGVsKSBzZXRDaGlsZEVsbShlbClcblxuICAgICAgaWYgKGNoaWxkICYmIHR5cGVvZiBjaGlsZCA9PT0gJ29iamVjdCcgJiYgY2hpbGQucmVmKSB7XG4gICAgICAgIGlmICh0eXBlb2YgY2hpbGQucmVmID09PSAnZnVuY3Rpb24nKSBjaGlsZC5yZWYoZWwpXG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiBjaGlsZC5yZWYgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgY2hpbGQucmVmLmN1cnJlbnQgPSBlbFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICBvbkNsaWNrOiAoZTogUmVhY3QuTW91c2VFdmVudCkgPT4ge1xuICAgICAgaWYgKGNoaWxkLnByb3BzICYmIHR5cGVvZiBjaGlsZC5wcm9wcy5vbkNsaWNrID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGNoaWxkLnByb3BzLm9uQ2xpY2soZSlcbiAgICAgIH1cbiAgICAgIGlmICghZS5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgIGxpbmtDbGlja2VkKGUsIHJvdXRlciwgaHJlZiwgYXMsIHJlcGxhY2UsIHNoYWxsb3csIHNjcm9sbClcbiAgICAgIH1cbiAgICB9LFxuICB9XG5cbiAgaWYgKHApIHtcbiAgICBjaGlsZFByb3BzLm9uTW91c2VFbnRlciA9IChlOiBSZWFjdC5Nb3VzZUV2ZW50KSA9PiB7XG4gICAgICBpZiAoIWlzTG9jYWxVUkwoaHJlZikpIHJldHVyblxuICAgICAgaWYgKGNoaWxkLnByb3BzICYmIHR5cGVvZiBjaGlsZC5wcm9wcy5vbk1vdXNlRW50ZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgY2hpbGQucHJvcHMub25Nb3VzZUVudGVyKGUpXG4gICAgICB9XG4gICAgICBwcmVmZXRjaChyb3V0ZXIsIGhyZWYsIGFzLCB7IHByaW9yaXR5OiB0cnVlIH0pXG4gICAgfVxuICB9XG5cbiAgLy8gSWYgY2hpbGQgaXMgYW4gPGE+IHRhZyBhbmQgZG9lc24ndCBoYXZlIGEgaHJlZiBhdHRyaWJ1dGUsIG9yIGlmIHRoZSAncGFzc0hyZWYnIHByb3BlcnR5IGlzXG4gIC8vIGRlZmluZWQsIHdlIHNwZWNpZnkgdGhlIGN1cnJlbnQgJ2hyZWYnLCBzbyB0aGF0IHJlcGV0aXRpb24gaXMgbm90IG5lZWRlZCBieSB0aGUgdXNlclxuICBpZiAocHJvcHMucGFzc0hyZWYgfHwgKGNoaWxkLnR5cGUgPT09ICdhJyAmJiAhKCdocmVmJyBpbiBjaGlsZC5wcm9wcykpKSB7XG4gICAgY2hpbGRQcm9wcy5ocmVmID0gYWRkQmFzZVBhdGgoXG4gICAgICBhZGRMb2NhbGUoYXMsIHJvdXRlciAmJiByb3V0ZXIubG9jYWxlLCByb3V0ZXIgJiYgcm91dGVyLmRlZmF1bHRMb2NhbGUpXG4gICAgKVxuICB9XG5cbiAgcmV0dXJuIFJlYWN0LmNsb25lRWxlbWVudChjaGlsZCwgY2hpbGRQcm9wcylcbn1cblxuZXhwb3J0IGRlZmF1bHQgTGlua1xuIiwiLyoqXG4gKiBSZW1vdmVzIHRoZSB0cmFpbGluZyBzbGFzaCBvZiBhIHBhdGggaWYgdGhlcmUgaXMgb25lLiBQcmVzZXJ2ZXMgdGhlIHJvb3QgcGF0aCBgL2AuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gcGF0aC5lbmRzV2l0aCgnLycpICYmIHBhdGggIT09ICcvJyA/IHBhdGguc2xpY2UoMCwgLTEpIDogcGF0aFxufVxuXG4vKipcbiAqIE5vcm1hbGl6ZXMgdGhlIHRyYWlsaW5nIHNsYXNoIG9mIGEgcGF0aCBhY2NvcmRpbmcgdG8gdGhlIGB0cmFpbGluZ1NsYXNoYCBvcHRpb25cbiAqIGluIGBuZXh0LmNvbmZpZy5qc2AuXG4gKi9cbmV4cG9ydCBjb25zdCBub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaCA9IHByb2Nlc3MuZW52Ll9fTkVYVF9UUkFJTElOR19TTEFTSFxuICA/IChwYXRoOiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xuICAgICAgaWYgKC9cXC5bXi9dK1xcLz8kLy50ZXN0KHBhdGgpKSB7XG4gICAgICAgIHJldHVybiByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRoKVxuICAgICAgfSBlbHNlIGlmIChwYXRoLmVuZHNXaXRoKCcvJykpIHtcbiAgICAgICAgcmV0dXJuIHBhdGhcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBwYXRoICsgJy8nXG4gICAgICB9XG4gICAgfVxuICA6IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoXG4iLCIvKiBnbG9iYWwgd2luZG93ICovXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgUm91dGVyLCB7IE5leHRSb3V0ZXIgfSBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvcm91dGVyL3JvdXRlcidcbmltcG9ydCB7IFJvdXRlckNvbnRleHQgfSBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvcm91dGVyLWNvbnRleHQnXG5cbnR5cGUgQ2xhc3NBcmd1bWVudHM8VD4gPSBUIGV4dGVuZHMgbmV3ICguLi5hcmdzOiBpbmZlciBVKSA9PiBhbnkgPyBVIDogYW55XG5cbnR5cGUgUm91dGVyQXJncyA9IENsYXNzQXJndW1lbnRzPHR5cGVvZiBSb3V0ZXI+XG5cbnR5cGUgU2luZ2xldG9uUm91dGVyQmFzZSA9IHtcbiAgcm91dGVyOiBSb3V0ZXIgfCBudWxsXG4gIHJlYWR5Q2FsbGJhY2tzOiBBcnJheTwoKSA9PiBhbnk+XG4gIHJlYWR5KGNiOiAoKSA9PiBhbnkpOiB2b2lkXG59XG5cbmV4cG9ydCB7IFJvdXRlciwgTmV4dFJvdXRlciB9XG5cbmV4cG9ydCB0eXBlIFNpbmdsZXRvblJvdXRlciA9IFNpbmdsZXRvblJvdXRlckJhc2UgJiBOZXh0Um91dGVyXG5cbmNvbnN0IHNpbmdsZXRvblJvdXRlcjogU2luZ2xldG9uUm91dGVyQmFzZSA9IHtcbiAgcm91dGVyOiBudWxsLCAvLyBob2xkcyB0aGUgYWN0dWFsIHJvdXRlciBpbnN0YW5jZVxuICByZWFkeUNhbGxiYWNrczogW10sXG4gIHJlYWR5KGNiOiAoKSA9PiB2b2lkKSB7XG4gICAgaWYgKHRoaXMucm91dGVyKSByZXR1cm4gY2IoKVxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgdGhpcy5yZWFkeUNhbGxiYWNrcy5wdXNoKGNiKVxuICAgIH1cbiAgfSxcbn1cblxuLy8gQ3JlYXRlIHB1YmxpYyBwcm9wZXJ0aWVzIGFuZCBtZXRob2RzIG9mIHRoZSByb3V0ZXIgaW4gdGhlIHNpbmdsZXRvblJvdXRlclxuY29uc3QgdXJsUHJvcGVydHlGaWVsZHMgPSBbXG4gICdwYXRobmFtZScsXG4gICdyb3V0ZScsXG4gICdxdWVyeScsXG4gICdhc1BhdGgnLFxuICAnY29tcG9uZW50cycsXG4gICdpc0ZhbGxiYWNrJyxcbiAgJ2Jhc2VQYXRoJyxcbiAgJ2xvY2FsZScsXG4gICdsb2NhbGVzJyxcbiAgJ2RlZmF1bHRMb2NhbGUnLFxuXVxuY29uc3Qgcm91dGVyRXZlbnRzID0gW1xuICAncm91dGVDaGFuZ2VTdGFydCcsXG4gICdiZWZvcmVIaXN0b3J5Q2hhbmdlJyxcbiAgJ3JvdXRlQ2hhbmdlQ29tcGxldGUnLFxuICAncm91dGVDaGFuZ2VFcnJvcicsXG4gICdoYXNoQ2hhbmdlU3RhcnQnLFxuICAnaGFzaENoYW5nZUNvbXBsZXRlJyxcbl1cbmNvbnN0IGNvcmVNZXRob2RGaWVsZHMgPSBbXG4gICdwdXNoJyxcbiAgJ3JlcGxhY2UnLFxuICAncmVsb2FkJyxcbiAgJ2JhY2snLFxuICAncHJlZmV0Y2gnLFxuICAnYmVmb3JlUG9wU3RhdGUnLFxuXVxuXG4vLyBFdmVudHMgaXMgYSBzdGF0aWMgcHJvcGVydHkgb24gdGhlIHJvdXRlciwgdGhlIHJvdXRlciBkb2Vzbid0IGhhdmUgdG8gYmUgaW5pdGlhbGl6ZWQgdG8gdXNlIGl0XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoc2luZ2xldG9uUm91dGVyLCAnZXZlbnRzJywge1xuICBnZXQoKSB7XG4gICAgcmV0dXJuIFJvdXRlci5ldmVudHNcbiAgfSxcbn0pXG5cbnVybFByb3BlcnR5RmllbGRzLmZvckVhY2goKGZpZWxkKSA9PiB7XG4gIC8vIEhlcmUgd2UgbmVlZCB0byB1c2UgT2JqZWN0LmRlZmluZVByb3BlcnR5IGJlY2F1c2UsIHdlIG5lZWQgdG8gcmV0dXJuXG4gIC8vIHRoZSBwcm9wZXJ0eSBhc3NpZ25lZCB0byB0aGUgYWN0dWFsIHJvdXRlclxuICAvLyBUaGUgdmFsdWUgbWlnaHQgZ2V0IGNoYW5nZWQgYXMgd2UgY2hhbmdlIHJvdXRlcyBhbmQgdGhpcyBpcyB0aGVcbiAgLy8gcHJvcGVyIHdheSB0byBhY2Nlc3MgaXRcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHNpbmdsZXRvblJvdXRlciwgZmllbGQsIHtcbiAgICBnZXQoKSB7XG4gICAgICBjb25zdCByb3V0ZXIgPSBnZXRSb3V0ZXIoKSBhcyBhbnlcbiAgICAgIHJldHVybiByb3V0ZXJbZmllbGRdIGFzIHN0cmluZ1xuICAgIH0sXG4gIH0pXG59KVxuXG5jb3JlTWV0aG9kRmllbGRzLmZvckVhY2goKGZpZWxkKSA9PiB7XG4gIC8vIFdlIGRvbid0IHJlYWxseSBrbm93IHRoZSB0eXBlcyBoZXJlLCBzbyB3ZSBhZGQgdGhlbSBsYXRlciBpbnN0ZWFkXG4gIDsoc2luZ2xldG9uUm91dGVyIGFzIGFueSlbZmllbGRdID0gKC4uLmFyZ3M6IGFueVtdKSA9PiB7XG4gICAgY29uc3Qgcm91dGVyID0gZ2V0Um91dGVyKCkgYXMgYW55XG4gICAgcmV0dXJuIHJvdXRlcltmaWVsZF0oLi4uYXJncylcbiAgfVxufSlcblxucm91dGVyRXZlbnRzLmZvckVhY2goKGV2ZW50KSA9PiB7XG4gIHNpbmdsZXRvblJvdXRlci5yZWFkeSgoKSA9PiB7XG4gICAgUm91dGVyLmV2ZW50cy5vbihldmVudCwgKC4uLmFyZ3MpID0+IHtcbiAgICAgIGNvbnN0IGV2ZW50RmllbGQgPSBgb24ke2V2ZW50LmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfSR7ZXZlbnQuc3Vic3RyaW5nKFxuICAgICAgICAxXG4gICAgICApfWBcbiAgICAgIGNvbnN0IF9zaW5nbGV0b25Sb3V0ZXIgPSBzaW5nbGV0b25Sb3V0ZXIgYXMgYW55XG4gICAgICBpZiAoX3NpbmdsZXRvblJvdXRlcltldmVudEZpZWxkXSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIF9zaW5nbGV0b25Sb3V0ZXJbZXZlbnRGaWVsZF0oLi4uYXJncylcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3Igd2hlbiBydW5uaW5nIHRoZSBSb3V0ZXIgZXZlbnQ6ICR7ZXZlbnRGaWVsZH1gKVxuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYCR7ZXJyLm1lc3NhZ2V9XFxuJHtlcnIuc3RhY2t9YClcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG4gIH0pXG59KVxuXG5mdW5jdGlvbiBnZXRSb3V0ZXIoKTogUm91dGVyIHtcbiAgaWYgKCFzaW5nbGV0b25Sb3V0ZXIucm91dGVyKSB7XG4gICAgY29uc3QgbWVzc2FnZSA9XG4gICAgICAnTm8gcm91dGVyIGluc3RhbmNlIGZvdW5kLlxcbicgK1xuICAgICAgJ1lvdSBzaG91bGQgb25seSB1c2UgXCJuZXh0L3JvdXRlclwiIGluc2lkZSB0aGUgY2xpZW50IHNpZGUgb2YgeW91ciBhcHAuXFxuJ1xuICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKVxuICB9XG4gIHJldHVybiBzaW5nbGV0b25Sb3V0ZXIucm91dGVyXG59XG5cbi8vIEV4cG9ydCB0aGUgc2luZ2xldG9uUm91dGVyIGFuZCB0aGlzIGlzIHRoZSBwdWJsaWMgQVBJLlxuZXhwb3J0IGRlZmF1bHQgc2luZ2xldG9uUm91dGVyIGFzIFNpbmdsZXRvblJvdXRlclxuXG4vLyBSZWV4cG9ydCB0aGUgd2l0aFJvdXRlIEhPQ1xuZXhwb3J0IHsgZGVmYXVsdCBhcyB3aXRoUm91dGVyIH0gZnJvbSAnLi93aXRoLXJvdXRlcidcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZVJvdXRlcigpOiBOZXh0Um91dGVyIHtcbiAgcmV0dXJuIFJlYWN0LnVzZUNvbnRleHQoUm91dGVyQ29udGV4dClcbn1cblxuLy8gSU5URVJOQUwgQVBJU1xuLy8gLS0tLS0tLS0tLS0tLVxuLy8gKGRvIG5vdCB1c2UgZm9sbG93aW5nIGV4cG9ydHMgaW5zaWRlIHRoZSBhcHApXG5cbi8vIENyZWF0ZSBhIHJvdXRlciBhbmQgYXNzaWduIGl0IGFzIHRoZSBzaW5nbGV0b24gaW5zdGFuY2UuXG4vLyBUaGlzIGlzIHVzZWQgaW4gY2xpZW50IHNpZGUgd2hlbiB3ZSBhcmUgaW5pdGlsaXppbmcgdGhlIGFwcC5cbi8vIFRoaXMgc2hvdWxkICoqbm90KiogdXNlIGluc2lkZSB0aGUgc2VydmVyLlxuZXhwb3J0IGNvbnN0IGNyZWF0ZVJvdXRlciA9ICguLi5hcmdzOiBSb3V0ZXJBcmdzKTogUm91dGVyID0+IHtcbiAgc2luZ2xldG9uUm91dGVyLnJvdXRlciA9IG5ldyBSb3V0ZXIoLi4uYXJncylcbiAgc2luZ2xldG9uUm91dGVyLnJlYWR5Q2FsbGJhY2tzLmZvckVhY2goKGNiKSA9PiBjYigpKVxuICBzaW5nbGV0b25Sb3V0ZXIucmVhZHlDYWxsYmFja3MgPSBbXVxuXG4gIHJldHVybiBzaW5nbGV0b25Sb3V0ZXIucm91dGVyXG59XG5cbi8vIFRoaXMgZnVuY3Rpb24gaXMgdXNlZCB0byBjcmVhdGUgdGhlIGB3aXRoUm91dGVyYCByb3V0ZXIgaW5zdGFuY2VcbmV4cG9ydCBmdW5jdGlvbiBtYWtlUHVibGljUm91dGVySW5zdGFuY2Uocm91dGVyOiBSb3V0ZXIpOiBOZXh0Um91dGVyIHtcbiAgY29uc3QgX3JvdXRlciA9IHJvdXRlciBhcyBhbnlcbiAgY29uc3QgaW5zdGFuY2UgPSB7fSBhcyBhbnlcblxuICBmb3IgKGNvbnN0IHByb3BlcnR5IG9mIHVybFByb3BlcnR5RmllbGRzKSB7XG4gICAgaWYgKHR5cGVvZiBfcm91dGVyW3Byb3BlcnR5XSA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGluc3RhbmNlW3Byb3BlcnR5XSA9IE9iamVjdC5hc3NpZ24oXG4gICAgICAgIEFycmF5LmlzQXJyYXkoX3JvdXRlcltwcm9wZXJ0eV0pID8gW10gOiB7fSxcbiAgICAgICAgX3JvdXRlcltwcm9wZXJ0eV1cbiAgICAgICkgLy8gbWFrZXMgc3VyZSBxdWVyeSBpcyBub3Qgc3RhdGVmdWxcbiAgICAgIGNvbnRpbnVlXG4gICAgfVxuXG4gICAgaW5zdGFuY2VbcHJvcGVydHldID0gX3JvdXRlcltwcm9wZXJ0eV1cbiAgfVxuXG4gIC8vIEV2ZW50cyBpcyBhIHN0YXRpYyBwcm9wZXJ0eSBvbiB0aGUgcm91dGVyLCB0aGUgcm91dGVyIGRvZXNuJ3QgaGF2ZSB0byBiZSBpbml0aWFsaXplZCB0byB1c2UgaXRcbiAgaW5zdGFuY2UuZXZlbnRzID0gUm91dGVyLmV2ZW50c1xuXG4gIGNvcmVNZXRob2RGaWVsZHMuZm9yRWFjaCgoZmllbGQpID0+IHtcbiAgICBpbnN0YW5jZVtmaWVsZF0gPSAoLi4uYXJnczogYW55W10pID0+IHtcbiAgICAgIHJldHVybiBfcm91dGVyW2ZpZWxkXSguLi5hcmdzKVxuICAgIH1cbiAgfSlcblxuICByZXR1cm4gaW5zdGFuY2Vcbn1cbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7IE5leHRDb21wb25lbnRUeXBlLCBOZXh0UGFnZUNvbnRleHQgfSBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvdXRpbHMnXG5pbXBvcnQgeyBOZXh0Um91dGVyLCB1c2VSb3V0ZXIgfSBmcm9tICcuL3JvdXRlcidcblxuZXhwb3J0IHR5cGUgV2l0aFJvdXRlclByb3BzID0ge1xuICByb3V0ZXI6IE5leHRSb3V0ZXJcbn1cblxuZXhwb3J0IHR5cGUgRXhjbHVkZVJvdXRlclByb3BzPFA+ID0gUGljazxcbiAgUCxcbiAgRXhjbHVkZTxrZXlvZiBQLCBrZXlvZiBXaXRoUm91dGVyUHJvcHM+XG4+XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHdpdGhSb3V0ZXI8XG4gIFAgZXh0ZW5kcyBXaXRoUm91dGVyUHJvcHMsXG4gIEMgPSBOZXh0UGFnZUNvbnRleHRcbj4oXG4gIENvbXBvc2VkQ29tcG9uZW50OiBOZXh0Q29tcG9uZW50VHlwZTxDLCBhbnksIFA+XG4pOiBSZWFjdC5Db21wb25lbnRUeXBlPEV4Y2x1ZGVSb3V0ZXJQcm9wczxQPj4ge1xuICBmdW5jdGlvbiBXaXRoUm91dGVyV3JhcHBlcihwcm9wczogYW55KSB7XG4gICAgcmV0dXJuIDxDb21wb3NlZENvbXBvbmVudCByb3V0ZXI9e3VzZVJvdXRlcigpfSB7Li4ucHJvcHN9IC8+XG4gIH1cblxuICBXaXRoUm91dGVyV3JhcHBlci5nZXRJbml0aWFsUHJvcHMgPSBDb21wb3NlZENvbXBvbmVudC5nZXRJbml0aWFsUHJvcHNcbiAgLy8gVGhpcyBpcyBuZWVkZWQgdG8gYWxsb3cgY2hlY2tpbmcgZm9yIGN1c3RvbSBnZXRJbml0aWFsUHJvcHMgaW4gX2FwcFxuICA7KFdpdGhSb3V0ZXJXcmFwcGVyIGFzIGFueSkub3JpZ0dldEluaXRpYWxQcm9wcyA9IChDb21wb3NlZENvbXBvbmVudCBhcyBhbnkpLm9yaWdHZXRJbml0aWFsUHJvcHNcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBjb25zdCBuYW1lID1cbiAgICAgIENvbXBvc2VkQ29tcG9uZW50LmRpc3BsYXlOYW1lIHx8IENvbXBvc2VkQ29tcG9uZW50Lm5hbWUgfHwgJ1Vua25vd24nXG4gICAgV2l0aFJvdXRlcldyYXBwZXIuZGlzcGxheU5hbWUgPSBgd2l0aFJvdXRlcigke25hbWV9KWBcbiAgfVxuXG4gIHJldHVybiBXaXRoUm91dGVyV3JhcHBlclxufVxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG4vKipcbiAqIFRva2VuaXplIGlucHV0IHN0cmluZy5cbiAqL1xuZnVuY3Rpb24gbGV4ZXIoc3RyKSB7XG4gICAgdmFyIHRva2VucyA9IFtdO1xuICAgIHZhciBpID0gMDtcbiAgICB3aGlsZSAoaSA8IHN0ci5sZW5ndGgpIHtcbiAgICAgICAgdmFyIGNoYXIgPSBzdHJbaV07XG4gICAgICAgIGlmIChjaGFyID09PSBcIipcIiB8fCBjaGFyID09PSBcIitcIiB8fCBjaGFyID09PSBcIj9cIikge1xuICAgICAgICAgICAgdG9rZW5zLnB1c2goeyB0eXBlOiBcIk1PRElGSUVSXCIsIGluZGV4OiBpLCB2YWx1ZTogc3RyW2krK10gfSk7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY2hhciA9PT0gXCJcXFxcXCIpIHtcbiAgICAgICAgICAgIHRva2Vucy5wdXNoKHsgdHlwZTogXCJFU0NBUEVEX0NIQVJcIiwgaW5kZXg6IGkrKywgdmFsdWU6IHN0cltpKytdIH0pO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNoYXIgPT09IFwie1wiKSB7XG4gICAgICAgICAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiT1BFTlwiLCBpbmRleDogaSwgdmFsdWU6IHN0cltpKytdIH0pO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNoYXIgPT09IFwifVwiKSB7XG4gICAgICAgICAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiQ0xPU0VcIiwgaW5kZXg6IGksIHZhbHVlOiBzdHJbaSsrXSB9KTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjaGFyID09PSBcIjpcIikge1xuICAgICAgICAgICAgdmFyIG5hbWUgPSBcIlwiO1xuICAgICAgICAgICAgdmFyIGogPSBpICsgMTtcbiAgICAgICAgICAgIHdoaWxlIChqIDwgc3RyLmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIHZhciBjb2RlID0gc3RyLmNoYXJDb2RlQXQoaik7XG4gICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgIC8vIGAwLTlgXG4gICAgICAgICAgICAgICAgKGNvZGUgPj0gNDggJiYgY29kZSA8PSA1NykgfHxcbiAgICAgICAgICAgICAgICAgICAgLy8gYEEtWmBcbiAgICAgICAgICAgICAgICAgICAgKGNvZGUgPj0gNjUgJiYgY29kZSA8PSA5MCkgfHxcbiAgICAgICAgICAgICAgICAgICAgLy8gYGEtemBcbiAgICAgICAgICAgICAgICAgICAgKGNvZGUgPj0gOTcgJiYgY29kZSA8PSAxMjIpIHx8XG4gICAgICAgICAgICAgICAgICAgIC8vIGBfYFxuICAgICAgICAgICAgICAgICAgICBjb2RlID09PSA5NSkge1xuICAgICAgICAgICAgICAgICAgICBuYW1lICs9IHN0cltqKytdO1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIW5hbWUpXG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk1pc3NpbmcgcGFyYW1ldGVyIG5hbWUgYXQgXCIgKyBpKTtcbiAgICAgICAgICAgIHRva2Vucy5wdXNoKHsgdHlwZTogXCJOQU1FXCIsIGluZGV4OiBpLCB2YWx1ZTogbmFtZSB9KTtcbiAgICAgICAgICAgIGkgPSBqO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNoYXIgPT09IFwiKFwiKSB7XG4gICAgICAgICAgICB2YXIgY291bnQgPSAxO1xuICAgICAgICAgICAgdmFyIHBhdHRlcm4gPSBcIlwiO1xuICAgICAgICAgICAgdmFyIGogPSBpICsgMTtcbiAgICAgICAgICAgIGlmIChzdHJbal0gPT09IFwiP1wiKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlBhdHRlcm4gY2Fubm90IHN0YXJ0IHdpdGggXFxcIj9cXFwiIGF0IFwiICsgaik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB3aGlsZSAoaiA8IHN0ci5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICBpZiAoc3RyW2pdID09PSBcIlxcXFxcIikge1xuICAgICAgICAgICAgICAgICAgICBwYXR0ZXJuICs9IHN0cltqKytdICsgc3RyW2orK107XG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoc3RyW2pdID09PSBcIilcIikge1xuICAgICAgICAgICAgICAgICAgICBjb3VudC0tO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY291bnQgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGorKztcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKHN0cltqXSA9PT0gXCIoXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgY291bnQrKztcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN0cltqICsgMV0gIT09IFwiP1wiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2FwdHVyaW5nIGdyb3VwcyBhcmUgbm90IGFsbG93ZWQgYXQgXCIgKyBqKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBwYXR0ZXJuICs9IHN0cltqKytdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNvdW50KVxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJVbmJhbGFuY2VkIHBhdHRlcm4gYXQgXCIgKyBpKTtcbiAgICAgICAgICAgIGlmICghcGF0dGVybilcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiTWlzc2luZyBwYXR0ZXJuIGF0IFwiICsgaSk7XG4gICAgICAgICAgICB0b2tlbnMucHVzaCh7IHR5cGU6IFwiUEFUVEVSTlwiLCBpbmRleDogaSwgdmFsdWU6IHBhdHRlcm4gfSk7XG4gICAgICAgICAgICBpID0gajtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHRva2Vucy5wdXNoKHsgdHlwZTogXCJDSEFSXCIsIGluZGV4OiBpLCB2YWx1ZTogc3RyW2krK10gfSk7XG4gICAgfVxuICAgIHRva2Vucy5wdXNoKHsgdHlwZTogXCJFTkRcIiwgaW5kZXg6IGksIHZhbHVlOiBcIlwiIH0pO1xuICAgIHJldHVybiB0b2tlbnM7XG59XG4vKipcbiAqIFBhcnNlIGEgc3RyaW5nIGZvciB0aGUgcmF3IHRva2Vucy5cbiAqL1xuZnVuY3Rpb24gcGFyc2Uoc3RyLCBvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkgeyBvcHRpb25zID0ge307IH1cbiAgICB2YXIgdG9rZW5zID0gbGV4ZXIoc3RyKTtcbiAgICB2YXIgX2EgPSBvcHRpb25zLnByZWZpeGVzLCBwcmVmaXhlcyA9IF9hID09PSB2b2lkIDAgPyBcIi4vXCIgOiBfYTtcbiAgICB2YXIgZGVmYXVsdFBhdHRlcm4gPSBcIlteXCIgKyBlc2NhcGVTdHJpbmcob3B0aW9ucy5kZWxpbWl0ZXIgfHwgXCIvIz9cIikgKyBcIl0rP1wiO1xuICAgIHZhciByZXN1bHQgPSBbXTtcbiAgICB2YXIga2V5ID0gMDtcbiAgICB2YXIgaSA9IDA7XG4gICAgdmFyIHBhdGggPSBcIlwiO1xuICAgIHZhciB0cnlDb25zdW1lID0gZnVuY3Rpb24gKHR5cGUpIHtcbiAgICAgICAgaWYgKGkgPCB0b2tlbnMubGVuZ3RoICYmIHRva2Vuc1tpXS50eXBlID09PSB0eXBlKVxuICAgICAgICAgICAgcmV0dXJuIHRva2Vuc1tpKytdLnZhbHVlO1xuICAgIH07XG4gICAgdmFyIG11c3RDb25zdW1lID0gZnVuY3Rpb24gKHR5cGUpIHtcbiAgICAgICAgdmFyIHZhbHVlID0gdHJ5Q29uc3VtZSh0eXBlKTtcbiAgICAgICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQpXG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgIHZhciBfYSA9IHRva2Vuc1tpXSwgbmV4dFR5cGUgPSBfYS50eXBlLCBpbmRleCA9IF9hLmluZGV4O1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiVW5leHBlY3RlZCBcIiArIG5leHRUeXBlICsgXCIgYXQgXCIgKyBpbmRleCArIFwiLCBleHBlY3RlZCBcIiArIHR5cGUpO1xuICAgIH07XG4gICAgdmFyIGNvbnN1bWVUZXh0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgcmVzdWx0ID0gXCJcIjtcbiAgICAgICAgdmFyIHZhbHVlO1xuICAgICAgICAvLyB0c2xpbnQ6ZGlzYWJsZS1uZXh0LWxpbmVcbiAgICAgICAgd2hpbGUgKCh2YWx1ZSA9IHRyeUNvbnN1bWUoXCJDSEFSXCIpIHx8IHRyeUNvbnN1bWUoXCJFU0NBUEVEX0NIQVJcIikpKSB7XG4gICAgICAgICAgICByZXN1bHQgKz0gdmFsdWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9O1xuICAgIHdoaWxlIChpIDwgdG9rZW5zLmxlbmd0aCkge1xuICAgICAgICB2YXIgY2hhciA9IHRyeUNvbnN1bWUoXCJDSEFSXCIpO1xuICAgICAgICB2YXIgbmFtZSA9IHRyeUNvbnN1bWUoXCJOQU1FXCIpO1xuICAgICAgICB2YXIgcGF0dGVybiA9IHRyeUNvbnN1bWUoXCJQQVRURVJOXCIpO1xuICAgICAgICBpZiAobmFtZSB8fCBwYXR0ZXJuKSB7XG4gICAgICAgICAgICB2YXIgcHJlZml4ID0gY2hhciB8fCBcIlwiO1xuICAgICAgICAgICAgaWYgKHByZWZpeGVzLmluZGV4T2YocHJlZml4KSA9PT0gLTEpIHtcbiAgICAgICAgICAgICAgICBwYXRoICs9IHByZWZpeDtcbiAgICAgICAgICAgICAgICBwcmVmaXggPSBcIlwiO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHBhdGgpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaChwYXRoKTtcbiAgICAgICAgICAgICAgICBwYXRoID0gXCJcIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICBuYW1lOiBuYW1lIHx8IGtleSsrLFxuICAgICAgICAgICAgICAgIHByZWZpeDogcHJlZml4LFxuICAgICAgICAgICAgICAgIHN1ZmZpeDogXCJcIixcbiAgICAgICAgICAgICAgICBwYXR0ZXJuOiBwYXR0ZXJuIHx8IGRlZmF1bHRQYXR0ZXJuLFxuICAgICAgICAgICAgICAgIG1vZGlmaWVyOiB0cnlDb25zdW1lKFwiTU9ESUZJRVJcIikgfHwgXCJcIlxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgdmFsdWUgPSBjaGFyIHx8IHRyeUNvbnN1bWUoXCJFU0NBUEVEX0NIQVJcIik7XG4gICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgICAgcGF0aCArPSB2YWx1ZTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwYXRoKSB7XG4gICAgICAgICAgICByZXN1bHQucHVzaChwYXRoKTtcbiAgICAgICAgICAgIHBhdGggPSBcIlwiO1xuICAgICAgICB9XG4gICAgICAgIHZhciBvcGVuID0gdHJ5Q29uc3VtZShcIk9QRU5cIik7XG4gICAgICAgIGlmIChvcGVuKSB7XG4gICAgICAgICAgICB2YXIgcHJlZml4ID0gY29uc3VtZVRleHQoKTtcbiAgICAgICAgICAgIHZhciBuYW1lXzEgPSB0cnlDb25zdW1lKFwiTkFNRVwiKSB8fCBcIlwiO1xuICAgICAgICAgICAgdmFyIHBhdHRlcm5fMSA9IHRyeUNvbnN1bWUoXCJQQVRURVJOXCIpIHx8IFwiXCI7XG4gICAgICAgICAgICB2YXIgc3VmZml4ID0gY29uc3VtZVRleHQoKTtcbiAgICAgICAgICAgIG11c3RDb25zdW1lKFwiQ0xPU0VcIik7XG4gICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgbmFtZTogbmFtZV8xIHx8IChwYXR0ZXJuXzEgPyBrZXkrKyA6IFwiXCIpLFxuICAgICAgICAgICAgICAgIHBhdHRlcm46IG5hbWVfMSAmJiAhcGF0dGVybl8xID8gZGVmYXVsdFBhdHRlcm4gOiBwYXR0ZXJuXzEsXG4gICAgICAgICAgICAgICAgcHJlZml4OiBwcmVmaXgsXG4gICAgICAgICAgICAgICAgc3VmZml4OiBzdWZmaXgsXG4gICAgICAgICAgICAgICAgbW9kaWZpZXI6IHRyeUNvbnN1bWUoXCJNT0RJRklFUlwiKSB8fCBcIlwiXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIG11c3RDb25zdW1lKFwiRU5EXCIpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZXhwb3J0cy5wYXJzZSA9IHBhcnNlO1xuLyoqXG4gKiBDb21waWxlIGEgc3RyaW5nIHRvIGEgdGVtcGxhdGUgZnVuY3Rpb24gZm9yIHRoZSBwYXRoLlxuICovXG5mdW5jdGlvbiBjb21waWxlKHN0ciwgb3B0aW9ucykge1xuICAgIHJldHVybiB0b2tlbnNUb0Z1bmN0aW9uKHBhcnNlKHN0ciwgb3B0aW9ucyksIG9wdGlvbnMpO1xufVxuZXhwb3J0cy5jb21waWxlID0gY29tcGlsZTtcbi8qKlxuICogRXhwb3NlIGEgbWV0aG9kIGZvciB0cmFuc2Zvcm1pbmcgdG9rZW5zIGludG8gdGhlIHBhdGggZnVuY3Rpb24uXG4gKi9cbmZ1bmN0aW9uIHRva2Vuc1RvRnVuY3Rpb24odG9rZW5zLCBvcHRpb25zKSB7XG4gICAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkgeyBvcHRpb25zID0ge307IH1cbiAgICB2YXIgcmVGbGFncyA9IGZsYWdzKG9wdGlvbnMpO1xuICAgIHZhciBfYSA9IG9wdGlvbnMuZW5jb2RlLCBlbmNvZGUgPSBfYSA9PT0gdm9pZCAwID8gZnVuY3Rpb24gKHgpIHsgcmV0dXJuIHg7IH0gOiBfYSwgX2IgPSBvcHRpb25zLnZhbGlkYXRlLCB2YWxpZGF0ZSA9IF9iID09PSB2b2lkIDAgPyB0cnVlIDogX2I7XG4gICAgLy8gQ29tcGlsZSBhbGwgdGhlIHRva2VucyBpbnRvIHJlZ2V4cHMuXG4gICAgdmFyIG1hdGNoZXMgPSB0b2tlbnMubWFwKGZ1bmN0aW9uICh0b2tlbikge1xuICAgICAgICBpZiAodHlwZW9mIHRva2VuID09PSBcIm9iamVjdFwiKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFJlZ0V4cChcIl4oPzpcIiArIHRva2VuLnBhdHRlcm4gKyBcIikkXCIsIHJlRmxhZ3MpO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgIHZhciBwYXRoID0gXCJcIjtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0b2tlbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIHZhciB0b2tlbiA9IHRva2Vuc1tpXTtcbiAgICAgICAgICAgIGlmICh0eXBlb2YgdG9rZW4gPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICAgICAgICBwYXRoICs9IHRva2VuO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIHZhbHVlID0gZGF0YSA/IGRhdGFbdG9rZW4ubmFtZV0gOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICB2YXIgb3B0aW9uYWwgPSB0b2tlbi5tb2RpZmllciA9PT0gXCI/XCIgfHwgdG9rZW4ubW9kaWZpZXIgPT09IFwiKlwiO1xuICAgICAgICAgICAgdmFyIHJlcGVhdCA9IHRva2VuLm1vZGlmaWVyID09PSBcIipcIiB8fCB0b2tlbi5tb2RpZmllciA9PT0gXCIrXCI7XG4gICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBpZiAoIXJlcGVhdCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiRXhwZWN0ZWQgXFxcIlwiICsgdG9rZW4ubmFtZSArIFwiXFxcIiB0byBub3QgcmVwZWF0LCBidXQgZ290IGFuIGFycmF5XCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodmFsdWUubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcHRpb25hbClcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiRXhwZWN0ZWQgXFxcIlwiICsgdG9rZW4ubmFtZSArIFwiXFxcIiB0byBub3QgYmUgZW1wdHlcIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSAwOyBqIDwgdmFsdWUubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHNlZ21lbnQgPSBlbmNvZGUodmFsdWVbal0sIHRva2VuKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRlICYmICFtYXRjaGVzW2ldLnRlc3Qoc2VnbWVudCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJFeHBlY3RlZCBhbGwgXFxcIlwiICsgdG9rZW4ubmFtZSArIFwiXFxcIiB0byBtYXRjaCBcXFwiXCIgKyB0b2tlbi5wYXR0ZXJuICsgXCJcXFwiLCBidXQgZ290IFxcXCJcIiArIHNlZ21lbnQgKyBcIlxcXCJcIik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcGF0aCArPSB0b2tlbi5wcmVmaXggKyBzZWdtZW50ICsgdG9rZW4uc3VmZml4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIgfHwgdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgICAgICAgICAgdmFyIHNlZ21lbnQgPSBlbmNvZGUoU3RyaW5nKHZhbHVlKSwgdG9rZW4pO1xuICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0ZSAmJiAhbWF0Y2hlc1tpXS50ZXN0KHNlZ21lbnQpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJFeHBlY3RlZCBcXFwiXCIgKyB0b2tlbi5uYW1lICsgXCJcXFwiIHRvIG1hdGNoIFxcXCJcIiArIHRva2VuLnBhdHRlcm4gKyBcIlxcXCIsIGJ1dCBnb3QgXFxcIlwiICsgc2VnbWVudCArIFwiXFxcIlwiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcGF0aCArPSB0b2tlbi5wcmVmaXggKyBzZWdtZW50ICsgdG9rZW4uc3VmZml4O1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG9wdGlvbmFsKVxuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgdmFyIHR5cGVPZk1lc3NhZ2UgPSByZXBlYXQgPyBcImFuIGFycmF5XCIgOiBcImEgc3RyaW5nXCI7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiRXhwZWN0ZWQgXFxcIlwiICsgdG9rZW4ubmFtZSArIFwiXFxcIiB0byBiZSBcIiArIHR5cGVPZk1lc3NhZ2UpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwYXRoO1xuICAgIH07XG59XG5leHBvcnRzLnRva2Vuc1RvRnVuY3Rpb24gPSB0b2tlbnNUb0Z1bmN0aW9uO1xuLyoqXG4gKiBDcmVhdGUgcGF0aCBtYXRjaCBmdW5jdGlvbiBmcm9tIGBwYXRoLXRvLXJlZ2V4cGAgc3BlYy5cbiAqL1xuZnVuY3Rpb24gbWF0Y2goc3RyLCBvcHRpb25zKSB7XG4gICAgdmFyIGtleXMgPSBbXTtcbiAgICB2YXIgcmUgPSBwYXRoVG9SZWdleHAoc3RyLCBrZXlzLCBvcHRpb25zKTtcbiAgICByZXR1cm4gcmVnZXhwVG9GdW5jdGlvbihyZSwga2V5cywgb3B0aW9ucyk7XG59XG5leHBvcnRzLm1hdGNoID0gbWF0Y2g7XG4vKipcbiAqIENyZWF0ZSBhIHBhdGggbWF0Y2ggZnVuY3Rpb24gZnJvbSBgcGF0aC10by1yZWdleHBgIG91dHB1dC5cbiAqL1xuZnVuY3Rpb24gcmVnZXhwVG9GdW5jdGlvbihyZSwga2V5cywgb3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zID09PSB2b2lkIDApIHsgb3B0aW9ucyA9IHt9OyB9XG4gICAgdmFyIF9hID0gb3B0aW9ucy5kZWNvZGUsIGRlY29kZSA9IF9hID09PSB2b2lkIDAgPyBmdW5jdGlvbiAoeCkgeyByZXR1cm4geDsgfSA6IF9hO1xuICAgIHJldHVybiBmdW5jdGlvbiAocGF0aG5hbWUpIHtcbiAgICAgICAgdmFyIG0gPSByZS5leGVjKHBhdGhuYW1lKTtcbiAgICAgICAgaWYgKCFtKVxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB2YXIgcGF0aCA9IG1bMF0sIGluZGV4ID0gbS5pbmRleDtcbiAgICAgICAgdmFyIHBhcmFtcyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgIHZhciBfbG9vcF8xID0gZnVuY3Rpb24gKGkpIHtcbiAgICAgICAgICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZVxuICAgICAgICAgICAgaWYgKG1baV0gPT09IHVuZGVmaW5lZClcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJjb250aW51ZVwiO1xuICAgICAgICAgICAgdmFyIGtleSA9IGtleXNbaSAtIDFdO1xuICAgICAgICAgICAgaWYgKGtleS5tb2RpZmllciA9PT0gXCIqXCIgfHwga2V5Lm1vZGlmaWVyID09PSBcIitcIikge1xuICAgICAgICAgICAgICAgIHBhcmFtc1trZXkubmFtZV0gPSBtW2ldLnNwbGl0KGtleS5wcmVmaXggKyBrZXkuc3VmZml4KS5tYXAoZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkZWNvZGUodmFsdWUsIGtleSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBwYXJhbXNba2V5Lm5hbWVdID0gZGVjb2RlKG1baV0sIGtleSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGZvciAodmFyIGkgPSAxOyBpIDwgbS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgX2xvb3BfMShpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyBwYXRoOiBwYXRoLCBpbmRleDogaW5kZXgsIHBhcmFtczogcGFyYW1zIH07XG4gICAgfTtcbn1cbmV4cG9ydHMucmVnZXhwVG9GdW5jdGlvbiA9IHJlZ2V4cFRvRnVuY3Rpb247XG4vKipcbiAqIEVzY2FwZSBhIHJlZ3VsYXIgZXhwcmVzc2lvbiBzdHJpbmcuXG4gKi9cbmZ1bmN0aW9uIGVzY2FwZVN0cmluZyhzdHIpIHtcbiAgICByZXR1cm4gc3RyLnJlcGxhY2UoLyhbLisqPz1eIToke30oKVtcXF18L1xcXFxdKS9nLCBcIlxcXFwkMVwiKTtcbn1cbi8qKlxuICogR2V0IHRoZSBmbGFncyBmb3IgYSByZWdleHAgZnJvbSB0aGUgb3B0aW9ucy5cbiAqL1xuZnVuY3Rpb24gZmxhZ3Mob3B0aW9ucykge1xuICAgIHJldHVybiBvcHRpb25zICYmIG9wdGlvbnMuc2Vuc2l0aXZlID8gXCJcIiA6IFwiaVwiO1xufVxuLyoqXG4gKiBQdWxsIG91dCBrZXlzIGZyb20gYSByZWdleHAuXG4gKi9cbmZ1bmN0aW9uIHJlZ2V4cFRvUmVnZXhwKHBhdGgsIGtleXMpIHtcbiAgICBpZiAoIWtleXMpXG4gICAgICAgIHJldHVybiBwYXRoO1xuICAgIC8vIFVzZSBhIG5lZ2F0aXZlIGxvb2thaGVhZCB0byBtYXRjaCBvbmx5IGNhcHR1cmluZyBncm91cHMuXG4gICAgdmFyIGdyb3VwcyA9IHBhdGguc291cmNlLm1hdGNoKC9cXCgoPyFcXD8pL2cpO1xuICAgIGlmIChncm91cHMpIHtcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBncm91cHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGtleXMucHVzaCh7XG4gICAgICAgICAgICAgICAgbmFtZTogaSxcbiAgICAgICAgICAgICAgICBwcmVmaXg6IFwiXCIsXG4gICAgICAgICAgICAgICAgc3VmZml4OiBcIlwiLFxuICAgICAgICAgICAgICAgIG1vZGlmaWVyOiBcIlwiLFxuICAgICAgICAgICAgICAgIHBhdHRlcm46IFwiXCJcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBwYXRoO1xufVxuLyoqXG4gKiBUcmFuc2Zvcm0gYW4gYXJyYXkgaW50byBhIHJlZ2V4cC5cbiAqL1xuZnVuY3Rpb24gYXJyYXlUb1JlZ2V4cChwYXRocywga2V5cywgb3B0aW9ucykge1xuICAgIHZhciBwYXJ0cyA9IHBhdGhzLm1hcChmdW5jdGlvbiAocGF0aCkgeyByZXR1cm4gcGF0aFRvUmVnZXhwKHBhdGgsIGtleXMsIG9wdGlvbnMpLnNvdXJjZTsgfSk7XG4gICAgcmV0dXJuIG5ldyBSZWdFeHAoXCIoPzpcIiArIHBhcnRzLmpvaW4oXCJ8XCIpICsgXCIpXCIsIGZsYWdzKG9wdGlvbnMpKTtcbn1cbi8qKlxuICogQ3JlYXRlIGEgcGF0aCByZWdleHAgZnJvbSBzdHJpbmcgaW5wdXQuXG4gKi9cbmZ1bmN0aW9uIHN0cmluZ1RvUmVnZXhwKHBhdGgsIGtleXMsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gdG9rZW5zVG9SZWdleHAocGFyc2UocGF0aCwgb3B0aW9ucyksIGtleXMsIG9wdGlvbnMpO1xufVxuLyoqXG4gKiBFeHBvc2UgYSBmdW5jdGlvbiBmb3IgdGFraW5nIHRva2VucyBhbmQgcmV0dXJuaW5nIGEgUmVnRXhwLlxuICovXG5mdW5jdGlvbiB0b2tlbnNUb1JlZ2V4cCh0b2tlbnMsIGtleXMsIG9wdGlvbnMpIHtcbiAgICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7IG9wdGlvbnMgPSB7fTsgfVxuICAgIHZhciBfYSA9IG9wdGlvbnMuc3RyaWN0LCBzdHJpY3QgPSBfYSA9PT0gdm9pZCAwID8gZmFsc2UgOiBfYSwgX2IgPSBvcHRpb25zLnN0YXJ0LCBzdGFydCA9IF9iID09PSB2b2lkIDAgPyB0cnVlIDogX2IsIF9jID0gb3B0aW9ucy5lbmQsIGVuZCA9IF9jID09PSB2b2lkIDAgPyB0cnVlIDogX2MsIF9kID0gb3B0aW9ucy5lbmNvZGUsIGVuY29kZSA9IF9kID09PSB2b2lkIDAgPyBmdW5jdGlvbiAoeCkgeyByZXR1cm4geDsgfSA6IF9kO1xuICAgIHZhciBlbmRzV2l0aCA9IFwiW1wiICsgZXNjYXBlU3RyaW5nKG9wdGlvbnMuZW5kc1dpdGggfHwgXCJcIikgKyBcIl18JFwiO1xuICAgIHZhciBkZWxpbWl0ZXIgPSBcIltcIiArIGVzY2FwZVN0cmluZyhvcHRpb25zLmRlbGltaXRlciB8fCBcIi8jP1wiKSArIFwiXVwiO1xuICAgIHZhciByb3V0ZSA9IHN0YXJ0ID8gXCJeXCIgOiBcIlwiO1xuICAgIC8vIEl0ZXJhdGUgb3ZlciB0aGUgdG9rZW5zIGFuZCBjcmVhdGUgb3VyIHJlZ2V4cCBzdHJpbmcuXG4gICAgZm9yICh2YXIgX2kgPSAwLCB0b2tlbnNfMSA9IHRva2VuczsgX2kgPCB0b2tlbnNfMS5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgdmFyIHRva2VuID0gdG9rZW5zXzFbX2ldO1xuICAgICAgICBpZiAodHlwZW9mIHRva2VuID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICByb3V0ZSArPSBlc2NhcGVTdHJpbmcoZW5jb2RlKHRva2VuKSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB2YXIgcHJlZml4ID0gZXNjYXBlU3RyaW5nKGVuY29kZSh0b2tlbi5wcmVmaXgpKTtcbiAgICAgICAgICAgIHZhciBzdWZmaXggPSBlc2NhcGVTdHJpbmcoZW5jb2RlKHRva2VuLnN1ZmZpeCkpO1xuICAgICAgICAgICAgaWYgKHRva2VuLnBhdHRlcm4pIHtcbiAgICAgICAgICAgICAgICBpZiAoa2V5cylcbiAgICAgICAgICAgICAgICAgICAga2V5cy5wdXNoKHRva2VuKTtcbiAgICAgICAgICAgICAgICBpZiAocHJlZml4IHx8IHN1ZmZpeCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAodG9rZW4ubW9kaWZpZXIgPT09IFwiK1wiIHx8IHRva2VuLm1vZGlmaWVyID09PSBcIipcIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1vZCA9IHRva2VuLm1vZGlmaWVyID09PSBcIipcIiA/IFwiP1wiIDogXCJcIjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdXRlICs9IFwiKD86XCIgKyBwcmVmaXggKyBcIigoPzpcIiArIHRva2VuLnBhdHRlcm4gKyBcIikoPzpcIiArIHN1ZmZpeCArIHByZWZpeCArIFwiKD86XCIgKyB0b2tlbi5wYXR0ZXJuICsgXCIpKSopXCIgKyBzdWZmaXggKyBcIilcIiArIG1vZDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdXRlICs9IFwiKD86XCIgKyBwcmVmaXggKyBcIihcIiArIHRva2VuLnBhdHRlcm4gKyBcIilcIiArIHN1ZmZpeCArIFwiKVwiICsgdG9rZW4ubW9kaWZpZXI7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHJvdXRlICs9IFwiKFwiICsgdG9rZW4ucGF0dGVybiArIFwiKVwiICsgdG9rZW4ubW9kaWZpZXI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcm91dGUgKz0gXCIoPzpcIiArIHByZWZpeCArIHN1ZmZpeCArIFwiKVwiICsgdG9rZW4ubW9kaWZpZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKGVuZCkge1xuICAgICAgICBpZiAoIXN0cmljdClcbiAgICAgICAgICAgIHJvdXRlICs9IGRlbGltaXRlciArIFwiP1wiO1xuICAgICAgICByb3V0ZSArPSAhb3B0aW9ucy5lbmRzV2l0aCA/IFwiJFwiIDogXCIoPz1cIiArIGVuZHNXaXRoICsgXCIpXCI7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB2YXIgZW5kVG9rZW4gPSB0b2tlbnNbdG9rZW5zLmxlbmd0aCAtIDFdO1xuICAgICAgICB2YXIgaXNFbmREZWxpbWl0ZWQgPSB0eXBlb2YgZW5kVG9rZW4gPT09IFwic3RyaW5nXCJcbiAgICAgICAgICAgID8gZGVsaW1pdGVyLmluZGV4T2YoZW5kVG9rZW5bZW5kVG9rZW4ubGVuZ3RoIC0gMV0pID4gLTFcbiAgICAgICAgICAgIDogLy8gdHNsaW50OmRpc2FibGUtbmV4dC1saW5lXG4gICAgICAgICAgICAgICAgZW5kVG9rZW4gPT09IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKCFzdHJpY3QpIHtcbiAgICAgICAgICAgIHJvdXRlICs9IFwiKD86XCIgKyBkZWxpbWl0ZXIgKyBcIig/PVwiICsgZW5kc1dpdGggKyBcIikpP1wiO1xuICAgICAgICB9XG4gICAgICAgIGlmICghaXNFbmREZWxpbWl0ZWQpIHtcbiAgICAgICAgICAgIHJvdXRlICs9IFwiKD89XCIgKyBkZWxpbWl0ZXIgKyBcInxcIiArIGVuZHNXaXRoICsgXCIpXCI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG5ldyBSZWdFeHAocm91dGUsIGZsYWdzKG9wdGlvbnMpKTtcbn1cbmV4cG9ydHMudG9rZW5zVG9SZWdleHAgPSB0b2tlbnNUb1JlZ2V4cDtcbi8qKlxuICogTm9ybWFsaXplIHRoZSBnaXZlbiBwYXRoIHN0cmluZywgcmV0dXJuaW5nIGEgcmVndWxhciBleHByZXNzaW9uLlxuICpcbiAqIEFuIGVtcHR5IGFycmF5IGNhbiBiZSBwYXNzZWQgaW4gZm9yIHRoZSBrZXlzLCB3aGljaCB3aWxsIGhvbGQgdGhlXG4gKiBwbGFjZWhvbGRlciBrZXkgZGVzY3JpcHRpb25zLiBGb3IgZXhhbXBsZSwgdXNpbmcgYC91c2VyLzppZGAsIGBrZXlzYCB3aWxsXG4gKiBjb250YWluIGBbeyBuYW1lOiAnaWQnLCBkZWxpbWl0ZXI6ICcvJywgb3B0aW9uYWw6IGZhbHNlLCByZXBlYXQ6IGZhbHNlIH1dYC5cbiAqL1xuZnVuY3Rpb24gcGF0aFRvUmVnZXhwKHBhdGgsIGtleXMsIG9wdGlvbnMpIHtcbiAgICBpZiAocGF0aCBpbnN0YW5jZW9mIFJlZ0V4cClcbiAgICAgICAgcmV0dXJuIHJlZ2V4cFRvUmVnZXhwKHBhdGgsIGtleXMpO1xuICAgIGlmIChBcnJheS5pc0FycmF5KHBhdGgpKVxuICAgICAgICByZXR1cm4gYXJyYXlUb1JlZ2V4cChwYXRoLCBrZXlzLCBvcHRpb25zKTtcbiAgICByZXR1cm4gc3RyaW5nVG9SZWdleHAocGF0aCwga2V5cywgb3B0aW9ucyk7XG59XG5leHBvcnRzLnBhdGhUb1JlZ2V4cCA9IHBhdGhUb1JlZ2V4cDtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIi8qXG5NSVQgTGljZW5zZVxuXG5Db3B5cmlnaHQgKGMpIEphc29uIE1pbGxlciAoaHR0cHM6Ly9qYXNvbmZvcm1hdC5jb20vKVxuXG5QZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSwgbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlIGZvbGxvd2luZyBjb25kaXRpb25zOlxuXG5UaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZCBpbiBhbGwgY29waWVzIG9yIHN1YnN0YW50aWFsIHBvcnRpb25zIG9mIHRoZSBTb2Z0d2FyZS5cblxuVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTUyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU4gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCwgVE9SVCBPUiBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4qL1xuXG4vLyBUaGlzIGZpbGUgaXMgYmFzZWQgb24gaHR0cHM6Ly9naXRodWIuY29tL2RldmVsb3BpdC9taXR0L2Jsb2IvdjEuMS4zL3NyYy9pbmRleC5qc1xuLy8gSXQncyBiZWVuIGVkaXRlZCBmb3IgdGhlIG5lZWRzIG9mIHRoaXMgc2NyaXB0XG4vLyBTZWUgdGhlIExJQ0VOU0UgYXQgdGhlIHRvcCBvZiB0aGUgZmlsZVxuXG50eXBlIEhhbmRsZXIgPSAoLi4uZXZ0czogYW55W10pID0+IHZvaWRcblxuZXhwb3J0IHR5cGUgTWl0dEVtaXR0ZXIgPSB7XG4gIG9uKHR5cGU6IHN0cmluZywgaGFuZGxlcjogSGFuZGxlcik6IHZvaWRcbiAgb2ZmKHR5cGU6IHN0cmluZywgaGFuZGxlcjogSGFuZGxlcik6IHZvaWRcbiAgZW1pdCh0eXBlOiBzdHJpbmcsIC4uLmV2dHM6IGFueVtdKTogdm9pZFxufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBtaXR0KCk6IE1pdHRFbWl0dGVyIHtcbiAgY29uc3QgYWxsOiB7IFtzOiBzdHJpbmddOiBIYW5kbGVyW10gfSA9IE9iamVjdC5jcmVhdGUobnVsbClcblxuICByZXR1cm4ge1xuICAgIG9uKHR5cGU6IHN0cmluZywgaGFuZGxlcjogSGFuZGxlcikge1xuICAgICAgOyhhbGxbdHlwZV0gfHwgKGFsbFt0eXBlXSA9IFtdKSkucHVzaChoYW5kbGVyKVxuICAgIH0sXG5cbiAgICBvZmYodHlwZTogc3RyaW5nLCBoYW5kbGVyOiBIYW5kbGVyKSB7XG4gICAgICBpZiAoYWxsW3R5cGVdKSB7XG4gICAgICAgIGFsbFt0eXBlXS5zcGxpY2UoYWxsW3R5cGVdLmluZGV4T2YoaGFuZGxlcikgPj4+IDAsIDEpXG4gICAgICB9XG4gICAgfSxcblxuICAgIGVtaXQodHlwZTogc3RyaW5nLCAuLi5ldnRzOiBhbnlbXSkge1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGFycmF5LWNhbGxiYWNrLXJldHVyblxuICAgICAgOyhhbGxbdHlwZV0gfHwgW10pLnNsaWNlKCkubWFwKChoYW5kbGVyOiBIYW5kbGVyKSA9PiB7XG4gICAgICAgIGhhbmRsZXIoLi4uZXZ0cylcbiAgICAgIH0pXG4gICAgfSxcbiAgfVxufVxuIiwiLyogZ2xvYmFsIF9fTkVYVF9EQVRBX18gKi9cbi8vIHRzbGludDpkaXNhYmxlOm5vLWNvbnNvbGVcbmltcG9ydCB7IFBhcnNlZFVybFF1ZXJ5IH0gZnJvbSAncXVlcnlzdHJpbmcnXG5pbXBvcnQgeyBDb21wb25lbnRUeXBlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBVcmxPYmplY3QgfSBmcm9tICd1cmwnXG5pbXBvcnQge1xuICBub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaCxcbiAgcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gsXG59IGZyb20gJy4uLy4uLy4uL2NsaWVudC9ub3JtYWxpemUtdHJhaWxpbmctc2xhc2gnXG5pbXBvcnQgeyBHb29kUGFnZUNhY2hlLCBTdHlsZVNoZWV0VHVwbGUgfSBmcm9tICcuLi8uLi8uLi9jbGllbnQvcGFnZS1sb2FkZXInXG5pbXBvcnQgeyBkZW5vcm1hbGl6ZVBhZ2VQYXRoIH0gZnJvbSAnLi4vLi4vc2VydmVyL2Rlbm9ybWFsaXplLXBhZ2UtcGF0aCdcbmltcG9ydCBtaXR0LCB7IE1pdHRFbWl0dGVyIH0gZnJvbSAnLi4vbWl0dCdcbmltcG9ydCB7XG4gIEFwcENvbnRleHRUeXBlLFxuICBmb3JtYXRXaXRoVmFsaWRhdGlvbixcbiAgZ2V0TG9jYXRpb25PcmlnaW4sXG4gIGdldFVSTCxcbiAgbG9hZEdldEluaXRpYWxQcm9wcyxcbiAgTmV4dFBhZ2VDb250ZXh0LFxuICBTVCxcbn0gZnJvbSAnLi4vdXRpbHMnXG5pbXBvcnQgeyBpc0R5bmFtaWNSb3V0ZSB9IGZyb20gJy4vdXRpbHMvaXMtZHluYW1pYydcbmltcG9ydCB7IHBhcnNlUmVsYXRpdmVVcmwgfSBmcm9tICcuL3V0aWxzL3BhcnNlLXJlbGF0aXZlLXVybCdcbmltcG9ydCB7IHNlYXJjaFBhcmFtc1RvVXJsUXVlcnkgfSBmcm9tICcuL3V0aWxzL3F1ZXJ5c3RyaW5nJ1xuaW1wb3J0IHJlc29sdmVSZXdyaXRlcyBmcm9tICcuL3V0aWxzL3Jlc29sdmUtcmV3cml0ZXMnXG5pbXBvcnQgeyBnZXRSb3V0ZU1hdGNoZXIgfSBmcm9tICcuL3V0aWxzL3JvdXRlLW1hdGNoZXInXG5pbXBvcnQgeyBnZXRSb3V0ZVJlZ2V4IH0gZnJvbSAnLi91dGlscy9yb3V0ZS1yZWdleCdcbmltcG9ydCBlc2NhcGVQYXRoRGVsaW1pdGVycyBmcm9tICcuL3V0aWxzL2VzY2FwZS1wYXRoLWRlbGltaXRlcnMnXG5cbmludGVyZmFjZSBUcmFuc2l0aW9uT3B0aW9ucyB7XG4gIHNoYWxsb3c/OiBib29sZWFuXG59XG5cbmludGVyZmFjZSBOZXh0SGlzdG9yeVN0YXRlIHtcbiAgdXJsOiBzdHJpbmdcbiAgYXM6IHN0cmluZ1xuICBvcHRpb25zOiBUcmFuc2l0aW9uT3B0aW9uc1xufVxuXG50eXBlIEhpc3RvcnlTdGF0ZSA9IG51bGwgfCB7IF9fTjogZmFsc2UgfSB8ICh7IF9fTjogdHJ1ZSB9ICYgTmV4dEhpc3RvcnlTdGF0ZSlcblxuY29uc3QgYmFzZVBhdGggPSAocHJvY2Vzcy5lbnYuX19ORVhUX1JPVVRFUl9CQVNFUEFUSCBhcyBzdHJpbmcpIHx8ICcnXG5cbmZ1bmN0aW9uIGJ1aWxkQ2FuY2VsbGF0aW9uRXJyb3IoKSB7XG4gIHJldHVybiBPYmplY3QuYXNzaWduKG5ldyBFcnJvcignUm91dGUgQ2FuY2VsbGVkJyksIHtcbiAgICBjYW5jZWxsZWQ6IHRydWUsXG4gIH0pXG59XG5cbmZ1bmN0aW9uIGFkZFBhdGhQcmVmaXgocGF0aDogc3RyaW5nLCBwcmVmaXg/OiBzdHJpbmcpIHtcbiAgcmV0dXJuIHByZWZpeCAmJiBwYXRoLnN0YXJ0c1dpdGgoJy8nKVxuICAgID8gcGF0aCA9PT0gJy8nXG4gICAgICA/IG5vcm1hbGl6ZVBhdGhUcmFpbGluZ1NsYXNoKHByZWZpeClcbiAgICAgIDogYCR7cHJlZml4fSR7cGF0aH1gXG4gICAgOiBwYXRoXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRMb2NhbGUoXG4gIHBhdGg6IHN0cmluZyxcbiAgbG9jYWxlPzogc3RyaW5nLFxuICBkZWZhdWx0TG9jYWxlPzogc3RyaW5nXG4pIHtcbiAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9pMThuX1NVUFBPUlQpIHtcbiAgICByZXR1cm4gbG9jYWxlICYmIGxvY2FsZSAhPT0gZGVmYXVsdExvY2FsZSAmJiAhcGF0aC5zdGFydHNXaXRoKCcvJyArIGxvY2FsZSlcbiAgICAgID8gYWRkUGF0aFByZWZpeChwYXRoLCAnLycgKyBsb2NhbGUpXG4gICAgICA6IHBhdGhcbiAgfVxuICByZXR1cm4gcGF0aFxufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVsTG9jYWxlKHBhdGg6IHN0cmluZywgbG9jYWxlPzogc3RyaW5nKSB7XG4gIGlmIChwcm9jZXNzLmVudi5fX05FWFRfaTE4bl9TVVBQT1JUKSB7XG4gICAgcmV0dXJuIGxvY2FsZSAmJiBwYXRoLnN0YXJ0c1dpdGgoJy8nICsgbG9jYWxlKVxuICAgICAgPyBwYXRoLnN1YnN0cihsb2NhbGUubGVuZ3RoICsgMSkgfHwgJy8nXG4gICAgICA6IHBhdGhcbiAgfVxuICByZXR1cm4gcGF0aFxufVxuXG5leHBvcnQgZnVuY3Rpb24gaGFzQmFzZVBhdGgocGF0aDogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiBwYXRoID09PSBiYXNlUGF0aCB8fCBwYXRoLnN0YXJ0c1dpdGgoYmFzZVBhdGggKyAnLycpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRCYXNlUGF0aChwYXRoOiBzdHJpbmcpOiBzdHJpbmcge1xuICAvLyB3ZSBvbmx5IGFkZCB0aGUgYmFzZXBhdGggb24gcmVsYXRpdmUgdXJsc1xuICByZXR1cm4gYWRkUGF0aFByZWZpeChwYXRoLCBiYXNlUGF0aClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlbEJhc2VQYXRoKHBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBwYXRoLnNsaWNlKGJhc2VQYXRoLmxlbmd0aCkgfHwgJy8nXG59XG5cbi8qKlxuICogRGV0ZWN0cyB3aGV0aGVyIGEgZ2l2ZW4gdXJsIGlzIHJvdXRhYmxlIGJ5IHRoZSBOZXh0LmpzIHJvdXRlciAoYnJvd3NlciBvbmx5KS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzTG9jYWxVUkwodXJsOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgaWYgKHVybC5zdGFydHNXaXRoKCcvJykpIHJldHVybiB0cnVlXG4gIHRyeSB7XG4gICAgLy8gYWJzb2x1dGUgdXJscyBjYW4gYmUgbG9jYWwgaWYgdGhleSBhcmUgb24gdGhlIHNhbWUgb3JpZ2luXG4gICAgY29uc3QgbG9jYXRpb25PcmlnaW4gPSBnZXRMb2NhdGlvbk9yaWdpbigpXG4gICAgY29uc3QgcmVzb2x2ZWQgPSBuZXcgVVJMKHVybCwgbG9jYXRpb25PcmlnaW4pXG4gICAgcmV0dXJuIHJlc29sdmVkLm9yaWdpbiA9PT0gbG9jYXRpb25PcmlnaW4gJiYgaGFzQmFzZVBhdGgocmVzb2x2ZWQucGF0aG5hbWUpXG4gIH0gY2F0Y2ggKF8pIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxufVxuXG50eXBlIFVybCA9IFVybE9iamVjdCB8IHN0cmluZ1xuXG5leHBvcnQgZnVuY3Rpb24gaW50ZXJwb2xhdGVBcyhcbiAgcm91dGU6IHN0cmluZyxcbiAgYXNQYXRobmFtZTogc3RyaW5nLFxuICBxdWVyeTogUGFyc2VkVXJsUXVlcnlcbikge1xuICBsZXQgaW50ZXJwb2xhdGVkUm91dGUgPSAnJ1xuXG4gIGNvbnN0IGR5bmFtaWNSZWdleCA9IGdldFJvdXRlUmVnZXgocm91dGUpXG4gIGNvbnN0IGR5bmFtaWNHcm91cHMgPSBkeW5hbWljUmVnZXguZ3JvdXBzXG4gIGNvbnN0IGR5bmFtaWNNYXRjaGVzID1cbiAgICAvLyBUcnkgdG8gbWF0Y2ggdGhlIGR5bmFtaWMgcm91dGUgYWdhaW5zdCB0aGUgYXNQYXRoXG4gICAgKGFzUGF0aG5hbWUgIT09IHJvdXRlID8gZ2V0Um91dGVNYXRjaGVyKGR5bmFtaWNSZWdleCkoYXNQYXRobmFtZSkgOiAnJykgfHxcbiAgICAvLyBGYWxsIGJhY2sgdG8gcmVhZGluZyB0aGUgdmFsdWVzIGZyb20gdGhlIGhyZWZcbiAgICAvLyBUT0RPOiBzaG91bGQgdGhpcyB0YWtlIHByaW9yaXR5OyBhbHNvIG5lZWQgdG8gY2hhbmdlIGluIHRoZSByb3V0ZXIuXG4gICAgcXVlcnlcblxuICBpbnRlcnBvbGF0ZWRSb3V0ZSA9IHJvdXRlXG4gIGNvbnN0IHBhcmFtcyA9IE9iamVjdC5rZXlzKGR5bmFtaWNHcm91cHMpXG5cbiAgaWYgKFxuICAgICFwYXJhbXMuZXZlcnkoKHBhcmFtKSA9PiB7XG4gICAgICBsZXQgdmFsdWUgPSBkeW5hbWljTWF0Y2hlc1twYXJhbV0gfHwgJydcbiAgICAgIGNvbnN0IHsgcmVwZWF0LCBvcHRpb25hbCB9ID0gZHluYW1pY0dyb3Vwc1twYXJhbV1cblxuICAgICAgLy8gc3VwcG9ydCBzaW5nbGUtbGV2ZWwgY2F0Y2gtYWxsXG4gICAgICAvLyBUT0RPOiBtb3JlIHJvYnVzdCBoYW5kbGluZyBmb3IgdXNlci1lcnJvciAocGFzc2luZyBgL2ApXG4gICAgICBsZXQgcmVwbGFjZWQgPSBgWyR7cmVwZWF0ID8gJy4uLicgOiAnJ30ke3BhcmFtfV1gXG4gICAgICBpZiAob3B0aW9uYWwpIHtcbiAgICAgICAgcmVwbGFjZWQgPSBgJHshdmFsdWUgPyAnLycgOiAnJ31bJHtyZXBsYWNlZH1dYFxuICAgICAgfVxuICAgICAgaWYgKHJlcGVhdCAmJiAhQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHZhbHVlID0gW3ZhbHVlXVxuXG4gICAgICByZXR1cm4gKFxuICAgICAgICAob3B0aW9uYWwgfHwgcGFyYW0gaW4gZHluYW1pY01hdGNoZXMpICYmXG4gICAgICAgIC8vIEludGVycG9sYXRlIGdyb3VwIGludG8gZGF0YSBVUkwgaWYgcHJlc2VudFxuICAgICAgICAoaW50ZXJwb2xhdGVkUm91dGUgPVxuICAgICAgICAgIGludGVycG9sYXRlZFJvdXRlIS5yZXBsYWNlKFxuICAgICAgICAgICAgcmVwbGFjZWQsXG4gICAgICAgICAgICByZXBlYXRcbiAgICAgICAgICAgICAgPyAodmFsdWUgYXMgc3RyaW5nW10pLm1hcChlc2NhcGVQYXRoRGVsaW1pdGVycykuam9pbignLycpXG4gICAgICAgICAgICAgIDogZXNjYXBlUGF0aERlbGltaXRlcnModmFsdWUgYXMgc3RyaW5nKVxuICAgICAgICAgICkgfHwgJy8nKVxuICAgICAgKVxuICAgIH0pXG4gICkge1xuICAgIGludGVycG9sYXRlZFJvdXRlID0gJycgLy8gZGlkIG5vdCBzYXRpc2Z5IGFsbCByZXF1aXJlbWVudHNcblxuICAgIC8vIG4uYi4gV2UgaWdub3JlIHRoaXMgZXJyb3IgYmVjYXVzZSB3ZSBoYW5kbGUgd2FybmluZyBmb3IgdGhpcyBjYXNlIGluXG4gICAgLy8gZGV2ZWxvcG1lbnQgaW4gdGhlIGA8TGluaz5gIGNvbXBvbmVudCBkaXJlY3RseS5cbiAgfVxuICByZXR1cm4ge1xuICAgIHBhcmFtcyxcbiAgICByZXN1bHQ6IGludGVycG9sYXRlZFJvdXRlLFxuICB9XG59XG5cbmZ1bmN0aW9uIG9taXRQYXJtc0Zyb21RdWVyeShxdWVyeTogUGFyc2VkVXJsUXVlcnksIHBhcmFtczogc3RyaW5nW10pIHtcbiAgY29uc3QgZmlsdGVyZWRRdWVyeTogUGFyc2VkVXJsUXVlcnkgPSB7fVxuXG4gIE9iamVjdC5rZXlzKHF1ZXJ5KS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICBpZiAoIXBhcmFtcy5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICBmaWx0ZXJlZFF1ZXJ5W2tleV0gPSBxdWVyeVtrZXldXG4gICAgfVxuICB9KVxuICByZXR1cm4gZmlsdGVyZWRRdWVyeVxufVxuXG4vKipcbiAqIFJlc29sdmVzIGEgZ2l2ZW4gaHlwZXJsaW5rIHdpdGggYSBjZXJ0YWluIHJvdXRlciBzdGF0ZSAoYmFzZVBhdGggbm90IGluY2x1ZGVkKS5cbiAqIFByZXNlcnZlcyBhYnNvbHV0ZSB1cmxzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUhyZWYoXG4gIGN1cnJlbnRQYXRoOiBzdHJpbmcsXG4gIGhyZWY6IFVybCxcbiAgcmVzb2x2ZUFzPzogYm9vbGVhblxuKTogc3RyaW5nIHtcbiAgLy8gd2UgdXNlIGEgZHVtbXkgYmFzZSB1cmwgZm9yIHJlbGF0aXZlIHVybHNcbiAgY29uc3QgYmFzZSA9IG5ldyBVUkwoY3VycmVudFBhdGgsICdodHRwOi8vbicpXG4gIGNvbnN0IHVybEFzU3RyaW5nID1cbiAgICB0eXBlb2YgaHJlZiA9PT0gJ3N0cmluZycgPyBocmVmIDogZm9ybWF0V2l0aFZhbGlkYXRpb24oaHJlZilcbiAgdHJ5IHtcbiAgICBjb25zdCBmaW5hbFVybCA9IG5ldyBVUkwodXJsQXNTdHJpbmcsIGJhc2UpXG4gICAgZmluYWxVcmwucGF0aG5hbWUgPSBub3JtYWxpemVQYXRoVHJhaWxpbmdTbGFzaChmaW5hbFVybC5wYXRobmFtZSlcbiAgICBsZXQgaW50ZXJwb2xhdGVkQXMgPSAnJ1xuXG4gICAgaWYgKFxuICAgICAgaXNEeW5hbWljUm91dGUoZmluYWxVcmwucGF0aG5hbWUpICYmXG4gICAgICBmaW5hbFVybC5zZWFyY2hQYXJhbXMgJiZcbiAgICAgIHJlc29sdmVBc1xuICAgICkge1xuICAgICAgY29uc3QgcXVlcnkgPSBzZWFyY2hQYXJhbXNUb1VybFF1ZXJ5KGZpbmFsVXJsLnNlYXJjaFBhcmFtcylcblxuICAgICAgY29uc3QgeyByZXN1bHQsIHBhcmFtcyB9ID0gaW50ZXJwb2xhdGVBcyhcbiAgICAgICAgZmluYWxVcmwucGF0aG5hbWUsXG4gICAgICAgIGZpbmFsVXJsLnBhdGhuYW1lLFxuICAgICAgICBxdWVyeVxuICAgICAgKVxuXG4gICAgICBpZiAocmVzdWx0KSB7XG4gICAgICAgIGludGVycG9sYXRlZEFzID0gZm9ybWF0V2l0aFZhbGlkYXRpb24oe1xuICAgICAgICAgIHBhdGhuYW1lOiByZXN1bHQsXG4gICAgICAgICAgaGFzaDogZmluYWxVcmwuaGFzaCxcbiAgICAgICAgICBxdWVyeTogb21pdFBhcm1zRnJvbVF1ZXJ5KHF1ZXJ5LCBwYXJhbXMpLFxuICAgICAgICB9KVxuICAgICAgfVxuICAgIH1cblxuICAgIC8vIGlmIHRoZSBvcmlnaW4gZGlkbid0IGNoYW5nZSwgaXQgbWVhbnMgd2UgcmVjZWl2ZWQgYSByZWxhdGl2ZSBocmVmXG4gICAgY29uc3QgcmVzb2x2ZWRIcmVmID1cbiAgICAgIGZpbmFsVXJsLm9yaWdpbiA9PT0gYmFzZS5vcmlnaW5cbiAgICAgICAgPyBmaW5hbFVybC5ocmVmLnNsaWNlKGZpbmFsVXJsLm9yaWdpbi5sZW5ndGgpXG4gICAgICAgIDogZmluYWxVcmwuaHJlZlxuXG4gICAgcmV0dXJuIChyZXNvbHZlQXNcbiAgICAgID8gW3Jlc29sdmVkSHJlZiwgaW50ZXJwb2xhdGVkQXMgfHwgcmVzb2x2ZWRIcmVmXVxuICAgICAgOiByZXNvbHZlZEhyZWYpIGFzIHN0cmluZ1xuICB9IGNhdGNoIChfKSB7XG4gICAgcmV0dXJuIChyZXNvbHZlQXMgPyBbdXJsQXNTdHJpbmddIDogdXJsQXNTdHJpbmcpIGFzIHN0cmluZ1xuICB9XG59XG5cbmNvbnN0IFBBR0VfTE9BRF9FUlJPUiA9IFN5bWJvbCgnUEFHRV9MT0FEX0VSUk9SJylcbmV4cG9ydCBmdW5jdGlvbiBtYXJrTG9hZGluZ0Vycm9yKGVycjogRXJyb3IpOiBFcnJvciB7XG4gIHJldHVybiBPYmplY3QuZGVmaW5lUHJvcGVydHkoZXJyLCBQQUdFX0xPQURfRVJST1IsIHt9KVxufVxuXG5mdW5jdGlvbiBwcmVwYXJlVXJsQXMocm91dGVyOiBOZXh0Um91dGVyLCB1cmw6IFVybCwgYXM6IFVybCkge1xuICAvLyBJZiB1cmwgYW5kIGFzIHByb3ZpZGVkIGFzIGFuIG9iamVjdCByZXByZXNlbnRhdGlvbixcbiAgLy8gd2UnbGwgZm9ybWF0IHRoZW0gaW50byB0aGUgc3RyaW5nIHZlcnNpb24gaGVyZS5cbiAgcmV0dXJuIHtcbiAgICB1cmw6IGFkZEJhc2VQYXRoKHJlc29sdmVIcmVmKHJvdXRlci5wYXRobmFtZSwgdXJsKSksXG4gICAgYXM6IGFzID8gYWRkQmFzZVBhdGgocmVzb2x2ZUhyZWYocm91dGVyLnBhdGhuYW1lLCBhcykpIDogYXMsXG4gIH1cbn1cblxuZXhwb3J0IHR5cGUgQmFzZVJvdXRlciA9IHtcbiAgcm91dGU6IHN0cmluZ1xuICBwYXRobmFtZTogc3RyaW5nXG4gIHF1ZXJ5OiBQYXJzZWRVcmxRdWVyeVxuICBhc1BhdGg6IHN0cmluZ1xuICBiYXNlUGF0aDogc3RyaW5nXG4gIGxvY2FsZT86IHN0cmluZ1xuICBsb2NhbGVzPzogc3RyaW5nW11cbiAgZGVmYXVsdExvY2FsZT86IHN0cmluZ1xufVxuXG5leHBvcnQgdHlwZSBOZXh0Um91dGVyID0gQmFzZVJvdXRlciAmXG4gIFBpY2s8XG4gICAgUm91dGVyLFxuICAgIHwgJ3B1c2gnXG4gICAgfCAncmVwbGFjZSdcbiAgICB8ICdyZWxvYWQnXG4gICAgfCAnYmFjaydcbiAgICB8ICdwcmVmZXRjaCdcbiAgICB8ICdiZWZvcmVQb3BTdGF0ZSdcbiAgICB8ICdldmVudHMnXG4gICAgfCAnaXNGYWxsYmFjaydcbiAgPlxuXG5leHBvcnQgdHlwZSBQcmVmZXRjaE9wdGlvbnMgPSB7XG4gIHByaW9yaXR5PzogYm9vbGVhblxufVxuXG5leHBvcnQgdHlwZSBQcml2YXRlUm91dGVJbmZvID0ge1xuICBDb21wb25lbnQ6IENvbXBvbmVudFR5cGVcbiAgc3R5bGVTaGVldHM6IFN0eWxlU2hlZXRUdXBsZVtdXG4gIF9fTl9TU0c/OiBib29sZWFuXG4gIF9fTl9TU1A/OiBib29sZWFuXG4gIHByb3BzPzogUmVjb3JkPHN0cmluZywgYW55PlxuICBlcnI/OiBFcnJvclxuICBlcnJvcj86IGFueVxufVxuXG5leHBvcnQgdHlwZSBBcHBQcm9wcyA9IFBpY2s8UHJpdmF0ZVJvdXRlSW5mbywgJ0NvbXBvbmVudCcgfCAnZXJyJz4gJiB7XG4gIHJvdXRlcjogUm91dGVyXG59ICYgUmVjb3JkPHN0cmluZywgYW55PlxuZXhwb3J0IHR5cGUgQXBwQ29tcG9uZW50ID0gQ29tcG9uZW50VHlwZTxBcHBQcm9wcz5cblxudHlwZSBTdWJzY3JpcHRpb24gPSAoZGF0YTogUHJpdmF0ZVJvdXRlSW5mbywgQXBwOiBBcHBDb21wb25lbnQpID0+IFByb21pc2U8dm9pZD5cblxudHlwZSBCZWZvcmVQb3BTdGF0ZUNhbGxiYWNrID0gKHN0YXRlOiBOZXh0SGlzdG9yeVN0YXRlKSA9PiBib29sZWFuXG5cbnR5cGUgQ29tcG9uZW50TG9hZENhbmNlbCA9ICgoKSA9PiB2b2lkKSB8IG51bGxcblxudHlwZSBIaXN0b3J5TWV0aG9kID0gJ3JlcGxhY2VTdGF0ZScgfCAncHVzaFN0YXRlJ1xuXG5jb25zdCBtYW51YWxTY3JvbGxSZXN0b3JhdGlvbiA9XG4gIHByb2Nlc3MuZW52Ll9fTkVYVF9TQ1JPTExfUkVTVE9SQVRJT04gJiZcbiAgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgJ3Njcm9sbFJlc3RvcmF0aW9uJyBpbiB3aW5kb3cuaGlzdG9yeVxuXG5mdW5jdGlvbiBmZXRjaFJldHJ5KHVybDogc3RyaW5nLCBhdHRlbXB0czogbnVtYmVyKTogUHJvbWlzZTxhbnk+IHtcbiAgcmV0dXJuIGZldGNoKHVybCwge1xuICAgIC8vIENvb2tpZXMgYXJlIHJlcXVpcmVkIHRvIGJlIHByZXNlbnQgZm9yIE5leHQuanMnIFNTRyBcIlByZXZpZXcgTW9kZVwiLlxuICAgIC8vIENvb2tpZXMgbWF5IGFsc28gYmUgcmVxdWlyZWQgZm9yIGBnZXRTZXJ2ZXJTaWRlUHJvcHNgLlxuICAgIC8vXG4gICAgLy8gPiBgZmV0Y2hgIHdvbuKAmXQgc2VuZCBjb29raWVzLCB1bmxlc3MgeW91IHNldCB0aGUgY3JlZGVudGlhbHMgaW5pdFxuICAgIC8vID4gb3B0aW9uLlxuICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9GZXRjaF9BUEkvVXNpbmdfRmV0Y2hcbiAgICAvL1xuICAgIC8vID4gRm9yIG1heGltdW0gYnJvd3NlciBjb21wYXRpYmlsaXR5IHdoZW4gaXQgY29tZXMgdG8gc2VuZGluZyAmXG4gICAgLy8gPiByZWNlaXZpbmcgY29va2llcywgYWx3YXlzIHN1cHBseSB0aGUgYGNyZWRlbnRpYWxzOiAnc2FtZS1vcmlnaW4nYFxuICAgIC8vID4gb3B0aW9uIGluc3RlYWQgb2YgcmVseWluZyBvbiB0aGUgZGVmYXVsdC5cbiAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vZ2l0aHViL2ZldGNoI2NhdmVhdHNcbiAgICBjcmVkZW50aWFsczogJ3NhbWUtb3JpZ2luJyxcbiAgfSkudGhlbigocmVzKSA9PiB7XG4gICAgaWYgKCFyZXMub2spIHtcbiAgICAgIGlmIChhdHRlbXB0cyA+IDEgJiYgcmVzLnN0YXR1cyA+PSA1MDApIHtcbiAgICAgICAgcmV0dXJuIGZldGNoUmV0cnkodXJsLCBhdHRlbXB0cyAtIDEpXG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBsb2FkIHN0YXRpYyBwcm9wc2ApXG4gICAgfVxuXG4gICAgcmV0dXJuIHJlcy5qc29uKClcbiAgfSlcbn1cblxuZnVuY3Rpb24gZmV0Y2hOZXh0RGF0YShkYXRhSHJlZjogc3RyaW5nLCBpc1NlcnZlclJlbmRlcjogYm9vbGVhbikge1xuICByZXR1cm4gZmV0Y2hSZXRyeShkYXRhSHJlZiwgaXNTZXJ2ZXJSZW5kZXIgPyAzIDogMSkuY2F0Y2goKGVycjogRXJyb3IpID0+IHtcbiAgICAvLyBXZSBzaG91bGQgb25seSB0cmlnZ2VyIGEgc2VydmVyLXNpZGUgdHJhbnNpdGlvbiBpZiB0aGlzIHdhcyBjYXVzZWRcbiAgICAvLyBvbiBhIGNsaWVudC1zaWRlIHRyYW5zaXRpb24uIE90aGVyd2lzZSwgd2UnZCBnZXQgaW50byBhbiBpbmZpbml0ZVxuICAgIC8vIGxvb3AuXG4gICAgaWYgKCFpc1NlcnZlclJlbmRlcikge1xuICAgICAgbWFya0xvYWRpbmdFcnJvcihlcnIpXG4gICAgfVxuICAgIHRocm93IGVyclxuICB9KVxufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSb3V0ZXIgaW1wbGVtZW50cyBCYXNlUm91dGVyIHtcbiAgcm91dGU6IHN0cmluZ1xuICBwYXRobmFtZTogc3RyaW5nXG4gIHF1ZXJ5OiBQYXJzZWRVcmxRdWVyeVxuICBhc1BhdGg6IHN0cmluZ1xuICBiYXNlUGF0aDogc3RyaW5nXG5cbiAgLyoqXG4gICAqIE1hcCBvZiBhbGwgY29tcG9uZW50cyBsb2FkZWQgaW4gYFJvdXRlcmBcbiAgICovXG4gIGNvbXBvbmVudHM6IHsgW3BhdGhuYW1lOiBzdHJpbmddOiBQcml2YXRlUm91dGVJbmZvIH1cbiAgLy8gU3RhdGljIERhdGEgQ2FjaGVcbiAgc2RjOiB7IFthc1BhdGg6IHN0cmluZ106IG9iamVjdCB9ID0ge31cbiAgc3ViOiBTdWJzY3JpcHRpb25cbiAgY2xjOiBDb21wb25lbnRMb2FkQ2FuY2VsXG4gIHBhZ2VMb2FkZXI6IGFueVxuICBfYnBzOiBCZWZvcmVQb3BTdGF0ZUNhbGxiYWNrIHwgdW5kZWZpbmVkXG4gIGV2ZW50czogTWl0dEVtaXR0ZXJcbiAgX3dyYXBBcHA6IChBcHA6IEFwcENvbXBvbmVudCkgPT4gYW55XG4gIGlzU3NyOiBib29sZWFuXG4gIGlzRmFsbGJhY2s6IGJvb2xlYW5cbiAgX2luRmxpZ2h0Um91dGU/OiBzdHJpbmdcbiAgX3NoYWxsb3c/OiBib29sZWFuXG4gIGxvY2FsZT86IHN0cmluZ1xuICBsb2NhbGVzPzogc3RyaW5nW11cbiAgZGVmYXVsdExvY2FsZT86IHN0cmluZ1xuXG4gIHN0YXRpYyBldmVudHM6IE1pdHRFbWl0dGVyID0gbWl0dCgpXG5cbiAgY29uc3RydWN0b3IoXG4gICAgcGF0aG5hbWU6IHN0cmluZyxcbiAgICBxdWVyeTogUGFyc2VkVXJsUXVlcnksXG4gICAgYXM6IHN0cmluZyxcbiAgICB7XG4gICAgICBpbml0aWFsUHJvcHMsXG4gICAgICBwYWdlTG9hZGVyLFxuICAgICAgQXBwLFxuICAgICAgd3JhcEFwcCxcbiAgICAgIENvbXBvbmVudCxcbiAgICAgIGluaXRpYWxTdHlsZVNoZWV0cyxcbiAgICAgIGVycixcbiAgICAgIHN1YnNjcmlwdGlvbixcbiAgICAgIGlzRmFsbGJhY2ssXG4gICAgICBsb2NhbGUsXG4gICAgICBsb2NhbGVzLFxuICAgICAgZGVmYXVsdExvY2FsZSxcbiAgICB9OiB7XG4gICAgICBzdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvblxuICAgICAgaW5pdGlhbFByb3BzOiBhbnlcbiAgICAgIHBhZ2VMb2FkZXI6IGFueVxuICAgICAgQ29tcG9uZW50OiBDb21wb25lbnRUeXBlXG4gICAgICBpbml0aWFsU3R5bGVTaGVldHM6IFN0eWxlU2hlZXRUdXBsZVtdXG4gICAgICBBcHA6IEFwcENvbXBvbmVudFxuICAgICAgd3JhcEFwcDogKEFwcDogQXBwQ29tcG9uZW50KSA9PiBhbnlcbiAgICAgIGVycj86IEVycm9yXG4gICAgICBpc0ZhbGxiYWNrOiBib29sZWFuXG4gICAgICBsb2NhbGU/OiBzdHJpbmdcbiAgICAgIGxvY2FsZXM/OiBzdHJpbmdbXVxuICAgICAgZGVmYXVsdExvY2FsZT86IHN0cmluZ1xuICAgIH1cbiAgKSB7XG4gICAgLy8gcmVwcmVzZW50cyB0aGUgY3VycmVudCBjb21wb25lbnQga2V5XG4gICAgdGhpcy5yb3V0ZSA9IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKHBhdGhuYW1lKVxuXG4gICAgLy8gc2V0IHVwIHRoZSBjb21wb25lbnQgY2FjaGUgKGJ5IHJvdXRlIGtleXMpXG4gICAgdGhpcy5jb21wb25lbnRzID0ge31cbiAgICAvLyBXZSBzaG91bGQgbm90IGtlZXAgdGhlIGNhY2hlLCBpZiB0aGVyZSdzIGFuIGVycm9yXG4gICAgLy8gT3RoZXJ3aXNlLCB0aGlzIGNhdXNlIGlzc3VlcyB3aGVuIHdoZW4gZ29pbmcgYmFjayBhbmRcbiAgICAvLyBjb21lIGFnYWluIHRvIHRoZSBlcnJvcmVkIHBhZ2UuXG4gICAgaWYgKHBhdGhuYW1lICE9PSAnL19lcnJvcicpIHtcbiAgICAgIHRoaXMuY29tcG9uZW50c1t0aGlzLnJvdXRlXSA9IHtcbiAgICAgICAgQ29tcG9uZW50LFxuICAgICAgICBzdHlsZVNoZWV0czogaW5pdGlhbFN0eWxlU2hlZXRzLFxuICAgICAgICBwcm9wczogaW5pdGlhbFByb3BzLFxuICAgICAgICBlcnIsXG4gICAgICAgIF9fTl9TU0c6IGluaXRpYWxQcm9wcyAmJiBpbml0aWFsUHJvcHMuX19OX1NTRyxcbiAgICAgICAgX19OX1NTUDogaW5pdGlhbFByb3BzICYmIGluaXRpYWxQcm9wcy5fX05fU1NQLFxuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMuY29tcG9uZW50c1snL19hcHAnXSA9IHtcbiAgICAgIENvbXBvbmVudDogQXBwIGFzIENvbXBvbmVudFR5cGUsXG4gICAgICBzdHlsZVNoZWV0czogW1xuICAgICAgICAvKiAvX2FwcCBkb2VzIG5vdCBuZWVkIGl0cyBzdHlsZXNoZWV0cyBtYW5hZ2VkICovXG4gICAgICBdLFxuICAgIH1cblxuICAgIC8vIEJhY2t3YXJkcyBjb21wYXQgZm9yIFJvdXRlci5yb3V0ZXIuZXZlbnRzXG4gICAgLy8gVE9ETzogU2hvdWxkIGJlIHJlbW92ZSB0aGUgZm9sbG93aW5nIG1ham9yIHZlcnNpb24gYXMgaXQgd2FzIG5ldmVyIGRvY3VtZW50ZWRcbiAgICB0aGlzLmV2ZW50cyA9IFJvdXRlci5ldmVudHNcblxuICAgIHRoaXMucGFnZUxvYWRlciA9IHBhZ2VMb2FkZXJcbiAgICB0aGlzLnBhdGhuYW1lID0gcGF0aG5hbWVcbiAgICB0aGlzLnF1ZXJ5ID0gcXVlcnlcbiAgICAvLyBpZiBhdXRvIHByZXJlbmRlcmVkIGFuZCBkeW5hbWljIHJvdXRlIHdhaXQgdG8gdXBkYXRlIGFzUGF0aFxuICAgIC8vIHVudGlsIGFmdGVyIG1vdW50IHRvIHByZXZlbnQgaHlkcmF0aW9uIG1pc21hdGNoXG4gICAgdGhpcy5hc1BhdGggPVxuICAgICAgLy8gQHRzLWlnbm9yZSB0aGlzIGlzIHRlbXBvcmFyaWx5IGdsb2JhbCAoYXR0YWNoZWQgdG8gd2luZG93KVxuICAgICAgaXNEeW5hbWljUm91dGUocGF0aG5hbWUpICYmIF9fTkVYVF9EQVRBX18uYXV0b0V4cG9ydCA/IHBhdGhuYW1lIDogYXNcbiAgICB0aGlzLmJhc2VQYXRoID0gYmFzZVBhdGhcbiAgICB0aGlzLnN1YiA9IHN1YnNjcmlwdGlvblxuICAgIHRoaXMuY2xjID0gbnVsbFxuICAgIHRoaXMuX3dyYXBBcHAgPSB3cmFwQXBwXG4gICAgLy8gbWFrZSBzdXJlIHRvIGlnbm9yZSBleHRyYSBwb3BTdGF0ZSBpbiBzYWZhcmkgb24gbmF2aWdhdGluZ1xuICAgIC8vIGJhY2sgZnJvbSBleHRlcm5hbCBzaXRlXG4gICAgdGhpcy5pc1NzciA9IHRydWVcblxuICAgIHRoaXMuaXNGYWxsYmFjayA9IGlzRmFsbGJhY2tcblxuICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfaTE4bl9TVVBQT1JUKSB7XG4gICAgICB0aGlzLmxvY2FsZSA9IGxvY2FsZVxuICAgICAgdGhpcy5sb2NhbGVzID0gbG9jYWxlc1xuICAgICAgdGhpcy5kZWZhdWx0TG9jYWxlID0gZGVmYXVsdExvY2FsZVxuICAgIH1cblxuICAgIGlmICh0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgLy8gbWFrZSBzdXJlIFwiYXNcIiBkb2Vzbid0IHN0YXJ0IHdpdGggZG91YmxlIHNsYXNoZXMgb3IgZWxzZSBpdCBjYW5cbiAgICAgIC8vIHRocm93IGFuIGVycm9yIGFzIGl0J3MgY29uc2lkZXJlZCBpbnZhbGlkXG4gICAgICBpZiAoYXMuc3Vic3RyKDAsIDIpICE9PSAnLy8nKSB7XG4gICAgICAgIC8vIGluIG9yZGVyIGZvciBgZS5zdGF0ZWAgdG8gd29yayBvbiB0aGUgYG9ucG9wc3RhdGVgIGV2ZW50XG4gICAgICAgIC8vIHdlIGhhdmUgdG8gcmVnaXN0ZXIgdGhlIGluaXRpYWwgcm91dGUgdXBvbiBpbml0aWFsaXphdGlvblxuICAgICAgICB0aGlzLmNoYW5nZVN0YXRlKFxuICAgICAgICAgICdyZXBsYWNlU3RhdGUnLFxuICAgICAgICAgIGZvcm1hdFdpdGhWYWxpZGF0aW9uKHsgcGF0aG5hbWU6IGFkZEJhc2VQYXRoKHBhdGhuYW1lKSwgcXVlcnkgfSksXG4gICAgICAgICAgZ2V0VVJMKClcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncG9wc3RhdGUnLCB0aGlzLm9uUG9wU3RhdGUpXG5cbiAgICAgIC8vIGVuYWJsZSBjdXN0b20gc2Nyb2xsIHJlc3RvcmF0aW9uIGhhbmRsaW5nIHdoZW4gYXZhaWxhYmxlXG4gICAgICAvLyBvdGhlcndpc2UgZmFsbGJhY2sgdG8gYnJvd3NlcidzIGRlZmF1bHQgaGFuZGxpbmdcbiAgICAgIGlmIChwcm9jZXNzLmVudi5fX05FWFRfU0NST0xMX1JFU1RPUkFUSU9OKSB7XG4gICAgICAgIGlmIChtYW51YWxTY3JvbGxSZXN0b3JhdGlvbikge1xuICAgICAgICAgIHdpbmRvdy5oaXN0b3J5LnNjcm9sbFJlc3RvcmF0aW9uID0gJ21hbnVhbCdcblxuICAgICAgICAgIGxldCBzY3JvbGxEZWJvdW5jZVRpbWVvdXQ6IHVuZGVmaW5lZCB8IE5vZGVKUy5UaW1lb3V0XG5cbiAgICAgICAgICBjb25zdCBkZWJvdW5jZWRTY3JvbGxTYXZlID0gKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHNjcm9sbERlYm91bmNlVGltZW91dCkgY2xlYXJUaW1lb3V0KHNjcm9sbERlYm91bmNlVGltZW91dClcblxuICAgICAgICAgICAgc2Nyb2xsRGVib3VuY2VUaW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHsgdXJsLCBhczogY3VyQXMsIG9wdGlvbnMgfSA9IGhpc3Rvcnkuc3RhdGVcbiAgICAgICAgICAgICAgdGhpcy5jaGFuZ2VTdGF0ZShcbiAgICAgICAgICAgICAgICAncmVwbGFjZVN0YXRlJyxcbiAgICAgICAgICAgICAgICB1cmwsXG4gICAgICAgICAgICAgICAgY3VyQXMsXG4gICAgICAgICAgICAgICAgT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucywge1xuICAgICAgICAgICAgICAgICAgX05fWDogd2luZG93LnNjcm9sbFgsXG4gICAgICAgICAgICAgICAgICBfTl9ZOiB3aW5kb3cuc2Nyb2xsWSxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9LCAxMClcbiAgICAgICAgICB9XG5cbiAgICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgZGVib3VuY2VkU2Nyb2xsU2F2ZSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIG9uUG9wU3RhdGUgPSAoZTogUG9wU3RhdGVFdmVudCk6IHZvaWQgPT4ge1xuICAgIGNvbnN0IHN0YXRlID0gZS5zdGF0ZSBhcyBIaXN0b3J5U3RhdGVcblxuICAgIGlmICghc3RhdGUpIHtcbiAgICAgIC8vIFdlIGdldCBzdGF0ZSBhcyB1bmRlZmluZWQgZm9yIHR3byByZWFzb25zLlxuICAgICAgLy8gIDEuIFdpdGggb2xkZXIgc2FmYXJpICg8IDgpIGFuZCBvbGRlciBjaHJvbWUgKDwgMzQpXG4gICAgICAvLyAgMi4gV2hlbiB0aGUgVVJMIGNoYW5nZWQgd2l0aCAjXG4gICAgICAvL1xuICAgICAgLy8gSW4gdGhlIGJvdGggY2FzZXMsIHdlIGRvbid0IG5lZWQgdG8gcHJvY2VlZCBhbmQgY2hhbmdlIHRoZSByb3V0ZS5cbiAgICAgIC8vIChhcyBpdCdzIGFscmVhZHkgY2hhbmdlZClcbiAgICAgIC8vIEJ1dCB3ZSBjYW4gc2ltcGx5IHJlcGxhY2UgdGhlIHN0YXRlIHdpdGggdGhlIG5ldyBjaGFuZ2VzLlxuICAgICAgLy8gQWN0dWFsbHksIGZvciAoMSkgd2UgZG9uJ3QgbmVlZCB0byBub3RoaW5nLiBCdXQgaXQncyBoYXJkIHRvIGRldGVjdCB0aGF0IGV2ZW50LlxuICAgICAgLy8gU28sIGRvaW5nIHRoZSBmb2xsb3dpbmcgZm9yICgxKSBkb2VzIG5vIGhhcm0uXG4gICAgICBjb25zdCB7IHBhdGhuYW1lLCBxdWVyeSB9ID0gdGhpc1xuICAgICAgdGhpcy5jaGFuZ2VTdGF0ZShcbiAgICAgICAgJ3JlcGxhY2VTdGF0ZScsXG4gICAgICAgIGZvcm1hdFdpdGhWYWxpZGF0aW9uKHsgcGF0aG5hbWU6IGFkZEJhc2VQYXRoKHBhdGhuYW1lKSwgcXVlcnkgfSksXG4gICAgICAgIGdldFVSTCgpXG4gICAgICApXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBpZiAoIXN0YXRlLl9fTikge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgY29uc3QgeyB1cmwsIGFzLCBvcHRpb25zIH0gPSBzdGF0ZVxuXG4gICAgY29uc3QgeyBwYXRobmFtZSB9ID0gcGFyc2VSZWxhdGl2ZVVybCh1cmwpXG5cbiAgICAvLyBNYWtlIHN1cmUgd2UgZG9uJ3QgcmUtcmVuZGVyIG9uIGluaXRpYWwgbG9hZCxcbiAgICAvLyBjYW4gYmUgY2F1c2VkIGJ5IG5hdmlnYXRpbmcgYmFjayBmcm9tIGFuIGV4dGVybmFsIHNpdGVcbiAgICBpZiAodGhpcy5pc1NzciAmJiBhcyA9PT0gdGhpcy5hc1BhdGggJiYgcGF0aG5hbWUgPT09IHRoaXMucGF0aG5hbWUpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIC8vIElmIHRoZSBkb3duc3RyZWFtIGFwcGxpY2F0aW9uIHJldHVybnMgZmFsc3ksIHJldHVybi5cbiAgICAvLyBUaGV5IHdpbGwgdGhlbiBiZSByZXNwb25zaWJsZSBmb3IgaGFuZGxpbmcgdGhlIGV2ZW50LlxuICAgIGlmICh0aGlzLl9icHMgJiYgIXRoaXMuX2JwcyhzdGF0ZSkpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHRoaXMuY2hhbmdlKFxuICAgICAgJ3JlcGxhY2VTdGF0ZScsXG4gICAgICB1cmwsXG4gICAgICBhcyxcbiAgICAgIE9iamVjdC5hc3NpZ24oe30sIG9wdGlvbnMsIHtcbiAgICAgICAgc2hhbGxvdzogb3B0aW9ucy5zaGFsbG93ICYmIHRoaXMuX3NoYWxsb3csXG4gICAgICB9KVxuICAgIClcbiAgfVxuXG4gIHJlbG9hZCgpOiB2b2lkIHtcbiAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKClcbiAgfVxuXG4gIC8qKlxuICAgKiBHbyBiYWNrIGluIGhpc3RvcnlcbiAgICovXG4gIGJhY2soKSB7XG4gICAgd2luZG93Lmhpc3RvcnkuYmFjaygpXG4gIH1cblxuICAvKipcbiAgICogUGVyZm9ybXMgYSBgcHVzaFN0YXRlYCB3aXRoIGFyZ3VtZW50c1xuICAgKiBAcGFyYW0gdXJsIG9mIHRoZSByb3V0ZVxuICAgKiBAcGFyYW0gYXMgbWFza3MgYHVybGAgZm9yIHRoZSBicm93c2VyXG4gICAqIEBwYXJhbSBvcHRpb25zIG9iamVjdCB5b3UgY2FuIGRlZmluZSBgc2hhbGxvd2AgYW5kIG90aGVyIG9wdGlvbnNcbiAgICovXG4gIHB1c2godXJsOiBVcmwsIGFzOiBVcmwgPSB1cmwsIG9wdGlvbnM6IFRyYW5zaXRpb25PcHRpb25zID0ge30pIHtcbiAgICA7KHsgdXJsLCBhcyB9ID0gcHJlcGFyZVVybEFzKHRoaXMsIHVybCwgYXMpKVxuICAgIHJldHVybiB0aGlzLmNoYW5nZSgncHVzaFN0YXRlJywgdXJsLCBhcywgb3B0aW9ucylcbiAgfVxuXG4gIC8qKlxuICAgKiBQZXJmb3JtcyBhIGByZXBsYWNlU3RhdGVgIHdpdGggYXJndW1lbnRzXG4gICAqIEBwYXJhbSB1cmwgb2YgdGhlIHJvdXRlXG4gICAqIEBwYXJhbSBhcyBtYXNrcyBgdXJsYCBmb3IgdGhlIGJyb3dzZXJcbiAgICogQHBhcmFtIG9wdGlvbnMgb2JqZWN0IHlvdSBjYW4gZGVmaW5lIGBzaGFsbG93YCBhbmQgb3RoZXIgb3B0aW9uc1xuICAgKi9cbiAgcmVwbGFjZSh1cmw6IFVybCwgYXM6IFVybCA9IHVybCwgb3B0aW9uczogVHJhbnNpdGlvbk9wdGlvbnMgPSB7fSkge1xuICAgIDsoeyB1cmwsIGFzIH0gPSBwcmVwYXJlVXJsQXModGhpcywgdXJsLCBhcykpXG4gICAgcmV0dXJuIHRoaXMuY2hhbmdlKCdyZXBsYWNlU3RhdGUnLCB1cmwsIGFzLCBvcHRpb25zKVxuICB9XG5cbiAgYXN5bmMgY2hhbmdlKFxuICAgIG1ldGhvZDogSGlzdG9yeU1ldGhvZCxcbiAgICB1cmw6IHN0cmluZyxcbiAgICBhczogc3RyaW5nLFxuICAgIG9wdGlvbnM6IFRyYW5zaXRpb25PcHRpb25zXG4gICk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIGlmICghaXNMb2NhbFVSTCh1cmwpKSB7XG4gICAgICB3aW5kb3cubG9jYXRpb24uaHJlZiA9IHVybFxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuXG4gICAgaWYgKCEob3B0aW9ucyBhcyBhbnkpLl9oKSB7XG4gICAgICB0aGlzLmlzU3NyID0gZmFsc2VcbiAgICB9XG4gICAgLy8gbWFya2luZyByb3V0ZSBjaGFuZ2VzIGFzIGEgbmF2aWdhdGlvbiBzdGFydCBlbnRyeVxuICAgIGlmIChTVCkge1xuICAgICAgcGVyZm9ybWFuY2UubWFyaygncm91dGVDaGFuZ2UnKVxuICAgIH1cblxuICAgIGlmICh0aGlzLl9pbkZsaWdodFJvdXRlKSB7XG4gICAgICB0aGlzLmFib3J0Q29tcG9uZW50TG9hZCh0aGlzLl9pbkZsaWdodFJvdXRlKVxuICAgIH1cblxuICAgIGFzID0gYWRkTG9jYWxlKGFzLCB0aGlzLmxvY2FsZSwgdGhpcy5kZWZhdWx0TG9jYWxlKVxuICAgIGNvbnN0IGNsZWFuZWRBcyA9IGRlbExvY2FsZShcbiAgICAgIGhhc0Jhc2VQYXRoKGFzKSA/IGRlbEJhc2VQYXRoKGFzKSA6IGFzLFxuICAgICAgdGhpcy5sb2NhbGVcbiAgICApXG4gICAgdGhpcy5faW5GbGlnaHRSb3V0ZSA9IGFzXG5cbiAgICAvLyBJZiB0aGUgdXJsIGNoYW5nZSBpcyBvbmx5IHJlbGF0ZWQgdG8gYSBoYXNoIGNoYW5nZVxuICAgIC8vIFdlIHNob3VsZCBub3QgcHJvY2VlZC4gV2Ugc2hvdWxkIG9ubHkgY2hhbmdlIHRoZSBzdGF0ZS5cblxuICAgIC8vIFdBUk5JTkc6IGBfaGAgaXMgYW4gaW50ZXJuYWwgb3B0aW9uIGZvciBoYW5kaW5nIE5leHQuanMgY2xpZW50LXNpZGVcbiAgICAvLyBoeWRyYXRpb24uIFlvdXIgYXBwIHNob3VsZCBfbmV2ZXJfIHVzZSB0aGlzIHByb3BlcnR5LiBJdCBtYXkgY2hhbmdlIGF0XG4gICAgLy8gYW55IHRpbWUgd2l0aG91dCBub3RpY2UuXG4gICAgaWYgKCEob3B0aW9ucyBhcyBhbnkpLl9oICYmIHRoaXMub25seUFIYXNoQ2hhbmdlKGNsZWFuZWRBcykpIHtcbiAgICAgIHRoaXMuYXNQYXRoID0gY2xlYW5lZEFzXG4gICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ2hhc2hDaGFuZ2VTdGFydCcsIGFzKVxuICAgICAgLy8gVE9ETzogZG8gd2UgbmVlZCB0aGUgcmVzb2x2ZWQgaHJlZiB3aGVuIG9ubHkgYSBoYXNoIGNoYW5nZT9cbiAgICAgIHRoaXMuY2hhbmdlU3RhdGUobWV0aG9kLCB1cmwsIGFzLCBvcHRpb25zKVxuICAgICAgdGhpcy5zY3JvbGxUb0hhc2goY2xlYW5lZEFzKVxuICAgICAgdGhpcy5ub3RpZnkodGhpcy5jb21wb25lbnRzW3RoaXMucm91dGVdKVxuICAgICAgUm91dGVyLmV2ZW50cy5lbWl0KCdoYXNoQ2hhbmdlQ29tcGxldGUnLCBhcylcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuXG4gICAgLy8gVGhlIGJ1aWxkIG1hbmlmZXN0IG5lZWRzIHRvIGJlIGxvYWRlZCBiZWZvcmUgYXV0by1zdGF0aWMgZHluYW1pYyBwYWdlc1xuICAgIC8vIGdldCB0aGVpciBxdWVyeSBwYXJhbWV0ZXJzIHRvIGFsbG93IGVuc3VyaW5nIHRoZXkgY2FuIGJlIHBhcnNlZCBwcm9wZXJseVxuICAgIC8vIHdoZW4gcmV3cml0dGVuIHRvXG4gICAgY29uc3QgcGFnZXMgPSBhd2FpdCB0aGlzLnBhZ2VMb2FkZXIuZ2V0UGFnZUxpc3QoKVxuICAgIGNvbnN0IHsgX19yZXdyaXRlczogcmV3cml0ZXMgfSA9IGF3YWl0IHRoaXMucGFnZUxvYWRlci5wcm9taXNlZEJ1aWxkTWFuaWZlc3RcblxuICAgIGxldCBwYXJzZWQgPSBwYXJzZVJlbGF0aXZlVXJsKHVybClcblxuICAgIGxldCB7IHBhdGhuYW1lLCBxdWVyeSB9ID0gcGFyc2VkXG5cbiAgICBwYXJzZWQgPSB0aGlzLl9yZXNvbHZlSHJlZihwYXJzZWQsIHBhZ2VzKSBhcyB0eXBlb2YgcGFyc2VkXG5cbiAgICBpZiAocGFyc2VkLnBhdGhuYW1lICE9PSBwYXRobmFtZSkge1xuICAgICAgcGF0aG5hbWUgPSBwYXJzZWQucGF0aG5hbWVcbiAgICAgIHVybCA9IGZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZClcbiAgICB9XG5cbiAgICAvLyB1cmwgYW5kIGFzIHNob3VsZCBhbHdheXMgYmUgcHJlZml4ZWQgd2l0aCBiYXNlUGF0aCBieSB0aGlzXG4gICAgLy8gcG9pbnQgYnkgZWl0aGVyIG5leHQvbGluayBvciByb3V0ZXIucHVzaC9yZXBsYWNlIHNvIHN0cmlwIHRoZVxuICAgIC8vIGJhc2VQYXRoIGZyb20gdGhlIHBhdGhuYW1lIHRvIG1hdGNoIHRoZSBwYWdlcyBkaXIgMS10by0xXG4gICAgcGF0aG5hbWUgPSBwYXRobmFtZVxuICAgICAgPyByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChkZWxCYXNlUGF0aChwYXRobmFtZSkpXG4gICAgICA6IHBhdGhuYW1lXG5cbiAgICAvLyBJZiBhc2tlZCB0byBjaGFuZ2UgdGhlIGN1cnJlbnQgVVJMIHdlIHNob3VsZCByZWxvYWQgdGhlIGN1cnJlbnQgcGFnZVxuICAgIC8vIChub3QgbG9jYXRpb24ucmVsb2FkKCkgYnV0IHJlbG9hZCBnZXRJbml0aWFsUHJvcHMgYW5kIG90aGVyIE5leHQuanMgc3R1ZmZzKVxuICAgIC8vIFdlIGFsc28gbmVlZCB0byBzZXQgdGhlIG1ldGhvZCA9IHJlcGxhY2VTdGF0ZSBhbHdheXNcbiAgICAvLyBhcyB0aGlzIHNob3VsZCBub3QgZ28gaW50byB0aGUgaGlzdG9yeSAoVGhhdCdzIGhvdyBicm93c2VycyB3b3JrKVxuICAgIC8vIFdlIHNob3VsZCBjb21wYXJlIHRoZSBuZXcgYXNQYXRoIHRvIHRoZSBjdXJyZW50IGFzUGF0aCwgbm90IHRoZSB1cmxcbiAgICBpZiAoIXRoaXMudXJsSXNOZXcoY2xlYW5lZEFzKSkge1xuICAgICAgbWV0aG9kID0gJ3JlcGxhY2VTdGF0ZSdcbiAgICB9XG5cbiAgICBsZXQgcm91dGUgPSByZW1vdmVQYXRoVHJhaWxpbmdTbGFzaChwYXRobmFtZSlcbiAgICBjb25zdCB7IHNoYWxsb3cgPSBmYWxzZSB9ID0gb3B0aW9uc1xuXG4gICAgLy8gd2UgbmVlZCB0byByZXNvbHZlIHRoZSBhcyB2YWx1ZSB1c2luZyByZXdyaXRlcyBmb3IgZHluYW1pYyBTU0dcbiAgICAvLyBwYWdlcyB0byBhbGxvdyBidWlsZGluZyB0aGUgZGF0YSBVUkwgY29ycmVjdGx5XG4gICAgbGV0IHJlc29sdmVkQXMgPSBhc1xuXG4gICAgaWYgKHByb2Nlc3MuZW52Ll9fTkVYVF9IQVNfUkVXUklURVMpIHtcbiAgICAgIHJlc29sdmVkQXMgPSByZXNvbHZlUmV3cml0ZXMoXG4gICAgICAgIHBhcnNlUmVsYXRpdmVVcmwoYXMpLnBhdGhuYW1lLFxuICAgICAgICBwYWdlcyxcbiAgICAgICAgYmFzZVBhdGgsXG4gICAgICAgIHJld3JpdGVzLFxuICAgICAgICBxdWVyeSxcbiAgICAgICAgKHA6IHN0cmluZykgPT4gdGhpcy5fcmVzb2x2ZUhyZWYoeyBwYXRobmFtZTogcCB9LCBwYWdlcykucGF0aG5hbWUhXG4gICAgICApXG5cbiAgICAgIGlmIChyZXNvbHZlZEFzICE9PSBhcykge1xuICAgICAgICBjb25zdCBwb3RlbnRpYWxIcmVmID0gcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2goXG4gICAgICAgICAgdGhpcy5fcmVzb2x2ZUhyZWYoXG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKHt9LCBwYXJzZWQsIHsgcGF0aG5hbWU6IHJlc29sdmVkQXMgfSksXG4gICAgICAgICAgICBwYWdlcyxcbiAgICAgICAgICAgIGZhbHNlXG4gICAgICAgICAgKS5wYXRobmFtZSFcbiAgICAgICAgKVxuXG4gICAgICAgIC8vIGlmIHRoaXMgZGlyZWN0bHkgbWF0Y2hlcyBhIHBhZ2Ugd2UgbmVlZCB0byB1cGRhdGUgdGhlIGhyZWYgdG9cbiAgICAgICAgLy8gYWxsb3cgdGhlIGNvcnJlY3QgcGFnZSBjaHVuayB0byBiZSBsb2FkZWRcbiAgICAgICAgaWYgKHBhZ2VzLmluY2x1ZGVzKHBvdGVudGlhbEhyZWYpKSB7XG4gICAgICAgICAgcm91dGUgPSBwb3RlbnRpYWxIcmVmXG4gICAgICAgICAgcGF0aG5hbWUgPSBwb3RlbnRpYWxIcmVmXG4gICAgICAgICAgcGFyc2VkLnBhdGhuYW1lID0gcGF0aG5hbWVcbiAgICAgICAgICB1cmwgPSBmb3JtYXRXaXRoVmFsaWRhdGlvbihwYXJzZWQpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmVzb2x2ZWRBcyA9IGRlbExvY2FsZShkZWxCYXNlUGF0aChyZXNvbHZlZEFzKSwgdGhpcy5sb2NhbGUpXG5cbiAgICBpZiAoaXNEeW5hbWljUm91dGUocm91dGUpKSB7XG4gICAgICBjb25zdCBwYXJzZWRBcyA9IHBhcnNlUmVsYXRpdmVVcmwocmVzb2x2ZWRBcylcbiAgICAgIGNvbnN0IGFzUGF0aG5hbWUgPSBwYXJzZWRBcy5wYXRobmFtZVxuXG4gICAgICBjb25zdCByb3V0ZVJlZ2V4ID0gZ2V0Um91dGVSZWdleChyb3V0ZSlcbiAgICAgIGNvbnN0IHJvdXRlTWF0Y2ggPSBnZXRSb3V0ZU1hdGNoZXIocm91dGVSZWdleCkoYXNQYXRobmFtZSlcbiAgICAgIGNvbnN0IHNob3VsZEludGVycG9sYXRlID0gcm91dGUgPT09IGFzUGF0aG5hbWVcbiAgICAgIGNvbnN0IGludGVycG9sYXRlZEFzID0gc2hvdWxkSW50ZXJwb2xhdGVcbiAgICAgICAgPyBpbnRlcnBvbGF0ZUFzKHJvdXRlLCBhc1BhdGhuYW1lLCBxdWVyeSlcbiAgICAgICAgOiAoe30gYXMgeyByZXN1bHQ6IHVuZGVmaW5lZDsgcGFyYW1zOiB1bmRlZmluZWQgfSlcblxuICAgICAgaWYgKCFyb3V0ZU1hdGNoIHx8IChzaG91bGRJbnRlcnBvbGF0ZSAmJiAhaW50ZXJwb2xhdGVkQXMucmVzdWx0KSkge1xuICAgICAgICBjb25zdCBtaXNzaW5nUGFyYW1zID0gT2JqZWN0LmtleXMocm91dGVSZWdleC5ncm91cHMpLmZpbHRlcihcbiAgICAgICAgICAocGFyYW0pID0+ICFxdWVyeVtwYXJhbV1cbiAgICAgICAgKVxuXG4gICAgICAgIGlmIChtaXNzaW5nUGFyYW1zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgICAgICBgJHtcbiAgICAgICAgICAgICAgICBzaG91bGRJbnRlcnBvbGF0ZVxuICAgICAgICAgICAgICAgICAgPyBgSW50ZXJwb2xhdGluZyBocmVmYFxuICAgICAgICAgICAgICAgICAgOiBgTWlzbWF0Y2hpbmcgXFxgYXNcXGAgYW5kIFxcYGhyZWZcXGBgXG4gICAgICAgICAgICAgIH0gZmFpbGVkIHRvIG1hbnVhbGx5IHByb3ZpZGUgYCArXG4gICAgICAgICAgICAgICAgYHRoZSBwYXJhbXM6ICR7bWlzc2luZ1BhcmFtcy5qb2luKFxuICAgICAgICAgICAgICAgICAgJywgJ1xuICAgICAgICAgICAgICAgICl9IGluIHRoZSBcXGBocmVmXFxgJ3MgXFxgcXVlcnlcXGBgXG4gICAgICAgICAgICApXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgKHNob3VsZEludGVycG9sYXRlXG4gICAgICAgICAgICAgID8gYFRoZSBwcm92aWRlZCBcXGBocmVmXFxgICgke3VybH0pIHZhbHVlIGlzIG1pc3NpbmcgcXVlcnkgdmFsdWVzICgke21pc3NpbmdQYXJhbXMuam9pbihcbiAgICAgICAgICAgICAgICAgICcsICdcbiAgICAgICAgICAgICAgICApfSkgdG8gYmUgaW50ZXJwb2xhdGVkIHByb3Blcmx5LiBgXG4gICAgICAgICAgICAgIDogYFRoZSBwcm92aWRlZCBcXGBhc1xcYCB2YWx1ZSAoJHthc1BhdGhuYW1lfSkgaXMgaW5jb21wYXRpYmxlIHdpdGggdGhlIFxcYGhyZWZcXGAgdmFsdWUgKCR7cm91dGV9KS4gYCkgK1xuICAgICAgICAgICAgICBgUmVhZCBtb3JlOiBodHRwczovL2Vyci5zaC92ZXJjZWwvbmV4dC5qcy8ke1xuICAgICAgICAgICAgICAgIHNob3VsZEludGVycG9sYXRlXG4gICAgICAgICAgICAgICAgICA/ICdocmVmLWludGVycG9sYXRpb24tZmFpbGVkJ1xuICAgICAgICAgICAgICAgICAgOiAnaW5jb21wYXRpYmxlLWhyZWYtYXMnXG4gICAgICAgICAgICAgIH1gXG4gICAgICAgICAgKVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKHNob3VsZEludGVycG9sYXRlKSB7XG4gICAgICAgIGFzID0gZm9ybWF0V2l0aFZhbGlkYXRpb24oXG4gICAgICAgICAgT2JqZWN0LmFzc2lnbih7fSwgcGFyc2VkQXMsIHtcbiAgICAgICAgICAgIHBhdGhuYW1lOiBpbnRlcnBvbGF0ZWRBcy5yZXN1bHQsXG4gICAgICAgICAgICBxdWVyeTogb21pdFBhcm1zRnJvbVF1ZXJ5KHF1ZXJ5LCBpbnRlcnBvbGF0ZWRBcy5wYXJhbXMhKSxcbiAgICAgICAgICB9KVxuICAgICAgICApXG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBNZXJnZSBwYXJhbXMgaW50byBgcXVlcnlgLCBvdmVyd3JpdGluZyBhbnkgc3BlY2lmaWVkIGluIHNlYXJjaFxuICAgICAgICBPYmplY3QuYXNzaWduKHF1ZXJ5LCByb3V0ZU1hdGNoKVxuICAgICAgfVxuICAgIH1cblxuICAgIFJvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VTdGFydCcsIGFzKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJvdXRlSW5mbyA9IGF3YWl0IHRoaXMuZ2V0Um91dGVJbmZvKFxuICAgICAgICByb3V0ZSxcbiAgICAgICAgcGF0aG5hbWUsXG4gICAgICAgIHF1ZXJ5LFxuICAgICAgICBhcyxcbiAgICAgICAgc2hhbGxvd1xuICAgICAgKVxuICAgICAgbGV0IHsgZXJyb3IsIHByb3BzLCBfX05fU1NHLCBfX05fU1NQIH0gPSByb3V0ZUluZm9cblxuICAgICAgLy8gaGFuZGxlIHJlZGlyZWN0IG9uIGNsaWVudC10cmFuc2l0aW9uXG4gICAgICBpZiAoXG4gICAgICAgIChfX05fU1NHIHx8IF9fTl9TU1ApICYmXG4gICAgICAgIHByb3BzICYmXG4gICAgICAgIChwcm9wcyBhcyBhbnkpLnBhZ2VQcm9wcyAmJlxuICAgICAgICAocHJvcHMgYXMgYW55KS5wYWdlUHJvcHMuX19OX1JFRElSRUNUXG4gICAgICApIHtcbiAgICAgICAgY29uc3QgZGVzdGluYXRpb24gPSAocHJvcHMgYXMgYW55KS5wYWdlUHJvcHMuX19OX1JFRElSRUNUXG5cbiAgICAgICAgLy8gY2hlY2sgaWYgZGVzdGluYXRpb24gaXMgaW50ZXJuYWwgKHJlc29sdmVzIHRvIGEgcGFnZSkgYW5kIGF0dGVtcHRcbiAgICAgICAgLy8gY2xpZW50LW5hdmlnYXRpb24gaWYgaXQgaXMgZmFsbGluZyBiYWNrIHRvIGhhcmQgbmF2aWdhdGlvbiBpZlxuICAgICAgICAvLyBpdCdzIG5vdFxuICAgICAgICBpZiAoZGVzdGluYXRpb24uc3RhcnRzV2l0aCgnLycpKSB7XG4gICAgICAgICAgY29uc3QgcGFyc2VkSHJlZiA9IHBhcnNlUmVsYXRpdmVVcmwoZGVzdGluYXRpb24pXG4gICAgICAgICAgdGhpcy5fcmVzb2x2ZUhyZWYocGFyc2VkSHJlZiwgcGFnZXMpXG5cbiAgICAgICAgICBpZiAocGFnZXMuaW5jbHVkZXMocGFyc2VkSHJlZi5wYXRobmFtZSkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNoYW5nZShcbiAgICAgICAgICAgICAgJ3JlcGxhY2VTdGF0ZScsXG4gICAgICAgICAgICAgIGRlc3RpbmF0aW9uLFxuICAgICAgICAgICAgICBkZXN0aW5hdGlvbixcbiAgICAgICAgICAgICAgb3B0aW9uc1xuICAgICAgICAgICAgKVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gZGVzdGluYXRpb25cbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKCgpID0+IHt9KVxuICAgICAgfVxuXG4gICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ2JlZm9yZUhpc3RvcnlDaGFuZ2UnLCBhcylcbiAgICAgIHRoaXMuY2hhbmdlU3RhdGUoXG4gICAgICAgIG1ldGhvZCxcbiAgICAgICAgdXJsLFxuICAgICAgICBhZGRMb2NhbGUoYXMsIHRoaXMubG9jYWxlLCB0aGlzLmRlZmF1bHRMb2NhbGUpLFxuICAgICAgICBvcHRpb25zXG4gICAgICApXG5cbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnN0IGFwcENvbXA6IGFueSA9IHRoaXMuY29tcG9uZW50c1snL19hcHAnXS5Db21wb25lbnRcbiAgICAgICAgOyh3aW5kb3cgYXMgYW55KS5uZXh0LmlzUHJlcmVuZGVyZWQgPVxuICAgICAgICAgIGFwcENvbXAuZ2V0SW5pdGlhbFByb3BzID09PSBhcHBDb21wLm9yaWdHZXRJbml0aWFsUHJvcHMgJiZcbiAgICAgICAgICAhKHJvdXRlSW5mby5Db21wb25lbnQgYXMgYW55KS5nZXRJbml0aWFsUHJvcHNcbiAgICAgIH1cblxuICAgICAgYXdhaXQgdGhpcy5zZXQocm91dGUsIHBhdGhuYW1lISwgcXVlcnksIGNsZWFuZWRBcywgcm91dGVJbmZvKS5jYXRjaChcbiAgICAgICAgKGUpID0+IHtcbiAgICAgICAgICBpZiAoZS5jYW5jZWxsZWQpIGVycm9yID0gZXJyb3IgfHwgZVxuICAgICAgICAgIGVsc2UgdGhyb3cgZVxuICAgICAgICB9XG4gICAgICApXG5cbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ3JvdXRlQ2hhbmdlRXJyb3InLCBlcnJvciwgY2xlYW5lZEFzKVxuICAgICAgICB0aHJvdyBlcnJvclxuICAgICAgfVxuXG4gICAgICBpZiAocHJvY2Vzcy5lbnYuX19ORVhUX1NDUk9MTF9SRVNUT1JBVElPTikge1xuICAgICAgICBpZiAobWFudWFsU2Nyb2xsUmVzdG9yYXRpb24gJiYgJ19OX1gnIGluIG9wdGlvbnMpIHtcbiAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oKG9wdGlvbnMgYXMgYW55KS5fTl9YLCAob3B0aW9ucyBhcyBhbnkpLl9OX1kpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VDb21wbGV0ZScsIGFzKVxuXG4gICAgICByZXR1cm4gdHJ1ZVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyci5jYW5jZWxsZWQpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG4gICAgICB0aHJvdyBlcnJcbiAgICB9XG4gIH1cblxuICBjaGFuZ2VTdGF0ZShcbiAgICBtZXRob2Q6IEhpc3RvcnlNZXRob2QsXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgYXM6IHN0cmluZyxcbiAgICBvcHRpb25zOiBUcmFuc2l0aW9uT3B0aW9ucyA9IHt9XG4gICk6IHZvaWQge1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICBpZiAodHlwZW9mIHdpbmRvdy5oaXN0b3J5ID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBXYXJuaW5nOiB3aW5kb3cuaGlzdG9yeSBpcyBub3QgYXZhaWxhYmxlLmApXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBpZiAodHlwZW9mIHdpbmRvdy5oaXN0b3J5W21ldGhvZF0gPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYFdhcm5pbmc6IHdpbmRvdy5oaXN0b3J5LiR7bWV0aG9kfSBpcyBub3QgYXZhaWxhYmxlYClcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKG1ldGhvZCAhPT0gJ3B1c2hTdGF0ZScgfHwgZ2V0VVJMKCkgIT09IGFzKSB7XG4gICAgICB0aGlzLl9zaGFsbG93ID0gb3B0aW9ucy5zaGFsbG93XG4gICAgICB3aW5kb3cuaGlzdG9yeVttZXRob2RdKFxuICAgICAgICB7XG4gICAgICAgICAgdXJsLFxuICAgICAgICAgIGFzLFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICAgX19OOiB0cnVlLFxuICAgICAgICB9IGFzIEhpc3RvcnlTdGF0ZSxcbiAgICAgICAgLy8gTW9zdCBicm93c2VycyBjdXJyZW50bHkgaWdub3JlcyB0aGlzIHBhcmFtZXRlciwgYWx0aG91Z2ggdGhleSBtYXkgdXNlIGl0IGluIHRoZSBmdXR1cmUuXG4gICAgICAgIC8vIFBhc3NpbmcgdGhlIGVtcHR5IHN0cmluZyBoZXJlIHNob3VsZCBiZSBzYWZlIGFnYWluc3QgZnV0dXJlIGNoYW5nZXMgdG8gdGhlIG1ldGhvZC5cbiAgICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0hpc3RvcnkvcmVwbGFjZVN0YXRlXG4gICAgICAgICcnLFxuICAgICAgICBhc1xuICAgICAgKVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGhhbmRsZVJvdXRlSW5mb0Vycm9yKFxuICAgIGVycjogRXJyb3IgJiB7IGNvZGU6IGFueTsgY2FuY2VsbGVkOiBib29sZWFuIH0sXG4gICAgcGF0aG5hbWU6IHN0cmluZyxcbiAgICBxdWVyeTogUGFyc2VkVXJsUXVlcnksXG4gICAgYXM6IHN0cmluZyxcbiAgICBsb2FkRXJyb3JGYWlsPzogYm9vbGVhblxuICApOiBQcm9taXNlPFByaXZhdGVSb3V0ZUluZm8+IHtcbiAgICBpZiAoZXJyLmNhbmNlbGxlZCkge1xuICAgICAgLy8gYnViYmxlIHVwIGNhbmNlbGxhdGlvbiBlcnJvcnNcbiAgICAgIHRocm93IGVyclxuICAgIH1cblxuICAgIGlmIChQQUdFX0xPQURfRVJST1IgaW4gZXJyIHx8IGxvYWRFcnJvckZhaWwpIHtcbiAgICAgIFJvdXRlci5ldmVudHMuZW1pdCgncm91dGVDaGFuZ2VFcnJvcicsIGVyciwgYXMpXG5cbiAgICAgIC8vIElmIHdlIGNhbid0IGxvYWQgdGhlIHBhZ2UgaXQgY291bGQgYmUgb25lIG9mIGZvbGxvd2luZyByZWFzb25zXG4gICAgICAvLyAgMS4gUGFnZSBkb2Vzbid0IGV4aXN0c1xuICAgICAgLy8gIDIuIFBhZ2UgZG9lcyBleGlzdCBpbiBhIGRpZmZlcmVudCB6b25lXG4gICAgICAvLyAgMy4gSW50ZXJuYWwgZXJyb3Igd2hpbGUgbG9hZGluZyB0aGUgcGFnZVxuXG4gICAgICAvLyBTbywgZG9pbmcgYSBoYXJkIHJlbG9hZCBpcyB0aGUgcHJvcGVyIHdheSB0byBkZWFsIHdpdGggdGhpcy5cbiAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gYXNcblxuICAgICAgLy8gQ2hhbmdpbmcgdGhlIFVSTCBkb2Vzbid0IGJsb2NrIGV4ZWN1dGluZyB0aGUgY3VycmVudCBjb2RlIHBhdGguXG4gICAgICAvLyBTbyBsZXQncyB0aHJvdyBhIGNhbmNlbGxhdGlvbiBlcnJvciBzdG9wIHRoZSByb3V0aW5nIGxvZ2ljLlxuICAgICAgdGhyb3cgYnVpbGRDYW5jZWxsYXRpb25FcnJvcigpXG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgcGFnZTogQ29tcG9uZW50LCBzdHlsZVNoZWV0cyB9ID0gYXdhaXQgdGhpcy5mZXRjaENvbXBvbmVudChcbiAgICAgICAgJy9fZXJyb3InXG4gICAgICApXG4gICAgICBjb25zdCByb3V0ZUluZm86IFByaXZhdGVSb3V0ZUluZm8gPSB7XG4gICAgICAgIENvbXBvbmVudCxcbiAgICAgICAgc3R5bGVTaGVldHMsXG4gICAgICAgIGVycixcbiAgICAgICAgZXJyb3I6IGVycixcbiAgICAgIH1cblxuICAgICAgdHJ5IHtcbiAgICAgICAgcm91dGVJbmZvLnByb3BzID0gYXdhaXQgdGhpcy5nZXRJbml0aWFsUHJvcHMoQ29tcG9uZW50LCB7XG4gICAgICAgICAgZXJyLFxuICAgICAgICAgIHBhdGhuYW1lLFxuICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICB9IGFzIGFueSlcbiAgICAgIH0gY2F0Y2ggKGdpcEVycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBpbiBlcnJvciBwYWdlIGBnZXRJbml0aWFsUHJvcHNgOiAnLCBnaXBFcnIpXG4gICAgICAgIHJvdXRlSW5mby5wcm9wcyA9IHt9XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByb3V0ZUluZm9cbiAgICB9IGNhdGNoIChyb3V0ZUluZm9FcnIpIHtcbiAgICAgIHJldHVybiB0aGlzLmhhbmRsZVJvdXRlSW5mb0Vycm9yKHJvdXRlSW5mb0VyciwgcGF0aG5hbWUsIHF1ZXJ5LCBhcywgdHJ1ZSlcbiAgICB9XG4gIH1cblxuICBhc3luYyBnZXRSb3V0ZUluZm8oXG4gICAgcm91dGU6IHN0cmluZyxcbiAgICBwYXRobmFtZTogc3RyaW5nLFxuICAgIHF1ZXJ5OiBhbnksXG4gICAgYXM6IHN0cmluZyxcbiAgICBzaGFsbG93OiBib29sZWFuID0gZmFsc2VcbiAgKTogUHJvbWlzZTxQcml2YXRlUm91dGVJbmZvPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNhY2hlZFJvdXRlSW5mbyA9IHRoaXMuY29tcG9uZW50c1tyb3V0ZV1cblxuICAgICAgaWYgKHNoYWxsb3cgJiYgY2FjaGVkUm91dGVJbmZvICYmIHRoaXMucm91dGUgPT09IHJvdXRlKSB7XG4gICAgICAgIHJldHVybiBjYWNoZWRSb3V0ZUluZm9cbiAgICAgIH1cblxuICAgICAgY29uc3Qgcm91dGVJbmZvOiBQcml2YXRlUm91dGVJbmZvID0gY2FjaGVkUm91dGVJbmZvXG4gICAgICAgID8gY2FjaGVkUm91dGVJbmZvXG4gICAgICAgIDogYXdhaXQgdGhpcy5mZXRjaENvbXBvbmVudChyb3V0ZSkudGhlbigocmVzKSA9PiAoe1xuICAgICAgICAgICAgQ29tcG9uZW50OiByZXMucGFnZSxcbiAgICAgICAgICAgIHN0eWxlU2hlZXRzOiByZXMuc3R5bGVTaGVldHMsXG4gICAgICAgICAgICBfX05fU1NHOiByZXMubW9kLl9fTl9TU0csXG4gICAgICAgICAgICBfX05fU1NQOiByZXMubW9kLl9fTl9TU1AsXG4gICAgICAgICAgfSkpXG5cbiAgICAgIGNvbnN0IHsgQ29tcG9uZW50LCBfX05fU1NHLCBfX05fU1NQIH0gPSByb3V0ZUluZm9cblxuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgY29uc3QgeyBpc1ZhbGlkRWxlbWVudFR5cGUgfSA9IHJlcXVpcmUoJ3JlYWN0LWlzJylcbiAgICAgICAgaWYgKCFpc1ZhbGlkRWxlbWVudFR5cGUoQ29tcG9uZW50KSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgIGBUaGUgZGVmYXVsdCBleHBvcnQgaXMgbm90IGEgUmVhY3QgQ29tcG9uZW50IGluIHBhZ2U6IFwiJHtwYXRobmFtZX1cImBcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbGV0IGRhdGFIcmVmOiBzdHJpbmcgfCB1bmRlZmluZWRcblxuICAgICAgaWYgKF9fTl9TU0cgfHwgX19OX1NTUCkge1xuICAgICAgICBkYXRhSHJlZiA9IHRoaXMucGFnZUxvYWRlci5nZXREYXRhSHJlZihcbiAgICAgICAgICBmb3JtYXRXaXRoVmFsaWRhdGlvbih7IHBhdGhuYW1lLCBxdWVyeSB9KSxcbiAgICAgICAgICBkZWxCYXNlUGF0aChhcyksXG4gICAgICAgICAgX19OX1NTRyxcbiAgICAgICAgICB0aGlzLmxvY2FsZSxcbiAgICAgICAgICB0aGlzLmRlZmF1bHRMb2NhbGVcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICBjb25zdCBwcm9wcyA9IGF3YWl0IHRoaXMuX2dldERhdGE8UHJpdmF0ZVJvdXRlSW5mbz4oKCkgPT5cbiAgICAgICAgX19OX1NTR1xuICAgICAgICAgID8gdGhpcy5fZ2V0U3RhdGljRGF0YShkYXRhSHJlZiEpXG4gICAgICAgICAgOiBfX05fU1NQXG4gICAgICAgICAgPyB0aGlzLl9nZXRTZXJ2ZXJEYXRhKGRhdGFIcmVmISlcbiAgICAgICAgICA6IHRoaXMuZ2V0SW5pdGlhbFByb3BzKFxuICAgICAgICAgICAgICBDb21wb25lbnQsXG4gICAgICAgICAgICAgIC8vIHdlIHByb3ZpZGUgQXBwVHJlZSBsYXRlciBzbyB0aGlzIG5lZWRzIHRvIGJlIGBhbnlgXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBwYXRobmFtZSxcbiAgICAgICAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICAgICAgICBhc1BhdGg6IGFzLFxuICAgICAgICAgICAgICB9IGFzIGFueVxuICAgICAgICAgICAgKVxuICAgICAgKVxuXG4gICAgICByb3V0ZUluZm8ucHJvcHMgPSBwcm9wc1xuICAgICAgdGhpcy5jb21wb25lbnRzW3JvdXRlXSA9IHJvdXRlSW5mb1xuICAgICAgcmV0dXJuIHJvdXRlSW5mb1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlUm91dGVJbmZvRXJyb3IoZXJyLCBwYXRobmFtZSwgcXVlcnksIGFzKVxuICAgIH1cbiAgfVxuXG4gIHNldChcbiAgICByb3V0ZTogc3RyaW5nLFxuICAgIHBhdGhuYW1lOiBzdHJpbmcsXG4gICAgcXVlcnk6IFBhcnNlZFVybFF1ZXJ5LFxuICAgIGFzOiBzdHJpbmcsXG4gICAgZGF0YTogUHJpdmF0ZVJvdXRlSW5mb1xuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0aGlzLmlzRmFsbGJhY2sgPSBmYWxzZVxuXG4gICAgdGhpcy5yb3V0ZSA9IHJvdXRlXG4gICAgdGhpcy5wYXRobmFtZSA9IHBhdGhuYW1lXG4gICAgdGhpcy5xdWVyeSA9IHF1ZXJ5XG4gICAgdGhpcy5hc1BhdGggPSBhc1xuICAgIHJldHVybiB0aGlzLm5vdGlmeShkYXRhKVxuICB9XG5cbiAgLyoqXG4gICAqIENhbGxiYWNrIHRvIGV4ZWN1dGUgYmVmb3JlIHJlcGxhY2luZyByb3V0ZXIgc3RhdGVcbiAgICogQHBhcmFtIGNiIGNhbGxiYWNrIHRvIGJlIGV4ZWN1dGVkXG4gICAqL1xuICBiZWZvcmVQb3BTdGF0ZShjYjogQmVmb3JlUG9wU3RhdGVDYWxsYmFjaykge1xuICAgIHRoaXMuX2JwcyA9IGNiXG4gIH1cblxuICBvbmx5QUhhc2hDaGFuZ2UoYXM6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIGlmICghdGhpcy5hc1BhdGgpIHJldHVybiBmYWxzZVxuICAgIGNvbnN0IFtvbGRVcmxOb0hhc2gsIG9sZEhhc2hdID0gdGhpcy5hc1BhdGguc3BsaXQoJyMnKVxuICAgIGNvbnN0IFtuZXdVcmxOb0hhc2gsIG5ld0hhc2hdID0gYXMuc3BsaXQoJyMnKVxuXG4gICAgLy8gTWFrZXMgc3VyZSB3ZSBzY3JvbGwgdG8gdGhlIHByb3ZpZGVkIGhhc2ggaWYgdGhlIHVybC9oYXNoIGFyZSB0aGUgc2FtZVxuICAgIGlmIChuZXdIYXNoICYmIG9sZFVybE5vSGFzaCA9PT0gbmV3VXJsTm9IYXNoICYmIG9sZEhhc2ggPT09IG5ld0hhc2gpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuXG4gICAgLy8gSWYgdGhlIHVybHMgYXJlIGNoYW5nZSwgdGhlcmUncyBtb3JlIHRoYW4gYSBoYXNoIGNoYW5nZVxuICAgIGlmIChvbGRVcmxOb0hhc2ggIT09IG5ld1VybE5vSGFzaCkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuXG4gICAgLy8gSWYgdGhlIGhhc2ggaGFzIGNoYW5nZWQsIHRoZW4gaXQncyBhIGhhc2ggb25seSBjaGFuZ2UuXG4gICAgLy8gVGhpcyBjaGVjayBpcyBuZWNlc3NhcnkgdG8gaGFuZGxlIGJvdGggdGhlIGVudGVyIGFuZFxuICAgIC8vIGxlYXZlIGhhc2ggPT09ICcnIGNhc2VzLiBUaGUgaWRlbnRpdHkgY2FzZSBmYWxscyB0aHJvdWdoXG4gICAgLy8gYW5kIGlzIHRyZWF0ZWQgYXMgYSBuZXh0IHJlbG9hZC5cbiAgICByZXR1cm4gb2xkSGFzaCAhPT0gbmV3SGFzaFxuICB9XG5cbiAgc2Nyb2xsVG9IYXNoKGFzOiBzdHJpbmcpOiB2b2lkIHtcbiAgICBjb25zdCBbLCBoYXNoXSA9IGFzLnNwbGl0KCcjJylcbiAgICAvLyBTY3JvbGwgdG8gdG9wIGlmIHRoZSBoYXNoIGlzIGp1c3QgYCNgIHdpdGggbm8gdmFsdWVcbiAgICBpZiAoaGFzaCA9PT0gJycpIHtcbiAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCAwKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgLy8gRmlyc3Qgd2UgY2hlY2sgaWYgdGhlIGVsZW1lbnQgYnkgaWQgaXMgZm91bmRcbiAgICBjb25zdCBpZEVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaGFzaClcbiAgICBpZiAoaWRFbCkge1xuICAgICAgaWRFbC5zY3JvbGxJbnRvVmlldygpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgLy8gSWYgdGhlcmUncyBubyBlbGVtZW50IHdpdGggdGhlIGlkLCB3ZSBjaGVjayB0aGUgYG5hbWVgIHByb3BlcnR5XG4gICAgLy8gVG8gbWlycm9yIGJyb3dzZXJzXG4gICAgY29uc3QgbmFtZUVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeU5hbWUoaGFzaClbMF1cbiAgICBpZiAobmFtZUVsKSB7XG4gICAgICBuYW1lRWwuc2Nyb2xsSW50b1ZpZXcoKVxuICAgIH1cbiAgfVxuXG4gIHVybElzTmV3KGFzUGF0aDogc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuYXNQYXRoICE9PSBhc1BhdGhcbiAgfVxuXG4gIF9yZXNvbHZlSHJlZihwYXJzZWRIcmVmOiBVcmxPYmplY3QsIHBhZ2VzOiBzdHJpbmdbXSwgYXBwbHlCYXNlUGF0aCA9IHRydWUpIHtcbiAgICBjb25zdCB7IHBhdGhuYW1lIH0gPSBwYXJzZWRIcmVmXG4gICAgY29uc3QgY2xlYW5QYXRobmFtZSA9IHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKFxuICAgICAgZGVub3JtYWxpemVQYWdlUGF0aChhcHBseUJhc2VQYXRoID8gZGVsQmFzZVBhdGgocGF0aG5hbWUhKSA6IHBhdGhuYW1lISlcbiAgICApXG5cbiAgICBpZiAoY2xlYW5QYXRobmFtZSA9PT0gJy80MDQnIHx8IGNsZWFuUGF0aG5hbWUgPT09ICcvX2Vycm9yJykge1xuICAgICAgcmV0dXJuIHBhcnNlZEhyZWZcbiAgICB9XG5cbiAgICAvLyBoYW5kbGUgcmVzb2x2aW5nIGhyZWYgZm9yIGR5bmFtaWMgcm91dGVzXG4gICAgaWYgKCFwYWdlcy5pbmNsdWRlcyhjbGVhblBhdGhuYW1lISkpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBhcnJheS1jYWxsYmFjay1yZXR1cm5cbiAgICAgIHBhZ2VzLnNvbWUoKHBhZ2UpID0+IHtcbiAgICAgICAgaWYgKFxuICAgICAgICAgIGlzRHluYW1pY1JvdXRlKHBhZ2UpICYmXG4gICAgICAgICAgZ2V0Um91dGVSZWdleChwYWdlKS5yZS50ZXN0KGNsZWFuUGF0aG5hbWUhKVxuICAgICAgICApIHtcbiAgICAgICAgICBwYXJzZWRIcmVmLnBhdGhuYW1lID0gYXBwbHlCYXNlUGF0aCA/IGFkZEJhc2VQYXRoKHBhZ2UpIDogcGFnZVxuICAgICAgICAgIHJldHVybiB0cnVlXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuICAgIHJldHVybiBwYXJzZWRIcmVmXG4gIH1cblxuICAvKipcbiAgICogUHJlZmV0Y2ggcGFnZSBjb2RlLCB5b3UgbWF5IHdhaXQgZm9yIHRoZSBkYXRhIGR1cmluZyBwYWdlIHJlbmRlcmluZy5cbiAgICogVGhpcyBmZWF0dXJlIG9ubHkgd29ya3MgaW4gcHJvZHVjdGlvbiFcbiAgICogQHBhcmFtIHVybCB0aGUgaHJlZiBvZiBwcmVmZXRjaGVkIHBhZ2VcbiAgICogQHBhcmFtIGFzUGF0aCB0aGUgYXMgcGF0aCBvZiB0aGUgcHJlZmV0Y2hlZCBwYWdlXG4gICAqL1xuICBhc3luYyBwcmVmZXRjaChcbiAgICB1cmw6IHN0cmluZyxcbiAgICBhc1BhdGg6IHN0cmluZyA9IHVybCxcbiAgICBvcHRpb25zOiBQcmVmZXRjaE9wdGlvbnMgPSB7fVxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBsZXQgcGFyc2VkID0gcGFyc2VSZWxhdGl2ZVVybCh1cmwpXG5cbiAgICBsZXQgeyBwYXRobmFtZSB9ID0gcGFyc2VkXG5cbiAgICBjb25zdCBwYWdlcyA9IGF3YWl0IHRoaXMucGFnZUxvYWRlci5nZXRQYWdlTGlzdCgpXG5cbiAgICBwYXJzZWQgPSB0aGlzLl9yZXNvbHZlSHJlZihwYXJzZWQsIHBhZ2VzKSBhcyB0eXBlb2YgcGFyc2VkXG5cbiAgICBpZiAocGFyc2VkLnBhdGhuYW1lICE9PSBwYXRobmFtZSkge1xuICAgICAgcGF0aG5hbWUgPSBwYXJzZWQucGF0aG5hbWVcbiAgICAgIHVybCA9IGZvcm1hdFdpdGhWYWxpZGF0aW9uKHBhcnNlZClcbiAgICB9XG5cbiAgICAvLyBQcmVmZXRjaCBpcyBub3Qgc3VwcG9ydGVkIGluIGRldmVsb3BtZW50IG1vZGUgYmVjYXVzZSBpdCB3b3VsZCB0cmlnZ2VyIG9uLWRlbWFuZC1lbnRyaWVzXG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGNvbnN0IHJvdXRlID0gcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2gocGF0aG5hbWUpXG4gICAgYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgdGhpcy5wYWdlTG9hZGVyLnByZWZldGNoRGF0YShcbiAgICAgICAgdXJsLFxuICAgICAgICBhc1BhdGgsXG4gICAgICAgIHRoaXMubG9jYWxlLFxuICAgICAgICB0aGlzLmRlZmF1bHRMb2NhbGVcbiAgICAgICksXG4gICAgICB0aGlzLnBhZ2VMb2FkZXJbb3B0aW9ucy5wcmlvcml0eSA/ICdsb2FkUGFnZScgOiAncHJlZmV0Y2gnXShyb3V0ZSksXG4gICAgXSlcbiAgfVxuXG4gIGFzeW5jIGZldGNoQ29tcG9uZW50KHJvdXRlOiBzdHJpbmcpOiBQcm9taXNlPEdvb2RQYWdlQ2FjaGU+IHtcbiAgICBsZXQgY2FuY2VsbGVkID0gZmFsc2VcbiAgICBjb25zdCBjYW5jZWwgPSAodGhpcy5jbGMgPSAoKSA9PiB7XG4gICAgICBjYW5jZWxsZWQgPSB0cnVlXG4gICAgfSlcblxuICAgIGNvbnN0IGNvbXBvbmVudFJlc3VsdCA9IGF3YWl0IHRoaXMucGFnZUxvYWRlci5sb2FkUGFnZShyb3V0ZSlcblxuICAgIGlmIChjYW5jZWxsZWQpIHtcbiAgICAgIGNvbnN0IGVycm9yOiBhbnkgPSBuZXcgRXJyb3IoXG4gICAgICAgIGBBYm9ydCBmZXRjaGluZyBjb21wb25lbnQgZm9yIHJvdXRlOiBcIiR7cm91dGV9XCJgXG4gICAgICApXG4gICAgICBlcnJvci5jYW5jZWxsZWQgPSB0cnVlXG4gICAgICB0aHJvdyBlcnJvclxuICAgIH1cblxuICAgIGlmIChjYW5jZWwgPT09IHRoaXMuY2xjKSB7XG4gICAgICB0aGlzLmNsYyA9IG51bGxcbiAgICB9XG5cbiAgICByZXR1cm4gY29tcG9uZW50UmVzdWx0XG4gIH1cblxuICBfZ2V0RGF0YTxUPihmbjogKCkgPT4gUHJvbWlzZTxUPik6IFByb21pc2U8VD4ge1xuICAgIGxldCBjYW5jZWxsZWQgPSBmYWxzZVxuICAgIGNvbnN0IGNhbmNlbCA9ICgpID0+IHtcbiAgICAgIGNhbmNlbGxlZCA9IHRydWVcbiAgICB9XG4gICAgdGhpcy5jbGMgPSBjYW5jZWxcbiAgICByZXR1cm4gZm4oKS50aGVuKChkYXRhKSA9PiB7XG4gICAgICBpZiAoY2FuY2VsID09PSB0aGlzLmNsYykge1xuICAgICAgICB0aGlzLmNsYyA9IG51bGxcbiAgICAgIH1cblxuICAgICAgaWYgKGNhbmNlbGxlZCkge1xuICAgICAgICBjb25zdCBlcnI6IGFueSA9IG5ldyBFcnJvcignTG9hZGluZyBpbml0aWFsIHByb3BzIGNhbmNlbGxlZCcpXG4gICAgICAgIGVyci5jYW5jZWxsZWQgPSB0cnVlXG4gICAgICAgIHRocm93IGVyclxuICAgICAgfVxuXG4gICAgICByZXR1cm4gZGF0YVxuICAgIH0pXG4gIH1cblxuICBfZ2V0U3RhdGljRGF0YShkYXRhSHJlZjogc3RyaW5nKTogUHJvbWlzZTxvYmplY3Q+IHtcbiAgICBjb25zdCB7IGhyZWY6IGNhY2hlS2V5IH0gPSBuZXcgVVJMKGRhdGFIcmVmLCB3aW5kb3cubG9jYXRpb24uaHJlZilcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdwcm9kdWN0aW9uJyAmJiB0aGlzLnNkY1tjYWNoZUtleV0pIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodGhpcy5zZGNbY2FjaGVLZXldKVxuICAgIH1cbiAgICByZXR1cm4gZmV0Y2hOZXh0RGF0YShkYXRhSHJlZiwgdGhpcy5pc1NzcikudGhlbigoZGF0YSkgPT4ge1xuICAgICAgdGhpcy5zZGNbY2FjaGVLZXldID0gZGF0YVxuICAgICAgcmV0dXJuIGRhdGFcbiAgICB9KVxuICB9XG5cbiAgX2dldFNlcnZlckRhdGEoZGF0YUhyZWY6IHN0cmluZyk6IFByb21pc2U8b2JqZWN0PiB7XG4gICAgcmV0dXJuIGZldGNoTmV4dERhdGEoZGF0YUhyZWYsIHRoaXMuaXNTc3IpXG4gIH1cblxuICBnZXRJbml0aWFsUHJvcHMoXG4gICAgQ29tcG9uZW50OiBDb21wb25lbnRUeXBlLFxuICAgIGN0eDogTmV4dFBhZ2VDb250ZXh0XG4gICk6IFByb21pc2U8YW55PiB7XG4gICAgY29uc3QgeyBDb21wb25lbnQ6IEFwcCB9ID0gdGhpcy5jb21wb25lbnRzWycvX2FwcCddXG4gICAgY29uc3QgQXBwVHJlZSA9IHRoaXMuX3dyYXBBcHAoQXBwIGFzIEFwcENvbXBvbmVudClcbiAgICBjdHguQXBwVHJlZSA9IEFwcFRyZWVcbiAgICByZXR1cm4gbG9hZEdldEluaXRpYWxQcm9wczxBcHBDb250ZXh0VHlwZTxSb3V0ZXI+PihBcHAsIHtcbiAgICAgIEFwcFRyZWUsXG4gICAgICBDb21wb25lbnQsXG4gICAgICByb3V0ZXI6IHRoaXMsXG4gICAgICBjdHgsXG4gICAgfSlcbiAgfVxuXG4gIGFib3J0Q29tcG9uZW50TG9hZChhczogc3RyaW5nKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuY2xjKSB7XG4gICAgICBSb3V0ZXIuZXZlbnRzLmVtaXQoJ3JvdXRlQ2hhbmdlRXJyb3InLCBidWlsZENhbmNlbGxhdGlvbkVycm9yKCksIGFzKVxuICAgICAgdGhpcy5jbGMoKVxuICAgICAgdGhpcy5jbGMgPSBudWxsXG4gICAgfVxuICB9XG5cbiAgbm90aWZ5KGRhdGE6IFByaXZhdGVSb3V0ZUluZm8pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICByZXR1cm4gdGhpcy5zdWIoZGF0YSwgdGhpcy5jb21wb25lbnRzWycvX2FwcCddLkNvbXBvbmVudCBhcyBBcHBDb21wb25lbnQpXG4gIH1cbn1cbiIsIi8vIGVzY2FwZSBkZWxpbWl0ZXJzIHVzZWQgYnkgcGF0aC10by1yZWdleHBcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGVzY2FwZVBhdGhEZWxpbWl0ZXJzKHNlZ21lbnQ6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBzZWdtZW50LnJlcGxhY2UoL1svIz9dL2csIChjaGFyOiBzdHJpbmcpID0+IGVuY29kZVVSSUNvbXBvbmVudChjaGFyKSlcbn1cbiIsIi8vIEZvcm1hdCBmdW5jdGlvbiBtb2RpZmllZCBmcm9tIG5vZGVqc1xuLy8gQ29weXJpZ2h0IEpveWVudCwgSW5jLiBhbmQgb3RoZXIgTm9kZSBjb250cmlidXRvcnMuXG4vL1xuLy8gUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGFcbi8vIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbi8vIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZ1xuLy8gd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLFxuLy8gZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvIHBlcm1pdFxuLy8gcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28sIHN1YmplY3QgdG8gdGhlXG4vLyBmb2xsb3dpbmcgY29uZGl0aW9uczpcbi8vXG4vLyBUaGUgYWJvdmUgY29weXJpZ2h0IG5vdGljZSBhbmQgdGhpcyBwZXJtaXNzaW9uIG5vdGljZSBzaGFsbCBiZSBpbmNsdWRlZFxuLy8gaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuXG4vL1xuLy8gVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTU1xuLy8gT1IgSU1QTElFRCwgSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRlxuLy8gTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTlxuLy8gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sXG4vLyBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIFRPUlQgT1Jcbi8vIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEVcbi8vIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG5cbmltcG9ydCB7IFVybE9iamVjdCB9IGZyb20gJ3VybCdcbmltcG9ydCB7IFBhcnNlZFVybFF1ZXJ5IH0gZnJvbSAncXVlcnlzdHJpbmcnXG5pbXBvcnQgKiBhcyBxdWVyeXN0cmluZyBmcm9tICcuL3F1ZXJ5c3RyaW5nJ1xuXG5jb25zdCBzbGFzaGVkUHJvdG9jb2xzID0gL2h0dHBzP3xmdHB8Z29waGVyfGZpbGUvXG5cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRVcmwodXJsT2JqOiBVcmxPYmplY3QpIHtcbiAgbGV0IHsgYXV0aCwgaG9zdG5hbWUgfSA9IHVybE9ialxuICBsZXQgcHJvdG9jb2wgPSB1cmxPYmoucHJvdG9jb2wgfHwgJydcbiAgbGV0IHBhdGhuYW1lID0gdXJsT2JqLnBhdGhuYW1lIHx8ICcnXG4gIGxldCBoYXNoID0gdXJsT2JqLmhhc2ggfHwgJydcbiAgbGV0IHF1ZXJ5ID0gdXJsT2JqLnF1ZXJ5IHx8ICcnXG4gIGxldCBob3N0OiBzdHJpbmcgfCBmYWxzZSA9IGZhbHNlXG5cbiAgYXV0aCA9IGF1dGggPyBlbmNvZGVVUklDb21wb25lbnQoYXV0aCkucmVwbGFjZSgvJTNBL2ksICc6JykgKyAnQCcgOiAnJ1xuXG4gIGlmICh1cmxPYmouaG9zdCkge1xuICAgIGhvc3QgPSBhdXRoICsgdXJsT2JqLmhvc3RcbiAgfSBlbHNlIGlmIChob3N0bmFtZSkge1xuICAgIGhvc3QgPSBhdXRoICsgKH5ob3N0bmFtZS5pbmRleE9mKCc6JykgPyBgWyR7aG9zdG5hbWV9XWAgOiBob3N0bmFtZSlcbiAgICBpZiAodXJsT2JqLnBvcnQpIHtcbiAgICAgIGhvc3QgKz0gJzonICsgdXJsT2JqLnBvcnRcbiAgICB9XG4gIH1cblxuICBpZiAocXVlcnkgJiYgdHlwZW9mIHF1ZXJ5ID09PSAnb2JqZWN0Jykge1xuICAgIHF1ZXJ5ID0gU3RyaW5nKHF1ZXJ5c3RyaW5nLnVybFF1ZXJ5VG9TZWFyY2hQYXJhbXMocXVlcnkgYXMgUGFyc2VkVXJsUXVlcnkpKVxuICB9XG5cbiAgbGV0IHNlYXJjaCA9IHVybE9iai5zZWFyY2ggfHwgKHF1ZXJ5ICYmIGA/JHtxdWVyeX1gKSB8fCAnJ1xuXG4gIGlmIChwcm90b2NvbCAmJiBwcm90b2NvbC5zdWJzdHIoLTEpICE9PSAnOicpIHByb3RvY29sICs9ICc6J1xuXG4gIGlmIChcbiAgICB1cmxPYmouc2xhc2hlcyB8fFxuICAgICgoIXByb3RvY29sIHx8IHNsYXNoZWRQcm90b2NvbHMudGVzdChwcm90b2NvbCkpICYmIGhvc3QgIT09IGZhbHNlKVxuICApIHtcbiAgICBob3N0ID0gJy8vJyArIChob3N0IHx8ICcnKVxuICAgIGlmIChwYXRobmFtZSAmJiBwYXRobmFtZVswXSAhPT0gJy8nKSBwYXRobmFtZSA9ICcvJyArIHBhdGhuYW1lXG4gIH0gZWxzZSBpZiAoIWhvc3QpIHtcbiAgICBob3N0ID0gJydcbiAgfVxuXG4gIGlmIChoYXNoICYmIGhhc2hbMF0gIT09ICcjJykgaGFzaCA9ICcjJyArIGhhc2hcbiAgaWYgKHNlYXJjaCAmJiBzZWFyY2hbMF0gIT09ICc/Jykgc2VhcmNoID0gJz8nICsgc2VhcmNoXG5cbiAgcGF0aG5hbWUgPSBwYXRobmFtZS5yZXBsYWNlKC9bPyNdL2csIGVuY29kZVVSSUNvbXBvbmVudClcbiAgc2VhcmNoID0gc2VhcmNoLnJlcGxhY2UoJyMnLCAnJTIzJylcblxuICByZXR1cm4gYCR7cHJvdG9jb2x9JHtob3N0fSR7cGF0aG5hbWV9JHtzZWFyY2h9JHtoYXNofWBcbn1cbiIsIi8vIElkZW50aWZ5IC9bcGFyYW1dLyBpbiByb3V0ZSBzdHJpbmdcbmNvbnN0IFRFU1RfUk9VVEUgPSAvXFwvXFxbW14vXSs/XFxdKD89XFwvfCQpL1xuXG5leHBvcnQgZnVuY3Rpb24gaXNEeW5hbWljUm91dGUocm91dGU6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gVEVTVF9ST1VURS50ZXN0KHJvdXRlKVxufVxuIiwiaW1wb3J0IHsgZ2V0TG9jYXRpb25PcmlnaW4gfSBmcm9tICcuLi8uLi91dGlscydcbmltcG9ydCB7IHNlYXJjaFBhcmFtc1RvVXJsUXVlcnkgfSBmcm9tICcuL3F1ZXJ5c3RyaW5nJ1xuXG5jb25zdCBEVU1NWV9CQVNFID0gbmV3IFVSTChcbiAgdHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcgPyAnaHR0cDovL24nIDogZ2V0TG9jYXRpb25PcmlnaW4oKVxuKVxuXG4vKipcbiAqIFBhcnNlcyBwYXRoLXJlbGF0aXZlIHVybHMgKGUuZy4gYC9oZWxsby93b3JsZD9mb289YmFyYCkuIElmIHVybCBpc24ndCBwYXRoLXJlbGF0aXZlXG4gKiAoZS5nLiBgLi9oZWxsb2ApIHRoZW4gYXQgbGVhc3QgYmFzZSBtdXN0IGJlLlxuICogQWJzb2x1dGUgdXJscyBhcmUgcmVqZWN0ZWQgd2l0aCBvbmUgZXhjZXB0aW9uLCBpbiB0aGUgYnJvd3NlciwgYWJzb2x1dGUgdXJscyB0aGF0IGFyZSBvblxuICogdGhlIGN1cnJlbnQgb3JpZ2luIHdpbGwgYmUgcGFyc2VkIGFzIHJlbGF0aXZlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVJlbGF0aXZlVXJsKHVybDogc3RyaW5nLCBiYXNlPzogc3RyaW5nKSB7XG4gIGNvbnN0IHJlc29sdmVkQmFzZSA9IGJhc2UgPyBuZXcgVVJMKGJhc2UsIERVTU1ZX0JBU0UpIDogRFVNTVlfQkFTRVxuICBjb25zdCB7XG4gICAgcGF0aG5hbWUsXG4gICAgc2VhcmNoUGFyYW1zLFxuICAgIHNlYXJjaCxcbiAgICBoYXNoLFxuICAgIGhyZWYsXG4gICAgb3JpZ2luLFxuICAgIHByb3RvY29sLFxuICB9ID0gbmV3IFVSTCh1cmwsIHJlc29sdmVkQmFzZSlcbiAgaWYgKFxuICAgIG9yaWdpbiAhPT0gRFVNTVlfQkFTRS5vcmlnaW4gfHxcbiAgICAocHJvdG9jb2wgIT09ICdodHRwOicgJiYgcHJvdG9jb2wgIT09ICdodHRwczonKVxuICApIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFyaWFudDogaW52YWxpZCByZWxhdGl2ZSBVUkwnKVxuICB9XG4gIHJldHVybiB7XG4gICAgcGF0aG5hbWUsXG4gICAgcXVlcnk6IHNlYXJjaFBhcmFtc1RvVXJsUXVlcnkoc2VhcmNoUGFyYW1zKSxcbiAgICBzZWFyY2gsXG4gICAgaGFzaCxcbiAgICBocmVmOiBocmVmLnNsaWNlKERVTU1ZX0JBU0Uub3JpZ2luLmxlbmd0aCksXG4gIH1cbn1cbiIsImltcG9ydCAqIGFzIHBhdGhUb1JlZ2V4cCBmcm9tICduZXh0L2Rpc3QvY29tcGlsZWQvcGF0aC10by1yZWdleHAnXG5cbmV4cG9ydCB7IHBhdGhUb1JlZ2V4cCB9XG5cbmV4cG9ydCBjb25zdCBtYXRjaGVyT3B0aW9uczogcGF0aFRvUmVnZXhwLlRva2Vuc1RvUmVnZXhwT3B0aW9ucyAmXG4gIHBhdGhUb1JlZ2V4cC5QYXJzZU9wdGlvbnMgPSB7XG4gIHNlbnNpdGl2ZTogZmFsc2UsXG4gIGRlbGltaXRlcjogJy8nLFxufVxuXG5leHBvcnQgY29uc3QgY3VzdG9tUm91dGVNYXRjaGVyT3B0aW9uczogcGF0aFRvUmVnZXhwLlRva2Vuc1RvUmVnZXhwT3B0aW9ucyAmXG4gIHBhdGhUb1JlZ2V4cC5QYXJzZU9wdGlvbnMgPSB7XG4gIC4uLm1hdGNoZXJPcHRpb25zLFxuICBzdHJpY3Q6IHRydWUsXG59XG5cbmV4cG9ydCBkZWZhdWx0IChjdXN0b21Sb3V0ZSA9IGZhbHNlKSA9PiB7XG4gIHJldHVybiAocGF0aDogc3RyaW5nKSA9PiB7XG4gICAgY29uc3Qga2V5czogcGF0aFRvUmVnZXhwLktleVtdID0gW11cbiAgICBjb25zdCBtYXRjaGVyUmVnZXggPSBwYXRoVG9SZWdleHAucGF0aFRvUmVnZXhwKFxuICAgICAgcGF0aCxcbiAgICAgIGtleXMsXG4gICAgICBjdXN0b21Sb3V0ZSA/IGN1c3RvbVJvdXRlTWF0Y2hlck9wdGlvbnMgOiBtYXRjaGVyT3B0aW9uc1xuICAgIClcbiAgICBjb25zdCBtYXRjaGVyID0gcGF0aFRvUmVnZXhwLnJlZ2V4cFRvRnVuY3Rpb24obWF0Y2hlclJlZ2V4LCBrZXlzKVxuXG4gICAgcmV0dXJuIChwYXRobmFtZTogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZCwgcGFyYW1zPzogYW55KSA9PiB7XG4gICAgICBjb25zdCByZXMgPSBwYXRobmFtZSA9PSBudWxsID8gZmFsc2UgOiBtYXRjaGVyKHBhdGhuYW1lKVxuICAgICAgaWYgKCFyZXMpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG4gICAgICB9XG5cbiAgICAgIGlmIChjdXN0b21Sb3V0ZSkge1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBrZXlzKSB7XG4gICAgICAgICAgLy8gdW5uYW1lZCBwYXJhbXMgc2hvdWxkIGJlIHJlbW92ZWQgYXMgdGhleVxuICAgICAgICAgIC8vIGFyZSBub3QgYWxsb3dlZCB0byBiZSB1c2VkIGluIHRoZSBkZXN0aW5hdGlvblxuICAgICAgICAgIGlmICh0eXBlb2Yga2V5Lm5hbWUgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICBkZWxldGUgKHJlcy5wYXJhbXMgYXMgYW55KVtrZXkubmFtZV1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHsgLi4ucGFyYW1zLCAuLi5yZXMucGFyYW1zIH1cbiAgICB9XG4gIH1cbn1cbiIsImltcG9ydCB7IFBhcnNlZFVybFF1ZXJ5IH0gZnJvbSAncXVlcnlzdHJpbmcnXG5pbXBvcnQgeyBzZWFyY2hQYXJhbXNUb1VybFF1ZXJ5IH0gZnJvbSAnLi9xdWVyeXN0cmluZydcbmltcG9ydCB7IHBhcnNlUmVsYXRpdmVVcmwgfSBmcm9tICcuL3BhcnNlLXJlbGF0aXZlLXVybCdcbmltcG9ydCAqIGFzIHBhdGhUb1JlZ2V4cCBmcm9tICduZXh0L2Rpc3QvY29tcGlsZWQvcGF0aC10by1yZWdleHAnXG5cbnR5cGUgUGFyYW1zID0geyBbcGFyYW06IHN0cmluZ106IGFueSB9XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHByZXBhcmVEZXN0aW5hdGlvbihcbiAgZGVzdGluYXRpb246IHN0cmluZyxcbiAgcGFyYW1zOiBQYXJhbXMsXG4gIHF1ZXJ5OiBQYXJzZWRVcmxRdWVyeSxcbiAgYXBwZW5kUGFyYW1zVG9RdWVyeTogYm9vbGVhbixcbiAgYmFzZVBhdGg6IHN0cmluZ1xuKSB7XG4gIGxldCBwYXJzZWREZXN0aW5hdGlvbjoge1xuICAgIHF1ZXJ5PzogUGFyc2VkVXJsUXVlcnlcbiAgICBwcm90b2NvbD86IHN0cmluZ1xuICAgIGhvc3RuYW1lPzogc3RyaW5nXG4gICAgcG9ydD86IHN0cmluZ1xuICB9ICYgUmV0dXJuVHlwZTx0eXBlb2YgcGFyc2VSZWxhdGl2ZVVybD4gPSB7fSBhcyBhbnlcblxuICBpZiAoZGVzdGluYXRpb24uc3RhcnRzV2l0aCgnLycpKSB7XG4gICAgcGFyc2VkRGVzdGluYXRpb24gPSBwYXJzZVJlbGF0aXZlVXJsKGRlc3RpbmF0aW9uKVxuICB9IGVsc2Uge1xuICAgIGNvbnN0IHtcbiAgICAgIHBhdGhuYW1lLFxuICAgICAgc2VhcmNoUGFyYW1zLFxuICAgICAgaGFzaCxcbiAgICAgIGhvc3RuYW1lLFxuICAgICAgcG9ydCxcbiAgICAgIHByb3RvY29sLFxuICAgICAgc2VhcmNoLFxuICAgICAgaHJlZixcbiAgICB9ID0gbmV3IFVSTChkZXN0aW5hdGlvbilcblxuICAgIHBhcnNlZERlc3RpbmF0aW9uID0ge1xuICAgICAgcGF0aG5hbWUsXG4gICAgICBxdWVyeTogc2VhcmNoUGFyYW1zVG9VcmxRdWVyeShzZWFyY2hQYXJhbXMpLFxuICAgICAgaGFzaCxcbiAgICAgIHByb3RvY29sLFxuICAgICAgaG9zdG5hbWUsXG4gICAgICBwb3J0LFxuICAgICAgc2VhcmNoLFxuICAgICAgaHJlZixcbiAgICB9XG4gIH1cblxuICBjb25zdCBkZXN0UXVlcnkgPSBwYXJzZWREZXN0aW5hdGlvbi5xdWVyeVxuICBjb25zdCBkZXN0UGF0aCA9IGAke3BhcnNlZERlc3RpbmF0aW9uLnBhdGhuYW1lIX0ke1xuICAgIHBhcnNlZERlc3RpbmF0aW9uLmhhc2ggfHwgJydcbiAgfWBcbiAgY29uc3QgZGVzdFBhdGhQYXJhbUtleXM6IHBhdGhUb1JlZ2V4cC5LZXlbXSA9IFtdXG4gIHBhdGhUb1JlZ2V4cC5wYXRoVG9SZWdleHAoZGVzdFBhdGgsIGRlc3RQYXRoUGFyYW1LZXlzKVxuXG4gIGNvbnN0IGRlc3RQYXRoUGFyYW1zID0gZGVzdFBhdGhQYXJhbUtleXMubWFwKChrZXkpID0+IGtleS5uYW1lKVxuXG4gIGxldCBkZXN0aW5hdGlvbkNvbXBpbGVyID0gcGF0aFRvUmVnZXhwLmNvbXBpbGUoXG4gICAgZGVzdFBhdGgsXG4gICAgLy8gd2UgZG9uJ3QgdmFsaWRhdGUgd2hpbGUgY29tcGlsaW5nIHRoZSBkZXN0aW5hdGlvbiBzaW5jZSB3ZSBzaG91bGRcbiAgICAvLyBoYXZlIGFscmVhZHkgdmFsaWRhdGVkIGJlZm9yZSB3ZSBnb3QgdG8gdGhpcyBwb2ludCBhbmQgdmFsaWRhdGluZ1xuICAgIC8vIGJyZWFrcyBjb21waWxpbmcgZGVzdGluYXRpb25zIHdpdGggbmFtZWQgcGF0dGVybiBwYXJhbXMgZnJvbSB0aGUgc291cmNlXG4gICAgLy8gZS5nLiAvc29tZXRoaW5nOmhlbGxvKC4qKSAtPiAvYW5vdGhlci86aGVsbG8gaXMgYnJva2VuIHdpdGggdmFsaWRhdGlvblxuICAgIC8vIHNpbmNlIGNvbXBpbGUgdmFsaWRhdGlvbiBpcyBtZWFudCBmb3IgcmV2ZXJzaW5nIGFuZCBub3QgZm9yIGluc2VydGluZ1xuICAgIC8vIHBhcmFtcyBmcm9tIGEgc2VwYXJhdGUgcGF0aC1yZWdleCBpbnRvIGFub3RoZXJcbiAgICB7IHZhbGlkYXRlOiBmYWxzZSB9XG4gIClcbiAgbGV0IG5ld1VybFxuXG4gIC8vIHVwZGF0ZSBhbnkgcGFyYW1zIGluIHF1ZXJ5IHZhbHVlc1xuICBmb3IgKGNvbnN0IFtrZXksIHN0ck9yQXJyYXldIG9mIE9iamVjdC5lbnRyaWVzKGRlc3RRdWVyeSkpIHtcbiAgICBsZXQgdmFsdWUgPSBBcnJheS5pc0FycmF5KHN0ck9yQXJyYXkpID8gc3RyT3JBcnJheVswXSA6IHN0ck9yQXJyYXlcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIC8vIHRoZSB2YWx1ZSBuZWVkcyB0byBzdGFydCB3aXRoIGEgZm9yd2FyZC1zbGFzaCB0byBiZSBjb21waWxlZFxuICAgICAgLy8gY29ycmVjdGx5XG4gICAgICB2YWx1ZSA9IGAvJHt2YWx1ZX1gXG4gICAgICBjb25zdCBxdWVyeUNvbXBpbGVyID0gcGF0aFRvUmVnZXhwLmNvbXBpbGUodmFsdWUsIHsgdmFsaWRhdGU6IGZhbHNlIH0pXG4gICAgICB2YWx1ZSA9IHF1ZXJ5Q29tcGlsZXIocGFyYW1zKS5zdWJzdHIoMSlcbiAgICB9XG4gICAgZGVzdFF1ZXJ5W2tleV0gPSB2YWx1ZVxuICB9XG5cbiAgLy8gYWRkIHBhdGggcGFyYW1zIHRvIHF1ZXJ5IGlmIGl0J3Mgbm90IGEgcmVkaXJlY3QgYW5kIG5vdFxuICAvLyBhbHJlYWR5IGRlZmluZWQgaW4gZGVzdGluYXRpb24gcXVlcnkgb3IgcGF0aFxuICBjb25zdCBwYXJhbUtleXMgPSBPYmplY3Qua2V5cyhwYXJhbXMpXG5cbiAgaWYgKFxuICAgIGFwcGVuZFBhcmFtc1RvUXVlcnkgJiZcbiAgICAhcGFyYW1LZXlzLnNvbWUoKGtleSkgPT4gZGVzdFBhdGhQYXJhbXMuaW5jbHVkZXMoa2V5KSlcbiAgKSB7XG4gICAgZm9yIChjb25zdCBrZXkgb2YgcGFyYW1LZXlzKSB7XG4gICAgICBpZiAoIShrZXkgaW4gZGVzdFF1ZXJ5KSkge1xuICAgICAgICBkZXN0UXVlcnlba2V5XSA9IHBhcmFtc1trZXldXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc2hvdWxkQWRkQmFzZVBhdGggPSBkZXN0aW5hdGlvbi5zdGFydHNXaXRoKCcvJykgJiYgYmFzZVBhdGhcblxuICB0cnkge1xuICAgIG5ld1VybCA9IGAke3Nob3VsZEFkZEJhc2VQYXRoID8gYmFzZVBhdGggOiAnJ30ke2Rlc3RpbmF0aW9uQ29tcGlsZXIoXG4gICAgICBwYXJhbXNcbiAgICApfWBcblxuICAgIGNvbnN0IFtwYXRobmFtZSwgaGFzaF0gPSBuZXdVcmwuc3BsaXQoJyMnKVxuICAgIHBhcnNlZERlc3RpbmF0aW9uLnBhdGhuYW1lID0gcGF0aG5hbWVcbiAgICBwYXJzZWREZXN0aW5hdGlvbi5oYXNoID0gYCR7aGFzaCA/ICcjJyA6ICcnfSR7aGFzaCB8fCAnJ31gXG4gICAgZGVsZXRlIHBhcnNlZERlc3RpbmF0aW9uLnNlYXJjaFxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBpZiAoZXJyLm1lc3NhZ2UubWF0Y2goL0V4cGVjdGVkIC4qPyB0byBub3QgcmVwZWF0LCBidXQgZ290IGFuIGFycmF5LykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYFRvIHVzZSBhIG11bHRpLW1hdGNoIGluIHRoZSBkZXN0aW5hdGlvbiB5b3UgbXVzdCBhZGQgXFxgKlxcYCBhdCB0aGUgZW5kIG9mIHRoZSBwYXJhbSBuYW1lIHRvIHNpZ25pZnkgaXQgc2hvdWxkIHJlcGVhdC4gaHR0cHM6Ly9lcnIuc2gvdmVyY2VsL25leHQuanMvaW52YWxpZC1tdWx0aS1tYXRjaGBcbiAgICAgIClcbiAgICB9XG4gICAgdGhyb3cgZXJyXG4gIH1cblxuICAvLyBRdWVyeSBtZXJnZSBvcmRlciBsb3dlc3QgcHJpb3JpdHkgdG8gaGlnaGVzdFxuICAvLyAxLiBpbml0aWFsIFVSTCBxdWVyeSB2YWx1ZXNcbiAgLy8gMi4gcGF0aCBzZWdtZW50IHZhbHVlc1xuICAvLyAzLiBkZXN0aW5hdGlvbiBzcGVjaWZpZWQgcXVlcnkgdmFsdWVzXG4gIHBhcnNlZERlc3RpbmF0aW9uLnF1ZXJ5ID0ge1xuICAgIC4uLnF1ZXJ5LFxuICAgIC4uLnBhcnNlZERlc3RpbmF0aW9uLnF1ZXJ5LFxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICBuZXdVcmwsXG4gICAgcGFyc2VkRGVzdGluYXRpb24sXG4gIH1cbn1cbiIsImltcG9ydCB7IFBhcnNlZFVybFF1ZXJ5IH0gZnJvbSAncXVlcnlzdHJpbmcnXG5cbmV4cG9ydCBmdW5jdGlvbiBzZWFyY2hQYXJhbXNUb1VybFF1ZXJ5KFxuICBzZWFyY2hQYXJhbXM6IFVSTFNlYXJjaFBhcmFtc1xuKTogUGFyc2VkVXJsUXVlcnkge1xuICBjb25zdCBxdWVyeTogUGFyc2VkVXJsUXVlcnkgPSB7fVxuICBzZWFyY2hQYXJhbXMuZm9yRWFjaCgodmFsdWUsIGtleSkgPT4ge1xuICAgIGlmICh0eXBlb2YgcXVlcnlba2V5XSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHF1ZXJ5W2tleV0gPSB2YWx1ZVxuICAgIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShxdWVyeVtrZXldKSkge1xuICAgICAgOyhxdWVyeVtrZXldIGFzIHN0cmluZ1tdKS5wdXNoKHZhbHVlKVxuICAgIH0gZWxzZSB7XG4gICAgICBxdWVyeVtrZXldID0gW3F1ZXJ5W2tleV0gYXMgc3RyaW5nLCB2YWx1ZV1cbiAgICB9XG4gIH0pXG4gIHJldHVybiBxdWVyeVxufVxuXG5mdW5jdGlvbiBzdHJpbmdpZnlVcmxRdWVyeVBhcmFtKHBhcmFtOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoXG4gICAgdHlwZW9mIHBhcmFtID09PSAnc3RyaW5nJyB8fFxuICAgICh0eXBlb2YgcGFyYW0gPT09ICdudW1iZXInICYmICFpc05hTihwYXJhbSkpIHx8XG4gICAgdHlwZW9mIHBhcmFtID09PSAnYm9vbGVhbidcbiAgKSB7XG4gICAgcmV0dXJuIFN0cmluZyhwYXJhbSlcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gJydcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXJsUXVlcnlUb1NlYXJjaFBhcmFtcyhcbiAgdXJsUXVlcnk6IFBhcnNlZFVybFF1ZXJ5XG4pOiBVUkxTZWFyY2hQYXJhbXMge1xuICBjb25zdCByZXN1bHQgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKClcbiAgT2JqZWN0LmVudHJpZXModXJsUXVlcnkpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgdmFsdWUuZm9yRWFjaCgoaXRlbSkgPT4gcmVzdWx0LmFwcGVuZChrZXksIHN0cmluZ2lmeVVybFF1ZXJ5UGFyYW0oaXRlbSkpKVxuICAgIH0gZWxzZSB7XG4gICAgICByZXN1bHQuc2V0KGtleSwgc3RyaW5naWZ5VXJsUXVlcnlQYXJhbSh2YWx1ZSkpXG4gICAgfVxuICB9KVxuICByZXR1cm4gcmVzdWx0XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhc3NpZ24oXG4gIHRhcmdldDogVVJMU2VhcmNoUGFyYW1zLFxuICAuLi5zZWFyY2hQYXJhbXNMaXN0OiBVUkxTZWFyY2hQYXJhbXNbXVxuKTogVVJMU2VhcmNoUGFyYW1zIHtcbiAgc2VhcmNoUGFyYW1zTGlzdC5mb3JFYWNoKChzZWFyY2hQYXJhbXMpID0+IHtcbiAgICBBcnJheS5mcm9tKHNlYXJjaFBhcmFtcy5rZXlzKCkpLmZvckVhY2goKGtleSkgPT4gdGFyZ2V0LmRlbGV0ZShrZXkpKVxuICAgIHNlYXJjaFBhcmFtcy5mb3JFYWNoKCh2YWx1ZSwga2V5KSA9PiB0YXJnZXQuYXBwZW5kKGtleSwgdmFsdWUpKVxuICB9KVxuICByZXR1cm4gdGFyZ2V0XG59XG4iLCJpbXBvcnQgeyBQYXJzZWRVcmxRdWVyeSB9IGZyb20gJ3F1ZXJ5c3RyaW5nJ1xuaW1wb3J0IHBhdGhNYXRjaCBmcm9tICcuL3BhdGgtbWF0Y2gnXG5pbXBvcnQgcHJlcGFyZURlc3RpbmF0aW9uIGZyb20gJy4vcHJlcGFyZS1kZXN0aW5hdGlvbidcbmltcG9ydCB7IFJld3JpdGUgfSBmcm9tICcuLi8uLi8uLi8uLi9saWIvbG9hZC1jdXN0b20tcm91dGVzJ1xuaW1wb3J0IHsgcmVtb3ZlUGF0aFRyYWlsaW5nU2xhc2ggfSBmcm9tICcuLi8uLi8uLi8uLi9jbGllbnQvbm9ybWFsaXplLXRyYWlsaW5nLXNsYXNoJ1xuXG5jb25zdCBjdXN0b21Sb3V0ZU1hdGNoZXIgPSBwYXRoTWF0Y2godHJ1ZSlcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gcmVzb2x2ZVJld3JpdGVzKFxuICBhc1BhdGg6IHN0cmluZyxcbiAgcGFnZXM6IHN0cmluZ1tdLFxuICBiYXNlUGF0aDogc3RyaW5nLFxuICByZXdyaXRlczogUmV3cml0ZVtdLFxuICBxdWVyeTogUGFyc2VkVXJsUXVlcnksXG4gIHJlc29sdmVIcmVmOiAocGF0aDogc3RyaW5nKSA9PiBzdHJpbmdcbikge1xuICBpZiAoIXBhZ2VzLmluY2x1ZGVzKGFzUGF0aCkpIHtcbiAgICBmb3IgKGNvbnN0IHJld3JpdGUgb2YgcmV3cml0ZXMpIHtcbiAgICAgIGNvbnN0IG1hdGNoZXIgPSBjdXN0b21Sb3V0ZU1hdGNoZXIocmV3cml0ZS5zb3VyY2UpXG4gICAgICBjb25zdCBwYXJhbXMgPSBtYXRjaGVyKGFzUGF0aClcblxuICAgICAgaWYgKHBhcmFtcykge1xuICAgICAgICBpZiAoIXJld3JpdGUuZGVzdGluYXRpb24pIHtcbiAgICAgICAgICAvLyB0aGlzIGlzIGEgcHJveGllZCByZXdyaXRlIHdoaWNoIGlzbid0IGhhbmRsZWQgb24gdGhlIGNsaWVudFxuICAgICAgICAgIGJyZWFrXG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZGVzdFJlcyA9IHByZXBhcmVEZXN0aW5hdGlvbihcbiAgICAgICAgICByZXdyaXRlLmRlc3RpbmF0aW9uLFxuICAgICAgICAgIHBhcmFtcyxcbiAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICB0cnVlLFxuICAgICAgICAgIHJld3JpdGUuYmFzZVBhdGggPT09IGZhbHNlID8gJycgOiBiYXNlUGF0aFxuICAgICAgICApXG4gICAgICAgIGFzUGF0aCA9IGRlc3RSZXMucGFyc2VkRGVzdGluYXRpb24ucGF0aG5hbWUhXG4gICAgICAgIE9iamVjdC5hc3NpZ24ocXVlcnksIGRlc3RSZXMucGFyc2VkRGVzdGluYXRpb24ucXVlcnkpXG5cbiAgICAgICAgaWYgKHBhZ2VzLmluY2x1ZGVzKHJlbW92ZVBhdGhUcmFpbGluZ1NsYXNoKGFzUGF0aCkpKSB7XG4gICAgICAgICAgLy8gY2hlY2sgaWYgd2Ugbm93IG1hdGNoIGEgcGFnZSBhcyB0aGlzIG1lYW5zIHdlIGFyZSBkb25lXG4gICAgICAgICAgLy8gcmVzb2x2aW5nIHRoZSByZXdyaXRlc1xuICAgICAgICAgIGJyZWFrXG4gICAgICAgIH1cblxuICAgICAgICAvLyBjaGVjayBpZiB3ZSBtYXRjaCBhIGR5bmFtaWMtcm91dGUsIGlmIHNvIHdlIGJyZWFrIHRoZSByZXdyaXRlcyBjaGFpblxuICAgICAgICBjb25zdCByZXNvbHZlZEhyZWYgPSByZXNvbHZlSHJlZihhc1BhdGgpXG5cbiAgICAgICAgaWYgKHJlc29sdmVkSHJlZiAhPT0gYXNQYXRoICYmIHBhZ2VzLmluY2x1ZGVzKHJlc29sdmVkSHJlZikpIHtcbiAgICAgICAgICBicmVha1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBhc1BhdGhcbn1cbiIsImltcG9ydCB7IGdldFJvdXRlUmVnZXggfSBmcm9tICcuL3JvdXRlLXJlZ2V4J1xuXG5leHBvcnQgZnVuY3Rpb24gZ2V0Um91dGVNYXRjaGVyKHJvdXRlUmVnZXg6IFJldHVyblR5cGU8dHlwZW9mIGdldFJvdXRlUmVnZXg+KSB7XG4gIGNvbnN0IHsgcmUsIGdyb3VwcyB9ID0gcm91dGVSZWdleFxuICByZXR1cm4gKHBhdGhuYW1lOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKSA9PiB7XG4gICAgY29uc3Qgcm91dGVNYXRjaCA9IHJlLmV4ZWMocGF0aG5hbWUhKVxuICAgIGlmICghcm91dGVNYXRjaCkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuXG4gICAgY29uc3QgZGVjb2RlID0gKHBhcmFtOiBzdHJpbmcpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBkZWNvZGVVUklDb21wb25lbnQocGFyYW0pXG4gICAgICB9IGNhdGNoIChfKSB7XG4gICAgICAgIGNvbnN0IGVycjogRXJyb3IgJiB7IGNvZGU/OiBzdHJpbmcgfSA9IG5ldyBFcnJvcihcbiAgICAgICAgICAnZmFpbGVkIHRvIGRlY29kZSBwYXJhbSdcbiAgICAgICAgKVxuICAgICAgICBlcnIuY29kZSA9ICdERUNPREVfRkFJTEVEJ1xuICAgICAgICB0aHJvdyBlcnJcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgcGFyYW1zOiB7IFtwYXJhbU5hbWU6IHN0cmluZ106IHN0cmluZyB8IHN0cmluZ1tdIH0gPSB7fVxuXG4gICAgT2JqZWN0LmtleXMoZ3JvdXBzKS5mb3JFYWNoKChzbHVnTmFtZTogc3RyaW5nKSA9PiB7XG4gICAgICBjb25zdCBnID0gZ3JvdXBzW3NsdWdOYW1lXVxuICAgICAgY29uc3QgbSA9IHJvdXRlTWF0Y2hbZy5wb3NdXG4gICAgICBpZiAobSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHBhcmFtc1tzbHVnTmFtZV0gPSB+bS5pbmRleE9mKCcvJylcbiAgICAgICAgICA/IG0uc3BsaXQoJy8nKS5tYXAoKGVudHJ5KSA9PiBkZWNvZGUoZW50cnkpKVxuICAgICAgICAgIDogZy5yZXBlYXRcbiAgICAgICAgICA/IFtkZWNvZGUobSldXG4gICAgICAgICAgOiBkZWNvZGUobSlcbiAgICAgIH1cbiAgICB9KVxuICAgIHJldHVybiBwYXJhbXNcbiAgfVxufVxuIiwiaW50ZXJmYWNlIEdyb3VwIHtcbiAgcG9zOiBudW1iZXJcbiAgcmVwZWF0OiBib29sZWFuXG4gIG9wdGlvbmFsOiBib29sZWFuXG59XG5cbi8vIHRoaXMgaXNuJ3QgaW1wb3J0aW5nIHRoZSBlc2NhcGUtc3RyaW5nLXJlZ2V4IG1vZHVsZVxuLy8gdG8gcmVkdWNlIGJ5dGVzXG5mdW5jdGlvbiBlc2NhcGVSZWdleChzdHI6IHN0cmluZykge1xuICByZXR1cm4gc3RyLnJlcGxhY2UoL1t8XFxcXHt9KClbXFxdXiQrKj8uLV0vZywgJ1xcXFwkJicpXG59XG5cbmZ1bmN0aW9uIHBhcnNlUGFyYW1ldGVyKHBhcmFtOiBzdHJpbmcpIHtcbiAgY29uc3Qgb3B0aW9uYWwgPSBwYXJhbS5zdGFydHNXaXRoKCdbJykgJiYgcGFyYW0uZW5kc1dpdGgoJ10nKVxuICBpZiAob3B0aW9uYWwpIHtcbiAgICBwYXJhbSA9IHBhcmFtLnNsaWNlKDEsIC0xKVxuICB9XG4gIGNvbnN0IHJlcGVhdCA9IHBhcmFtLnN0YXJ0c1dpdGgoJy4uLicpXG4gIGlmIChyZXBlYXQpIHtcbiAgICBwYXJhbSA9IHBhcmFtLnNsaWNlKDMpXG4gIH1cbiAgcmV0dXJuIHsga2V5OiBwYXJhbSwgcmVwZWF0LCBvcHRpb25hbCB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRSb3V0ZVJlZ2V4KFxuICBub3JtYWxpemVkUm91dGU6IHN0cmluZ1xuKToge1xuICByZTogUmVnRXhwXG4gIG5hbWVkUmVnZXg/OiBzdHJpbmdcbiAgcm91dGVLZXlzPzogeyBbbmFtZWQ6IHN0cmluZ106IHN0cmluZyB9XG4gIGdyb3VwczogeyBbZ3JvdXBOYW1lOiBzdHJpbmddOiBHcm91cCB9XG59IHtcbiAgY29uc3Qgc2VnbWVudHMgPSAobm9ybWFsaXplZFJvdXRlLnJlcGxhY2UoL1xcLyQvLCAnJykgfHwgJy8nKVxuICAgIC5zbGljZSgxKVxuICAgIC5zcGxpdCgnLycpXG5cbiAgY29uc3QgZ3JvdXBzOiB7IFtncm91cE5hbWU6IHN0cmluZ106IEdyb3VwIH0gPSB7fVxuICBsZXQgZ3JvdXBJbmRleCA9IDFcbiAgY29uc3QgcGFyYW1ldGVyaXplZFJvdXRlID0gc2VnbWVudHNcbiAgICAubWFwKChzZWdtZW50KSA9PiB7XG4gICAgICBpZiAoc2VnbWVudC5zdGFydHNXaXRoKCdbJykgJiYgc2VnbWVudC5lbmRzV2l0aCgnXScpKSB7XG4gICAgICAgIGNvbnN0IHsga2V5LCBvcHRpb25hbCwgcmVwZWF0IH0gPSBwYXJzZVBhcmFtZXRlcihzZWdtZW50LnNsaWNlKDEsIC0xKSlcbiAgICAgICAgZ3JvdXBzW2tleV0gPSB7IHBvczogZ3JvdXBJbmRleCsrLCByZXBlYXQsIG9wdGlvbmFsIH1cbiAgICAgICAgcmV0dXJuIHJlcGVhdCA/IChvcHRpb25hbCA/ICcoPzovKC4rPykpPycgOiAnLyguKz8pJykgOiAnLyhbXi9dKz8pJ1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIGAvJHtlc2NhcGVSZWdleChzZWdtZW50KX1gXG4gICAgICB9XG4gICAgfSlcbiAgICAuam9pbignJylcblxuICAvLyBkZWFkIGNvZGUgZWxpbWluYXRlIGZvciBicm93c2VyIHNpbmNlIGl0J3Mgb25seSBuZWVkZWRcbiAgLy8gd2hpbGUgZ2VuZXJhdGluZyByb3V0ZXMtbWFuaWZlc3RcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgbGV0IHJvdXRlS2V5Q2hhckNvZGUgPSA5N1xuICAgIGxldCByb3V0ZUtleUNoYXJMZW5ndGggPSAxXG5cbiAgICAvLyBidWlsZHMgYSBtaW5pbWFsIHJvdXRlS2V5IHVzaW5nIG9ubHkgYS16IGFuZCBtaW5pbWFsIG51bWJlciBvZiBjaGFyYWN0ZXJzXG4gICAgY29uc3QgZ2V0U2FmZVJvdXRlS2V5ID0gKCkgPT4ge1xuICAgICAgbGV0IHJvdXRlS2V5ID0gJydcblxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByb3V0ZUtleUNoYXJMZW5ndGg7IGkrKykge1xuICAgICAgICByb3V0ZUtleSArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKHJvdXRlS2V5Q2hhckNvZGUpXG4gICAgICAgIHJvdXRlS2V5Q2hhckNvZGUrK1xuXG4gICAgICAgIGlmIChyb3V0ZUtleUNoYXJDb2RlID4gMTIyKSB7XG4gICAgICAgICAgcm91dGVLZXlDaGFyTGVuZ3RoKytcbiAgICAgICAgICByb3V0ZUtleUNoYXJDb2RlID0gOTdcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIHJvdXRlS2V5XG4gICAgfVxuXG4gICAgY29uc3Qgcm91dGVLZXlzOiB7IFtuYW1lZDogc3RyaW5nXTogc3RyaW5nIH0gPSB7fVxuXG4gICAgbGV0IG5hbWVkUGFyYW1ldGVyaXplZFJvdXRlID0gc2VnbWVudHNcbiAgICAgIC5tYXAoKHNlZ21lbnQpID0+IHtcbiAgICAgICAgaWYgKHNlZ21lbnQuc3RhcnRzV2l0aCgnWycpICYmIHNlZ21lbnQuZW5kc1dpdGgoJ10nKSkge1xuICAgICAgICAgIGNvbnN0IHsga2V5LCBvcHRpb25hbCwgcmVwZWF0IH0gPSBwYXJzZVBhcmFtZXRlcihzZWdtZW50LnNsaWNlKDEsIC0xKSlcbiAgICAgICAgICAvLyByZXBsYWNlIGFueSBub24td29yZCBjaGFyYWN0ZXJzIHNpbmNlIHRoZXkgY2FuIGJyZWFrXG4gICAgICAgICAgLy8gdGhlIG5hbWVkIHJlZ2V4XG4gICAgICAgICAgbGV0IGNsZWFuZWRLZXkgPSBrZXkucmVwbGFjZSgvXFxXL2csICcnKVxuICAgICAgICAgIGxldCBpbnZhbGlkS2V5ID0gZmFsc2VcblxuICAgICAgICAgIC8vIGNoZWNrIGlmIHRoZSBrZXkgaXMgc3RpbGwgaW52YWxpZCBhbmQgZmFsbGJhY2sgdG8gdXNpbmcgYSBrbm93blxuICAgICAgICAgIC8vIHNhZmUga2V5XG4gICAgICAgICAgaWYgKGNsZWFuZWRLZXkubGVuZ3RoID09PSAwIHx8IGNsZWFuZWRLZXkubGVuZ3RoID4gMzApIHtcbiAgICAgICAgICAgIGludmFsaWRLZXkgPSB0cnVlXG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICghaXNOYU4ocGFyc2VJbnQoY2xlYW5lZEtleS5zdWJzdHIoMCwgMSkpKSkge1xuICAgICAgICAgICAgaW52YWxpZEtleSA9IHRydWVcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoaW52YWxpZEtleSkge1xuICAgICAgICAgICAgY2xlYW5lZEtleSA9IGdldFNhZmVSb3V0ZUtleSgpXG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcm91dGVLZXlzW2NsZWFuZWRLZXldID0ga2V5XG4gICAgICAgICAgcmV0dXJuIHJlcGVhdFxuICAgICAgICAgICAgPyBvcHRpb25hbFxuICAgICAgICAgICAgICA/IGAoPzovKD88JHtjbGVhbmVkS2V5fT4uKz8pKT9gXG4gICAgICAgICAgICAgIDogYC8oPzwke2NsZWFuZWRLZXl9Pi4rPylgXG4gICAgICAgICAgICA6IGAvKD88JHtjbGVhbmVkS2V5fT5bXi9dKz8pYFxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBgLyR7ZXNjYXBlUmVnZXgoc2VnbWVudCl9YFxuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgLmpvaW4oJycpXG5cbiAgICByZXR1cm4ge1xuICAgICAgcmU6IG5ldyBSZWdFeHAoYF4ke3BhcmFtZXRlcml6ZWRSb3V0ZX0oPzovKT8kYCksXG4gICAgICBncm91cHMsXG4gICAgICByb3V0ZUtleXMsXG4gICAgICBuYW1lZFJlZ2V4OiBgXiR7bmFtZWRQYXJhbWV0ZXJpemVkUm91dGV9KD86Lyk/JGAsXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHtcbiAgICByZTogbmV3IFJlZ0V4cChgXiR7cGFyYW1ldGVyaXplZFJvdXRlfSg/Oi8pPyRgKSxcbiAgICBncm91cHMsXG4gIH1cbn1cbiIsImltcG9ydCB7IEluY29taW5nTWVzc2FnZSwgU2VydmVyUmVzcG9uc2UgfSBmcm9tICdodHRwJ1xuaW1wb3J0IHsgUGFyc2VkVXJsUXVlcnkgfSBmcm9tICdxdWVyeXN0cmluZydcbmltcG9ydCB7IENvbXBvbmVudFR5cGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IFVybE9iamVjdCB9IGZyb20gJ3VybCdcbmltcG9ydCB7IGZvcm1hdFVybCB9IGZyb20gJy4vcm91dGVyL3V0aWxzL2Zvcm1hdC11cmwnXG5pbXBvcnQgeyBNYW5pZmVzdEl0ZW0gfSBmcm9tICcuLi9zZXJ2ZXIvbG9hZC1jb21wb25lbnRzJ1xuaW1wb3J0IHsgTmV4dFJvdXRlciB9IGZyb20gJy4vcm91dGVyL3JvdXRlcidcbmltcG9ydCB7IEVudiB9IGZyb20gJ0BuZXh0L2VudidcbmltcG9ydCB7IEJ1aWxkTWFuaWZlc3QgfSBmcm9tICcuLi9zZXJ2ZXIvZ2V0LXBhZ2UtZmlsZXMnXG5cbi8qKlxuICogVHlwZXMgdXNlZCBieSBib3RoIG5leHQgYW5kIG5leHQtc2VydmVyXG4gKi9cblxuZXhwb3J0IHR5cGUgTmV4dENvbXBvbmVudFR5cGU8XG4gIEMgZXh0ZW5kcyBCYXNlQ29udGV4dCA9IE5leHRQYWdlQ29udGV4dCxcbiAgSVAgPSB7fSxcbiAgUCA9IHt9XG4+ID0gQ29tcG9uZW50VHlwZTxQPiAmIHtcbiAgLyoqXG4gICAqIFVzZWQgZm9yIGluaXRpYWwgcGFnZSBsb2FkIGRhdGEgcG9wdWxhdGlvbi4gRGF0YSByZXR1cm5lZCBmcm9tIGBnZXRJbml0aWFsUHJvcHNgIGlzIHNlcmlhbGl6ZWQgd2hlbiBzZXJ2ZXIgcmVuZGVyZWQuXG4gICAqIE1ha2Ugc3VyZSB0byByZXR1cm4gcGxhaW4gYE9iamVjdGAgd2l0aG91dCB1c2luZyBgRGF0ZWAsIGBNYXBgLCBgU2V0YC5cbiAgICogQHBhcmFtIGN0eCBDb250ZXh0IG9mIGBwYWdlYFxuICAgKi9cbiAgZ2V0SW5pdGlhbFByb3BzPyhjb250ZXh0OiBDKTogSVAgfCBQcm9taXNlPElQPlxufVxuXG5leHBvcnQgdHlwZSBEb2N1bWVudFR5cGUgPSBOZXh0Q29tcG9uZW50VHlwZTxcbiAgRG9jdW1lbnRDb250ZXh0LFxuICBEb2N1bWVudEluaXRpYWxQcm9wcyxcbiAgRG9jdW1lbnRQcm9wc1xuPiAmIHtcbiAgcmVuZGVyRG9jdW1lbnQoXG4gICAgRG9jdW1lbnQ6IERvY3VtZW50VHlwZSxcbiAgICBwcm9wczogRG9jdW1lbnRQcm9wc1xuICApOiBSZWFjdC5SZWFjdEVsZW1lbnRcbn1cblxuZXhwb3J0IHR5cGUgQXBwVHlwZSA9IE5leHRDb21wb25lbnRUeXBlPFxuICBBcHBDb250ZXh0VHlwZSxcbiAgQXBwSW5pdGlhbFByb3BzLFxuICBBcHBQcm9wc1R5cGVcbj5cblxuZXhwb3J0IHR5cGUgQXBwVHJlZVR5cGUgPSBDb21wb25lbnRUeXBlPFxuICBBcHBJbml0aWFsUHJvcHMgJiB7IFtuYW1lOiBzdHJpbmddOiBhbnkgfVxuPlxuXG4vKipcbiAqIFdlYiB2aXRhbHMgcHJvdmlkZWQgdG8gX2FwcC5yZXBvcnRXZWJWaXRhbHMgYnkgQ29yZSBXZWIgVml0YWxzIHBsdWdpbiBkZXZlbG9wZWQgYnkgR29vZ2xlIENocm9tZSB0ZWFtLlxuICogaHR0cHM6Ly9uZXh0anMub3JnL2Jsb2cvbmV4dC05LTQjaW50ZWdyYXRlZC13ZWItdml0YWxzLXJlcG9ydGluZ1xuICovXG5leHBvcnQgdHlwZSBOZXh0V2ViVml0YWxzTWV0cmljID0ge1xuICBpZDogc3RyaW5nXG4gIGxhYmVsOiBzdHJpbmdcbiAgbmFtZTogc3RyaW5nXG4gIHN0YXJ0VGltZTogbnVtYmVyXG4gIHZhbHVlOiBudW1iZXJcbn1cblxuZXhwb3J0IHR5cGUgRW5oYW5jZXI8Qz4gPSAoQ29tcG9uZW50OiBDKSA9PiBDXG5cbmV4cG9ydCB0eXBlIENvbXBvbmVudHNFbmhhbmNlciA9XG4gIHwge1xuICAgICAgZW5oYW5jZUFwcD86IEVuaGFuY2VyPEFwcFR5cGU+XG4gICAgICBlbmhhbmNlQ29tcG9uZW50PzogRW5oYW5jZXI8TmV4dENvbXBvbmVudFR5cGU+XG4gICAgfVxuICB8IEVuaGFuY2VyPE5leHRDb21wb25lbnRUeXBlPlxuXG5leHBvcnQgdHlwZSBSZW5kZXJQYWdlUmVzdWx0ID0ge1xuICBodG1sOiBzdHJpbmdcbiAgaGVhZD86IEFycmF5PEpTWC5FbGVtZW50IHwgbnVsbD5cbn1cblxuZXhwb3J0IHR5cGUgUmVuZGVyUGFnZSA9IChcbiAgb3B0aW9ucz86IENvbXBvbmVudHNFbmhhbmNlclxuKSA9PiBSZW5kZXJQYWdlUmVzdWx0IHwgUHJvbWlzZTxSZW5kZXJQYWdlUmVzdWx0PlxuXG5leHBvcnQgdHlwZSBCYXNlQ29udGV4dCA9IHtcbiAgcmVzPzogU2VydmVyUmVzcG9uc2VcbiAgW2s6IHN0cmluZ106IGFueVxufVxuXG5leHBvcnQgdHlwZSBIZWFkRW50cnkgPSBbc3RyaW5nLCB7IFtrZXk6IHN0cmluZ106IGFueSB9XVxuXG5leHBvcnQgdHlwZSBORVhUX0RBVEEgPSB7XG4gIHByb3BzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+XG4gIHBhZ2U6IHN0cmluZ1xuICBxdWVyeTogUGFyc2VkVXJsUXVlcnlcbiAgYnVpbGRJZDogc3RyaW5nXG4gIGFzc2V0UHJlZml4Pzogc3RyaW5nXG4gIHJ1bnRpbWVDb25maWc/OiB7IFtrZXk6IHN0cmluZ106IGFueSB9XG4gIG5leHRFeHBvcnQ/OiBib29sZWFuXG4gIGF1dG9FeHBvcnQ/OiBib29sZWFuXG4gIGlzRmFsbGJhY2s/OiBib29sZWFuXG4gIGR5bmFtaWNJZHM/OiBzdHJpbmdbXVxuICBlcnI/OiBFcnJvciAmIHsgc3RhdHVzQ29kZT86IG51bWJlciB9XG4gIGdzcD86IGJvb2xlYW5cbiAgZ3NzcD86IGJvb2xlYW5cbiAgY3VzdG9tU2VydmVyPzogYm9vbGVhblxuICBnaXA/OiBib29sZWFuXG4gIGFwcEdpcD86IGJvb2xlYW5cbiAgaGVhZDogSGVhZEVudHJ5W11cbiAgbG9jYWxlPzogc3RyaW5nXG4gIGxvY2FsZXM/OiBzdHJpbmdbXVxuICBkZWZhdWx0TG9jYWxlPzogc3RyaW5nXG59XG5cbi8qKlxuICogYE5leHRgIGNvbnRleHRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBOZXh0UGFnZUNvbnRleHQge1xuICAvKipcbiAgICogRXJyb3Igb2JqZWN0IGlmIGVuY291bnRlcmVkIGR1cmluZyByZW5kZXJpbmdcbiAgICovXG4gIGVycj86IChFcnJvciAmIHsgc3RhdHVzQ29kZT86IG51bWJlciB9KSB8IG51bGxcbiAgLyoqXG4gICAqIGBIVFRQYCByZXF1ZXN0IG9iamVjdC5cbiAgICovXG4gIHJlcT86IEluY29taW5nTWVzc2FnZVxuICAvKipcbiAgICogYEhUVFBgIHJlc3BvbnNlIG9iamVjdC5cbiAgICovXG4gIHJlcz86IFNlcnZlclJlc3BvbnNlXG4gIC8qKlxuICAgKiBQYXRoIHNlY3Rpb24gb2YgYFVSTGAuXG4gICAqL1xuICBwYXRobmFtZTogc3RyaW5nXG4gIC8qKlxuICAgKiBRdWVyeSBzdHJpbmcgc2VjdGlvbiBvZiBgVVJMYCBwYXJzZWQgYXMgYW4gb2JqZWN0LlxuICAgKi9cbiAgcXVlcnk6IFBhcnNlZFVybFF1ZXJ5XG4gIC8qKlxuICAgKiBgU3RyaW5nYCBvZiB0aGUgYWN0dWFsIHBhdGggaW5jbHVkaW5nIHF1ZXJ5LlxuICAgKi9cbiAgYXNQYXRoPzogc3RyaW5nXG4gIC8qKlxuICAgKiBgQ29tcG9uZW50YCB0aGUgdHJlZSBvZiB0aGUgQXBwIHRvIHVzZSBpZiBuZWVkaW5nIHRvIHJlbmRlciBzZXBhcmF0ZWx5XG4gICAqL1xuICBBcHBUcmVlOiBBcHBUcmVlVHlwZVxufVxuXG5leHBvcnQgdHlwZSBBcHBDb250ZXh0VHlwZTxSIGV4dGVuZHMgTmV4dFJvdXRlciA9IE5leHRSb3V0ZXI+ID0ge1xuICBDb21wb25lbnQ6IE5leHRDb21wb25lbnRUeXBlPE5leHRQYWdlQ29udGV4dD5cbiAgQXBwVHJlZTogQXBwVHJlZVR5cGVcbiAgY3R4OiBOZXh0UGFnZUNvbnRleHRcbiAgcm91dGVyOiBSXG59XG5cbmV4cG9ydCB0eXBlIEFwcEluaXRpYWxQcm9wcyA9IHtcbiAgcGFnZVByb3BzOiBhbnlcbn1cblxuZXhwb3J0IHR5cGUgQXBwUHJvcHNUeXBlPFxuICBSIGV4dGVuZHMgTmV4dFJvdXRlciA9IE5leHRSb3V0ZXIsXG4gIFAgPSB7fVxuPiA9IEFwcEluaXRpYWxQcm9wcyAmIHtcbiAgQ29tcG9uZW50OiBOZXh0Q29tcG9uZW50VHlwZTxOZXh0UGFnZUNvbnRleHQsIGFueSwgUD5cbiAgcm91dGVyOiBSXG4gIF9fTl9TU0c/OiBib29sZWFuXG4gIF9fTl9TU1A/OiBib29sZWFuXG59XG5cbmV4cG9ydCB0eXBlIERvY3VtZW50Q29udGV4dCA9IE5leHRQYWdlQ29udGV4dCAmIHtcbiAgcmVuZGVyUGFnZTogUmVuZGVyUGFnZVxufVxuXG5leHBvcnQgdHlwZSBEb2N1bWVudEluaXRpYWxQcm9wcyA9IFJlbmRlclBhZ2VSZXN1bHQgJiB7XG4gIHN0eWxlcz86IFJlYWN0LlJlYWN0RWxlbWVudFtdIHwgUmVhY3QuUmVhY3RGcmFnbWVudFxufVxuXG5leHBvcnQgdHlwZSBEb2N1bWVudFByb3BzID0gRG9jdW1lbnRJbml0aWFsUHJvcHMgJiB7XG4gIF9fTkVYVF9EQVRBX186IE5FWFRfREFUQVxuICBkYW5nZXJvdXNBc1BhdGg6IHN0cmluZ1xuICBkb2NDb21wb25lbnRzUmVuZGVyZWQ6IHtcbiAgICBIdG1sPzogYm9vbGVhblxuICAgIE1haW4/OiBib29sZWFuXG4gICAgSGVhZD86IGJvb2xlYW5cbiAgICBOZXh0U2NyaXB0PzogYm9vbGVhblxuICB9XG4gIGJ1aWxkTWFuaWZlc3Q6IEJ1aWxkTWFuaWZlc3RcbiAgYW1wUGF0aDogc3RyaW5nXG4gIGluQW1wTW9kZTogYm9vbGVhblxuICBoeWJyaWRBbXA6IGJvb2xlYW5cbiAgaXNEZXZlbG9wbWVudDogYm9vbGVhblxuICBkeW5hbWljSW1wb3J0czogTWFuaWZlc3RJdGVtW11cbiAgYXNzZXRQcmVmaXg/OiBzdHJpbmdcbiAgY2Fub25pY2FsQmFzZTogc3RyaW5nXG4gIGhlYWRUYWdzOiBhbnlbXVxuICB1bnN0YWJsZV9ydW50aW1lSlM/OiBmYWxzZVxuICBkZXZPbmx5Q2FjaGVCdXN0ZXJRdWVyeVN0cmluZzogc3RyaW5nXG4gIGxvY2FsZT86IHN0cmluZ1xufVxuXG4vKipcbiAqIE5leHQgYEFQSWAgcm91dGUgcmVxdWVzdFxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5leHRBcGlSZXF1ZXN0IGV4dGVuZHMgSW5jb21pbmdNZXNzYWdlIHtcbiAgLyoqXG4gICAqIE9iamVjdCBvZiBgcXVlcnlgIHZhbHVlcyBmcm9tIHVybFxuICAgKi9cbiAgcXVlcnk6IHtcbiAgICBba2V5OiBzdHJpbmddOiBzdHJpbmcgfCBzdHJpbmdbXVxuICB9XG4gIC8qKlxuICAgKiBPYmplY3Qgb2YgYGNvb2tpZXNgIGZyb20gaGVhZGVyXG4gICAqL1xuICBjb29raWVzOiB7XG4gICAgW2tleTogc3RyaW5nXTogc3RyaW5nXG4gIH1cblxuICBib2R5OiBhbnlcblxuICBlbnY6IEVudlxuXG4gIHByZXZpZXc/OiBib29sZWFuXG4gIC8qKlxuICAgKiBQcmV2aWV3IGRhdGEgc2V0IG9uIHRoZSByZXF1ZXN0LCBpZiBhbnlcbiAgICogKi9cbiAgcHJldmlld0RhdGE/OiBhbnlcbn1cblxuLyoqXG4gKiBTZW5kIGJvZHkgb2YgcmVzcG9uc2VcbiAqL1xudHlwZSBTZW5kPFQ+ID0gKGJvZHk6IFQpID0+IHZvaWRcblxuLyoqXG4gKiBOZXh0IGBBUElgIHJvdXRlIHJlc3BvbnNlXG4gKi9cbmV4cG9ydCB0eXBlIE5leHRBcGlSZXNwb25zZTxUID0gYW55PiA9IFNlcnZlclJlc3BvbnNlICYge1xuICAvKipcbiAgICogU2VuZCBkYXRhIGBhbnlgIGRhdGEgaW4gcmVzcG9uc2VcbiAgICovXG4gIHNlbmQ6IFNlbmQ8VD5cbiAgLyoqXG4gICAqIFNlbmQgZGF0YSBganNvbmAgZGF0YSBpbiByZXNwb25zZVxuICAgKi9cbiAganNvbjogU2VuZDxUPlxuICBzdGF0dXM6IChzdGF0dXNDb2RlOiBudW1iZXIpID0+IE5leHRBcGlSZXNwb25zZTxUPlxuICByZWRpcmVjdCh1cmw6IHN0cmluZyk6IE5leHRBcGlSZXNwb25zZTxUPlxuICByZWRpcmVjdChzdGF0dXM6IG51bWJlciwgdXJsOiBzdHJpbmcpOiBOZXh0QXBpUmVzcG9uc2U8VD5cblxuICAvKipcbiAgICogU2V0IHByZXZpZXcgZGF0YSBmb3IgTmV4dC5qcycgcHJlcmVuZGVyIG1vZGVcbiAgICovXG4gIHNldFByZXZpZXdEYXRhOiAoXG4gICAgZGF0YTogb2JqZWN0IHwgc3RyaW5nLFxuICAgIG9wdGlvbnM/OiB7XG4gICAgICAvKipcbiAgICAgICAqIFNwZWNpZmllcyB0aGUgbnVtYmVyIChpbiBzZWNvbmRzKSBmb3IgdGhlIHByZXZpZXcgc2Vzc2lvbiB0byBsYXN0IGZvci5cbiAgICAgICAqIFRoZSBnaXZlbiBudW1iZXIgd2lsbCBiZSBjb252ZXJ0ZWQgdG8gYW4gaW50ZWdlciBieSByb3VuZGluZyBkb3duLlxuICAgICAgICogQnkgZGVmYXVsdCwgbm8gbWF4aW11bSBhZ2UgaXMgc2V0IGFuZCB0aGUgcHJldmlldyBzZXNzaW9uIGZpbmlzaGVzXG4gICAgICAgKiB3aGVuIHRoZSBjbGllbnQgc2h1dHMgZG93biAoYnJvd3NlciBpcyBjbG9zZWQpLlxuICAgICAgICovXG4gICAgICBtYXhBZ2U/OiBudW1iZXJcbiAgICB9XG4gICkgPT4gTmV4dEFwaVJlc3BvbnNlPFQ+XG4gIGNsZWFyUHJldmlld0RhdGE6ICgpID0+IE5leHRBcGlSZXNwb25zZTxUPlxufVxuXG4vKipcbiAqIE5leHQgYEFQSWAgcm91dGUgaGFuZGxlclxuICovXG5leHBvcnQgdHlwZSBOZXh0QXBpSGFuZGxlcjxUID0gYW55PiA9IChcbiAgcmVxOiBOZXh0QXBpUmVxdWVzdCxcbiAgcmVzOiBOZXh0QXBpUmVzcG9uc2U8VD5cbikgPT4gdm9pZCB8IFByb21pc2U8dm9pZD5cblxuLyoqXG4gKiBVdGlsc1xuICovXG5leHBvcnQgZnVuY3Rpb24gZXhlY09uY2U8VCBleHRlbmRzICguLi5hcmdzOiBhbnlbXSkgPT4gUmV0dXJuVHlwZTxUPj4oXG4gIGZuOiBUXG4pOiBUIHtcbiAgbGV0IHVzZWQgPSBmYWxzZVxuICBsZXQgcmVzdWx0OiBSZXR1cm5UeXBlPFQ+XG5cbiAgcmV0dXJuICgoLi4uYXJnczogYW55W10pID0+IHtcbiAgICBpZiAoIXVzZWQpIHtcbiAgICAgIHVzZWQgPSB0cnVlXG4gICAgICByZXN1bHQgPSBmbiguLi5hcmdzKVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0XG4gIH0pIGFzIFRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldExvY2F0aW9uT3JpZ2luKCkge1xuICBjb25zdCB7IHByb3RvY29sLCBob3N0bmFtZSwgcG9ydCB9ID0gd2luZG93LmxvY2F0aW9uXG4gIHJldHVybiBgJHtwcm90b2NvbH0vLyR7aG9zdG5hbWV9JHtwb3J0ID8gJzonICsgcG9ydCA6ICcnfWBcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFVSTCgpIHtcbiAgY29uc3QgeyBocmVmIH0gPSB3aW5kb3cubG9jYXRpb25cbiAgY29uc3Qgb3JpZ2luID0gZ2V0TG9jYXRpb25PcmlnaW4oKVxuICByZXR1cm4gaHJlZi5zdWJzdHJpbmcob3JpZ2luLmxlbmd0aClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldERpc3BsYXlOYW1lPFA+KENvbXBvbmVudDogQ29tcG9uZW50VHlwZTxQPikge1xuICByZXR1cm4gdHlwZW9mIENvbXBvbmVudCA9PT0gJ3N0cmluZydcbiAgICA/IENvbXBvbmVudFxuICAgIDogQ29tcG9uZW50LmRpc3BsYXlOYW1lIHx8IENvbXBvbmVudC5uYW1lIHx8ICdVbmtub3duJ1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNSZXNTZW50KHJlczogU2VydmVyUmVzcG9uc2UpIHtcbiAgcmV0dXJuIHJlcy5maW5pc2hlZCB8fCByZXMuaGVhZGVyc1NlbnRcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvYWRHZXRJbml0aWFsUHJvcHM8XG4gIEMgZXh0ZW5kcyBCYXNlQ29udGV4dCxcbiAgSVAgPSB7fSxcbiAgUCA9IHt9XG4+KEFwcDogTmV4dENvbXBvbmVudFR5cGU8QywgSVAsIFA+LCBjdHg6IEMpOiBQcm9taXNlPElQPiB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgaWYgKEFwcC5wcm90b3R5cGU/LmdldEluaXRpYWxQcm9wcykge1xuICAgICAgY29uc3QgbWVzc2FnZSA9IGBcIiR7Z2V0RGlzcGxheU5hbWUoXG4gICAgICAgIEFwcFxuICAgICAgKX0uZ2V0SW5pdGlhbFByb3BzKClcIiBpcyBkZWZpbmVkIGFzIGFuIGluc3RhbmNlIG1ldGhvZCAtIHZpc2l0IGh0dHBzOi8vZXJyLnNoL3ZlcmNlbC9uZXh0LmpzL2dldC1pbml0aWFsLXByb3BzLWFzLWFuLWluc3RhbmNlLW1ldGhvZCBmb3IgbW9yZSBpbmZvcm1hdGlvbi5gXG4gICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSlcbiAgICB9XG4gIH1cbiAgLy8gd2hlbiBjYWxsZWQgZnJvbSBfYXBwIGBjdHhgIGlzIG5lc3RlZCBpbiBgY3R4YFxuICBjb25zdCByZXMgPSBjdHgucmVzIHx8IChjdHguY3R4ICYmIGN0eC5jdHgucmVzKVxuXG4gIGlmICghQXBwLmdldEluaXRpYWxQcm9wcykge1xuICAgIGlmIChjdHguY3R4ICYmIGN0eC5Db21wb25lbnQpIHtcbiAgICAgIC8vIEB0cy1pZ25vcmUgcGFnZVByb3BzIGRlZmF1bHRcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHBhZ2VQcm9wczogYXdhaXQgbG9hZEdldEluaXRpYWxQcm9wcyhjdHguQ29tcG9uZW50LCBjdHguY3R4KSxcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHt9IGFzIElQXG4gIH1cblxuICBjb25zdCBwcm9wcyA9IGF3YWl0IEFwcC5nZXRJbml0aWFsUHJvcHMoY3R4KVxuXG4gIGlmIChyZXMgJiYgaXNSZXNTZW50KHJlcykpIHtcbiAgICByZXR1cm4gcHJvcHNcbiAgfVxuXG4gIGlmICghcHJvcHMpIHtcbiAgICBjb25zdCBtZXNzYWdlID0gYFwiJHtnZXREaXNwbGF5TmFtZShcbiAgICAgIEFwcFxuICAgICl9LmdldEluaXRpYWxQcm9wcygpXCIgc2hvdWxkIHJlc29sdmUgdG8gYW4gb2JqZWN0LiBCdXQgZm91bmQgXCIke3Byb3BzfVwiIGluc3RlYWQuYFxuICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKVxuICB9XG5cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBpZiAoT2JqZWN0LmtleXMocHJvcHMpLmxlbmd0aCA9PT0gMCAmJiAhY3R4LmN0eCkge1xuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICBgJHtnZXREaXNwbGF5TmFtZShcbiAgICAgICAgICBBcHBcbiAgICAgICAgKX0gcmV0dXJuZWQgYW4gZW1wdHkgb2JqZWN0IGZyb20gXFxgZ2V0SW5pdGlhbFByb3BzXFxgLiBUaGlzIGRlLW9wdGltaXplcyBhbmQgcHJldmVudHMgYXV0b21hdGljIHN0YXRpYyBvcHRpbWl6YXRpb24uIGh0dHBzOi8vZXJyLnNoL3ZlcmNlbC9uZXh0LmpzL2VtcHR5LW9iamVjdC1nZXRJbml0aWFsUHJvcHNgXG4gICAgICApXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHByb3BzXG59XG5cbmV4cG9ydCBjb25zdCB1cmxPYmplY3RLZXlzID0gW1xuICAnYXV0aCcsXG4gICdoYXNoJyxcbiAgJ2hvc3QnLFxuICAnaG9zdG5hbWUnLFxuICAnaHJlZicsXG4gICdwYXRoJyxcbiAgJ3BhdGhuYW1lJyxcbiAgJ3BvcnQnLFxuICAncHJvdG9jb2wnLFxuICAncXVlcnknLFxuICAnc2VhcmNoJyxcbiAgJ3NsYXNoZXMnLFxuXVxuXG5leHBvcnQgZnVuY3Rpb24gZm9ybWF0V2l0aFZhbGlkYXRpb24odXJsOiBVcmxPYmplY3QpOiBzdHJpbmcge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICBpZiAodXJsICE9PSBudWxsICYmIHR5cGVvZiB1cmwgPT09ICdvYmplY3QnKSB7XG4gICAgICBPYmplY3Qua2V5cyh1cmwpLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICBpZiAodXJsT2JqZWN0S2V5cy5pbmRleE9mKGtleSkgPT09IC0xKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgICAgYFVua25vd24ga2V5IHBhc3NlZCB2aWEgdXJsT2JqZWN0IGludG8gdXJsLmZvcm1hdDogJHtrZXl9YFxuICAgICAgICAgIClcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZm9ybWF0VXJsKHVybClcbn1cblxuZXhwb3J0IGNvbnN0IFNQID0gdHlwZW9mIHBlcmZvcm1hbmNlICE9PSAndW5kZWZpbmVkJ1xuZXhwb3J0IGNvbnN0IFNUID1cbiAgU1AgJiZcbiAgdHlwZW9mIHBlcmZvcm1hbmNlLm1hcmsgPT09ICdmdW5jdGlvbicgJiZcbiAgdHlwZW9mIHBlcmZvcm1hbmNlLm1lYXN1cmUgPT09ICdmdW5jdGlvbidcbiIsIlwidXNlIHN0cmljdFwiO2V4cG9ydHMuX19lc01vZHVsZT10cnVlO2V4cG9ydHMubm9ybWFsaXplUGF0aFNlcD1ub3JtYWxpemVQYXRoU2VwO2V4cG9ydHMuZGVub3JtYWxpemVQYWdlUGF0aD1kZW5vcm1hbGl6ZVBhZ2VQYXRoO2Z1bmN0aW9uIG5vcm1hbGl6ZVBhdGhTZXAocGF0aCl7cmV0dXJuIHBhdGgucmVwbGFjZSgvXFxcXC9nLCcvJyk7fWZ1bmN0aW9uIGRlbm9ybWFsaXplUGFnZVBhdGgocGFnZSl7cGFnZT1ub3JtYWxpemVQYXRoU2VwKHBhZ2UpO2lmKHBhZ2Uuc3RhcnRzV2l0aCgnL2luZGV4LycpKXtwYWdlPXBhZ2Uuc2xpY2UoNik7fWVsc2UgaWYocGFnZT09PScvaW5kZXgnKXtwYWdlPScvJzt9cmV0dXJuIHBhZ2U7fVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZGVub3JtYWxpemUtcGFnZS1wYXRoLmpzLm1hcCIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9kaXN0L2NsaWVudC9saW5rJylcbiIsImltcG9ydCBMaW5rIGZyb20gJ25leHQvbGluayc7XG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHdpdGhSZWR1eCBmcm9tICduZXh0LXJlZHV4LXdyYXBwZXInO1xuaW1wb3J0IExheW91dCBmcm9tICcuLi9jb21wb25lbnRzL015TGF5b3V0LmpzJztcbmltcG9ydCB7IGluaXRTdG9yZSB9IGZyb20gJy4uL3N0b3JlL3N0b3JlJztcbmltcG9ydCB7IGZldGNoUXVldWUgfSBmcm9tICcuLi9hY3Rpb25zL3F1ZXVlQWN0aW9ucyc7XG5pbXBvcnQgeyBmZXRjaFVzZXJzIH0gZnJvbSAnLi4vYWN0aW9ucy91c2Vyc0FjdGlvbnMnO1xuaW1wb3J0IHsgZmV0Y2hQbGF5aW5nQ29udGV4dCB9IGZyb20gJy4uL2FjdGlvbnMvcGxheWJhY2tBY3Rpb25zJztcbmltcG9ydCBVc2VycyBmcm9tICcuLi9jb21wb25lbnRzL1VzZXJzJztcbmltcG9ydCBRdWV1ZSBmcm9tICcuLi9jb21wb25lbnRzL1F1ZXVlJztcbmltcG9ydCBBZGRUb1F1ZXVlIGZyb20gJy4uL2NvbXBvbmVudHMvQWRkVG9RdWV1ZSc7XG5pbXBvcnQgTm93UGxheWluZyBmcm9tICcuLi9jb21wb25lbnRzL05vd1BsYXlpbmcnO1xuaW1wb3J0IERldmljZXMgZnJvbSAnLi4vY29tcG9uZW50cy9EZXZpY2VzJztcbmltcG9ydCBQYWdlV2l0aEludGwgZnJvbSAnLi4vY29tcG9uZW50cy9QYWdlV2l0aEludGwnO1xuaW1wb3J0IHsgRm9ybWF0dGVkTWVzc2FnZSB9IGZyb20gJ3JlYWN0LWludGwnO1xuXG5jbGFzcyBNYWluIGV4dGVuZHMgUmVhY3QuQ29tcG9uZW50IHtcbiAgc3RhdGljIGdldEluaXRpYWxQcm9wcyh7IHJlcSwgc3RvcmUsIGlzU2VydmVyIH0pIHtcbiAgICByZXR1cm4gUHJvbWlzZS5hbGwoW1xuICAgICAgc3RvcmUuZGlzcGF0Y2goZmV0Y2hRdWV1ZSgpKSxcbiAgICAgIHN0b3JlLmRpc3BhdGNoKGZldGNoVXNlcnMoKSksXG4gICAgICBzdG9yZS5kaXNwYXRjaChmZXRjaFBsYXlpbmdDb250ZXh0KCkpXG4gICAgXSk7XG4gIH1cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiAoXG4gICAgICA8TGF5b3V0PlxuICAgICAgICB7dGhpcy5wcm9wcy5wbGF5aW5nLnRyYWNrID8gKFxuICAgICAgICAgIDxOb3dQbGF5aW5nXG4gICAgICAgICAgICB0cmFjaz17dGhpcy5wcm9wcy5wbGF5aW5nLnRyYWNrfVxuICAgICAgICAgICAgdXNlcj17dGhpcy5wcm9wcy5wbGF5aW5nLnVzZXJ9XG4gICAgICAgICAgICBwb3NpdGlvbj17dGhpcy5wcm9wcy5wbGF5aW5nLnBvc2l0aW9ufVxuICAgICAgICAgIC8+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFwcFwiPlxuICAgICAgICAgIDxzdHlsZSBqc3g+XG4gICAgICAgICAgICB7YFxuICAgICAgICAgICAgICAuYXBwIHtcbiAgICAgICAgICAgICAgICBtYXJnaW46IDAgMjBweDtcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwIDIwcHg7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGB9XG4gICAgICAgICAgPC9zdHlsZT5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsb2F0OiAnbGVmdCcgfX0+XG4gICAgICAgICAgICA8UXVldWUgaXRlbXM9e3RoaXMucHJvcHMucXVldWV9IHNlc3Npb249e3RoaXMucHJvcHMuc2Vzc2lvbn0gLz5cbiAgICAgICAgICAgIHt0aGlzLnByb3BzLnNlc3Npb24udXNlciAhPT0gbnVsbCA/IDxBZGRUb1F1ZXVlIC8+IDogbnVsbH1cbiAgICAgICAgICAgIHt0aGlzLnByb3BzLnNlc3Npb24udXNlciAhPT0gbnVsbCA/IDxEZXZpY2VzIC8+IDogbnVsbH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsb2F0OiAnbGVmdCcsIHdpZHRoOiAnMTUwcHgnIH19PlxuICAgICAgICAgICAgPFVzZXJzIGl0ZW1zPXt0aGlzLnByb3BzLnVzZXJzfSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvTGF5b3V0PlxuICAgICk7XG4gIH1cbn1cblxuY29uc3QgbWFwU3RhdGVUb1Byb3BzID0gc3RhdGUgPT4gKHtcbiAgcGxheWluZzogc3RhdGUucGxheWJhY2ssXG4gIHF1ZXVlOiBzdGF0ZS5xdWV1ZSxcbiAgdXNlcnM6IHN0YXRlLnVzZXJzLFxuICBzZXNzaW9uOiBzdGF0ZS5zZXNzaW9uXG59KTtcblxuZXhwb3J0IGRlZmF1bHQgd2l0aFJlZHV4KGluaXRTdG9yZSwgbWFwU3RhdGVUb1Byb3BzLCBudWxsKShQYWdlV2l0aEludGwoTWFpbikpO1xuIiwiaW1wb3J0IHtcclxuICBGRVRDSF9BVkFJTEFCTEVfREVWSUNFUyxcclxuICBGRVRDSF9BVkFJTEFCTEVfREVWSUNFU19FUlJPUixcclxuICBGRVRDSF9BVkFJTEFCTEVfREVWSUNFU19TVUNDRVNTXHJcbn0gZnJvbSAnLi4vY29uc3RhbnRzL0FjdGlvblR5cGVzJztcclxuXHJcbmNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICBpc0ZldGNoaW5nOiBmYWxzZSxcclxuICBkYXRhOiBbXVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgKHN0YXRlLCBhY3Rpb24pID0+IHtcclxuICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XHJcbiAgICBjYXNlIEZFVENIX0FWQUlMQUJMRV9ERVZJQ0VTOlxyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgIGlzRmV0Y2hpbmc6IHRydWVcclxuICAgICAgfTtcclxuICAgIGNhc2UgRkVUQ0hfQVZBSUxBQkxFX0RFVklDRVNfU1VDQ0VTUzpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICBpc0ZldGNoaW5nOiBmYWxzZSxcclxuICAgICAgICBkYXRhOiBhY3Rpb24ubGlzdFxyXG4gICAgICB9O1xyXG4gICAgY2FzZSBGRVRDSF9BVkFJTEFCTEVfREVWSUNFU19FUlJPUjpcclxuICAgICAgcmV0dXJuIGluaXRpYWxTdGF0ZTtcclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJldHVybiBzdGF0ZSA/IHN0YXRlIDogaW5pdGlhbFN0YXRlO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBnZXRJc0ZldGNoaW5nID0gc3RhdGUgPT4ge1xyXG4gIHJldHVybiBzdGF0ZS5pc0ZldGNoaW5nO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldERldmljZXMgPSBzdGF0ZSA9PiB7XHJcbiAgcmV0dXJuIHN0YXRlLmRhdGE7XHJcbn07XHJcbiIsImltcG9ydCB7IGNvbWJpbmVSZWR1Y2VycyB9IGZyb20gJ3JlZHV4JztcclxuXHJcbmltcG9ydCBxdWV1ZVJlZHVjZXIgZnJvbSAnLi4vcmVkdWNlcnMvcXVldWVSZWR1Y2VyJztcclxuaW1wb3J0IHNlc3Npb25SZWR1Y2VyIGZyb20gJy4uL3JlZHVjZXJzL3Nlc3Npb25SZWR1Y2VyJztcclxuaW1wb3J0IHBsYXliYWNrUmVkdWNlciBmcm9tICcuLi9yZWR1Y2Vycy9wbGF5YmFja1JlZHVjZXInO1xyXG5pbXBvcnQgZGV2aWNlc1JlZHVjZXIsICogYXMgZnJvbURldmljZXMgZnJvbSAnLi4vcmVkdWNlcnMvZGV2aWNlc1JlZHVjZXInO1xyXG5pbXBvcnQgdXNlcnNSZWR1Y2VyIGZyb20gJy4uL3JlZHVjZXJzL3VzZXJzUmVkdWNlcic7XHJcbmltcG9ydCBzZWFyY2hSZWR1Y2VyIGZyb20gJy4uL3JlZHVjZXJzL3NlYXJjaFJlZHVjZXInO1xyXG5cclxuZXhwb3J0IGNvbnN0IHJlZHVjZXJzID0gKCkgPT5cclxuICBjb21iaW5lUmVkdWNlcnMoe1xyXG4gICAgcXVldWU6IHF1ZXVlUmVkdWNlcixcclxuICAgIHBsYXliYWNrOiBwbGF5YmFja1JlZHVjZXIsXHJcbiAgICBzZXNzaW9uOiBzZXNzaW9uUmVkdWNlcixcclxuICAgIHVzZXJzOiB1c2Vyc1JlZHVjZXIsXHJcbiAgICBzZWFyY2g6IHNlYXJjaFJlZHVjZXIsXHJcbiAgICBkZXZpY2VzOiBkZXZpY2VzUmVkdWNlclxyXG4gIH0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldERldmljZXMgPSBzdGF0ZSA9PiBmcm9tRGV2aWNlcy5nZXREZXZpY2VzKHN0YXRlLmRldmljZXMpO1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldElzRmV0Y2hpbmdEZXZpY2VzID0gc3RhdGUgPT4gZnJvbURldmljZXMuZ2V0SXNGZXRjaGluZyhzdGF0ZS5kZXZpY2VzKTtcclxuIiwiaW1wb3J0IHtcclxuICBGRVRDSF9QTEFZSU5HX0NPTlRFWFRfU1VDQ0VTUyxcclxuICBQTEFZX1RSQUNLX1NVQ0NFU1MsXHJcbiAgUVVFVUVfRU5ERUQsXHJcbiAgTVVURV9QTEFZQkFDSyxcclxuICBVTk1VVEVfUExBWUJBQ0ssXHJcbiAgVVBEQVRFX05PV19QTEFZSU5HXHJcbn0gZnJvbSAnLi4vY29uc3RhbnRzL0FjdGlvblR5cGVzJztcclxuXHJcbmNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICBtdXRlZDogZmFsc2VcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IChzdGF0ZSwgYWN0aW9uKSA9PiB7XHJcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgY2FzZSBGRVRDSF9QTEFZSU5HX0NPTlRFWFRfU1VDQ0VTUzpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICB0cmFjazogYWN0aW9uLnBsYXlpbmdDb250ZXh0LnRyYWNrLFxyXG4gICAgICAgIHVzZXI6IGFjdGlvbi5wbGF5aW5nQ29udGV4dC51c2VyLFxyXG4gICAgICAgIHBvc2l0aW9uOiAwXHJcbiAgICAgIH07XHJcbiAgICBjYXNlIFBMQVlfVFJBQ0tfU1VDQ0VTUzpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICB0cmFjazogYWN0aW9uLnRyYWNrLFxyXG4gICAgICAgIHVzZXI6IGFjdGlvbi51c2VyLFxyXG4gICAgICAgIHBvc2l0aW9uOiBhY3Rpb24ucG9zaXRpb24sXHJcbiAgICAgICAgc3RhcnRUaW1lOiBuZXcgRGF0ZSgpXHJcbiAgICAgIH07XHJcbiAgICBjYXNlIFVQREFURV9OT1dfUExBWUlORzpcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICB0cmFjazogYWN0aW9uLnRyYWNrLFxyXG4gICAgICAgIHVzZXI6IGFjdGlvbi51c2VyLFxyXG4gICAgICAgIHBvc2l0aW9uOiBhY3Rpb24ucG9zaXRpb24sXHJcbiAgICAgICAgc3RhcnRUaW1lOiBuZXcgRGF0ZSgpXHJcbiAgICAgIH07XHJcbiAgICBjYXNlIFFVRVVFX0VOREVEOiB7XHJcbiAgICAgIHJldHVybiBpbml0aWFsU3RhdGU7XHJcbiAgICB9XHJcbiAgICBjYXNlIE1VVEVfUExBWUJBQ0s6XHJcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBtdXRlZDogdHJ1ZSB9O1xyXG4gICAgY2FzZSBVTk1VVEVfUExBWUJBQ0s6XHJcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBtdXRlZDogZmFsc2UgfTtcclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJldHVybiBzdGF0ZSA/IHN0YXRlIDogaW5pdGlhbFN0YXRlO1xyXG4gIH1cclxufTtcclxuIiwiaW1wb3J0IHsgVVBEQVRFX1FVRVVFIH0gZnJvbSAnLi4vY29uc3RhbnRzL0FjdGlvblR5cGVzJztcclxuXHJcbmNvbnN0IGluaXRpYWxTdGF0ZSA9IFtdO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgKHN0YXRlLCBhY3Rpb24pID0+IHtcclxuICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XHJcbiAgICBjYXNlIFVQREFURV9RVUVVRTpcclxuICAgICAgcmV0dXJuIGFjdGlvbi5kYXRhO1xyXG4gICAgZGVmYXVsdDpcclxuICAgICAgcmV0dXJuIHN0YXRlID8gc3RhdGUgOiBpbml0aWFsU3RhdGU7XHJcbiAgfVxyXG59O1xyXG4iLCJpbXBvcnQgeyBTRUFSQ0hfVFJBQ0tTLCBTRUFSQ0hfVFJBQ0tTX1NVQ0NFU1MsIFNFQVJDSF9UUkFDS1NfUkVTRVQgfSBmcm9tICcuLi9jb25zdGFudHMvQWN0aW9uVHlwZXMnO1xyXG5cclxuY29uc3QgaW5pdGlhbFN0YXRlID0ge307XHJcblxyXG5leHBvcnQgZGVmYXVsdCAoc3RhdGUsIGFjdGlvbikgPT4ge1xyXG4gIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgIGNhc2UgU0VBUkNIX1RSQUNLUzpcclxuICAgICAgcmV0dXJuIHsgcXVlcnk6IGFjdGlvbi5xdWVyeSB9O1xyXG4gICAgY2FzZSBTRUFSQ0hfVFJBQ0tTX1NVQ0NFU1M6XHJcbiAgICAgIGlmIChzdGF0ZS5xdWVyeSA9PT0gYWN0aW9uLnF1ZXJ5KSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIHF1ZXJ5OiBhY3Rpb24ucXVlcnksXHJcbiAgICAgICAgICByZXN1bHRzOiBhY3Rpb24ucmVzdWx0c1xyXG4gICAgICAgIH07XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gICAgICB9XHJcbiAgICBjYXNlIFNFQVJDSF9UUkFDS1NfUkVTRVQ6XHJcbiAgICAgIHJldHVybiBpbml0aWFsU3RhdGU7XHJcblxyXG4gICAgZGVmYXVsdDpcclxuICAgICAgcmV0dXJuIHN0YXRlID8gc3RhdGUgOiBpbml0aWFsU3RhdGU7XHJcbiAgfVxyXG59O1xyXG4iLCJpbXBvcnQgeyBMT0FELCBMT0dJTl9TVUNDRVNTLCBVUERBVEVfVE9LRU5fU1VDQ0VTUywgVVBEQVRFX0NVUlJFTlRfVVNFUiB9IGZyb20gJy4uL2NvbnN0YW50cy9BY3Rpb25UeXBlcyc7XHJcblxyXG5jb25zdCBpbml0aWFsU3RhdGUgPSB7XHJcbiAgcmVmcmVzaF90b2tlbjogbnVsbCwgLy8nbG9jYWxTdG9yYWdlJyBpbiB3aW5kb3cgJiYgbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3JlZnJlc2hUb2tlbicpLFxyXG4gIHVzZXI6IG51bGxcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IChzdGF0ZSwgYWN0aW9uKSA9PiB7XHJcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgY2FzZSBMT0FEOlxyXG4gICAgICBpZiAocHJvY2Vzcy5icm93c2VyKSB7XHJcbiAgICAgICAgY29uc3QgcmVmcmVzaFRva2VuID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3JlZnJlc2hUb2tlbicpO1xyXG4gICAgICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2FjY2Vzc1Rva2VuJyk7XHJcbiAgICAgICAgY29uc3QgZXhwaXJlc0luID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2V4cGlyZXNJbicpO1xyXG4gICAgICAgIHJldHVybiBPYmplY3QuYXNzaWduKHt9LCBzdGF0ZSwge1xyXG4gICAgICAgICAgYWNjZXNzX3Rva2VuOiBhY2Nlc3NUb2tlbixcclxuICAgICAgICAgIHJlZnJlc2hfdG9rZW46IHJlZnJlc2hUb2tlbixcclxuICAgICAgICAgIGV4cGlyZXNfaW46IGV4cGlyZXNJbiA/ICtleHBpcmVzSW4gOiBudWxsXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gICAgICB9XHJcbiAgICBjYXNlIFVQREFURV9UT0tFTl9TVUNDRVNTOlxyXG4gICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgc3RhdGUsIHsgYWNjZXNzX3Rva2VuOiBhY3Rpb24uYWNjZXNzX3Rva2VuIH0pO1xyXG4gICAgY2FzZSBMT0dJTl9TVUNDRVNTOlxyXG4gICAgICBpZiAoYWN0aW9uLnJlZnJlc2hfdG9rZW4pIHtcclxuICAgICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgc3RhdGUsIHtcclxuICAgICAgICAgIHJlZnJlc2hfdG9rZW46IGFjdGlvbi5yZWZyZXNoX3Rva2VuXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gICAgY2FzZSBVUERBVEVfQ1VSUkVOVF9VU0VSOlxyXG4gICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgc3RhdGUsIHsgdXNlcjogYWN0aW9uLnVzZXIgfSk7XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXR1cm4gc3RhdGUgPyBzdGF0ZSA6IGluaXRpYWxTdGF0ZTtcclxuICB9XHJcbn07XHJcbiIsImltcG9ydCB7IFVQREFURV9VU0VSUyB9IGZyb20gJy4uL2NvbnN0YW50cy9BY3Rpb25UeXBlcyc7XHJcblxyXG5jb25zdCBpbml0aWFsU3RhdGUgPSBbXHJcbiAge1xyXG4gICAgaWQ6ICdzb21ldGhpbmcnLFxyXG4gICAgbmFtZTogJ0FkcmlhbidcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiAnc29tZXRoaW5nJyxcclxuICAgIG5hbWU6ICdCZWEnXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogJ3NvbWV0aGluZycsXHJcbiAgICBuYW1lOiAnQ2FybG9zJ1xyXG4gIH1cclxuXTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IChzdGF0ZSwgYWN0aW9uKSA9PiB7XHJcbiAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgY2FzZSBVUERBVEVfVVNFUlM6XHJcbiAgICAgIHJldHVybiBhY3Rpb24uZGF0YTtcclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJldHVybiBzdGF0ZSA/IHN0YXRlIDogaW5pdGlhbFN0YXRlO1xyXG4gIH1cclxufTtcclxuIiwiaW1wb3J0IHsgY3JlYXRlU3RvcmUsIGNvbXBvc2UsIGFwcGx5TWlkZGxld2FyZSB9IGZyb20gJ3JlZHV4JztcclxuaW1wb3J0IHRodW5rIGZyb20gJ3JlZHV4LXRodW5rJztcclxuXHJcbmltcG9ydCB7IHJlZHVjZXJzIH0gZnJvbSAnLi4vcmVkdWNlcnMnO1xyXG5cclxuaW1wb3J0IHNlc3Npb25NaWRkbGV3YXJlIGZyb20gJy4uL21pZGRsZXdhcmVzL3Nlc3Npb25NaWRkbGV3YXJlJztcclxuaW1wb3J0IHBsYXliYWNrTWlkZGxld2FyZSBmcm9tICcuLi9taWRkbGV3YXJlcy9wbGF5YmFja01pZGRsZXdhcmUnO1xyXG5pbXBvcnQgZGV2aWNlc01pZGRsZXdhcmUgZnJvbSAnLi4vbWlkZGxld2FyZXMvZGV2aWNlc01pZGRsZXdhcmUnO1xyXG5pbXBvcnQgeyBzb2NrZXRNaWRkbGV3YXJlIH0gZnJvbSAnLi4vbWlkZGxld2FyZXMvc29ja2V0TWlkZGxld2FyZSc7XHJcbmltcG9ydCBsb2dnZXJNaWRkbGV3YXJlIGZyb20gJy4uL21pZGRsZXdhcmVzL2xvZ2dlck1pZGRsZXdhcmUnO1xyXG5pbXBvcnQgc29ja2V0TWlkZGxld2FyZURlZmF1bHQgZnJvbSAnLi4vbWlkZGxld2FyZXMvc29ja2V0TWlkZGxld2FyZSc7XHJcbmltcG9ydCBzZWFyY2hNaWRkbGV3YXJlIGZyb20gJy4uL21pZGRsZXdhcmVzL3NlYXJjaE1pZGRsZXdhcmUnO1xyXG5cclxuaW1wb3J0IHsgbG9hZCB9IGZyb20gJy4uL2FjdGlvbnMvc2Vzc2lvbkFjdGlvbnMnO1xyXG5cclxuZXhwb3J0IGNvbnN0IGluaXRTdG9yZSA9IChpbml0aWFsU3RhdGUgPSB7fSkgPT4ge1xyXG4gIGNvbnN0IHN0b3JlID0gY3JlYXRlU3RvcmUoXHJcbiAgICByZWR1Y2VycygpLFxyXG4gICAgaW5pdGlhbFN0YXRlLFxyXG4gICAgYXBwbHlNaWRkbGV3YXJlKFxyXG4gICAgICB0aHVuayxcclxuICAgICAgc2Vzc2lvbk1pZGRsZXdhcmUsXHJcbiAgICAgIHNvY2tldE1pZGRsZXdhcmUsXHJcbiAgICAgIHBsYXliYWNrTWlkZGxld2FyZSxcclxuICAgICAgZGV2aWNlc01pZGRsZXdhcmUsXHJcbiAgICAgIGxvZ2dlck1pZGRsZXdhcmUsXHJcbiAgICAgIHNlYXJjaE1pZGRsZXdhcmVcclxuICAgIClcclxuICApO1xyXG4gIHNvY2tldE1pZGRsZXdhcmVEZWZhdWx0KHN0b3JlKTtcclxuICBzdG9yZS5kaXNwYXRjaChsb2FkKCkpO1xyXG4gIHJldHVybiBzdG9yZTtcclxufTtcclxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiaXNvbW9ycGhpYy11bmZldGNoXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQtcmVkdXgtd3JhcHBlclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2hlYWRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtaW50bFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1pc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1yZWR1eFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWR1eFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWR1eC10aHVua1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJzb2NrZXQuaW8tY2xpZW50XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInN0eWxlZC1qc3gvc3R5bGVcIik7Il0sInNvdXJjZVJvb3QiOiIifQ==
import css from 'styled-jsx/css';

export default css`.btn--dark {
  background-color: #bbc8d5;
  border: 1px solid #bbc8d5;
  color: #333;
}`;

module.exports = {
  HOST: process.env.HOST
};
